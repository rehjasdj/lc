/* Dark Mode - Schalter. Laeuft bei document_start (vor dem ersten Paint), damit
   die Seite nach Reload/Navigation nicht erst hell aufblitzt und der Modus
   nicht "raus" ist. Gemerkt in chrome.storage.local (lcDark); ein localStorage-
   Spiegel liefert den Wert synchron, bevor der Storage-Callback kommt.
   Das Theme selbst steht in dark.css (echtes Farbschema, kein Invert-Filter).
   Bilder bleiben unangetastet (LO, 28.08.2026).

   Fremde Add-ons (Helium 10, Keepa, Jungle Scout ...) zeichnen ihre Fenster
   in Shadow-Roots - dort gilt Seiten-CSS nicht. Fuer jeden OFFENEN Shadow-Root
   wird darum ein kleines Theme-Blatt eingehaengt. Geschlossene sind unerreichbar. */
(function () {
  if (window.top !== window) return;
  var root = document.documentElement;
  var an = function () { return root.classList.contains('lc-dark'); };

  var SHADOW_CSS = [
    ':host{color-scheme:dark;color:#e6e9eb}',
    '*:not(img):not(svg):not(svg *):not(video):not(canvas):not(iframe):not(input):not(select):not(textarea):not([style*="background-image"]):not([data-lc-surface]){background-color:transparent!important;background-image:none!important;border-color:#33404a!important;color:inherit!important;text-shadow:none!important}',
    '[data-lc-surface]{background-color:#1c242b!important;background-image:none!important;border-color:#33404a!important;color:#e6e9eb!important}',
    'a{color:#7cc7e8!important}',
    'button,input,select,textarea,[role="button"]{background:#232d36!important;color:#e6e9eb!important;border-color:#3b4854!important}',
    '.highcharts-background,.highcharts-plot-background{fill:#1c242b!important}',
    '.highcharts-grid-line,.highcharts-axis-line,.highcharts-tick{stroke:#3b4854!important}',
    '.highcharts-root text{fill:#a3adb5!important}'
  ].join('\n');

  var hell = function (c) {
    var m = String(c || '').match(/rgba?\((\d+)[, ]+(\d+)[, ]+(\d+)(?:[, /]+([\d.]+))?\)/);
    return !!(m && +m[1] >= 235 && +m[2] >= 235 && +m[3] >= 235 && (m[4] == null || +m[4] > 0.5));
  };
  var flaechenMarkieren = function (sr) {
    var ebene = Array.prototype.slice.call(sr.children);
    ebene = ebene.concat.apply(ebene, ebene.map(function (e) { return Array.prototype.slice.call(e.children); }));
    ebene.forEach(function (e) {
      if (e.tagName === 'STYLE' || e.tagName === 'SCRIPT' || e.tagName === 'IMG') return;
      var r = e.getBoundingClientRect();
      if (r.width >= 60 && r.height >= 20 && hell(getComputedStyle(e).backgroundColor)) e.setAttribute('data-lc-surface', '1');
    });
  };
  var shadowTheme = function (host, on) {
    var sr = host.shadowRoot;
    if (!sr) return;
    var st = sr.querySelector('style[data-lc-dark]');
    if (on && !st) {
      try { flaechenMarkieren(sr); } catch (e) { /* egal */ }
      st = document.createElement('style'); st.setAttribute('data-lc-dark', '1'); st.textContent = SHADOW_CSS;
      sr.appendChild(st);
    } else if (!on && st) {
      st.remove();
      Array.prototype.forEach.call(sr.querySelectorAll('[data-lc-surface]'), function (e) { e.removeAttribute('data-lc-surface'); });
    }
    Array.prototype.forEach.call(sr.querySelectorAll('*'), function (e) { if (e.shadowRoot) shadowTheme(e, on); });
  };

  var timer = 0, offen = [];
  var spaeter = function (node) {
    if (node) offen.push(node);
    clearTimeout(timer);
    timer = setTimeout(function () {
      var liste = offen; offen = [];
      if (!liste.length) liste = [document];
      var on = an();
      liste.forEach(function (n) {
        try {
          if (n.nodeType !== 1 && n.nodeType !== 9) return;
          if (n.shadowRoot) shadowTheme(n, on);
          Array.prototype.forEach.call(n.querySelectorAll('*'), function (e) { if (e.shadowRoot) shadowTheme(e, on); });
        } catch (e) { /* egal */ }
      });
    }, 120);
  };

  var set = function (on) {
    root.classList.toggle('lc-dark', !!on);
    try { localStorage.setItem('lcDark', on ? '1' : '0'); } catch (e) { /* egal */ }
    spaeter(null);
  };
  try { if (localStorage.getItem('lcDark') === '1') root.classList.add('lc-dark'); } catch (e) { /* egal */ }
  try {
    chrome.storage.local.get('lcDark', function (d) { set(d && d.lcDark); });
    chrome.storage.onChanged.addListener(function (ch, area) { if (area === 'local' && ch.lcDark) set(ch.lcDark.newValue); });
  } catch (e) { /* kein Storage - hell lassen */ }

  new MutationObserver(function (muts) {
    if (!an()) return;
    muts.forEach(function (m) { Array.prototype.forEach.call(m.addedNodes, function (n) { if (n.nodeType === 1) spaeter(n); }); });
  }).observe(root, { childList: true, subtree: true });
  document.addEventListener('DOMContentLoaded', function () { spaeter(null); });
})();
