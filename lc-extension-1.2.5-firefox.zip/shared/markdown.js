/* Listing Checker - kompakter Markdown-Export fuer ChatGPT & Co.

   Warum: Der eigentliche Arbeitsablauf ist "Keywords holen, eigenes Listing und
   ein Competitor-Listing ziehen, Unrelevantes loeschen, alles mit einem Prompt
   an ChatGPT" (LO, 26.08.2026). Die .xlsx ist dafuer zu schwer - Belegblaetter,
   60 Spalten, Zahlenformate. Hier stehen nur die Felder, die ein Sprachmodell
   zum Schreiben oder Vergleichen eines Listings braucht, als lesbares Markdown.
   Setzt shared/extract.js voraus (globalThis.LC). */
(function () {
  'use strict';

  var LC = globalThis.LC || (typeof window !== 'undefined' ? window.LC : null);
  if (!LC) throw new Error('shared/extract.js muss vor shared/markdown.js geladen werden');

  // Eigene Marken (Deuba-Dach) - alles andere gilt als Wettbewerber.
  var EIGENE = /casaria|monzana|gardebruk|deuba/i;

  var s = function (v) { return v == null ? '' : String(v).replace(/\s+/g, ' ').trim(); };
  var eur = function (p, w) {
    return p == null || p === '' ? '-' : Number(p).toFixed(2).replace('.', ',') + ' ' + (w || 'EUR');
  };
  var cut = function (t, n) { t = s(t); return t.length > n ? t.slice(0, n) + ' …' : t; };
  var cell = function (v) { return s(v).replace(/\|/g, '\\|'); };

  function istEigen(r) {
    return EIGENE.test(s(r.marke)) || /deubaxxl/i.test(s(r.plattform)) ||
      EIGENE.test(s(r.verkaeufer)) || EIGENE.test(s(r.titel).slice(0, 40));
  }

  // A+-Beschreibungen kommen mit <style>/<img>-Resten - fuer ein Sprachmodell nur Ballast.
  var ohneHtml = function (t) {
    return s(String(t == null ? '' : t).replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' '));
  };
  // Amazon-URLs auf /dp/ASIN kuerzen, sonst Tracking-Parameter weg.
  var kurzeUrl = function (u, asin) {
    u = s(u);
    if (/amazon\./i.test(u) && /^[A-Z0-9]{10}$/i.test(asin || '')) return 'https://www.amazon.de/dp/' + String(asin).toUpperCase();
    return u.replace(/[?#].*$/, '');
  };

  function listing(r, i) {
    var out = [];
    out.push('### Listing ' + (i + 1) + ' — ' + s(r.plattform) + ' ' + s(r.produkt_id || r.sku) +
      (istEigen(r) ? '  (EIGENES Listing)' : '  (Wettbewerber)'));
    out.push('- Marke: ' + (s(r.marke) || '-') + (r.ean ? ' · EAN ' + r.ean : '') + (r.sku ? ' · SKU ' + r.sku : ''));
    out.push('- Titel (' + s(r.titel).length + ' Zeichen): ' + s(r.titel));
    if (r.item_highlights) {
      out.push('- Item Highlights (' + s(r.item_highlights).length + ' Zeichen): ' + s(r.item_highlights));
    }
    out.push('- Preis: ' + eur(r.preis, r.waehrung) +
      (r.uvp != null && r.uvp !== '' ? ' (UVP ' + eur(r.uvp, r.waehrung) + ')' : '') +
      (r.buybox ? ' · Buybox: ' + r.buybox : '') +
      (r.verkaeufer ? ' · Verkäufer: ' + s(r.verkaeufer) : ''));
    var meta = [];
    if (r.bewertung) meta.push('Bewertung ' + r.bewertung + (r.anzahl_bewertungen ? ' (' + r.anzahl_bewertungen + ')' : ''));
    if (r.aplus) meta.push('A+: ' + r.aplus);
    if (r.bilder_anzahl != null && r.bilder_anzahl !== '') meta.push(r.bilder_anzahl + ' Bilder');
    if (r.kategorie) meta.push('Kategorie: ' + cut(r.kategorie, 120));
    if (r.bsr_text) meta.push('BSR ' + s(r.bsr_text));
    if (meta.length) out.push('- ' + meta.join(' · '));
    var bullets = [];
    for (var b = 1; b <= 8; b++) if (r['bullet_' + b]) bullets.push(r['bullet_' + b]);
    if (r.bullets_weitere) bullets = bullets.concat(String(r.bullets_weitere).split(' | ').filter(Boolean));
    if (bullets.length) {
      out.push('- Bullets:');
      bullets.forEach(function (x, n) { out.push('  ' + (n + 1) + '. ' + s(x)); });
    }
    var attr = s(r.eigenschaften || r.attribute);
    if (attr) out.push('- Attribute: ' + cut(attr, 1200));
    if (r.beschreibung) out.push('- Beschreibung: ' + cut(ohneHtml(r.beschreibung), 2500));
    if (r.warnungen) out.push('- Warnungen (Tool): ' + s(r.warnungen));
    if (r.url) out.push('- URL: ' + kurzeUrl(r.url, r.produkt_id));
    return out.join('\n');
  }

  /* Eine Zeile je Keyword ueber alle Marktplaetze: max. Demand, beste Position,
     Kaufzahl - dieselbe Verdichtung wie das Blatt "Keyword-Auswertung". */
  function keywords(kw, limit) {
    var map = {};
    (kw || []).forEach(function (k) {
      var n = s(k.keyword).toLowerCase();
      if (!n) return;
      var e = map[n] || (map[n] = { keyword: n, plats: {}, demand: 0, pos: null, verk: 0, med: null, quelle: {} });
      if (k.plattform) e.plats[k.plattform] = 1;
      e.demand = Math.max(e.demand, Number(k.demand_graph_index_0_100) || 0);
      if (k.beste_position != null && k.beste_position !== '') {
        e.pos = e.pos == null ? Number(k.beste_position) : Math.min(e.pos, Number(k.beste_position));
      }
      if (k.serp_gekauft_max) e.verk = Math.max(e.verk, Number(k.serp_gekauft_max) || 0);
      if (k.serp_preis_median != null && k.serp_preis_median !== '') e.med = Number(k.serp_preis_median);
      if (/SERP-Titel|Aehnliche/i.test(s(k.datenquelle))) e.quelle.verwandt = 1;
    });
    var rows = Object.keys(map).map(function (n) { return map[n]; })
      .sort(function (a, b) { return b.demand - a.demand || (a.pos || 99) - (b.pos || 99) || a.keyword.localeCompare(b.keyword); })
      .slice(0, limit);
    if (!rows.length) return '';
    var out = ['| Keyword | Marktplätze | Demand 0-100 | beste Pos. | Verk./Monat (SERP-Spitze) | Preis-Median |',
               '|---|---|---|---|---|---|'];
    rows.forEach(function (e) {
      out.push('| ' + cell(e.keyword) + (e.quelle.verwandt ? ' *' : '') + ' | ' + Object.keys(e.plats).join(', ') + ' | ' + e.demand +
        ' | ' + (e.pos == null ? '' : e.pos) + ' | ' + (e.verk || '') + ' | ' + (e.med == null ? '' : eur(e.med)) + ' |');
    });
    out.push('', '\\* = verwandter Begriff aus Wettbewerber-Titeln / "Ähnliche Suchbegriffe" (nicht nur Autocomplete)');
    return out.join('\n');
  }

  function matches(list) {
    var rows = (list || []).filter(function (m) { return m.preis != null && m.preis !== ''; });
    if (!rows.length) return '';
    var out = ['| Plattform | Titel | Preis | Beleg | URL |', '|---|---|---|---|---|'];
    rows.forEach(function (m) {
      out.push('| ' + cell(m.plattform) + ' | ' + cell(cut(m.titel, 90)) + ' | ' + eur(m.preis, m.waehrung) + ' | ' +
        cell(m.match_bestaetigt === 'ja' ? '✓ ' + (m.match_stufe || '') : (m.match_grund ? '✗ ' + m.match_grund : '')) +
        ' | ' + kurzeUrl(m.url, m.produkt_id) + ' |');
    });
    return out.join('\n');
  }

  function pro(list) {
    if (!list || !list.length) return '';
    return list.map(function (p) {
      var t = ['- **' + s(p.asin) + '**: ' + s(p.urteil || ('Buybox ' + (p.buybox || '?')))];
      if (p.buybox) {
        t.push('  - Buybox: ' + p.buybox + (p.buybox_verkaeufer ? ' (' + p.buybox_verkaeufer + ')' : '') +
          (p.angebot_min != null && p.angebot_min !== '' ? ', Amazon ab ' + eur(p.angebot_min) : ''));
      }
      if (p.wettbewerb) {
        t.push('  - Wettbewerbsfeld:\n' + String(p.wettbewerb).split('\n').map(function (z) { return '    - ' + z; }).join('\n'));
      }
      return t.join('\n');
    }).join('\n');
  }


  /* ------------------------------------------------------------ Skill v4
     Der Arbeitsauftrag steht IN der Datei ("er sollte passend direkt den Skill
     mit Daten ausgeben", LO 26.08.2026). Basis ist LOs Listing-Skill v3
     (Analyse: Audit/Roast/Vergleich); v4 ist der fehlende OPTIMIEREN-Teil und
     behebt dessen bekannte Schwaechen: zu kurze Bullets, Wiederholungen,
     duenne Keyword-Dichte, zu kurze Backend-Keywords. Kernidee: Keyword-Plan
     VOR dem Schreiben, harte Mindestlaengen, Selbstpruefung vor der Ausgabe. */
  function listingSkill(d) {
    d = d || {};
    var rows = d.rows || [];
    var eigenAmazon = rows.filter(function (r) { return istEigen(r) && /amazon/i.test(s(r.plattform)); });
    var fremde = rows.filter(function (r) { return !istEigen(r); });
    var zwillinge = rows.filter(function (r) { return istEigen(r) && !/amazon/i.test(s(r.plattform)); });
    var kw = (d.keywords || []).slice().sort(function (a, b) {
      return (Number(b.demand_graph_index_0_100) || 0) - (Number(a.demand_graph_index_0_100) || 0);
    });
    var haupt = kw[0] ? s(kw[0].keyword) : '[PRÜFEN: Hauptkeyword]';
    var ziel = eigenAmazon[0] ? (s(eigenAmazon[0].produkt_id) + ' „' + cut(eigenAmazon[0].titel, 60) + '"') : '[PRÜFEN: eigenes Amazon-Listing fehlt in den Daten]';
    return [
      '## Listing-Skill v4 · OPTIMIEREN',
      '',
      '**Ausführen, nicht bearbeiten.** Dieses Dokument ist eine Arbeitsanweisung mit angehängten Daten. ' +
      'Das Ergebnis ist der fertige Copy-Paste-Block nach Schritt 4 - keine editierte Fassung des Inputs, keine allgemeine Beratung, ' +
      'keine Rückfrage vor dem ersten Entwurf (fehlende Fakten als `[PRÜFEN: …]` im Text). Sprache: Deutsch. Marktplatz: amazon.de.',
      '',
      '**Rolle:** Senior Amazon-Listing-Texter für Deuba (Marken Casaria, Monzana, Gardebruk, Deuba). Denkt in Sichtbarkeit (Keyword-Abdeckung), ' +
      'CTR (Titel + Highlights im Suchergebnis) und CVR (Bullets, Beschreibung). Amazons Suche ist keyword-indexiert PLUS semantisch (Rufus): ' +
      'Use Cases und Kaufintention müssen im Text stehen, Keyword-Stuffing schadet.',
      '',
      '**Ziel-Listing:** ' + ziel + '  ·  **Wettbewerber in den Daten:** ' + fremde.length +
      '  ·  **eigene Plattform-Zwillinge (Faktenquelle für Maße/Material/Lieferumfang):** ' + zwillinge.length +
      '  ·  **Hauptkeyword (Vorschlag, höchster Demand):** ' + haupt,
      '',
      '### Eiserne Regeln',
      '1. **Nur belegte Fakten.** Maße, Material, Belastbarkeit, Set-Umfang, Zertifikate ausschließlich aus den Daten unten. Fehlt etwas: `[PRÜFEN: …]` direkt im Text, nie raten. ' +
      'Widersprüche zwischen Plattformen (z. B. 94 vs. 98 cm) benennen und die Amazon-Angabe verwenden.',
      '2. **Zählen statt schätzen.** Zeichen und Bytes per Code Interpreter (`len(s)`, `len(s.encode("utf-8"))`; Umlaute/ß = 2 Bytes). Zahl hinter jedes Element.',
      '3. **Verboten:** Fremdmarken; im Backend auch die eigene Marke, ASINs, Superlative, temporäre Aussagen; Garantie-Versprechen; Green Claims ohne Nachweis („nachhaltig", „öko"); ' +
      'Emojis und Sonderzeichen (® nur im Markennamen); ALL CAPS außer Bullet-Anker; Werbewörter („Top", „Bestseller", „Angebot").',
      '4. **Wiederholungsverbot.** Dasselbe Substantiv max. 2× über Titel + Highlights zusammen. Jedes Keyword aus dem Plan steht in genau EINEM Element ' +
      '(Ausnahme Hauptkeyword: Titel + ein Bullet). Kein Bullet wiederholt einen Gedanken eines anderen Bullets oder des Titels.',
      '5. **Dichte-Pflicht** (hier hat v3 versagt): jeder Bullet 200-250 Zeichen und enthält mindestens 2 verschiedene Plan-Keywords, natürlich in Sätzen eingebaut; ' +
      'Highlights 110-125 Zeichen; Backend 230-249 Bytes voll ausgenutzt mit Long-Tail-Phrasen aus 2-4 Wörtern, nicht mit Einzelwörtern; Beschreibung 1000-1500 Zeichen.',
      '6. **Bestand respektieren.** Jedes Element bekommt ein Verdikt BEHALTEN / ANPASSEN / NEU mit einem Satz Begründung. Gutes bleibt, der Rest wird gezielt umgebaut.',
      '',
      '### Ablauf',
      '**Schritt 1 - Inventur (max. 5 Zeilen):** eigenes Amazon-Listing, Wettbewerber, Plattform-Zwillinge, Hauptkeyword (Vorschlag oben; ändern, wenn die Tabelle etwas Besseres zeigt). ' +
      'Welche Fakten liegen vor, welche fehlen (→ `[PRÜFEN]`).',
      '**Schritt 2 - Keyword-Plan (Tabelle, VOR dem Schreiben):** aus der Keyword-Tabelle die Top 25 nach Demand, bei Gleichstand nach Verk./Monat. ' +
      'Irrelevante (anderer Produkttyp, Fremdmarke, Zubehör) aussortieren und in Schritt 4 auflisten. Jedem Keyword genau ein Ziel zuweisen: ' +
      'Titel | Highlights | Bullet 1-5 | Beschreibung | Backend. Keywords mit * (aus Wettbewerber-Titeln / „Ähnliche Suchbegriffe") bevorzugt in Titel, Highlights, Bullet 1-3. ' +
      'Prüfen: Titel + Highlights decken ≥ 6 Keywords, Bullets ≥ 10, Backend den Rest.',
      '**Schritt 3 - Texte schreiben:**',
      '- Titel ≤ 75 Zeichen: Marke + Produkttyp (Hauptkeyword) + 1-2 Schlüsselattribute + Variante. Hauptkeyword so früh wie möglich. Keine Maßketten, keine Keyword-Reihung.',
      '- Item Highlights 110-125 Zeichen: kommagetrennte Phrasen - Material, Maße, Use Cases, Set-Umfang. Ergänzt den Titel, wiederholt ihn nicht.',
      '- 5 Bullets à 200-250 Zeichen: `ANKER: Nutzen + Beleg (Zahl, Material, Zertifikat) + Use Case`. Bullet 1-3 tragen das stärkste Kaufargument und den größten Einwand (mobil sind nur 3 sichtbar). ' +
      'Maße und Lieferumfang explizit. Je Bullet ≥ 2 Plan-Keywords.',
      '- Beschreibung 1000-1500 Zeichen, reiner Text, 3-4 Absätze: Einsatz und Zielgruppe · Material und Konstruktion · Maße und Belastbarkeit · Pflege und Lieferumfang. Plan-Keywords „Beschreibung" natürlich einbauen, keine Bullet-Kopie.',
      '- Backend Search Terms 230-249 Bytes: Plan-Keywords „Backend", kleingeschrieben, nur Leerzeichen als Trenner, Singular ODER Plural, keine Wörter, die schon sichtbar im Listing stehen, keine Vertipper.',
      '**Schritt 4 - Selbstprüfung (als Tabelle ausgeben):** Zeichen/Bytes je Element gegen die Limits · Keyword-Abdeckung Keyword → Element (Ist) · Wiederholungs-Check (Wörter > 2× in Titel + Highlights + Bullets) · ' +
      'Dichte (Plan-Keywords je Bullet, Ziel ≥ 2) · Faktencheck (jede Zahl → Datenquelle). Fällt ein Punkt durch: korrigieren und erneut prüfen, BEVOR ausgegeben wird.',
      '',
      '### Output (genau diese Reihenfolge; Elemente 1-5 je in einem Codeblock, Zahl dahinter)',
      '1. Titel + eine Alternative  2. Item Highlights  3. Bullets 1-5  4. Beschreibung  5. Backend Search Terms  ' +
      '6. Keyword-Plan (Ist-Tabelle)  7. Selbstprüfung  8. Verdikte je Element + drei Dinge, die die Wettbewerber besser machen  9. `[PRÜFEN]`-Liste und aussortierte Keywords mit Grund.',
      '',
      'Modi: Standard = OPTIMIEREN (oben). Sagt der Nutzer „audit", „roast" oder „vergleich", gilt Listing-Skill v3 (Analyse), falls im Chat vorhanden - danach zurück zu OPTIMIEREN.',
      ''
    ].join('\n');
  }

  /* d = { rows, matches, keywords, pro } wie in chrome.storage.
     opts.keywordLimit (Standard 80). */
  function buildMarkdown(d, opts) {
    d = d || {}; opts = opts || {};
    var limit = opts.keywordLimit || 80;
    var out = [];
    out.push('# Listing-Skill v4 + Daten ' + new Date().toISOString().slice(0, 16).replace('T', ' '));
    out.push('');
    out.push(listingSkill(d));
    out.push('# Daten');
    out.push('');
    out.push('Daten aus dem DEUBA Listing Checker. Amazon.de-Regeln seit 27.07.2026: Titel max. 75 Zeichen, ' +
      'Item Highlights max. 125 Zeichen (eigenes Feld unter dem Titel), dazu Bullets und Beschreibung. ' +
      '"EIGENES Listing" = Marke Casaria/Monzana/Gardebruk/Deuba bzw. deubaxxl.de; alles andere sind Wettbewerber. ' +
      'Keywords: "Demand 0-100" ist ein Index aus Autocomplete-Rängen (kein Suchvolumen); "Verk./Monat" ist die von Amazon ' +
      'auf der Suchseite gezeigte Kaufzahl des Spitzenreiters zu diesem Keyword.');
    var rows = d.rows || [];
    if (rows.length) {
      out.push('', '## Listings (' + rows.length + ')', '');
      rows.forEach(function (r, i) { out.push(listing(r, i), ''); });
    }
    var kw = keywords(d.keywords, limit);
    if (kw) out.push('## Keywords (Top ' + limit + ' nach Demand)', '', kw, '');
    var mt = matches(d.matches);
    if (mt) out.push('## Preise auf anderen Plattformen', '', mt, '');
    var pr = pro(d.pro);
    if (pr) out.push('## Buybox-Prüfungen', '', pr, '');
    return out.join('\n');
  }

  LC.buildMarkdown = buildMarkdown;
  LC.listingSkill = listingSkill;
  if (typeof module !== 'undefined' && module.exports) module.exports = { buildMarkdown: buildMarkdown, listingSkill: listingSkill };
})();
