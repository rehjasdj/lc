/* Listing Checker - Plattform-Endpoints (RE'te bzw. oeffentliche JSON-Schnittstellen).
   Oberste Schicht des Extraktors: strukturiertes JSON schlaegt DOM-Selektoren,
   weil es Redesigns ueberlebt und keine Hydration braucht.

   Jeder Endpoint hier ist am 30.07.2026 gegen die Live-Seite geprueft worden.
   Ungeprueftes steht bewusst NICHT drin - lieber eine Luecke als eine Luege.

   Laeuft wie die anderen shared-Module im Addon und in Node (fetch ist in beiden global).
   Setzt shared/extract.js voraus (globalThis.LC). */
(function () {
  'use strict';

  var LC = globalThis.LC || (typeof window !== 'undefined' ? window.LC : null);
  if (!LC) throw new Error('shared/extract.js muss vor shared/api.js geladen werden');

  // ---------------------------------------------------------------- Marktplatz-IDs

  // Amazon: Marketplace-ID je Domain, ohne sie liefert completion.amazon.* nichts Sinnvolles.
  var AMAZON_MID = {
    'amazon.de': 'A1PA6795UKMFR9',
    'amazon.com': 'ATVPDKIKX0DER',
    'amazon.co.uk': 'A1F83G8C2ARO7P',
    'amazon.fr': 'A13V1IB3VIYZZH',
    'amazon.it': 'APJ6JRA9NG5V4',
    'amazon.es': 'A1RKKUPIHCS9HS',
    'amazon.nl': 'A1805IZSGTT6HS'
  };

  // eBay: Site-ID je Domain.
  var EBAY_SID = {
    'ebay.de': 77, 'ebay.com': 0, 'ebay.co.uk': 3,
    'ebay.fr': 71, 'ebay.it': 101, 'ebay.es': 186, 'ebay.nl': 146
  };

  // ---------------------------------------------------------------- Suggest / Keywords

  /* Die Autocomplete-Endpoints sind das, was bei Helium "Magnet" heisst: die Plattform
     verraet selbst, wonach gesucht wird - sortiert nach Popularitaet. Kein Auth, kein
     Seller-Konto. Absolute Suchvolumina gibt es damit nicht, die Reihenfolge ist aber
     ein belastbarer Nachfrage-Proxy. */
  var SUGGEST = {
    // GEPRUEFT: HTTP 200, {"suggestions":[{"value":"..."}]}
    amazon: {
      url: function (prefix, opts) {
        var host = (opts && opts.host) || 'amazon.de';
        var mid = AMAZON_MID[host] || AMAZON_MID['amazon.de'];
        return 'https://completion.' + host + '/api/2017/suggestions' +
          '?prefix=' + encodeURIComponent(prefix) +
          '&alias=aps&mid=' + mid +
          '&lop=' + ((opts && opts.lop) || 'de_DE') +
          '&client-info=amazon-search-ui&site-variant=desktop' +
          '&limit=' + ((opts && opts.limit) || 11);
      },
      parse: function (d) {
        return (d && d.suggestions ? d.suggestions : [])
          .filter(function (s) { return s && s.value; })
          .map(function (s) { return s.value; });
      }
    },

    // GEPRUEFT: HTTP 200, OpenSearch-Format ["prefix",["sug1","sug2",...]]
    // Nicht /sch/ajax/autocomplete - das liefert nur den JS-Bundle-Loader.
    ebay: {
      url: function (prefix, opts) {
        var host = (opts && opts.host) || 'ebay.de';
        var sid = EBAY_SID[host];
        if (sid == null) sid = EBAY_SID['ebay.de'];
        return 'https://autosug.ebay.com/autosug' +
          '?kwd=' + encodeURIComponent(prefix) +
          '&sId=' + sid + '&fmt=osr&maxKw=' + ((opts && opts.limit) || 10);
      },
      parse: function (d) {
        return Array.isArray(d) && Array.isArray(d[1]) ? d[1] : [];
      }
    },

    // GEPRUEFT: HTTP 200, {"original":{...},"keywords":["..."]}
    // Parameter heisst q - userInput/searchTerm quittiert Otto mit 502.
    otto: {
      url: function (prefix) {
        return 'https://www.otto.de/san-squirrel-suggest-api/completion' +
          '?q=' + encodeURIComponent(prefix);
      },
      parse: function (d) {
        var kw = d && d.keywords ? d.keywords : [];
        return kw.map(function (k) { return typeof k === 'string' ? k : (k && (k.term || k.visual)); })
                 .filter(Boolean);
      }
    }

    /* --- Abgeklopft, aber bewusst NICHT als Fetch-Endpoint eingebaut ---

       kaufland: Endpoints existieren und sind per Traffic-Mitschnitt belegt:
         GET /api/search/v1/auto-suggestions?searchValue={q}
         GET /api/home-page/frontend/bff/v1/trendy-search-terms
             ?storefront=de&numberOfSearchTerms=24
       Die alte Route /api/search/v1/search-trends?limit=10 ist nur noch als
       Legacy-Beleg notiert.
       Die 403-Antwort kommt NICHT von Kaufland, sondern von Cloudflare
       (Response-Header: Server: cloudflare, Cf-Mitigated: challenge). Ein
       fetch() aus dem Service-Worker scheitert, weil ihm zwei Dinge fehlen:
       der cf_clearance-Cookie (nur credentials:'include' schickt ihn) und die
       same-origin-Herkunft. Beides hat nur der echte kaufland.de-Tab, der die
       Managed Challenge beim Laden transparent besteht.
       Konsequenz: die API im MAIN-world eines Kaufland-Tabs per
       fetch(url, {credentials:'include'}) rufen (siehe kauflandKeywords in
       background.js). Dann gehen cf_clearance/__cf_bm automatisch mit und der
       Request ist fuer Cloudflare identisch zum App-eigenen - sauberes JSON
       statt DOM-Scraping. Nur der Service-Worker allein kann es nicht.

       bol: liefert 403 auch mit echtem Chrome im sichtbaren Modus, schon beim
       Laden der Startseite. Kein Pfad-Problem, sondern Bot-Schutz vor allem
       anderen. Ebenfalls nur ueber eine echte Nutzersession erreichbar.

       amazon reviews: POST /portal/customer-reviews/ajax/lazy-widgets/stream
         ?asin={asin}&csrf={token}   body: th=1&{hash}=C&scope=reviewsAjax0
       Der CSRF-Token steht in der Produktseite - also nur mit vorherigem
       Seitenabruf nutzbar, nicht standalone.

       deubaxxl: Shopware Store API antwortet 401 "sw-access-key is required".
       Ohne Key aus dem Admin kein Zugang. */
  };

  /* Nur zur Dokumentation und fuer den Addon-Pfad - hier bewusst ohne fetch-Wrapper,
     siehe Begruendung oben. */
  var BROWSER_ONLY = {
    kaufland: {
      suggest: 'https://www.kaufland.de/api/search/v1/auto-suggestions?searchValue={q}',
      trends: 'https://www.kaufland.de/api/home-page/frontend/bff/v1/trendy-search-terms?storefront=de&numberOfSearchTerms=24',
      trendsLegacy: 'https://www.kaufland.de/api/search/v1/search-trends?limit=10'
    },
    amazon: {
      reviews: 'https://www.amazon.de/portal/customer-reviews/ajax/lazy-widgets/stream?asin={asin}&csrf={csrf}'
    }
  };

  // ---------------------------------------------------------------- Abruf

  function sha256Hex(value) {
    var text = String(value == null ? '' : value);
    if (!globalThis.crypto || !globalThis.crypto.subtle || typeof TextEncoder === 'undefined') {
      return Promise.resolve('sha256-nicht-verfuegbar');
    }
    return globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(text))
      .then(function (buffer) {
        return Array.from(new Uint8Array(buffer)).map(function (byte) {
          return byte.toString(16).padStart(2, '0');
        }).join('');
      });
  }

  function fetchJsonWithMeta(url, timeoutMs) {
    var ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = ctl ? setTimeout(function () { ctl.abort(); }, timeoutMs || 12000) : null;
    var responseMeta = null;

    return fetch(url, {
      signal: ctl ? ctl.signal : undefined,
      credentials: 'omit',
      headers: { 'Accept': 'application/json,text/javascript,*/*' }
    }).then(function (res) {
      responseMeta = {
        status: res.status,
        contentType: res.headers.get('content-type') || ''
      };
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.text();
    }).then(function (body) {
      /* eBay liefert bei fmt=json ein JSONP-Paket. fmt=osr nutzen wir zwar,
         aber der Guard kostet nichts und faengt Formatwechsel ab. */
      var t = body.replace(/^\/\*\*\/[\w.$]+\(/, '').replace(/\);?\s*$/, '');
      var data = JSON.parse(t);
      return sha256Hex(body).then(function (hash) {
        return {
          data: data, status: responseMeta.status, contentType: responseMeta.contentType,
          body: body, responseHashSha256: hash
        };
      });
    }).finally(function () {
      if (timer) clearTimeout(timer);
    });
  }

  function fetchJson(url, timeoutMs) {
    return fetchJsonWithMeta(url, timeoutMs).then(function (meta) { return meta.data; });
  }

  var cleanKeyword = function (value) {
    return String(value == null ? '' : value).replace(/\s+/g, ' ').trim().toLowerCase();
  };

  /* Rohantwort-Auszug je API-Abruf. 12 kB x 27 Praefixe x Plattformen haben
     die .xlsx aufgeblaeht; der SHA-256 bleibt der eigentliche Beleg, der
     Auszug nur ein Sichtfenster. */
  var AUSZUG_MAX = 600;

  /* n Aufgaben mit begrenzter Parallelitaet; Ergebnisse in Eingabereihenfolge,
     ein Fehler ergibt null statt den ganzen Lauf zu killen. */
  function mapLimit(items, limit, fn) {
    var out = new Array(items.length), next = 0;
    var worker = function () {
      if (next >= items.length) return Promise.resolve();
      var i = next++;
      return Promise.resolve().then(function () { return fn(items[i], i); })
        .then(function (r) { out[i] = r; }, function () { out[i] = null; })
        .then(worker);
    };
    var n = Math.max(1, Math.min(limit || 1, items.length));
    var workers = [];
    for (var k = 0; k < n; k++) workers.push(worker());
    return Promise.all(workers).then(function () { return out; });
  }

  /* Ein Vorschlag allein ist noch kein Beleg. Diese Variante behaelt deshalb
     die exakte Suchanfrage, den wirklichen Rang in der Antwort, Antwortgroesse,
     Zeitpunkt und reproduzierbare First-Party-URL. Die klassische suggest()-
     Schnittstelle unten bleibt fuer bestehende Aufrufer erhalten. */
  function suggestObservations(platformId, prefix, opts) {
    var cfg = SUGGEST[platformId];
    prefix = String(prefix || '').replace(/\s+/g, ' ').trim();
    if (!cfg || !prefix) return Promise.resolve([]);
    var url = cfg.url(prefix, opts);
    return fetchJsonWithMeta(url, opts && opts.timeout)
      .then(function (meta) {
        var list = (cfg.parse(meta.data) || []).map(cleanKeyword).filter(Boolean);
        var observedAt = new Date().toISOString();
        return list.map(function (keyword, index) {
          return {
            beobachtet_am: observedAt,
            plattform_id: platformId,
            such_prefix: prefix,
            keyword: keyword,
            position: index + 1,
            antwort_anzahl: list.length,
            datenquelle: platformId + ' Autocomplete',
            beleg_url: url,
            abrufart: 'First-Party JSON',
            api_call: {
              abgerufen_am: observedAt,
              request_url: url,
              methode: 'GET',
              http_status: meta.status,
              content_type: meta.contentType,
              antwort_hash_sha256: meta.responseHashSha256,
              antwort_auszug: meta.body.slice(0, AUSZUG_MAX),
              antwort_gekuerzt: meta.body.length > AUSZUG_MAX,
              messwert_typ: 'Autocomplete-Rang',
              einheit: 'Rang in First-Party-Antwort',
              zeitraum: 'Momentaufnahme'
            }
          };
        });
      })
      .catch(function () { return []; });
  }

  /* Keyword-Vorschlaege einer Plattform. Liefert [] statt zu werfen, damit ein
     blockierter Marktplatz nicht den ganzen Durchlauf killt. */
  function suggest(platformId, prefix, opts) {
    return suggestObservations(platformId, prefix, opts).then(function (rows) {
      return rows.map(function (row) { return row.keyword; });
    });
  }

  function hasSuggest(platformId) { return !!SUGGEST[platformId]; }

  /* Keyword-Ernte: Seed um a-z erweitern und einsammeln. Das ist die
     Standardmethode, um aus einer Autocomplete-Box einen Keyword-Pool zu machen.
     Frueher sequenziell mit 350 ms Pause (27 Abrufe = ~15 s je Plattform).
     Die Autocomplete-Endpoints sind aber genau dafuer gebaut, bei JEDEM
     Tastendruck zu antworten - sechs parallele Abrufe sind weniger, als ein
     schnell tippender Nutzer erzeugt. Belege bleiben deterministisch geordnet
     (Seed, dann a..z). */
  function expandObservations(platformId, seed, opts) {
    opts = opts || {};
    var alphabet = opts.alphabet || 'abcdefghijklmnopqrstuvwxyz'.split('');
    var limit = opts.concurrency || 6;
    var done = 0;

    return suggestObservations(platformId, seed, opts).then(function (base) {
      return mapLimit(alphabet, limit, function (c) {
        return suggestObservations(platformId, seed + ' ' + c, opts).then(function (list) {
          done++;
          if (opts.onProgress) opts.onProgress(done, alphabet.length, 0);
          return list;
        });
      }).then(function (lists) {
        var observations = base.slice();
        lists.forEach(function (l) { observations = observations.concat(l || []); });
        return observations;
      });
    });
  }

  function expand(platformId, seed, opts) {
    return expandObservations(platformId, seed, opts).then(function (rows) {
      var seen = Object.create(null), out = [];
      rows.forEach(function (row) {
        var keyword = cleanKeyword(row.keyword);
        if (keyword && !seen[keyword]) { seen[keyword] = 1; out.push(keyword); }
      });
      return out;
    });
  }

  var setSize = function (obj) { return Object.keys(obj || {}).length; };
  var addSet = function (obj, value) { if (value != null && value !== '') obj[String(value)] = 1; };
  var pct = function (part, total) { return total ? Math.round(100 * part / total) : 0; };
  var round1 = function (n) { return Math.round(n * 10) / 10; };
  var avg = function (list) {
    return list.length ? list.reduce(function (a, b) { return a + b; }, 0) / list.length : 0;
  };
  function rankStrength(row) {
    var pos = Math.max(1, Number(row.position) || 1);
    var count = Math.max(pos, Number(row.antwort_anzahl) || pos);
    return count <= 1 ? 100 : 100 * (count - pos) / (count - 1);
  }

  /* Demand Graph: aus den unveraenderten Rohbelegen entstehen vier getrennte
     Aussagen. Rangstaerke, Praefixbreite, Wiederholbarkeit und Marktplatz-
     Konsens bleiben einzeln sichtbar. Confidence misst nur, wie breit der
     Beleg ist; sie wird nie als Suchvolumen ausgegeben. SERP-Messungen werden
     lediglich an die passende Zeile angehaengt und bleiben ebenfalls roh. */
  function aggregateEvidence(evidence, runs, serpMeasurements) {
    evidence = (evidence || []).filter(function (row) { return row && cleanKeyword(row.keyword); });
    runs = runs || [];
    serpMeasurements = serpMeasurements || [];

    var groups = Object.create(null), responseBuckets = Object.create(null);
    var runsByScope = Object.create(null), runById = Object.create(null);
    var marketsByPhrase = Object.create(null), attemptedBySeed = Object.create(null);
    var serpLatest = Object.create(null);

    runs.forEach(function (run) {
      var pid = run.plattform_id || String(run.plattform || '').toLowerCase();
      var seed = cleanKeyword(run.seed), scope = pid + '|' + seed;
      if (run.lauf_id) runById[run.lauf_id] = run;
      (runsByScope[scope] || (runsByScope[scope] = Object.create(null)))[run.lauf_id || scope] = 1;
      addSet(attemptedBySeed[seed] || (attemptedBySeed[seed] = Object.create(null)), pid);
    });

    serpMeasurements.forEach(function (row) {
      var key = (row.plattform_id || String(row.plattform || '').toLowerCase()) + '|' + cleanKeyword(row.keyword);
      if (!serpLatest[key] || String(serpLatest[key].gemessen_am || '') < String(row.gemessen_am || '')) {
        serpLatest[key] = row;
      }
    });

    evidence.forEach(function (row) {
      var pid = row.plattform_id || String(row.plattform || '').toLowerCase();
      var seed = cleanKeyword(row.seed), keyword = cleanKeyword(row.keyword);
      var key = pid + '|' + seed + '|' + keyword;
      var group = groups[key] || (groups[key] = {
        key: key, pid: pid, seed: seed, keyword: keyword,
        plattform: row.plattform || pid, rows: [], prefixes: Object.create(null),
        runIds: Object.create(null), apiCallIds: Object.create(null),
        sources: Object.create(null), urls: Object.create(null)
      });
      group.rows.push(row);
      addSet(group.prefixes, cleanKeyword(row.such_prefix));
      addSet(group.runIds, row.lauf_id);
      addSet(group.apiCallIds, row.api_abruf_id);
      addSet(group.sources, row.datenquelle);
      addSet(group.urls, row.beleg_url);

      var phraseKey = seed + '|' + keyword;
      addSet(marketsByPhrase[phraseKey] || (marketsByPhrase[phraseKey] = Object.create(null)), pid);

      var bucketKey = (row.lauf_id || row.beobachtet_am || '') + '|' + pid + '|' + seed + '|' + cleanKeyword(row.such_prefix);
      var bucket = responseBuckets[bucketKey] || (responseBuckets[bucketKey] = Object.create(null));
      bucket[key] = keyword;
    });

    var neighbors = Object.create(null);
    Object.keys(responseBuckets).forEach(function (bucketKey) {
      var entries = Object.keys(responseBuckets[bucketKey]);
      entries.forEach(function (a) {
        var map = neighbors[a] || (neighbors[a] = Object.create(null));
        entries.forEach(function (b) {
          if (a !== b) map[responseBuckets[bucketKey][b]] = (map[responseBuckets[bucketKey][b]] || 0) + 1;
        });
      });
    });

    var out = Object.keys(groups).map(function (key) {
      var g = groups[key], positions = [], strengths = [], dates = [];
      var scoresByRun = Object.create(null);
      g.rows.forEach(function (row) {
        positions.push(Number(row.position) || 1);
        strengths.push(rankStrength(row));
        if (row.beobachtet_am) dates.push(String(row.beobachtet_am));
        var rid = row.lauf_id || String(row.beobachtet_am || 'unbekannt');
        (scoresByRun[rid] || (scoresByRun[rid] = [])).push(rankStrength(row));
      });
      dates.sort();

      var scopeRuns = runsByScope[g.pid + '|' + g.seed] || Object.create(null);
      var runTotal = Math.max(1, setSize(scopeRuns));
      var runsSeen = Math.max(1, setSize(g.runIds));
      var plannedPrefixes = 1;
      Object.keys(scopeRuns).forEach(function (rid) {
        var run = runById[rid];
        plannedPrefixes = Math.max(plannedPrefixes, Number(run && run.prefixe_gesamt) || 1);
      });

      var phraseKey = g.seed + '|' + g.keyword;
      var phraseMarkets = marketsByPhrase[phraseKey] || Object.create(null);
      var attemptedMarkets = attemptedBySeed[g.seed] || Object.create(null);
      var marketCount = setSize(phraseMarkets), attemptedCount = Math.max(1, setSize(attemptedMarkets));
      var prefixCount = setSize(g.prefixes);
      var rankScore = round1(avg(strengths));
      var prefixScore = pct(prefixCount, plannedPrefixes);
      var persistence = pct(runsSeen, runTotal);
      var consensus = pct(marketCount, attemptedCount);
      var signalScore = Math.round(0.45 * rankScore + 0.20 * prefixScore + 0.20 * persistence + 0.15 * consensus);
      var confidence = Math.round(100 * (
        0.45 * Math.min(1, runsSeen / 3) +
        0.30 * Math.min(1, marketCount / 3) +
        0.25 * Math.min(1, g.rows.length / 6)
      ));
      /* Ein perfekter Rang in nur einem einzigen Lauf darf nicht wie eine
         gesicherte 100 aussehen. Der sichtbare Graph-Index ist deshalb das
         Rohsignal gewichtet mit der separat ausgewiesenen Beleg-Confidence. */
      var graphIndex = Math.round(signalScore * confidence / 100);

      var runSeries = Object.keys(scoresByRun).map(function (rid) {
        var run = runById[rid] || {};
        return { at: run.gestartet_am || rid, value: avg(scoresByRun[rid]) };
      }).sort(function (a, b) { return String(a.at).localeCompare(String(b.at)); });
      var trend = 'neu', trendDelta = '';
      if (runSeries.length >= 2) {
        trendDelta = round1(runSeries[runSeries.length - 1].value - runSeries[runSeries.length - 2].value);
        trend = trendDelta >= 8 ? 'steigend' : (trendDelta <= -8 ? 'fallend' : 'stabil');
      }

      var related = Object.keys(neighbors[key] || {}).sort(function (a, b) {
        return neighbors[key][b] - neighbors[key][a] || a.localeCompare(b);
      }).slice(0, 5).map(function (word) { return word + ' (' + neighbors[key][word] + ')'; }).join(', ');
      var serp = serpLatest[g.pid + '|' + g.keyword] || {};
      var proofSeen = Object.create(null), prefixRankProofs = [];
      g.rows.slice().sort(function (a, b) {
        return String(a.beobachtet_am || '').localeCompare(String(b.beobachtet_am || '')) ||
          String(a.such_prefix || '').localeCompare(String(b.such_prefix || '')) ||
          Number(a.position || 0) - Number(b.position || 0);
      }).forEach(function (row) {
        var proof = String(row.such_prefix || '') + ' -> #' + String(row.position || '?') +
          (row.lauf_id ? ' [' + row.lauf_id + ']' : '');
        if (!proofSeen[proof]) { proofSeen[proof] = 1; prefixRankProofs.push(proof); }
      });

      return {
        gefunden_am: dates[dates.length - 1] || '',
        plattform: g.plattform,
        plattform_id: g.pid,
        seed: g.seed,
        keyword: g.keyword,
        position: Math.min.apply(Math, positions),
        beste_position: Math.min.apply(Math, positions),
        mittlere_position: round1(avg(positions)),
        beobachtungen: g.rows.length,
        praefixe: prefixCount,
        praefix_abdeckung_prozent: prefixScore,
        laeufe: runsSeen,
        lauf_ids: Object.keys(g.runIds).sort().join(', '),
        api_abruf_ids: Object.keys(g.apiCallIds).sort().join(', '),
        prefix_rang_belege: prefixRankProofs.join(' | '),
        autocomplete_beleg_urls: Object.keys(g.urls).sort().join(' | '),
        lauf_persistenz_prozent: persistence,
        marktplatz_konsens: marketCount + '/' + attemptedCount,
        konsens_plattformen: Object.keys(phraseMarkets).join(', '),
        rangstaerke_0_100: rankScore,
        demand_signal_0_100: signalScore,
        demand_graph_index_0_100: graphIndex,
        confidence_0_100: confidence,
        trend: trend,
        trend_delta: trendDelta,
        verwandte_keywords: related,
        serp_gemessen_am: serp.gemessen_am || '',
        serp_lauf_id: serp.lauf_id || '',
        serp_sichtbare_treffer: serp.sichtbare_treffer == null ? '' : serp.sichtbare_treffer,
        serp_gesamt_ergebnis: serp.gesamt_ergebnis == null ? '' : serp.gesamt_ergebnis,
        serp_gesamt_text: serp.gesamt_text || '',
        serp_anzeigen: serp.anzeigen == null ? '' : serp.anzeigen,
        serp_anzeigenquote_prozent: serp.anzeigenquote_prozent == null ? '' : serp.anzeigenquote_prozent,
        serp_preis_min: serp.preis_min == null ? '' : serp.preis_min,
        serp_preis_median: serp.preis_median == null ? '' : serp.preis_median,
        serp_preis_max: serp.preis_max == null ? '' : serp.preis_max,
        serp_gekauft_summe: serp.gekauft_summe == null ? '' : serp.gekauft_summe,
        serp_gekauft_max: serp.gekauft_max == null ? '' : serp.gekauft_max,
        serp_url: serp.beleg_url || '',
        datenquelle: Object.keys(g.sources).join(' + '),
        belegart: 'First-Party-Autocomplete + direkte SERP-Messung; kein modelliertes Suchvolumen',
        search_volume: serp.search_volume == null ? '' : serp.search_volume,
        zeitraum: dates.length ? dates[0].slice(0, 10) + ' bis ' + dates[dates.length - 1].slice(0, 10) : '',
        score_methode: 'Signal = 45% Rangstaerke + 20% Praefixbreite + 20% Persistenz + 15% Marktplatz-Konsens; Demand Graph = Signal x Confidence'
      };
    });

    return out.sort(function (a, b) {
      return b.demand_graph_index_0_100 - a.demand_graph_index_0_100 ||
             b.confidence_0_100 - a.confidence_0_100 ||
             a.keyword.localeCompare(b.keyword);
    });
  }

  LC.api = {
    suggest: suggest,
    suggestObservations: suggestObservations,
    expand: expand,
    expandObservations: expandObservations,
    aggregateEvidence: aggregateEvidence,
    rankStrength: rankStrength,
    hasSuggest: hasSuggest,
    fetchJson: fetchJson,
    fetchJsonWithMeta: fetchJsonWithMeta,
    sha256Hex: sha256Hex,
    mapLimit: mapLimit,
    AUSZUG_MAX: AUSZUG_MAX,
    SUGGEST: SUGGEST,
    BROWSER_ONLY: BROWSER_ONLY,
    AMAZON_MID: AMAZON_MID,
    EBAY_SID: EBAY_SID
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = LC.api;
})();
