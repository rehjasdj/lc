/* Quick View in der Suche (nach DS Amazon Quick View / Helium Xray): BSR mit
   Kategorie (verlinkt auf Amazons Bestseller-Liste), Verkaeufer/FBA, "seit"
   und Variantenzahl an jeder Kachel - ohne Klick.

   Datenquelle: die Produktseite jeder Kachel, same-origin geholt
   (/dp/<ASIN>, mit Cookies), durch shared/extract.js gelesen. Nur sichtbare
   Kacheln (IntersectionObserver), 2 gleichzeitig, >= 400 ms Abstand, max. 60 je
   Seitenaufruf, 6 h Cache (qv:<ASIN>). Captcha -> sofort Stopp.
   Nebenbei wandert jede Messung in den lokalen Verlauf (histSample), so
   entsteht auch fuer Wettbewerber eine Preis/BSR-Kurve.
   Rechte: keine neuen (amazon.de ist freigegeben). Aus-/Einschalter im Kopf. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC || !LC.extract || !LC.amazonPro) return;
  var H = LC.onpage = LC.onpage || {};
  H.serp = H.serp || [];

  var CFG = H.quickview = { GAP: 400, PAR: 2, MAX: 60, TTL: 6 * 60 * 60 * 1000 };
  var ui = null, queue = [], running = 0, fetched = 0, geladen = 0, gesamt = 0;
  var stopped = false, aus = false, ausGelesen = false, lastAt = 0, io = null, headChip = null;
  var bsrs = [];
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  var zahl = function (v) { var n = parseInt(String(v == null ? '' : v).replace(/\D/g, ''), 10); return isFinite(n) && n > 0 ? n : null; };

  // ---- Produktseite lesen ------------------------------------------------
  function lesen(html, asin) {
    var doc = new DOMParser().parseFromString(html, 'text/html');
    if (!doc.getElementById('productTitle')) {
      if (/captcha|automatische Zugriffe|Roboter|validateCaptcha/i.test(html)) throw new Error('captcha');
      return { leer: true, ts: Date.now() };
    }
    var r = LC.extract(doc, location.origin + '/dp/' + asin) || {};
    var bb = LC.amazonPro.buyboxOnPage(doc) || {};
    var kat = clean(r.bsr_kategorie).toLowerCase(), link = '';
    Array.prototype.forEach.call(doc.querySelectorAll('a[href*="/gp/bestsellers/"]'), function (a) {
      var t = clean(a.textContent).replace(/^Siehe Top \d+ in\s+/i, '').toLowerCase();
      if (!link && t && t === kat) link = a.getAttribute('href');
    });
    var seit = '';
    Array.prototype.forEach.call(doc.querySelectorAll('th, span.a-text-bold'), function (n) {
      if (seit || !/Im Angebot .*seit|Date First Available/i.test(n.textContent)) return;
      var v = n.tagName === 'TH' ? n.nextElementSibling : n.nextElementSibling;
      var m = clean(v && v.textContent).match(/(\d{4})/);
      if (m) seit = m[1];
    });
    var vars = {};
    Array.prototype.forEach.call(doc.querySelectorAll('[data-defaultasin]'), function (li) { vars[li.getAttribute('data-defaultasin')] = 1; });
    var bbTxt = ((doc.getElementById('desktop_buybox') || doc.getElementById('buybox') || {}).textContent) || '';
    return {
      bsr: zahl(r.bsr), bsr_kategorie: clean(r.bsr_kategorie), bsr_link: link,
      bsr_unter: zahl(r.bsr_unter), bsr_unter_kategorie: clean(r.bsr_unter_kategorie),
      verkaeufer: clean(bb.verkaeufer || r.verkaeufer), fba: /Versand (?:durch|von) Amazon/i.test(bbTxt),
      buybox: bb.status || '', seit: seit, varianten: Object.keys(vars).length,
      preis: r.preis == null ? null : Number(r.preis), ts: Date.now()
    };
  }

  function holen(asin) {
    return fetch('/dp/' + asin, { credentials: 'same-origin' })
      .then(function (res) { return res.text(); })
      .then(function (html) { return lesen(html, asin); });
  }

  // ---- Chips an der Kachel -----------------------------------------------
  function zeigen(item, d) {
    var t = item.tile, b = item.badges;
    if (!b || b.querySelector('.lc-qv')) return;
    var add = function (c) { c.classList.add('lc-qv'); b.appendChild(c); };
    if (d.leer) { add(ui.chip('Quick View: Seite nicht lesbar', 'mut')); }
    else {
      if (d.bsr) {
        add(ui.chip('<span class="lc-k">BSR</span> ' + ui.nf(d.bsr) + (d.bsr_kategorie ? ' <span class="lc-k">· ' + ui.esc(d.bsr_kategorie) + '</span>' : ''), '',
          (d.bsr_unter ? 'Nr. ' + ui.nf(d.bsr_unter) + ' in ' + d.bsr_unter_kategorie + ' · ' : '') + (d.bsr_link ? 'Bestseller-Liste öffnen' : 'Bestseller-Rang'), d.bsr_link || undefined));
        bsrs.push(d.bsr);
      } else add(ui.chip('<span class="lc-k">BSR</span> –', 'mut', 'kein Bestseller-Rang auf der Produktseite'));
      if (d.verkaeufer) add(ui.chip('<span class="lc-k">Verk.</span> ' + ui.esc(d.verkaeufer) + (d.fba ? ' <span class="lc-k">· FBA</span>' : ''), ui.EIGEN.test(d.verkaeufer) ? 'ok' : 'mut', 'Buybox-Verkäufer' + (d.fba ? ', Versand durch Amazon' : '')));
      else if (d.buybox === 'UNTERDRUECKT') add(ui.chip('Buybox unterdrückt', 'bad'));
      if (d.seit) add(ui.chip('<span class="lc-k">seit</span> ' + ui.esc(d.seit), 'mut', 'Im Angebot seit'));
      if (d.varianten > 1) add(ui.chip(d.varianten + ' <span class="lc-k">Var.</span>', 'mut', d.varianten + ' Varianten'));
    }
    t.setAttribute('data-lc-qv-data', JSON.stringify(d));
    t.dataset.lcQv = 'done';
    geladen++;
    kopf();
  }

  function kopf() {
    if (!headChip) return;
    var txt;
    if (stopped) { headChip.className = 'lc-chip bad'; txt = 'Quick View pausiert – Amazon bremst'; }
    else if (aus) { headChip.className = 'lc-chip mut'; txt = 'Quick View aus'; }
    else {
      headChip.className = 'lc-chip ' + (geladen >= gesamt ? 'ok' : '');
      txt = '<span class="lc-k">Quick View</span> ' + geladen + '/' + gesamt;
      if (bsrs.length >= 3) {
        var s = bsrs.slice().sort(function (a, b) { return a - b; });
        txt += ' <span class="lc-k">· Ø BSR</span> ' + ui.nf(s[Math.floor(s.length / 2)]);
      }
    }
    headChip.innerHTML = txt;
  }

  // ---- Warteschlange -----------------------------------------------------
  function pump() {
    if (stopped || aus) return;
    while (running < CFG.PAR && queue.length) {
      if (fetched >= CFG.MAX) { queue = []; break; }
      var item = queue.shift();
      if (item.tile.dataset.lcQv !== 'pending') continue;
      var wait = Math.max(0, lastAt + CFG.GAP - Date.now());
      lastAt = Date.now() + wait;
      running++; fetched++;
      (function (it, w) {
        setTimeout(function () {
          holen(it.asin).then(function (d) {
            var o = {}; o['qv:' + it.asin] = d;
            chrome.storage.local.set(o);
            zeigen(it, d);
            if (!d.leer && (d.preis != null || d.bsr)) ui.send({ type: 'histSample', asin: it.asin, sample: { preis: d.preis, bsr: d.bsr, buybox: null, anbieter: null, angebot_min: null } });
          }).catch(function (e) {
            it.tile.dataset.lcQv = 'err';
            if (e && e.message === 'captcha') { stopped = true; queue = []; kopf(); }
          }).then(function () { running--; pump(); });
        }, w);
      })(item, wait);
    }
  }

  function anstellen(item) {
    if (item.tile.dataset.lcQv !== 'pending' || queue.indexOf(item) >= 0) return;
    queue.push(item);
    queue.sort(function (a, b) { return a.pos - b.pos; });
    pump();
  }

  function beobachten(item) {
    if (typeof IntersectionObserver !== 'function') return anstellen(item);   // jsdom/alt: sofort
    if (!io) {
      io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (!en.isIntersecting) return;
          io.unobserve(en.target);
          var it = en.target.__lcQv;
          if (it) anstellen(it);
        });
      }, { rootMargin: '300px' });
    }
    item.tile.__lcQv = item;
    io.observe(item.tile);
  }

  // ---- Hook ---------------------------------------------------------------
  H.serp.push(function (ctx) {
    if (document.visibilityState !== 'visible') return;
    ui = ctx.ui;
    var anker = ctx.head.querySelector('.lc-sp');
    headChip = ui.chip('<span class="lc-k">Quick View</span> …', 'mut', 'BSR, Verkäufer und Varianten je Treffer (von der Produktseite gelesen). Klick: aus/an');
    headChip.classList.add('lc-copy');
    headChip.addEventListener('click', function (ev) {
      ev.preventDefault(); ev.stopPropagation();
      aus = !aus;
      chrome.storage.local.set({ qvOff: aus });
      if (!aus) { stopped = false; ctx.tiles.forEach(function (t) { if (t.tile.dataset.lcQv === 'pending') anstellen(t); }); }
      kopf();
    });
    ctx.head.insertBefore(headChip, anker || null);

    var neu = ctx.tiles.filter(function (t) { return !t.tile.dataset.lcQv; });
    gesamt = ctx.tiles.length;
    neu.forEach(function (t) { t.tile.dataset.lcQv = 'pending'; });
    var start = function () {
      if (!neu.length) return kopf();
      var keys = neu.map(function (t) { return 'qv:' + t.asin; });
      ui.storage(keys).then(function (d) {
        neu.forEach(function (t) {
          var c = d['qv:' + t.asin];
          if (c && Date.now() - c.ts < CFG.TTL) zeigen(t, c);
          else if (!aus) beobachten(t);
        });
        kopf();
      }).catch(function () { /* Storage weg - dann eben ohne Cache */ neu.forEach(beobachten); });
    };
    if (ausGelesen) start();
    else ui.storage('qvOff').then(function (d) { aus = !!d.qvOff; ausGelesen = true; start(); }).catch(start);
  });
})();
