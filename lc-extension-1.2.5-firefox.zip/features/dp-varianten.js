/* Varianten-Liste (nach Seller Assistant "Variation Viewer"): alle Kind-ASINs
   mit Auspraegung aus Amazons Twister-JSON im Seitenquelltext
   (dimensionValuesDisplayData, parentAsin, variationDisplayLabels - verifiziert
   27.08.2026), Fallback #twister li[data-asin]. Preise je Variante stehen nicht
   im JSON - dafuer waere je ASIN ein Fetch noetig, bewusst weggelassen.
   Keine Requests, keine Rechte. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };

  function twister() {
    var out = { asins: {}, parent: '', labels: {} };
    var scripts = document.querySelectorAll('script');
    for (var i = 0; i < scripts.length; i++) {
      var t = scripts[i].textContent || '';
      if (t.indexOf('dimensionValuesDisplayData') < 0) continue;
      var m = t.match(/"dimensionValuesDisplayData"\s*:\s*(\{[^{}]*\})/);
      if (m) { try { out.asins = JSON.parse(m[1]); } catch (e) { /* JSON kaputt -> Fallback */ } }
      var p = t.match(/"parentAsin"\s*:\s*"([A-Z0-9]{10})"/); if (p) out.parent = p[1];
      var l = t.match(/"variationDisplayLabels"\s*:\s*(\{[^{}]*\})/);
      if (l) { try { out.labels = JSON.parse(l[1]); } catch (e) { /* egal */ } }
      if (Object.keys(out.asins).length) break;
    }
    if (!Object.keys(out.asins).length) {
      Array.prototype.forEach.call(document.querySelectorAll('#twister li[data-asin], #twister_feature_div li[data-asin]'), function (li) {
        var a = li.getAttribute('data-asin'); if (!a) return;
        out.asins[a] = [clean(li.getAttribute('title') || li.textContent).replace(/^Klicken, um .*? auszuwählen\s*/i, '')];
      });
    }
    return out;
  }

  H.panel.push(function (ctx) {
    var ui = ctx.ui;
    if (!ui || typeof ctx.sec !== 'function') return;
    var tw = twister();
    var asins = Object.keys(tw.asins);
    if (asins.length < 2) return;
    var labels = Object.keys(tw.labels).map(function (k) { return tw.labels[k]; }).join(' / ');
    var box = ctx.sec('Varianten (' + asins.length + ')' + (labels ? ' · ' + labels : ''));
    var cur = String(ctx.asin || '').toUpperCase();
    box.appendChild(ui.el('div', 'lc-k', (tw.parent ? '<div>Parent <span class="lc-mono">' + ui.esc(tw.parent) + '</span></div>' : '') +
      asins.map(function (a) {
        var v = tw.asins[a]; var txt = Array.isArray(v) ? v.join(' · ') : clean(v);
        var ist = a.toUpperCase() === cur;
        return '<div' + (ist ? ' class="a-text-bold lc-ok"' : '') + '><a class="a-link-normal lc-mono" href="/dp/' + ui.esc(a) + '">' + ui.esc(a) + '</a> ' + ui.esc(txt) + (ist ? ' ← diese' : '') + '</div>';
      }).join('')));
    var cp = ui.chip('alle ASINs kopieren', 'mut lc-copy', 'Kind-ASINs zeilenweise in die Zwischenablage');
    cp.addEventListener('click', function () {
      var text = asins.join('\n');
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function () { cp.textContent = 'kopiert ✓'; });
    });
    box.appendChild(cp);
  });
})();
