/* Service Worker: Badge + Batch-Suche + Varianten-Check + EAN-Mapping.
   Alles Schreibende laeuft hier, weil das Popup beim Tab-Oeffnen schliessen
   kann - der Worker arbeitet weiter, Ergebnisse landen in chrome.storage.local. */
'use strict';

/* Chrome laedt background.js als Service Worker -> importScripts.
   Firefox/Zen laedt die geteilten Dateien schon ueber background.scripts
   im Manifest - dort gibt es kein importScripts. */
/* shared/amazon-pro.js gehoert NICHT hierher: es braucht DOMParser, den es im
   Service Worker nicht gibt. Es wird ausschliesslich in den Seitenkontext
   injiziert (siehe inTab). */
if (typeof importScripts === 'function') {
  importScripts('shared/extract.js', 'shared/search.js', 'shared/api.js', 'shared/match.js');
}

/* Der Live-Test wird nur in einer vom Test-Runner erzeugten Kopie aktiviert.
   Der normale Build kann den Diagnoseauftrag weder aus dem Popup noch von
   einer Webseite aus starten. */
var MANIFEST_INFO = chrome.runtime.getManifest ? chrome.runtime.getManifest() : {};
var IST_LIVE_TEST_BUILD = /\[TEST\]$/.test(MANIFEST_INFO.name || '');

// ------------------------------------------------------------------ Badge

function refreshBadge() {
  get(['rows', 'matches']).then(function (d) {
    var n = (d.rows || []).length + (d.matches || []).length;
    chrome.action.setBadgeText({ text: n ? String(n) : '' });
    chrome.action.setBadgeBackgroundColor({ color: '#2f6feb' });
  }).catch(function () {});
}

chrome.runtime.onInstalled.addListener(refreshBadge);
chrome.runtime.onStartup.addListener(refreshBadge);
chrome.storage.onChanged.addListener(function (changes, area) {
  if (area === 'local' && (changes.rows || changes.matches)) refreshBadge();
});

// ------------------------------------------------------------------ Helfer

var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
/* Haerte gegen haengende Seiten-Skripte: executeScript mit async func resolved
   NIE, wenn darin ein fetch ohne Timeout haengen bleibt - der unsichtbare Tab
   bliebe fuer immer offen und der Lauf steckt fest (Review 31.08.). */
var mitTimeout = function (p, ms, was) {
  return Promise.race([p, sleep(ms).then(function () { throw new Error('Timeout: ' + was); })]);
};

function rawGet(keys) {
  return new Promise(function (res) { chrome.storage.local.get(keys, res); });
}
/* Letzter Quota-Fehler, egal aus welcher Schreibkette (schreibKette/histKette/
   diskKette) - viele Aufrufer fangen ihn nur lokal ab und schreiben lediglich
   ins Protokoll (z.B. belegeTreffer). Ohne diese Merkstelle laeuft ein Lauf,
   der an der 10-MB-Quota gescheitert ist, scheinbar sauber durch und
   searchStatus.result zeigt "3 Treffer" statt "Speicher voll" (Review 03.09.). */
var quotaWarnung = '';
/* Abbruch-Flag fuer lange Laeufe (Preisjagd/Keyword-Ernte/Buybox-Pruefung).
   Wird beim Start jedes Laufs zurueckgesetzt, per 'lcAbbruch'-Nachricht
   gesetzt und in den Schleifen der drei Laeufe vor jedem Schritt geprueft. */
var abbruchAngefordert = false;
function rawSet(obj) {
  return new Promise(function (res, rej) {
    chrome.storage.local.set(obj, function () {
      // Ohne diese Pruefung meldet z.B. ein Keyword-Lauf "ok", obwohl der
      // Write an der 10-MB-Quota gescheitert ist (Review 31.08.)
      var e = chrome.runtime.lastError;
      if (e) { quotaWarnung = e.message; rej(new Error(e.message)); } else res();
    });
  });
}

/* ---------------------------------------------------------------- Datenspeicher (OPFS + Spiegel)

   Nutzdaten (Listings, Belege, Verlaeufe, Kalibrierung, Raenge, Watchlist ...)
   liegen im Origin Private File System der Extension
   (navigator.storage.getDirectory): kein 10-MB-Limit wie chrome.storage.local,
   keine Freigabe noetig, aus dem Service Worker immer erreichbar. Jeder
   Schluessel ist eine JSON-Datei; ein neuer BSR-Punkt schreibt nur seine
   Datei und zieht nicht den ganzen Bestand in den Worker-Heap.
   chrome.storage.local behaelt Einstellungen und kurze Caches (lc*, qv:*,
   aod:*, h10:*).

   Der vom Nutzer gewaehlte Ordner (Popup "Datensicherung") ist SPIEGEL, nicht
   fuehrend: dieselben Dateien werden dorthin kopiert, sobald die Freigabe da
   ist. Warum nicht mehr fuehrend (03.09.): die Freigabe eines aus IndexedDB
   geladenen Ordner-Handles gilt nur fuer die laufende Sitzung. Nach jedem
   Worker-Neustart stand queryPermission auf 'prompt', get()/set() scheiterten,
   die Aufrufer fielen still auf chrome.storage.local zurueck - wo die Keys
   nach der Migration nicht mehr lagen: leere Tabelle, "Schaetzer lernt: 1.
   Datenpunkt", und im Ordner kam seit der Migration kein Write mehr an.
   Was der Worker nicht spiegeln kann (keine Freigabe), merkt er sich in
   lcSpiegelDirty/lcSpiegelLoeschen; das Popup holt es beim naechsten Oeffnen
   nach (LC.backup.spiegelSync - dort gibt es die Nutzergeste fuer die
   Freigabe) und importiert umgekehrt Dateien, die nur im Ordner liegen. */
var DISK_SCHEMA_KEY = 'lcDiskSchema';
var DISK_SCHEMA = 3;   // 3 = OPFS fuehrend (2 = Nutzerordner fuehrend, 1 = nur Messreihen)
var DISK_DIR = 'listing-checker-data';
var diskModus = false;
var diskKette = Promise.resolve();
// Handle-Caches (hier deklariert: diskBereit unten nutzt diskVerzeichnis schon
// beim Laden - eine spaetere "var x = null"-Zeile wuerde den Cache leeren)
var opfsDirP = null, diskKeysP = null, spiegelRootP = null;
var DISK_EXAKT = {
  rows: 1, matches: 1, keywords: 1, pro: 1, eanMap: 1,
  watch: 1, compare: 1, sfr: 1,
  keywordEvidence: 1, keywordRuns: 1, keywordSerpMeasurements: 1,
  keywordApiEvidence: 1
};
function istDiskKey(k) {
  return !!DISK_EXAKT[k] || /^(hist:|rank:|rankIndex:|krank:|cal:|backend:|calc:|cmp:|h10sales:|h10child:)/.test(String(k || ''));
}
/* Spiegel-Ordner eingerichtet? (Key lcAutoBackup - Name aus der Zeit, als es
   ein Backup-Toggle war; Popup und dp-watchlist haengen daran.) */
var spiegelAn = false;
chrome.storage.onChanged.addListener(function (ch, area) {
  if (area === 'local' && ch.lcAutoBackup) { spiegelAn = !!ch.lcAutoBackup.newValue; spiegelRootP = null; }
});
/* diskBereit: get()/set() warten darauf. Die Nachricht, die den Worker weckt,
   kam sonst VOR der Initialisierung an und lief ohne Disk - leerer Verlauf
   bzw. Ghost-Kopie in storage.local (Audit 03.09., R3). Einmalige Probe, ob
   OPFS da ist (Chrome 86+, Firefox 111+); ohne OPFS bleibt alles wie frueher
   in chrome.storage.local. */
var diskBereit = (typeof navigator !== 'undefined' && navigator.storage && typeof navigator.storage.getDirectory === 'function'
  ? diskVerzeichnis().then(function () { diskModus = true; })
  : Promise.reject(new Error('navigator.storage.getDirectory fehlt'))
).catch(function (e) {
  diskModus = false;
  console.warn('[Datenspeicher] OPFS nicht verfuegbar, bleibe bei storage.local:', e && e.message);
}).then(function () {
  return rawGet(['lcAutoBackup', DISK_SCHEMA_KEY]).then(function (d) {
    spiegelAn = !!d.lcAutoBackup;
    if (!diskModus || Number(d[DISK_SCHEMA_KEY] || 0) >= DISK_SCHEMA) return;
    /* Schema 3: Umzug in OPFS - genau einmal nach dem Update alle Disk-Keys aus
       storage.local holen. Den Stand des alten Nutzerordners (Schema 2) holt
       spiegelSync beim naechsten Popup-Oeffnen: Dateien nur im Ordner werden
       importiert, danach wird alles ('*') frisch gespiegelt. */
    return diskMigrieren().then(function () {
      var o = {}; o[DISK_SCHEMA_KEY] = DISK_SCHEMA;
      return rawSet(o).then(function () { return spiegelMerken('lcSpiegelDirty', ['*']); });
    });
  });
}).catch(function (e) { console.warn('[Datenspeicher] Initialisierung:', e); });
/* Ghost-Kopien (Direkt-Writes aelterer Module) nachmigrieren - aber nur bei
   Install/Update und Browserstart, nicht bei jedem Aufwachen: diskMigrieren()
   liest dafuer den GESAMTEN storage.local, und der Worker wacht bei jedem
   histSample auf (Audit 03.09., P7). */
function diskMigrierenWennAktiv() {
  diskBereit.then(function () {
    if (diskModus) return diskMigrieren();
  }).catch(function (e) { console.warn('[Datenspeicher] Migration:', e); });
}
chrome.runtime.onInstalled.addListener(diskMigrierenWennAktiv);
chrome.runtime.onStartup.addListener(diskMigrierenWennAktiv);

function diskDateiname(key) {
  var bytes = new TextEncoder().encode(key), bin = '';
  for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
  return 'k-' + btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '') + '.json';
}
/* Dateiname -> Schluessel (Gegenstueck zu diskDateiname). */
function diskKeyAusName(name) {
  var m = /^k-([A-Za-z0-9_-]+)\.json$/.exec(String(name || ''));
  if (!m) return null;
  var b64 = m[1].replace(/-/g, '+').replace(/_/g, '/');
  while (b64.length % 4) b64 += '=';
  try {
    var bin = atob(b64), bytes = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new TextDecoder().decode(bytes);
  } catch (e) { return null; }
}
/* OPFS-Verzeichnis, einmal je Worker-Lebensdauer geoeffnet. */
function diskVerzeichnis() {
  if (!opfsDirP) {
    opfsDirP = navigator.storage.getDirectory()
      .then(function (root) { return root.getDirectoryHandle(DISK_DIR, { create: true }); })
      .catch(function (e) { opfsDirP = null; throw e; });
  }
  return opfsDirP;
}
function diskListe(dir) {
  return new Promise(function (res, rej) {
    var out = [], it = dir.keys();
    (function schritt() {
      it.next().then(function (r) {
        if (r.done) return res(out);
        var k = diskKeyAusName(r.value);
        if (k) out.push(k);
        schritt();
      }).catch(rej);
    })();
  });
}
/* Vorhandene Schluessel als Set - einmal gelistet, danach von diskSet/
   diskRemove gepflegt. Ersetzt den frueheren lcDiskIndex in storage.local
   (ein RMW je Write) und erspart NotFoundErrors: jede Suchseite fragt 60
   hist:-Keys ab, von denen die meisten keine Datei haben. */
function diskKeys() {
  if (!diskKeysP) {
    diskKeysP = diskVerzeichnis().then(diskListe).then(function (ks) { return new Set(ks); })
      .catch(function (e) { diskKeysP = null; throw e; });
  }
  return diskKeysP;
}
function diskLeseKey(dir, key) {
  return dir.getFileHandle(diskDateiname(key)).then(function (fh) { return fh.getFile(); })
    .then(function (f) { return f.text(); }).then(function (txt) { return JSON.parse(txt); })
    .catch(function (e) { if (e && e.name === 'NotFoundError') return undefined; throw e; });
}
function diskSchreibeKey(dir, key, wert) {
  return dir.getFileHandle(diskDateiname(key), { create: true }).then(function (fh) {
    return fh.createWritable().then(function (w) {
      return w.write(JSON.stringify(wert)).then(function () { return w.close(); });
    });
  });
}
function keysArray(keys) {
  if (keys == null) return null;
  if (typeof keys === 'string') return [keys];
  if (Array.isArray(keys)) return keys;
  return Object.keys(keys || {});
}
function diskGet(keys) {
  return Promise.all([diskVerzeichnis(), diskKeys()]).then(function (x) {
    var dir = x[0], vorhanden = x[1], out = {};
    // Nur Keys lesen, die als Datei existieren - und parallel: vorher lief
    // jede Suchseite 60 hist:-Dateien SERIELL durch (Sparklines).
    var ks = keys == null
      ? Array.from(vorhanden)
      : keysArray(keys).filter(function (k) { return istDiskKey(k) && vorhanden.has(k); });
    return Promise.all(ks.map(function (key) {
      return diskLeseKey(dir, key).then(function (v) { if (v !== undefined) out[key] = v; });
    })).then(function () { return out; });
  });
}
/* Alle Keys mit einem Praefix (z.B. 'cal:') - lokal UND auf Disk. Ersetzt das
   get(null) der Content-Scripts: sales.js zog damit bei JEDEM Seitenaufruf den
   kompletten Bestand (keywords 5,7 MB + alle Disk-Dateien) in den Tab. */
function keysMitPrefix(prefixe) {
  var lokal = typeof chrome.storage.local.getKeys === 'function'
    ? chrome.storage.local.getKeys()
    : rawGet(null).then(function (all) { return Object.keys(all || {}); });
  return Promise.all([lokal, diskModus ? diskKeys() : new Set()]).then(function (x) {
    var alle = (x[0] || []).concat(Array.from(x[1] || []));
    return alle.filter(function (k) { return prefixe.some(function (p) { return k.indexOf(p) === 0; }); });
  });
}
function diskSet(obj) {
  var ks = Object.keys(obj || {}).filter(istDiskKey);
  if (!ks.length) return Promise.resolve();
  var op = diskKette.then(function () {
    return Promise.all([diskVerzeichnis(), diskKeys()]).then(function (x) {
      var dir = x[0], vorhanden = x[1];
      return ks.reduce(function (p, key) {
        return p.then(function () { return diskSchreibeKey(dir, key, obj[key]); })
          .then(function () { vorhanden.add(key); });
      }, Promise.resolve());
    }).then(function () {
      /* Lokale Kopie (Altbestand, Direkt-Write) entfernen - beim Lesen
         gewinnt lokal, sie wuerde sonst den frischen OPFS-Stand verdecken. */
      return new Promise(function (res) { chrome.storage.local.remove(ks, function () { void chrome.runtime.lastError; res(); }); });
    }).then(function () {
      diskAenderungMelden(ks);
      spiegelSchreiben(ks, obj);
    });
  });
  /* Ein IO-Fehler darf den aktuellen Write ablehnen, aber nicht die serielle
     Kette dauerhaft vergiften. */
  diskKette = op.catch(function (e) { console.warn('[Datenspeicher] Schreiben:', e); });
  return op;
}

/* ---- Spiegel: Nutzerordner (File System Access, Handle in IndexedDB 'lc-backup') ---- */
function spiegelVerzeichnis() {
  if (!spiegelAn) return Promise.resolve(null);
  if (!spiegelRootP) spiegelRootP = autoBackupIdbGetHandle().catch(function () { return null; });
  return spiegelRootP.then(function (root) {
    if (!root || typeof root.queryPermission !== 'function') return null;
    // Nur wenn die Freigabe schon da ist - im Worker gibt es keine Nutzergeste.
    return root.queryPermission({ mode: 'readwrite' }).then(function (p) {
      return p === 'granted' ? root.getDirectoryHandle(DISK_DIR, { create: true }) : null;
    });
  }).catch(function () { return null; });
}
/* Ausstehende Spiegel-Arbeit merken: lcSpiegelDirty (key -> 1, '*' = alles)
   und lcSpiegelLoeschen (key -> 1). Einziger Schreiber ist der Worker; das
   Popup meldet Erledigtes per lcSpiegelErledigt zurueck - zwischen Lesen und
   Zuruecksetzen geht so nichts verloren. */
var spiegelKette = Promise.resolve();
function spiegelMerken(feld, keys, entfernen) {
  spiegelKette = spiegelKette.then(function () {
    return rawGet(feld).then(function (d) {
      var m = Object.assign({}, d[feld] || {});
      if (entfernen) {
        keys.forEach(function (k) { delete m[k]; });
      } else {
        if (!spiegelAn) return;
        keys.forEach(function (k) { m[k] = 1; });
        if (Object.keys(m).length > 2000) m = { '*': 1 };   // Deckel: dann eben alles
      }
      var o = {}; o[feld] = m; return rawSet(o);
    });
  }).catch(function () { /* Spiegel-Buchhaltung ist nie ein Fehler des Aufrufers */ });
  return spiegelKette;
}
function spiegelSchreiben(ks, obj) {
  if (!spiegelAn) return;
  spiegelVerzeichnis().then(function (dir) {
    if (!dir) throw new Error('keine Freigabe');
    return ks.reduce(function (p, key) {
      return p.then(function () { return diskSchreibeKey(dir, key, obj[key]); });
    }, Promise.resolve());
  }).catch(function () { spiegelMerken('lcSpiegelDirty', ks); });
}
function spiegelLoeschen(ks) {
  if (!spiegelAn) return;
  spiegelVerzeichnis().then(function (dir) {
    if (!dir) throw new Error('keine Freigabe');
    return Promise.all(ks.map(function (k) { return dir.removeEntry(diskDateiname(k)).catch(function () {}); }));
  }).catch(function () { spiegelMerken('lcSpiegelLoeschen', ks); });
}
function diskAenderungMelden(keys) {
  if (keys.indexOf('rows') >= 0 || keys.indexOf('matches') >= 0) refreshBadge();
  try {
    chrome.runtime.sendMessage({ type: 'lcDiskChanged', keys: keys }, function () { void chrome.runtime.lastError; });
    // nur Tabs mit unserem Content-Script (amazon.de) - vorher ging der
    // Broadcast an JEDEN Tab und lief dort ins Leere (lastError)
    chrome.tabs.query({ url: ['*://www.amazon.de/*'] }, function (tabs) {
      if (chrome.runtime.lastError) return;
      (tabs || []).forEach(function (tab) {
        try { chrome.tabs.sendMessage(tab.id, { type: 'lcDiskChanged', keys: keys }, function () { void chrome.runtime.lastError; }); } catch (e) { /* kein Content-Script */ }
      });
    });
  } catch (e) { /* Benachrichtigung ist nur Cache-Invalidierung */ }
}
function diskRemove(keys) {
  var ks = (Array.isArray(keys) ? keys : [keys]).filter(istDiskKey);
  if (!ks.length) return Promise.resolve();
  var op = diskKette.then(function () {
    return Promise.all([diskVerzeichnis(), diskKeys()]).then(function (x) {
      var dir = x[0], vorhanden = x[1];
      return Promise.all(ks.map(function (key) {
        return dir.removeEntry(diskDateiname(key)).catch(function () {}).then(function () { vorhanden.delete(key); });
      }));
    }).then(function () {
      diskAenderungMelden(ks);
      spiegelLoeschen(ks);
    });
  });
  diskKette = op.catch(function (e) { console.warn('[Datenspeicher] Loeschen:', e); });
  return op;
}
function get(keys) {
  return diskBereit.then(function () {
    if (!diskModus) return rawGet(keys);
    // Reine Einstellungs-/Cache-Keys (lcDark, qv:*, aod:*) brauchen keinen
    // OPFS-Zugriff je Aufruf.
    if (keys != null && !keysArray(keys).some(istDiskKey)) return rawGet(keys);
    /* Lokal gewinnt: eine lokale Kopie ist immer die juengere (Direkt-Write
       eines aelteren Moduls, noch nicht migriert) - diskSet raeumt sie weg. */
    return Promise.all([rawGet(keys), diskGet(keys)]).then(function (x) { return Object.assign({}, x[1] || {}, x[0] || {}); });
  });
}
function set(obj) {
  return diskBereit.then(function () {
    if (!diskModus) return rawSet(obj);
    var lokal = {}, disk = {};
    Object.keys(obj || {}).forEach(function (k) { (istDiskKey(k) ? disk : lokal)[k] = obj[k]; });
    return Promise.all([Object.keys(lokal).length ? rawSet(lokal) : Promise.resolve(), diskSet(disk)]).then(function () {});
  });
}

/* Disk-Keys, die (noch) in storage.local liegen, in den OPFS-Store schieben;
   diskSet loescht sie danach lokal. Idempotent - laeuft beim Schema-Wechsel
   sowie bei Install/Update/Browserstart. */
function diskMigrieren() {
  if (!diskModus) return Promise.resolve(0);
  return rawGet(null).then(function (all) {
    var obj = {};
    Object.keys(all || {}).forEach(function (k) { if (istDiskKey(k)) obj[k] = all[k]; });
    // lcDiskIndex (Schema 1/2) wird nicht mehr gefuehrt
    if (all && all.lcDiskIndex) chrome.storage.local.remove('lcDiskIndex', function () { void chrome.runtime.lastError; });
    if (!Object.keys(obj).length) return 0;
    /* Invertierter Rank-Index: Produktseiten lesen danach nur eine ASIN-Datei
       statt aller rank:*-Reihen. Beim ersten Migrieren aus Altbeständen bauen. */
    Object.keys(obj).forEach(function (k) {
      if (k.indexOf('rank:') !== 0 || !obj[k] || !obj[k].asins) return;
      var kw = k.slice(5);
      Object.keys(obj[k].asins).forEach(function (asin) {
        var ik = 'rankIndex:' + asin;
        var idx = obj[ik] || (obj[ik] = {});
        idx[kw] = obj[k].asins[asin];
      });
    });
    return diskSet(obj).then(function () { return Object.keys(obj).length; });
  });
}

/* Alle Read-Modify-Write-Zugriffe auf gemeinsame Keys (rows, eanMap, matches,
   searchStatus) laufen durch EINE Kette. Vorher: belegeTreffer faehrt bis zu
   8 Plattformen parallel, jede ruft saveRows() - zwei lesen denselben Stand,
   der zweite set() ueberschreibt still die Zeile des ersten (Review 31.08.). */
var schreibKette = Promise.resolve();
function seriell(fn) {
  var p = schreibKette.then(fn);
  schreibKette = p.catch(function () { /* Kette lebt weiter */ });
  return p;
}

function setStatus(patch) {
  return seriell(function () {
    return get('searchStatus').then(function (d) {
      var s = Object.assign({}, d.searchStatus || {}, patch);
      return set({ searchStatus: s });
    });
  });
}

/* Startzeile + Status-Reset nur bei ECHTEM (Neu-)Start. Auf Modulebene
   stuende die Zeile bei jedem Aufwachen des Workers im Protokoll (jede
   histSample-Nachricht weckt ihn) und verdraengte den letzten echten Lauf.
   Und searchStatus.running darf einen Neustart nicht ueberleben - sonst
   zeigt das Popup fuer immer "Suche laeuft ..." (Review 31.08.). */
/* MV3 killt den Service Worker auch OHNE Extension-Update/Browser-Neustart -
   ein Lauf mit langen sleep()-Pausen (Google-Sperre, Tab-Wartezeit) haelt ihn
   nicht zuverlaessig wach. onStartup/onInstalled feuern dann NICHT, running
   bleibt fuer immer true und das Popup zeigt ewig "Suche laeuft" (Review
   03.09.). Deshalb zusaetzlich ein Alters-Check, der bei JEDEM Neuladen des
   Skripts laeuft (Modulebene, siehe Aufruf unten) - nicht nur bei den beiden
   Events. 10 Minuten sind grosszuegig ueber dem laengsten realen Lauf. */
var LAUF_STALE_MS = 10 * 60 * 1000;
function staleLaufZuruecksetzen() {
  return get('searchStatus').then(function (d) {
    var s = d.searchStatus;
    if (!s || !s.running) return;
    var alter = s.laeuftSeit ? Date.now() - Date.parse(s.laeuftSeit) : Infinity;
    if (alter > LAUF_STALE_MS) {
      return setStatus({ running: false, current: '', result: 'abgebrochen (Worker-Neustart)', ok: false });
    }
  }).catch(function () { /* Disk nicht freigegeben - Reset beim naechsten Start */ });
}
function startAufraeumen() {
  logLine('Service Worker gestartet — ' + CODE_STAND);
  staleLaufZuruecksetzen();
}
chrome.runtime.onStartup.addListener(startAufraeumen);
chrome.runtime.onInstalled.addListener(startAufraeumen);
// Modulebene: laeuft bei JEDEM Laden des Skripts, auch wenn der Worker nur
// wegen einer Nachricht aufgewacht ist (kein onStartup/onInstalled-Event).
staleLaufZuruecksetzen();

/* ------------------------------------------------------------------ Protokoll

   Warum: Der Ablauf laeuft im Hintergrund und ueber fremde Seiten - wenn eine
   Plattform nichts liefert, war bisher nicht erkennbar, WOMIT gesucht wurde,
   ob eine zweite Stufe ueberhaupt lief und woran ein Treffer gescheitert ist.
   Ohne das bleibt nur Raten. Jede Suchstufe schreibt deshalb eine Zeile.
   Ringpuffer statt unbegrenztem Wachstum - 300 Zeilen decken einen ganzen
   Durchlauf ab, mehr braucht niemand. */
var LOG_MAX = 300;

/* Serialisierte Schreibkette statt Sammelpuffer mit Timer.
   Der erste Entwurf hat Zeilen 120 ms lang gesammelt und dann gebuendelt
   geschrieben - im MV3-Service-Worker ist das unzuverlaessig: der Worker darf
   zwischen zwei Ereignissen jederzeit beendet werden, und dann ist der Puffer
   samt allem, was drinstand, weg. Genau deshalb blieb das Protokoll leer.
   Jede Zeile wird jetzt sofort geschrieben, die Aufrufe haengen aber
   hintereinander in einer Kette - sonst ueberschreiben sich parallele
   get/set-Paare gegenseitig. storage.local ist schnell genug dafuer. */
var logKette = Promise.resolve();

function logLine(text) {
  var t = new Date();
  var zeit = ('0' + t.getHours()).slice(-2) + ':' + ('0' + t.getMinutes()).slice(-2) +
             ':' + ('0' + t.getSeconds()).slice(-2);
  var zeile = zeit + '  ' + text;

  logKette = logKette
    .then(function () { return get('log'); })
    .then(function (d) {
      return set({ log: (d.log || []).concat([zeile]).slice(-LOG_MAX) });
    })
    .catch(function () { /* Protokoll darf den Ablauf nie stoppen */ });
  return logKette;
}

function logReset(was) {
  logKette = logKette
    .then(function () { return set({ log: [] }); })
    .catch(function () { /* egal */ });
  // Codestand in JEDE Kopfzeile: logReset leert das Protokoll, die Startzeile
  // des Workers waere sonst weg - und genau sie beantwortet die Frage, ob
  // ueberhaupt der neue Code laeuft.
  return logLine('=== ' + was + ' ===  [' + CODE_STAND + ']');
}

/* Kennung des geladenen Codestands. Wichtig, weil ein Service Worker NUR beim
   Neuladen der Erweiterung ersetzt wird - popup.html dagegen bei jedem Oeffnen.
   Man sieht also leicht ein neues Aussehen und bekommt trotzdem altes
   Verhalten. Steht diese Zeile nicht im Protokoll, laeuft alter Code. */
var CODE_STAND = '2026-08-26b OnPagePanel+BSR+Verlauf+VollParallel';
// (Die Startzeile schreibt startAufraeumen() bei onStartup/onInstalled - nicht
//  mehr auf Modulebene, sonst spammt jedes Worker-Aufwachen das Protokoll voll.)

/* ASIN<->EAN-Merkliste. Amazon zeigt keine EAN - einmal per EAN-Suche gefunden
   (oder aus der Modellnummer gelesen), muss nie wieder gesucht werden. */
function learnEan(map, key, ean) {
  key = String(key || '').trim();
  ean = String(ean || '').replace(/\D/g, '');
  if (/^0\d{13}$/.test(ean)) ean = ean.slice(1);
  if (key && (/^\d{8}$/.test(ean) || /^\d{12,14}$/.test(ean))) map[key] = ean;
}

/* ------------------------------------------------------------------ Verlauf (Keepa-Ersatz)

   Jede gelesene Amazon-Seite hinterlaesst ein kompaktes Sample unter
   hist:<ASIN>: [ISO-Zeit, Preis, BSR, Buybox-Code, Anbieterzahl, Angebot-min].
   Kein Crawl, kein Timer - nur was der Nutzer ohnehin aufruft (Panel auf der
   Produktseite, Erfassen, Buybox-Check). Dedupe: gleiche Werte innerhalb von
   6 h werden nicht erneut geschrieben, damit Reloads die Reihe nicht fluten.
   Cap 2000 Samples je ASIN. "Alles loeschen" laesst hist:* wie eanMap stehen. */
var HIST_MAX = 2000;
var histKette = Promise.resolve();
var BUYBOX_CODE = { 'ja': 1, 'UNTERDRUECKT': 2, 'nicht verfuegbar': 3 };

var letzteSamples = {};   // asin -> { sig, ts } - siehe Frueh-Ausstieg in recordSample
function recordSample(asin, s) {
  asin = String(asin || '').toUpperCase();
  if (!/^[A-Z0-9]{10}$/.test(asin)) return Promise.resolve();
  var key = 'hist:' + asin;
  var sample = [
    new Date().toISOString(),
    s.preis == null ? null : Math.round(Number(s.preis) * 100) / 100,
    s.bsr == null ? null : Number(s.bsr),
    BUYBOX_CODE[s.buybox] || 0,
    s.anbieter == null ? null : Number(s.anbieter),
    s.angebot_min == null ? null : Math.round(Number(s.angebot_min) * 100) / 100
  ];
  /* Frueh-Ausstieg OHNE Disk-Zugriff: das zuletzt geschriebene Sample je ASIN
     bleibt im Worker-Speicher. Quick View schickt je Kachel ein Sample, eine
     zweite Suche mit denselben ASINs kostete sonst je ASIN Datei-Read + Write
     + Broadcast (Audit 03.09., P4). Stirbt der Worker, ist die Map leer und
     der Pfad unten prueft wie bisher gegen den Speicher. */
  var sig = sample.slice(1, 6).join('|');
  var zuletzt = letzteSamples[asin];
  if (zuletzt && zuletzt.sig === sig && Date.now() - zuletzt.ts < 6 * 3600 * 1000) return histKette;
  histKette = histKette.then(function () { return get(key); }).then(function (d) {
    var list = d[key] || [];
    var last = list[list.length - 1];
    var alterMs = last ? Date.now() - Date.parse(last[0]) : Infinity;
    if (last && alterMs < 6 * 3600 * 1000 &&
        last.slice(1, 6).join('|') === sample.slice(1, 6).join('|')) {   // [6] = Bestand (nachtraeglich), zaehlt nicht als Aenderung
      letzteSamples[asin] = { sig: sig, ts: Date.parse(last[0]) };
      return;
    }
    letzteSamples[asin] = { sig: sig, ts: Date.now() };
    if (last && alterMs < 3600 * 1000) {
      // Max. 1 Messpunkt je Stunde (LO 01.09.): eine offen gelassene Seite
      // (800ms-Poll, Preisflackern) haengt sonst Dutzende Punkte an. Innerhalb
      // der Stunde wird der letzte Punkt AKTUALISIERT; Bestand [6] mitnehmen.
      if (sample[6] == null && last[6] != null) sample[6] = last[6];
      list[list.length - 1] = sample;
    } else {
      list.push(sample);
    }
    var o = {}; o[key] = list.slice(-HIST_MAX);
    return set(o);
  }).catch(function () { /* Verlauf darf nichts blockieren */ });
  return histKette;
}

/* Zentraler Row-Writer: dedupe per URL, EAN-Mapping pflegen und anwenden. */
function saveRows(newRows) {
  newRows.forEach(function (nr) {
    if (nr.plattform === 'Amazon' && nr.produkt_id) {
      recordSample(nr.produkt_id, { preis: nr.preis, bsr: nr.bsr, buybox: nr.buybox });
    }
  });
  // seriell(): siehe schreibKette - 8 parallele Plattform-Schritte duerfen
  // sich hier nicht gegenseitig die Zeilen ueberschreiben
  return seriell(function () {
    return get(['rows', 'eanMap']).then(function (d) {
      var rows = d.rows || [];
      var eanMap = d.eanMap || {};

      newRows.forEach(function (nr) {
        // Aus jeder Zeile mit EAN lernen (eigener Shop liefert SKU+EAN,
        // Amazon-Zeilen mit Modellnummer-EAN liefern ASIN+EAN).
        learnEan(eanMap, nr.produkt_id, nr.ean);
        learnEan(eanMap, nr.sku, nr.ean);
        // Umgekehrt: bekannte EAN in Zeilen ohne EAN eintragen (Amazon).
        if (!nr.ean && nr.produkt_id && eanMap[nr.produkt_id]) {
          nr.ean = eanMap[nr.produkt_id];
          nr.warnungen = String(nr.warnungen || '').split('; ')
            .filter(function (w) { return w && w !== 'keine EAN'; }).join('; ');
        }
        var idx = rows.findIndex(function (r) { return r.url === nr.url; });
        if (idx > -1) rows[idx] = nr; else rows.push(nr);
      });

      return set({ rows: rows, eanMap: eanMap });
    });
  });
}

// ------------------------------------------------------------------ Tab-Maschinerie

function waitForComplete(tabId, timeoutMs) {
  return new Promise(function (resolve) {
    var done = false;
    var finish = function () {
      if (done) return;
      done = true;
      chrome.tabs.onUpdated.removeListener(onUpd);
      resolve();
    };
    var onUpd = function (id, info) {
      if (id === tabId && info.status === 'complete') finish();
    };
    chrome.tabs.onUpdated.addListener(onUpd);
    chrome.tabs.get(tabId, function (t) {
      if (!chrome.runtime.lastError && t && t.status === 'complete') finish();
    });
    setTimeout(finish, timeoutMs || 30000);
  });
}

function closeTab(tabId) {
  return new Promise(function (res) {
    chrome.tabs.remove(tabId, function () {
      void chrome.runtime.lastError; // Tab evtl. schon zu - egal
      res();
    });
  });
}

/* Automatisierte Amazon-Tabs muessen unabhaengig von einem frischen oder
   englisch eingestellten Browser denselben deutschen Katalogtext liefern.
   Sonst sucht der Resolver mit "Side Table" im deutschen Deuba-Shop. */
function amazonProduktUrl(asin, origin) {
  return String(origin || 'https://www.amazon.de').replace(/\/$/, '') +
    '/dp/' + encodeURIComponent(String(asin || '').toUpperCase()) + '?language=de_DE';
}

/* Bereitschaft je Host: statt pauschal 2,5 s "Hydration" zu warten, bis zu
   2,5 s auf das Element pollen, das die Extraktion wirklich braucht - meist
   ist es 200-500 ms nach "complete" da. Bei 20-40 Tabs je Preisjagd war die
   Pauschale allein eine Minute Leerlauf. */
var READY_SELECTORS = [
  [/amazon\./i, '#productTitle, div[data-component-type="s-search-result"], #captchacharacters, #noResultsTitle, .s-no-outline'],
  [/ebay\./i, 'li.s-card, li.s-item, .x-item-title__mainTitle, h1'],
  [/kaufland\./i, 'a[data-testid$="product-tile"], h1'],
  [/otto\./i, 'article[data-qa="reptile-product-tile"], h1'],
  [/bol\.com/i, 'a[href*="/nl/nl/p/"], h1'],
  [/temu\.com/i, 'a[href*="-g-"], [data-type="price"], h1'],
  [/deubaxxl\./i, 'a.vsai-item, .product-box, .product-detail, h1'],
  [/google\./i, '#search h3, #rso, form[action="/search"]'],
  [/guenstiger\./i, 'div.offerListItem, h1'],
  [/geizhals\./i, '.offerlist, h1']
];

function readySelectorFor(url) {
  var host = '';
  try { host = new URL(url).hostname; } catch (e) { /* leer */ }
  for (var i = 0; i < READY_SELECTORS.length; i++) {
    if (READY_SELECTORS[i][0].test(host)) return READY_SELECTORS[i][1];
  }
  return 'h1, main, article';
}

function waitForReady(tabId, selector, maxMs) {
  return chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: function (sel, limit) {
      return new Promise(function (resolve) {
        var t0 = Date.now();
        var tick = function () {
          var hit = false;
          try { hit = !!document.querySelector(sel); } catch (e) { hit = true; }
          if (hit || Date.now() - t0 > limit) return resolve(Date.now() - t0);
          setTimeout(tick, 120);
        };
        tick();
      });
    },
    args: [selector, maxMs]
  }).then(function (frames) { return frames && frames[0] ? frames[0].result : null; })
    .catch(function () { return null; });
}

/* Google bekommt nie zwei Tabs gleichzeitig - die Preisjagd laeuft jetzt je
   Plattform parallel, und parallele Google-Suchen sind der schnellste Weg
   zum Captcha. Eine simple Promise-Kette als Sperre reicht. */
var googleKette = Promise.resolve();
function mitGoogleSperre(fn) {
  var p = googleKette.then(fn, fn);
  googleKette = p.catch(function () { /* Sperre nie blockieren */ });
  return p;
}

/* Wie viele Zielplattformen die Preisjagd gleichzeitig bearbeitet: ALLE.
   Jede Plattform sieht dabei weiterhin nur EINEN Tab nach dem anderen -
   fuer eBay ist es egal, ob nebenan gerade Otto laedt. */
var PARALLEL_PLATTFORMEN = 8;

/* Tab-Bereitschaft: "complete" ODER das erwartete Element ist da - was zuerst
   kommt. Amazon/Otto haengen mit Werbe-Nachladern oft 5-10 s in "loading",
   obwohl Titel und Preis laengst im DOM stehen. Die Abfrage laeuft alle 400 ms
   im Tab; schlaegt executeScript waehrend der Navigation fehl, ist das nur
   "noch nicht", kein Fehler. */
function waitForLoadOrReady(tabId, url, maxMs) {
  var ready = readySelectorFor(url);
  var ende = Date.now() + (maxMs || 30000);
  var fertig = false;   // gewinnt ein Race-Zweig, pollt der andere nicht weiter
  var loop = function () {
    if (fertig || Date.now() > ende) return Promise.resolve(false);
    return waitForReady(tabId, ready, 400).then(function (ms) {
      if (ms != null && ms < 400) return true;
      return sleep(300).then(loop);
    });
  };
  return Promise.race([waitForComplete(tabId, maxMs || 30000), sleep(700).then(loop)])
    .then(function (v) { fertig = true; return v; }, function (e) { fertig = true; throw e; });
}

/* URL in unsichtbarem Tab laden, fn in der Seite ausfuehren, Tab schliessen. */
function inTab(url, fn, args) {
  var tabId = null;
  return new Promise(function (res, rej) {
    chrome.tabs.create({ url: url, active: false }, function (tab) {
      if (chrome.runtime.lastError || !tab) return rej(new Error('Tab konnte nicht geoeffnet werden'));
      res(tab.id);
    });
  }).then(function (id) {
    tabId = id;
    return waitForLoadOrReady(tabId, url, 30000);
  }).then(function () {
    return waitForReady(tabId, readySelectorFor(url), 2500);
  }).then(function () {
    return sleep(300); // kurze Nachfrist fuer nachgeladene Preise
  }).then(function () {
    return chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['shared/extract.js', 'shared/search.js', 'shared/api.js', 'shared/match.js', 'shared/amazon-pro.js']
    });
  }).then(function () {
    return mitTimeout(chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: fn,
      args: args || []
    }), 45000, 'Seiten-Skript ' + url);
  }).then(function (frames) {
    return frames && frames[0] ? frames[0].result : null;
  }).finally(function () {
    if (tabId != null) return closeTab(tabId);
  });
}

// ------------------------------------------------------------------ Batch-Suche / Preisvergleich

/* JEDE Kennung im Suchfeld laeuft zuerst ueber den Deuba-Stammsatz:
   - ASIN: Amazon-Seite einmal lesen (Titel/Marke/EAN), DANN Deuba finden.
     Ein ASIN ist Amazon-intern - auf Kaufland/Otto/Temu sucht er ins Leere.
   - EAN/SKU: direkt im Shop aufloesen (SKU-Suche leitet dort aufs Produkt).
   Erst mit den SHOP-Daten (EAN, kanonischer Titel) suchen die Marktplaetze.
   Gelingt kein Stammsatz, laeuft die klassische Suche - bei Freitext ist das
   der Normalfall, kein Fehler. */
function stammsatzFuerQuery(query, qtype, platforms, opts) {
  var fertig = { platforms: platforms, opts: opts };
  if (opts.perPlatform || !query) return Promise.resolve(fertig);

  var vorab;
  if (qtype === 'asin') {
    vorab = setStatus({ current: 'ASIN ' + query + ' aufloesen' })
      .then(function () {
        return inTab(amazonProduktUrl(query), function () {
          return globalThis.LC.extract(document, location.href);
        });
      })
      .then(function (row) {
        if (!row || !row.titel) return null;
        row.produkt_id = row.produkt_id || query;
        return saveRows([row]).then(function () { return row; });
      })
      .catch(function () { return null; });
  } else if (qtype === 'ean') {
    vorab = Promise.resolve({ ean: query });
  } else {
    /* SKU ODER Produktname: erst als Artikelnummer im Shop versuchen - und den
       Text zugleich als Titel mitgeben. Ist die Eingabe kein SKU, sondern ein
       Produktname ("casaria sonnenliege"), loest ihn AUSSCHLIESSLICH die
       Titel-Eskalation in stammsatz() zum Deuba-Artikel auf. Fehlte der Titel
       (alter Stand), scheiterte die Aufloesung und die Suche fiel auf die
       UNGEPRUEFTE Kachel-Suche zurueck - genau so landeten alle Fremdartikel
       ungefiltert und unmarkiert in der Trefferliste ("es muss der Artikel
       sein"). Mit Titel greift der volle Identitaets-Pfad: Stammsatz aufloesen,
       Kandidaten oeffnen, gegen den echten Artikel belegen -> jeder Treffer
       bekommt eine Match-Stufe, die die Anzeige echt/unsicher/fremd trennen kann. */
    vorab = Promise.resolve({ sku: query, mpn: query, titel: query });
  }

  return vorab.then(function (row) {
    if (!row) return fertig;
    return stammsatz(row).then(function (s) {
      if (!s.master) return fertig;   // kein Deuba-Artikel -> klassische Suche
      var basisAmazon = qtype === 'asin';
      return {
        platforms: platforms.filter(function (p) {
          return p !== 'deubaxxl' && (!basisAmazon || p !== 'amazon');
        }),
        opts: Object.assign({}, opts, {
          perPlatform: true,
          ean: s.master.ean, titel: s.master.titel, marke: s.master.marke,
          mpn: s.master.mpn, sku: s.master.sku,
          herkunft: s.herkunft,
          // Basis deubaxxl: der Shop-Preis ist der Vergleichswert, kein Treffer.
          shopHit: basisAmazon ? s.shopHit : null,
          sourcePreis: opts.sourcePreis != null ? opts.sourcePreis
            : (basisAmazon ? row.preis : s.master.preis),
          sourceLabel: opts.sourceLabel || (basisAmazon ? 'Amazon' : 'deubaxxl')
        })
      };
    });
  });
}

/* Plattformen nacheinander statt parallel: 6 gleichzeitige Suchseiten
   sehen nach Bot aus, und der Rechner bleibt bedienbar.
   opts.sourcePreis/sourceLabel: Vergleichsbasis fuer die Bilanz-Zeile. */
function runBatchSearch(query, qtype, platforms, opts) {
  opts = opts || {};
  logReset('Suche: ' + (query || opts.ean || opts.titel || '?') +
    ' auf ' + (platforms || []).join(', '));
  var collected = [];
  var errors = [];
  var usedQueries = {};
  var urteil = '';
  if (query) usedQueries[query] = 1;

  var step = function (i) {
    if (abbruchAngefordert || i >= platforms.length) return Promise.resolve();
    var pid = platforms[i];

    /* Preisvergleich-Modus: Query je Plattform waehlen - EAN wo die Suche
       EANs versteht, sonst Marke+Titel (Otto, Temu). */
    var qf = opts.perPlatform
      ? globalThis.LC.search.queryFor(pid, opts.ean, opts.titel, opts.marke)
      : { q: query, type: qtype };
    if (!qf) return step(i + 1);
    usedQueries[qf.q] = 1;

    var url = globalThis.LC.search.searchUrl(pid, qf.q, qf.type);

    return setStatus({ current: pid, done: i, total: platforms.length })
      .then(function () {
        // ASIN auf Amazon = direkte Produktseite -> volles Listing extrahieren.
        if (pid === 'amazon' && qf.type === 'asin') {
          return inTab(url, function () {
            return globalThis.LC.extract(document, location.href);
          }).then(function (row) {
            if (row && row.titel) return saveRows([row]);
            errors.push('amazon: ASIN nicht gefunden');
          });
        }
        return inTab(url, function (q, qt) {
          return globalThis.LC.search.extractSearchResults(document, location.href, q, qt, 5);
        }, [qf.q, qf.type]).then(function (hits) {
          if (hits && hits.length) {
            hits.forEach(function (h) { h.gesucht_am = new Date().toISOString(); });
            /* Auch hier pruefen, nicht nur in der Preisjagd: sonst landen ueber
               diesen Weg weiter Hochbeete und Gartenduschen ungeprueft in der
               Trefferliste und sehen aus wie derselbe Artikel. */
            if (opts.perPlatform) {
              var key = globalThis.LC.match.produktSchluessel({
                ean: opts.ean, titel: opts.titel, marke: opts.marke
              });
              hits = globalThis.LC.match.bewerteAlle(key, hits).treffer;
            }
            collected = collected.concat(hits);
          } else {
            errors.push(pid + ': keine Treffer');
          }
        });
      })
      .catch(function (e) {
        errors.push(pid + ': ' + (e && e.message ? e.message.split('\n')[0] : 'Fehler'));
      })
      .then(function () { return step(i + 1); });
  };

  /* Erst die Kennung ueber den Deuba-Stammsatz aufloesen, dann suchen. Im
     Preisvergleich-Modus uebernimmt sammlePreise: gleiche Schleife, aber mit
     Identitaets-Beleg auf der Trefferseite. */
  return stammsatzFuerQuery(query, qtype, platforms, opts).then(function (v) {
    platforms = v.platforms;
    opts = v.opts;
    if (!opts.perPlatform) return step(0);
    if (!platforms.length) return null;

    /* Button-Pfad (Analyse-Panel): opts kommt direkt vom Popup, der Stammsatz
       ist noch nicht beschafft - nachholen. Der Suchfeld-Pfad hat ihn schon
       (opts.herkunft gesetzt). */
    var vorbereitet = opts.herkunft ? Promise.resolve() : stammsatz({
      ean: opts.ean, titel: opts.titel, marke: opts.marke,
      mpn: opts.mpn, sku: opts.sku, produkt_id: opts.produktId
    }).then(function (s) {
      if (s.master) {
        opts.ean = s.master.ean; opts.titel = s.master.titel;
        opts.marke = s.master.marke; opts.mpn = s.master.mpn; opts.sku = s.master.sku;
        opts.herkunft = s.herkunft;
        if (opts.sourceLabel !== 'deubaxxl') opts.shopHit = s.shopHit;
        platforms = platforms.filter(function (p) { return p !== 'deubaxxl'; });
      } else {
        /* KEIN Stammsatz -> KEINE Suche. Mit dem Marktplatz-Titel
           weiterzustreuen sammelt garantiert Fremdartikel ein ("sucht nach
           allem Moeglichen") - das ist schlimmer als eine ehrliche Absage. */
        opts.kein_stammsatz = 'ABBRUCH: Artikel im Deuba-Shop nicht gefunden (' +
          s.versuche.join('; ') + ') - Suche gestoppt, bevor Fremdartikel eingesammelt werden';
      }
    });

    return vorbereitet.then(function () {
      if (opts.kein_stammsatz) {
        urteil = opts.kein_stammsatz;
        return;
      }
      var key = globalThis.LC.match.produktSchluessel({
        ean: opts.ean, titel: opts.titel, marke: opts.marke, mpn: opts.mpn, sku: opts.sku
      });
      return sammlePreise(key, platforms).then(function (pv) {
        var alle = opts.shopHit ? [opts.shopHit].concat(pv.hits) : pv.hits;
        var b = globalThis.LC.match.bewerteAlle(key, alle, opts.sourcePreis);
        collected = b.treffer;               // inkl. Begruendung je Treffer
        urteil = (opts.herkunft ? '[' + opts.herkunft + '] ' : '') + b.urteil;
        errors = errors.concat(pv.fehler);
        Object.keys(pv.queries).forEach(function (q) { usedQueries[q] = 1; });
      });
    });
  }).then(function () {
    // seriell(): matches/eanMap sind dieselben Keys, die saveRows/stammsatz
    // waehrend des Laufs fortschreiben - nicht auf altem Snapshot schreiben
    return seriell(function () {
      return get(['matches', 'eanMap']).then(function (d) {
        var matches = d.matches || [];
        var eanMap = d.eanMap || {};

        // EAN-Suche + Amazon-Treffer mit ASIN -> Mapping lernen.
        var gelernteEan = qtype === 'ean' ? query : (opts.perPlatform ? opts.ean : null);
        if (gelernteEan) {
          collected.forEach(function (h) {
            if (h.plattform === 'Amazon' && /^B0[A-Z0-9]{8}$/i.test(h.produkt_id || '')) {
              learnEan(eanMap, h.produkt_id.toUpperCase(), gelernteEan);
            }
          });
        }

        // Alte Treffer zu denselben Suchbegriffen ersetzen - der neue Stand zaehlt.
        matches = matches.filter(function (m) { return !usedQueries[m.suchbegriff]; });
        matches = matches.concat(collected);
        return set({ matches: matches, eanMap: eanMap });
      });
    });
  }).then(function () {
    // Bilanz: guenstigster Fremd-Treffer vs. unser Preis.
    var result = collected.length + ' Treffer';
    /* Der eigene Webshop ist hier genauso ausgenommen wie im Urteil von
       bewerteAlle(): Amazon rechnet ihn dem Seller nicht an, also darf er
       auch in dieser Kurzbilanz nicht als "guenstigster" erscheinen. */
    var priced = collected.filter(function (h) {
      return h.preis != null && !globalThis.LC.match.istEigenerShop(h);
    }).sort(function (a, b) { return a.preis - b.preis; });
    if (urteil) {
      // Preisvergleich-Modus: nur BELEGTE Treffer duerfen ins Urteil.
      result = urteil;
    } else if (priced.length && opts.sourcePreis != null) {
      var best = priced[0];
      var diff = Math.round((best.preis / opts.sourcePreis - 1) * 100);
      result = 'guenstigster: ' + best.plattform + ' ' +
        best.preis.toFixed(2).replace('.', ',') + ' € (' +
        (opts.sourceLabel || 'unser Preis') + ' ' + opts.sourcePreis.toFixed(2).replace('.', ',') +
        ' €, ' + (diff > 0 ? '+' : '') + diff + '%)' +
        (diff < 0 ? ' - UNTERBOTEN!' : '');
    } else if (priced.length) {
      var b0 = priced[0];
      result = collected.length + ' Treffer, guenstigster: ' + b0.plattform + ' ' +
        b0.preis.toFixed(2).replace('.', ',') + ' €';
    }
    if (errors.length) result += ' | ' + errors.join('; ');
    if (quotaWarnung) { result += ' | SPEICHER VOLL: ' + quotaWarnung; quotaWarnung = ''; }
    if (abbruchAngefordert) result = 'Abgebrochen';
    return setStatus({
      running: false, current: '', done: platforms.length, total: platforms.length,
      result: result, ok: abbruchAngefordert ? false : collected.length > 0
    });
  });
}

// ------------------------------------------------------------------ Deep-Grab

/* Treffer-URL -> volles Listing ins Blatt "Listings". */
function runDeepGrab(url) {
  return inTab(url, function () {
    return globalThis.LC.extract(document, location.href);
  }).then(function (row) {
    if (!row || !row.titel) throw new Error('kein Listing erkannt');
    return saveRows([row]).then(function () { return row; });
  });
}

// ------------------------------------------------------------------ Varianten-Check (A+)

/* Geschwister-ASINs nacheinander laden und pruefen: haben die Varianten A+,
   wo das aktuelle Listing keins hat? Ergebnisse landen als volle Listings
   in rows, die Zusammenfassung im Status. */
function runCheckVariants(asins) {
  var fehlt = [], hat = [], fehler = [];

  var step = function (i) {
    if (i >= asins.length) return Promise.resolve();
    var asin = asins[i];
    return setStatus({ current: 'Variante ' + asin, done: i, total: asins.length })
      .then(function () {
        return inTab(amazonProduktUrl(asin), function () {
          return globalThis.LC.extract(document, location.href);
        });
      })
      .then(function (row) {
        if (!row || !row.titel) { fehler.push(asin); return; }
        (row.aplus === 'KEIN A+' ? fehlt : hat).push(asin);
        return saveRows([row]);
      })
      .catch(function () { fehler.push(asin); })
      .then(function () { return sleep(1500); })
      .then(function () { return step(i + 1); });
  };

  return step(0).then(function () {
    var teile = [];
    if (fehlt.length) teile.push('A+ FEHLT bei: ' + fehlt.join(', '));
    if (hat.length) teile.push(hat.length + ' Variante(n) mit A+');
    if (fehler.length) teile.push(fehler.length + ' nicht ladbar');
    var result = teile.join(' | ') || 'keine Varianten geprueft';
    if (quotaWarnung) { result += ' | SPEICHER VOLL: ' + quotaWarnung; quotaWarnung = ''; }
    return setStatus({
      running: false, current: '', done: asins.length, total: asins.length,
      result: result, ok: !fehlt.length && !fehler.length
    });
  });
}

// ------------------------------------------------------------------ Keyword-Ernte

/* Kauflands Such-API sitzt hinter Cloudflare (Cf-Mitigated: challenge). Ein
   fetch() aus dem Service-Worker bekommt 403, weil ihm der cf_clearance-Cookie
   und die same-origin-Herkunft fehlen. Loesung: den echten kaufland.de-Tab
   (der die Challenge beim Laden transparent besteht) als Absender nutzen und
   die JSON-API dort per same-origin fetch mit credentials:'include' rufen -
   cf_clearance/__cf_bm gehen automatisch mit, der Request ist fuer Cloudflare
   ununterscheidbar vom App-eigenen. So bekommen wir sauberes JSON statt der
   DOM-Vorschlaege aus der Suchbox. Ein Tab pro Seed, Praefixe sequenziell. */
function kauflandKeywords(seed, opts) {
  opts = opts || {};
  var tabId = null;
  var alphabet = opts.tief ? 'abcdefghijklmnopqrstuvwxyz'.split('') : [];
  var prefixes = [seed].concat(alphabet.map(function (c) { return seed + ' ' + c; }));
  var out = [], letzteDiagnose = '';

  var create = new Promise(function (resolve, reject) {
    chrome.tabs.create({ url: 'https://www.kaufland.de/', active: false }, function (tab) {
      if (chrome.runtime.lastError || !tab) return reject(new Error('Kaufland-Tab konnte nicht geoeffnet werden'));
      tabId = tab.id;
      resolve();
    });
  });

  var suggestTemplate = globalThis.LC.api.BROWSER_ONLY.kaufland.suggest;
  var urls = prefixes.map(function (p) { return suggestTemplate.replace('{q}', encodeURIComponent(p)); });

  /* EIN executeScript fuer ALLE Praefixe: frueher 27 Round-Trips Worker->Tab
     mit je 850 ms Pause (= ~25 s je Seed). Die Abrufe laufen jetzt IM Tab,
     vier gleichzeitig - Kauflands eigene Suchbox feuert bei jedem Tastendruck.
     same-origin fetch im Kaufland-Tab: der Tab besitzt cf_clearance,
     credentials:'include' schickt es mit -> Cloudflare laesst durch, exakt wie
     der App-eigene Auto-Suggest-Request. */
  var suggestAll = function () {
    return mitTimeout(chrome.scripting.executeScript({
      target: { tabId: tabId },
      world: 'MAIN',
      func: async function (urls, limit) {
        var results = new Array(urls.length), next = 0;
        var one = async function (url) {
          try {
            var res = await fetch(url, {
              credentials: 'include',
              headers: {
                'accept': 'application/json,text/plain,*/*',
                'accept-language': 'de-DE,de;q=0.9',
                'x-storefront': 'de'
              }
            });
            var body = '';
            try { body = await res.text(); } catch (e) { body = ''; }
            var suggestions = [];
            if (res.ok) {
              try {
                var json = JSON.parse(body);
                var raw = (Array.isArray(json) ? json : null) || json.suggestions ||
                  (json.data && json.data.suggestions) || json.items || json.results || [];
                suggestions = (Array.isArray(raw) ? raw : []).map(function (x) {
                  return typeof x === 'string' ? x
                    : (x && (x.value || x.text || x.term || x.keyword || x.suggestion || x.name || x.title));
                }).filter(Boolean);
              } catch (e) { /* Rohbeleg bleibt im body erhalten */ }
            }
            return { status: res.status, ok: res.ok, body: String(body).slice(0, 20000), suggestions: suggestions };
          } catch (e) {
            return { status: -1, ok: false, error: String((e && e.message) || e), body: '', suggestions: [] };
          }
        };
        var worker = async function () {
          while (next < urls.length) { var i = next++; results[i] = await one(urls[i]); }
        };
        var ws = [];
        for (var k = 0; k < Math.min(limit, urls.length); k++) ws.push(worker());
        await Promise.all(ws);
        return results;
      },
      args: [urls, 4]
    }), 120000, 'Autocomplete-Ernte im Tab')
      .then(function (frames) { return (frames && frames[0] && frames[0].result) || []; });
  };

  var verarbeite = function (results) {
    return Promise.all(prefixes.map(function (prefix, i) {
      var res = results[i];
      var suggestions = (res && res.suggestions) || [];
      var status = res && res.status != null ? res.status : '';
      var url = urls[i];
      if (!suggestions.length) {
        if (res && res.error) letzteDiagnose = 'Kaufland fetch-Fehler: ' + res.error;
        else if (status === 403) letzteDiagnose = 'Kaufland-Wall nicht bestanden (403) - cf_clearance fehlt, Tab-Challenge nicht durchgelaufen';
        else if (res) letzteDiagnose = 'Kaufland ohne Vorschlaege (HTTP ' + status + '): ' + String(res.body || '').slice(0, 300);
      }
      var responseBody = res && res.body ? res.body : JSON.stringify(suggestions);
      return globalThis.LC.api.sha256Hex(responseBody).then(function (hash) {
        return suggestions.map(function (kw, index) {
          var value = String(kw || '').trim().toLowerCase();
          if (!value) return null;
          return {
            beobachtet_am: new Date().toISOString(),
            plattform_id: 'kaufland',
            such_prefix: prefix,
            keyword: value,
            position: index + 1,
            antwort_anzahl: suggestions.length,
            datenquelle: 'Kaufland Auto-Suggest API',
            beleg_url: url,
            abrufart: 'First-Party same-origin fetch (cf_clearance)',
            api_call: {
              abgerufen_am: new Date().toISOString(), request_url: url, methode: 'GET',
              http_status: status,
              content_type: 'application/json', antwort_hash_sha256: hash,
              antwort_auszug: responseBody.slice(0, globalThis.LC.api.AUSZUG_MAX),
              antwort_gekuerzt: responseBody.length > globalThis.LC.api.AUSZUG_MAX,
              messwert_typ: 'Autocomplete-Rang', einheit: 'Rang in First-Party-Antwort',
              zeitraum: 'Momentaufnahme'
            }
          };
        }).filter(Boolean);
      });
    })).then(function (lists) {
      lists.forEach(function (l) { out = out.concat(l); });
    });
  };

  return create.then(function () { return waitForComplete(tabId, 30000); })
    // Cloudflare-Challenge braucht nach "complete" noch einen Moment fuer cf_clearance.
    .then(function () { return sleep(1000); })
    .then(suggestAll)
    .then(verarbeite)
    .then(function () {
      if (!out.length && letzteDiagnose) throw new Error(letzteDiagnose);
      return out;
    })
    .finally(function () { if (tabId != null) return closeTab(tabId); });
}

/* Autocomplete kann nur Phrasen liefern, die den Seed ENTHALTEN: "sonnenliege"
   bringt nie "relaxliege" oder "gartenliege" - genau die Synonyme, unter denen
   die Wettbewerber ranken (LO, 26.08.2026). Die stehen aber in den TITELN der
   Suchergebnisseite zum Seed nebeneinander (live 26.08.2026 amazon.de
   "sonnenliege", 71 Titel: gartenliege 43x, liegestuhl 35x, strandliege 12x,
   relaxliege 10x) und in Amazons Block "Aehnliche Suchbegriffe" am Seitenende.
   Beides lesen; die haeufigsten Substantive werden zweite Seeds fuer die
   Autocomplete-Ernte. Eine Seitenladung, kein Modell, kein bezahlter Dienst. */
var KEIN_BEGRIFF = /^(garten|terrasse|balkon|outdoor|indoor|anzeige|gesponsert|gesponserte|camping|strand|pool|wetterfest|witterungsbestaendig|klappbar|faltbar|tragbar|verstellbar|verstellbare|verstellbarer|verstellbaren|grau|schwarz|weiss|weiß|braun|beige|blau|gruen|grün|rot|natur|anthrazit|farbe|farben|stueck|stück|inkl|inklusive|kissen|polster|dach|zertifiziert|material|holz|metall|stahl|aluminium|kunststoff|polyester|textil|gewebe|belastbar|belastbarkeit|rueckenlehne|rückenlehne|kopfkissen|nackenkissen|kopfstuetze|kopfstütze|seitentasche|position|positionen|einklemmschutz|schnell|quick|premium|hochwertig|robust|stabil|gross|groß|klein|breit|extra|ideal|perfekt|neu|neue|neuer|neues|black|white|chair|lounge|outdoorm)$/;

function kandidatenAusTiteln(seed, titel) {
  var seedWorte = String(seed || '').toLowerCase().split(/\s+/).filter(Boolean);
  var kopf = seedWorte[seedWorte.length - 1] || '';
  // "sonnenliege" -> "liege": Komposita mit demselben Grundwort sind fast immer Synonyme.
  var suffix = kopf.length >= 8 ? kopf.slice(-5) : '';
  var df = Object.create(null);
  (titel || []).forEach(function (t) {
    var toks = String(t).replace(/^gesponserte anzeige\s*[-–·]?\s*/i, '')
      .match(/[A-Za-zÄÖÜäöüß][A-Za-zÄÖÜäöüß-]{4,}/g) || [];
    var seen = Object.create(null);
    toks.forEach(function (w, i) {
      if (i === 0) return;                        // erste Position = Marke
      if (!/^[A-ZÄÖÜ]/.test(w)) return;           // Substantive sind in Titeln grossgeschrieben
      var k = w.toLowerCase().replace(/-$/, '');
      if (seen[k] || KEIN_BEGRIFF.test(k) || seedWorte.indexOf(k) > -1) return;
      seen[k] = 1;
      df[k] = (df[k] || 0) + 1;
    });
  });
  var min = (titel || []).length >= 20 ? 3 : 2;
  return Object.keys(df).filter(function (k) { return df[k] >= min; })
    .map(function (k) { return { begriff: k, titel: df[k], score: df[k] * (suffix && k.slice(-5) === suffix ? 2 : 1) }; })
    .sort(function (a, b) { return b.score - a.score || a.begriff.localeCompare(b.begriff); })
    .slice(0, 6);
}

function verwandteBegriffe(platformId, seed) {
  var url = globalThis.LC.search.searchUrl(platformId, seed, 'sku');
  if (!url) return Promise.resolve({ begriffe: [], aehnlich: [], url: '' });
  return inTab(url, function (query) {
    var hits = globalThis.LC.search.extractSearchResults(document, location.href, query, 'sku', 80) || [];
    var titel = hits.map(function (h) { return String(h.titel || ''); }).filter(Boolean);
    var aehnlich = [];
    /* Live 26.08.2026: die Ueberschrift traegt aria-label="Aehnliche Suchbegriffe
       in <seed>", die Links stecken im GESCHWISTER-Element
       span[data-component-type="text-reformulation-widget"] - also das Widget
       zuerst, sonst der Elternblock der Ueberschrift. */
    var block = document.querySelector('[data-component-type="text-reformulation-widget"]');
    if (!block) {
      var kopf = document.querySelector('[aria-label^="Ähnliche Suchbegriffe"], [aria-label^="Related searches"]');
      block = kopf && kopf.parentElement;
    }
    if (block) {
      Array.prototype.forEach.call(block.querySelectorAll('a'), function (a) {
        var t = String(a.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
        if (t && t.length < 60 && aehnlich.indexOf(t) === -1) aehnlich.push(t);
      });
    }
    return { titel: titel, aehnlich: aehnlich, url: location.href };
  }, [seed]).then(function (r) {
    r = r || {};
    return {
      begriffe: kandidatenAusTiteln(seed, r.titel || []),
      aehnlich: (r.aehnlich || []).slice(0, 8),
      titelAnzahl: (r.titel || []).length,
      url: r.url || url
    };
  }).catch(function () { return { begriffe: [], aehnlich: [], titelAnzahl: 0, url: url }; });
}

/* Direkte Markt-Messung fuer ein bereits gefundenes Keyword. Autocomplete sagt,
   DASS eine Phrase vorgeschlagen wird; die SERP sagt, was den Nutzer dahinter
   wirklich erwartet: sichtbare Produktdichte, Werbedruck und Preisband. Das
   sind Messwerte der First-Party-Seite, kein hochgerechnetes Suchvolumen. */
function keywordSerpMeasurement(platformId, keyword) {
  var url = globalThis.LC.search.searchUrl(platformId, keyword, 'sku');
  if (!url) return Promise.resolve(null);
  return inTab(url, function (pid, query) {
    var hits = globalThis.LC.search.extractSearchResults(document, location.href, query, 'sku', 80) || [];
    var visible = hits.length ? Number(hits[0].treffer_gesamt || hits.length) : 0;
    var ads = hits.filter(function (row) { return row.gesponsert === 'ja'; }).length;
    var prices = hits.map(function (row) { return Number(row.preis); })
      .filter(function (value) { return isFinite(value) && value > 0; })
      .sort(function (a, b) { return a - b; });
    var median = prices.length
      ? (prices.length % 2 ? prices[(prices.length - 1) / 2]
        : (prices[prices.length / 2 - 1] + prices[prices.length / 2]) / 2)
      : null;

    var selectors = [
      '[data-component-type="s-result-info-bar"]', '.s-breadcrumb',
      '.srp-controls__count-heading', '[data-testid*="result-count" i]',
      '[data-test*="result-count" i]', '[class*="resultCount" i]',
      '[class*="result-count" i]', 'main h1'
    ];
    var totalText = '';
    for (var i = 0; i < selectors.length && !totalText; i += 1) {
      var nodes = [];
      try { nodes = Array.from(document.querySelectorAll(selectors[i])); } catch (e) { /* weiter */ }
      for (var j = 0; j < nodes.length; j += 1) {
        var text = String(nodes[j].innerText || nodes[j].textContent || '').replace(/\s+/g, ' ').trim();
        if (/\d/.test(text) && /ergebnis|treffer|produkt|artikel|result/i.test(text)) {
          totalText = text.slice(0, 220); break;
        }
      }
    }
    var nums = (totalText.match(/\d[\d.,\s]*/g) || []).map(function (value) {
      return Number(value.replace(/[^\d]/g, ''));
    }).filter(function (value) { return isFinite(value); });
    var total = nums.length ? Math.max.apply(Math, nums) : null;
    var bodyProbe = String((document.body && document.body.innerText) || '').replace(/\s+/g, ' ').slice(0, 500);
    var blocked = /access denied|temporarily blocked|zugriff verweigert|captcha|ungewoehnliche aktivitaet/i.test(bodyProbe);

    /* Die ECHTE Verkaufszahl, die Amazon selbst neben jeden Treffer schreibt:
       "X+ Mal im letzten Monat gekauft". Sie steht bei jedem gefragten Produkt
       schon in der Suchseite - EIN Aufruf liefert die Monatsverkaeufe der ganzen
       ersten Seite. Kein Proxy, das ist die Zahl. Live 09.08.2026 an amazon.de:
       22 Angaben auf einer Gartenliegen-Seite (1000+, 700+, 500+ ...).
       Nur Amazon rendert das - bei anderen Plattformen bleiben die Felder leer. */
    var vollText = String((document.body && document.body.innerText) || '');
    var mapZahl = function (roh, einheit) {
      var n = parseFloat(String(roh).replace(/\./g, '').replace(',', '.'));
      if (!isFinite(n)) return null;
      if (/Tsd/i.test(einheit || '')) n *= 1000;
      else if (/Mio/i.test(einheit || '')) n *= 1000000;
      return Math.round(n);
    };
    var kauf = [], km;
    var kre = /([\d.,]+)\s*(Tsd\.|Mio\.)?\+?\s*(?:Mal )?im (?:letzten|vergangenen) Monat gekauft/gi;
    while ((km = kre.exec(vollText))) { var kv = mapZahl(km[1], km[2]); if (kv) kauf.push(kv); }

    return {
      gemessen_am: new Date().toISOString(),
      plattform_id: pid,
      keyword: String(query || '').toLowerCase(),
      sichtbare_treffer: visible,
      gesamt_ergebnis: total,
      gesamt_text: totalText,
      anzeigen: ads,
      anzeigenquote_prozent: hits.length ? Math.round(1000 * ads / hits.length) / 10 : 0,
      preis_stichprobe: prices.length,
      preis_min: prices.length ? prices[0] : null,
      preis_median: median == null ? null : Math.round(median * 100) / 100,
      preis_max: prices.length ? prices[prices.length - 1] : null,
      // Echte Monatsverkaeufe der ersten Seite: Summe, Spitzenreiter, Anzahl der
      // Treffer mit Angabe. Die Summe ist das belastbarste Nachfragemass hier.
      gekauft_summe: kauf.length ? kauf.reduce(function (a, b) { return a + b; }, 0) : null,
      gekauft_max: kauf.length ? Math.max.apply(Math, kauf) : null,
      gekauft_treffer: kauf.length,
      beleg_url: location.href,
      blockiert: blocked,
      datenquelle: 'First-Party Suchergebnisseite'
    };
  }, [platformId, keyword]);
}

function topKeywordsForSerp(observations, limit) {
  var groups = Object.create(null);
  (observations || []).forEach(function (row) {
    var keyword = String(row.keyword || '').trim().toLowerCase();
    if (!keyword) return;
    var g = groups[keyword] || (groups[keyword] = { keyword: keyword, best: 999, count: 0 });
    g.best = Math.min(g.best, Number(row.position) || 999);
    g.count += 1;
  });
  return Object.keys(groups).map(function (key) { return groups[key]; })
    .sort(function (a, b) { return a.best - b.best || b.count - a.count || a.keyword.localeCompare(b.keyword); })
    .slice(0, limit).map(function (row) { return row.keyword; });
}

/* Autocomplete-Ernte plus Demand-Graph und direkte SERP-Sensoren. Rohbelege,
   Laeufe und SERP-Messungen bleiben getrennt gespeichert und exportierbar. */
function runKeywords(seeds, platforms, opts) {
  opts = opts || {};
  var evidence = [], runs = [], serpMeasurements = [], apiEvidence = [];
  var errors = [];
  var jobs = [];
  var batchId = 'kw-' + new Date().toISOString().replace(/[^0-9]/g, '') + '-' + Math.random().toString(36).slice(2, 7);

  seeds.forEach(function (s) {
    platforms.forEach(function (p) { jobs.push({ seed: s, plat: p }); });
  });

  var fertig = 0;

  var runJob = function (job, i) {
    if (abbruchAngefordert) return Promise.resolve();
    var platLabel = (globalThis.LC.PLATFORMS.find(function (p) { return p.id === job.plat; }) || {}).label || job.plat;
    var runId = batchId + '-' + job.plat + '-' + i;
    var startedAt = new Date().toISOString();
    var prefixTotal = opts.tief ? 27 : 1;
    var currentObservations = [];
    var runError = '';
    var kannSuggest = globalThis.LC.api.hasSuggest(job.plat);

    return setStatus({ current: platLabel + ': ' + job.seed, done: fertig, total: jobs.length })
      .then(function () {
        // expand() haengt a-z an den Seed - das ist die Standard-Keyword-Ernte.
        // Ohne tiefe Ernte nur der direkte Vorschlag (schnell, fuer einen Schnellcheck).
        if (job.plat === 'kaufland') {
          return kauflandKeywords(job.seed, { tief: !!opts.tief });
        }
        return opts.tief
          ? globalThis.LC.api.expandObservations(job.plat, job.seed, {})
          : globalThis.LC.api.suggestObservations(job.plat, job.seed, {});
      })
      .then(function (list) {
        list = list || [];
        if (opts.verwandt === false) return list;
        /* Zweite Stufe: Synonyme aus den SERP-Titeln und "Aehnliche
           Suchbegriffe" - siehe verwandteBegriffe(). Die Begriffe selbst werden
           Belege (Rang = Haeufigkeit), und jeder laeuft noch einmal durch
           Autocomplete, damit auch "relaxliege klappbar" & Co. auftauchen. */
        return setStatus({ current: platLabel + ': verwandte Begriffe zu "' + job.seed + '"', done: fertig, total: jobs.length })
          .then(function () { return verwandteBegriffe(job.plat, job.seed); })
          .then(function (v) {
            var jetzt = new Date().toISOString();
            logLine(platLabel + ' "' + job.seed + '": ' + v.titelAnzahl + ' SERP-Titel -> verwandt: ' +
              (v.begriffe.map(function (b) { return b.begriff + ' (' + b.titel + 'x)'; }).join(', ') || 'keine') +
              (v.aehnlich.length ? ' | aehnliche Suchbegriffe: ' + v.aehnlich.join(', ') : ''));
            v.begriffe.forEach(function (b, n) {
              list.push({
                beobachtet_am: jetzt, plattform_id: job.plat, such_prefix: job.seed,
                keyword: b.begriff, position: n + 1, antwort_anzahl: v.begriffe.length,
                datenquelle: platLabel + ' SERP-Titel (verwandter Begriff, ' + b.titel + ' von ' + v.titelAnzahl + ' Titeln)',
                beleg_url: v.url, abrufart: 'Titel-Haeufigkeit auf der Suchseite'
              });
            });
            v.aehnlich.forEach(function (phrase, n) {
              list.push({
                beobachtet_am: jetzt, plattform_id: job.plat, such_prefix: job.seed,
                keyword: phrase, position: n + 1, antwort_anzahl: v.aehnlich.length,
                datenquelle: platLabel + ' "Aehnliche Suchbegriffe"',
                beleg_url: v.url, abrufart: 'Block am Ende der Suchseite'
              });
            });
            if (!kannSuggest || !v.begriffe.length) return list;
            // Verwandte Begriffe selbst ernten: die staerksten drei tief (a-z), der Rest direkt.
            return globalThis.LC.api.mapLimit(v.begriffe, 3, function (b, n) {
              return (opts.tief && n < 3)
                ? globalThis.LC.api.expandObservations(job.plat, b.begriff, {})
                : globalThis.LC.api.suggestObservations(job.plat, b.begriff, {});
            }).then(function (lists) {
              lists.forEach(function (l) { list = list.concat(l || []); });
              return list;
            });
          })
          .catch(function () { return list; });
      })
      .then(function (list) {
        if (!list || !list.length) { errors.push(platLabel + '/' + job.seed + ': nichts'); return; }
        var calls = Object.create(null), callIndex = 0;
        currentObservations = list.map(function (row) {
          var apiCall = row.api_call || null;
          var callKey = apiCall ? [apiCall.request_url, apiCall.antwort_hash_sha256].join('|') : '';
          var callRow = callKey && calls[callKey];
          if (apiCall && !callRow) {
            callIndex += 1;
            callRow = calls[callKey] = {
              abruf_id: runId + '-api-' + callIndex,
              batch_id: batchId, lauf_id: runId,
              abgerufen_am: apiCall.abgerufen_am || row.beobachtet_am || new Date().toISOString(),
              plattform: platLabel, plattform_id: job.plat, seed: job.seed,
              such_prefix: row.such_prefix || job.seed,
              messwert_typ: apiCall.messwert_typ || 'Autocomplete-Rang',
              messwert_wert: Number(row.antwort_anzahl) || list.length,
              einheit: apiCall.einheit || 'Rang in First-Party-Antwort',
              zeitraum: apiCall.zeitraum || 'Momentaufnahme',
              methode: apiCall.methode || 'GET', request_url: apiCall.request_url || row.beleg_url || '',
              http_status: apiCall.http_status, content_type: apiCall.content_type || '',
              antwort_hash_sha256: apiCall.antwort_hash_sha256 || '',
              antwort_auszug: apiCall.antwort_auszug || '',
              antwort_gekuerzt: apiCall.antwort_gekuerzt ? 'ja' : 'nein',
              abrufart: row.abrufart || 'First-Party JSON',
              zugaenglichkeit: job.plat === 'kaufland' ? 'nur echter First-Party-UI-Request' : 'oeffentlich ohne Login'
            };
            apiEvidence.push(callRow);
          }
          return {
            beobachtet_am: row.beobachtet_am || new Date().toISOString(),
            lauf_id: runId,
            batch_id: batchId,
            plattform_id: job.plat,
            plattform: platLabel,
            seed: job.seed,
            such_prefix: row.such_prefix || job.seed,
            keyword: String(row.keyword || '').trim().toLowerCase(),
            position: Number(row.position) || 1,
            antwort_anzahl: Number(row.antwort_anzahl) || list.length,
            datenquelle: platLabel + ' Autocomplete' + (job.plat === 'kaufland' ? ' (Browser-UI)' : ''),
            beleg_url: row.beleg_url || '',
            abrufart: row.abrufart || 'First-Party JSON',
            api_abruf_id: callRow ? callRow.abruf_id : ''
          };
        });
        evidence = evidence.concat(currentObservations);

        /* SERP-Messungen: zwei Tabs gleichzeitig statt einer nach dem anderen
           mit 850 ms Pause. */
        var measuredKeywords = topKeywordsForSerp(currentObservations, opts.tief ? 5 : 3);
        return globalThis.LC.api.mapLimit(measuredKeywords, 2, function (kw) {
          return setStatus({ current: platLabel + ' Marktdaten: ' + kw, done: fertig, total: jobs.length })
            .then(function () { return keywordSerpMeasurement(job.plat, kw); })
            .then(function (measurement) {
              if (measurement) {
                measurement.plattform = platLabel;
                measurement.seed = job.seed;
                measurement.lauf_id = runId;
                measurement.batch_id = batchId;
                serpMeasurements.push(measurement);
              }
            })
            .catch(function (e) {
              errors.push(platLabel + '/SERP/' + kw + ': ' + ((e && e.message) || 'Fehler'));
            });
        });
      })
      .catch(function (e) {
        runError = (e && e.message) || 'Fehler';
        errors.push(platLabel + '/' + job.seed + ': ' + runError);
      })
      .then(function () {
        var prefixesSeen = Object.create(null);
        currentObservations.forEach(function (row) { prefixesSeen[row.such_prefix] = 1; });
        runs.push({
          lauf_id: runId, batch_id: batchId, gestartet_am: startedAt,
          beendet_am: new Date().toISOString(), plattform_id: job.plat,
          plattform: platLabel, seed: job.seed, modus: opts.tief ? 'tief' : 'schnell',
          prefixe_gesamt: prefixTotal, prefixe_mit_treffern: Object.keys(prefixesSeen).length,
          beobachtungen: currentObservations.length, status: runError ? 'fehler' : 'ok', fehler: runError
        });
        fertig++;
      });
  };

  /* Plattformen PARALLEL - jede sieht nur ihre eigenen Abrufe -, Seeds je
     Plattform nacheinander. Vorher lief alles hintereinander: drei
     Plattformen x (27 Abrufe + 3-5 SERP-Tabs) = mehrere Minuten. */
  var byPlat = {};
  jobs.forEach(function (job, i) { (byPlat[job.plat] = byPlat[job.plat] || []).push({ job: job, i: i }); });
  var kette = function (list, k) {
    if (k >= list.length) return Promise.resolve();
    return runJob(list[k].job, list[k].i).then(function () { return kette(list, k + 1); });
  };

  return Promise.all(Object.keys(byPlat).map(function (p) { return kette(byPlat[p], 0); })).then(function () {
    // seriell(): sonst liest ein zweiter, gleichzeitig laufender Keyword-Auftrag
    // (z.B. der isolierte Live-Test) denselben alten Stand und ueberschreibt
    // beim eigenen set() still die gerade erst gespeicherten Belege des ersten
    // Laufs - derselbe Bug, den saveRows() fuer rows/eanMap schon behebt (Review 03.09.).
    return seriell(function () {
      return get(['keywordEvidence', 'keywordRuns', 'keywordSerpMeasurements', 'keywordApiEvidence']).then(function (d) {
        var allEvidence = (d.keywordEvidence || []).concat(evidence).slice(-30000);
        var allRuns = (d.keywordRuns || []).concat(runs).slice(-1000);
        var allSerp = (d.keywordSerpMeasurements || []).concat(serpMeasurements).slice(-5000);
        var allApiEvidence = (d.keywordApiEvidence || []).concat(apiEvidence).slice(-10000);
        var keywords = globalThis.LC.api.aggregateEvidence(allEvidence, allRuns, allSerp);
        return set({
          keywords: keywords, keywordEvidence: allEvidence,
          keywordRuns: allRuns, keywordSerpMeasurements: allSerp,
          keywordApiEvidence: allApiEvidence
        });
      });
    });
  }).then(function () {
    var res = evidence.length + ' Belege + ' + apiEvidence.length + ' API-Abrufe + ' +
      serpMeasurements.length + ' direkte Marktmessungen';
    if (errors.length) res += ' | ' + errors.join('; ');
    if (quotaWarnung) { res += ' | SPEICHER VOLL: ' + quotaWarnung; quotaWarnung = ''; }
    if (abbruchAngefordert) res = 'Abgebrochen';
    return setStatus({
      running: false, current: '', done: jobs.length, total: jobs.length,
      result: res, ok: abbruchAngefordert ? false : evidence.length > 0
    });
  });
}

// ------------------------------------------------------------------ Stammsatz aus dem eigenen Shop

/* ERSTER SCHRITT JEDER PREISJAGD - ohne Ergebnis wird NICHT weitergesucht.
   Grund: Der Amazon-Titel ist seit dem Titel-Update vom 27.07.2026 bewusst
   generisch ("Garten Beistelltisch FSC-Zertifiziert Wetterfest"). Als Suchtext
   auf fremden Plattformen liefert er Hochbeete und Gartenduschen. Nur der
   eigene Shop hat Artikelnummer, EAN UND den Titel, unter dem derselbe Artikel
   auch auf den Marktplaetzen steht.

   Reihenfolge der Kandidaten nach Beweiskraft: EAN, dann Modellnummer/MPN,
   dann SKU. Jeder Fund wird gegengeprueft - ein Shop-Treffer, dessen EAN oder
   Artikelnummer nicht passt, ist KEIN Stammsatz. Lieber abbrechen als mit dem
   falschen Artikel weiterrechnen. */
function findeDeubaArtikel(kandidaten) {
  var versuche = [];

  var step = function (i) {
    if (i >= kandidaten.length) return Promise.resolve(null);
    var k = kandidaten[i];
    if (!k || !k.wert) return step(i + 1);

    var typ = globalThis.LC.search.detectQueryType(k.wert);
    var url = globalThis.LC.search.searchUrl('deubaxxl', k.wert, typ);

    return setStatus({ current: 'Shop-Artikel ueber ' + k.label + ' ' + k.wert })
      .then(function () {
        return inTab(url, function (q, qt) {
          return {
            row: globalThis.LC.extract(document, location.href),
            hits: globalThis.LC.search.extractSearchResults(document, location.href, q, qt, 5),
            href: location.href
          };
        }, [k.wert, typ]);
      })
      .then(function (res) {
        var r = res && res.row;
        /* Suchseite = Pfad /search. NICHT ?vsaisearch= mitmatchen: das
           Vision-AI-Widget haengt diesen Parameter an die PRODUKTSEITE an,
           auf die es bei exakter SKU direkt umleitet (live 05.08.2026,
           /schubkarre-.../108751/?vsaisearch=108751) - der alte Check
           verwarf genau diese Treffer als "noch auf der Suchseite". */
        var aufSuchseite = /\/search([?/]|$)/i.test((res && res.href) || '');

        /* Die SKU-Suche leitet direkt auf die Produktseite um - dann steht hier
           bereits der volle Artikel. Bleiben wir auf der Suchseite, kann das
           Overlay trotzdem GENAU EINEN Kandidaten zeigen (Screenshot-Fall
           "1 Ergebnis gefunden") - den oeffnen wir und pruefen ihn, statt
           aufzugeben. */
        if (!r || !r.titel || aufSuchseite) {
          var treffer = ((res && res.hits) || []).filter(function (h) { return h.url; });
          // Kandidat, der die gesuchte Nummer in der Produkt-URL/ID traegt, sonst Einzeltreffer.
          var kandidat = treffer.filter(function (h) {
            return String(h.produkt_id || '') === String(k.wert);
          })[0] || (treffer.length === 1 ? treffer[0] : null);
          if (!kandidat) {
            versuche.push(k.label + ' ' + k.wert + ': kein eindeutiger Shop-Treffer');
            return step(i + 1);
          }
          return inTab(kandidat.url, function () {
            return globalThis.LC.extract(document, location.href);
          }).then(function (r2) {
            if (!r2 || !r2.titel) {
              versuche.push(k.label + ' ' + k.wert + ': Kandidatenseite nicht lesbar');
              return step(i + 1);
            }
            return pruefeGegenprobe(r2);
          });
        }
        return pruefeGegenprobe(r);

        // Gegenprobe: der gefundene Artikel muss den Kandidaten auch tragen.
        function pruefeGegenprobe(r) {
          var passt = true, grund = '';
          if (k.art === 'ean') {
            var sollEan = String(k.wert || '').replace(/\D/g, '');
            var istEan = String(r.ean || '').replace(/\D/g, '');
            if (/^0\d{13}$/.test(sollEan)) sollEan = sollEan.slice(1);
            if (/^0\d{13}$/.test(istEan)) istEan = istEan.slice(1);
            if (!istEan) {
              passt = false; grund = 'EAN fehlt auf der Shop-Produktseite';
            } else if (istEan !== sollEan) {
              passt = false; grund = 'EAN im Shop ist ' + r.ean;
            }
          }
          if (k.art === 'nummer') {
            var hay = (String(r.sku || '') + ' ' + String(r.mpn || '') + ' ' + String(r.produkt_id || '')).toLowerCase();
            if (hay.indexOf(String(k.wert).toLowerCase()) === -1) {
              passt = false; grund = 'Artikelnummer im Shop: ' + (r.sku || r.produkt_id || '?');
            }
          }
          if (!passt) {
            versuche.push(k.label + ' ' + k.wert + ': Treffer passt nicht (' + grund + ')');
            return step(i + 1);
          }

          r._gefundenUeber = k.label + ' ' + k.wert;
          return r;
        }
      })
      .catch(function (e) {
        versuche.push(k.label + ' ' + k.wert + ': ' + ((e && e.message) ? e.message.split('\n')[0] : 'Fehler'));
        return step(i + 1);
      });
  };

  return step(0).then(function (r) {
    return { artikel: r, versuche: versuche };
  });
}

// ------------------------------------------------------------------ Preisjagd

/* Denselben Artikel auf allen anderen Plattformen suchen und die Preise holen.
   Bewusst NICHT auf comparePlatforms() beschraenkt: fuer die Buybox-Sanierung
   sind gerade die EIGENEN Angebote auf Kaufland/eBay/ManoMano entscheidend -
   Amazon vergleicht dagegen, ganz gleich wer dort verkauft. Am 05.08.2026 an
   B078Y6TKG4 belegt: eigenes Kaufland-Angebot 62,95 € bei Amazon-Preis 62,95 €,
   Amazon forderte 62,48 €.
   Kaufland und bol blocken statisches Fetching - ueber den echten Tab (inTab)
   gehen sie trotzdem. */
/* Wie viele Kandidaten pro Plattform wir zum Belegen wirklich aufmachen.
   Jeder Aufruf ist ein echter Tab - zwei reichen, weil vorher nach
   Plausibilitaet sortiert wird. */
var PRUEF_TIEFE = 2;
var PRUEF_TIEFE_EAN_BLIND = 5;

/* Ein Suchtreffer zeigt Titel und Preis, aber keine EAN. Ohne die Trefferseite
   selbst zu oeffnen bleibt jeder Marktplatztreffer eine Vermutung - genau der
   Fehler, der auf Otto und Temu den falschen Artikel als "guenstiger" meldet.
   Also: die aussichtsreichsten Kandidaten aufmachen, EAN/Artikelnummer und den
   echten Seitenpreis nachtragen (Trefferkacheln zeigen oft "ab"-Preise).
   Beim ersten EAN-Beleg ist Schluss - mehr Beweis geht nicht. */
function belegeTreffer(key, hits, label) {
  if (!hits.length || (!key.ean && !key.mpn)) return Promise.resolve(hits);
  var m = globalThis.LC.match;

  /* NACH PLATTFORM gruppieren, dann je Plattform die aussichtsreichsten
     Kandidaten. Vorher galt PRUEF_TIEFE global - beim Preisportal, das SECHS
     Plattformen auf einmal liefert, wurden damit nur zwei Zeilen ueberhaupt
     geoeffnet und die uebrigen vier blieben ohne Nachweis. Genau das war das
     gemeldete "5 Kandidaten ohne Identitaetsnachweis": die Preise waren da,
     nur belegt hat sie niemand. Ein EAN-Beleg fuer Otto sagt eben nichts
     ueber den Kaufland-Preis. */
  var proPlattform = {};
  hits.filter(function (h) { return h.url; }).forEach(function (h) {
    var p = h.plattform || '?';
    (proPlattform[p] = proPlattform[p] || []).push(h);
  });

  /* Plausible zuerst, aber "anderer Artikel" NICHT ausschliessen: eine
     passende EAN schlaegt jeden Titelverdacht - und ein Marktplatztitel, der
     nichts mit dem Shoptitel zu tun hat, kann trotzdem derselbe Artikel sein. */
  /* Kandidaten JE PLATTFORM als eigene Liste - die Listen laufen unten
     parallel (Portal-Treffer fuer sechs Plattformen wurden vorher nacheinander
     geoeffnet), innerhalb einer Plattform weiter einer nach dem anderen. */
  var gruppen = {};
  Object.keys(proPlattform).forEach(function (p) {
    var tiefe = /^(Kaufland|Otto|BOL|Temu)$/i.test(p)
      ? PRUEF_TIEFE_EAN_BLIND : PRUEF_TIEFE;
    gruppen[p] = proPlattform[p]
      /* Zweites Sortierkriterium, weil das erste allein nichts tut: an einer
         echten bol-Trefferseite bekamen 29 von 29 Kandidaten denselben Rang,
         die Sortierung war ein No-Op und PRUEF_TIEFE schnitt nach
         DOM-Reihenfolge ab - der richtige Treffer wurde nie geoeffnet. */
      .map(function (h) { var b = m.bewerte(key, h); return { hit: h, rang: b.rang, punkte: b.punkte }; })
      .sort(function (a, b) { return a.rang - b.rang || b.punkte - a.punkte; })
      .slice(0, tiefe)
      .map(function (x) { return x.hit; });
  });

  // Je Plattform ist nach dem ersten EAN-Beleg Schluss - mehr Beweis geht nicht.
  var belegt = {};

  var step = function (kandidaten, i) {
    if (i >= kandidaten.length) return Promise.resolve(hits);
    var hit = kandidaten[i];
    var platKey = hit.plattform || '?';
    if (belegt[platKey]) return step(kandidaten, i + 1);

    /* Ein EAN-verankertes Preisportal hat die Identitaet bereits auf seiner
       eigenen Belegseite bewiesen. Die BOL-Zielseite danach trotzdem zu
       oeffnen waere im gesperrten Firmennetz nicht nur nutzlos, sondern wuerde
       den guten Beleg durch eine IP-Sperrseite ersetzen. */
    if (key.ean && hit.ean === key.ean && hit.ean_beleg_url && hit.preis != null) {
      logLine('  Beleg ' + platKey + ': EAN ' + key.ean + ' via ' + hit.ean_beleg_url +
        ', ' + hit.preis + ' EUR');
      belegt[platKey] = true;
      return step(kandidaten, i + 1);
    }

    return setStatus({ current: 'Beleg pruefen: ' + label + ' (' + (i + 1) + '/' + kandidaten.length + ')' })
      .then(function () {
        /* Die erwartete Kennung MITGEBEN. Grund: Ob wir eine EAN aus einer
           Seite herauslesen koennen, haengt an unseren Selektoren - ob sie
           dort steht, nicht. Findet die Extraktion kein EAN-Feld, heisst das
           also nicht, dass der Artikel ein anderer ist; es heisst nur, dass
           wir das Feld nicht kennen. Deshalb zusaetzlich die simpelste und
           haerteste Probe: kommt genau diese Ziffernfolge im Quelltext vor?
           Eine 13-stellige GTIN steht nicht zufaellig auf einer fremden
           Produktseite - das ist ein Beleg, keine Vermutung. */
        return inTab(hit.url, function (wantEan, wantMpn) {
          var row = globalThis.LC.extract(document, location.href);
          if (!row.ean || !row.mpn) {
            var html = '';
            try { html = document.documentElement.innerHTML; } catch (e) { /* leer */ }
            if (!row.ean && wantEan && html.indexOf(wantEan) > -1) {
              row.ean = wantEan;
              row.kennung_aus_quelltext = 'EAN';
            }
            /* Artikelnummern sind kuerzer und damit anfaelliger fuer
               Zufallstreffer - nur ab 5 Ziffern und mit Ziffernbegrenzung. */
            if (!row.mpn && wantMpn && /^\d{5,9}$/.test(wantMpn) &&
                new RegExp('(^|[^0-9])' + wantMpn + '([^0-9]|$)').test(html)) {
              row.mpn = wantMpn;
              row.kennung_aus_quelltext = (row.kennung_aus_quelltext ? 'EAN+' : '') + 'Artikelnummer';
            }
          }
          return row;
        }, [key.ean || '', key.mpn || '']);
      })
      .then(function (row) {
        if (!row || !row.titel) {
          logLine('  Beleg ' + label + ': Seite nicht lesbar');
          return;
        }
        /* Login- oder Sperrseite statt Produktseite: Temu schickt JEDE
           Trefferseite ohne Session auf login.html ("Anmelden / Registrieren"),
           bol antwortet mit einer IP-Sperrseite. Ohne jede Kennung UND ohne
           Preis ist das kein Produkt - solche Daten duerfen den bereits
           gefundenen Treffer nicht ueberschreiben. Genau so wurde aus
           "TRESKO Campingstuhl" ein "Anmelden / Registrieren", das die
           Identitaetspruefung dann folgerichtig als FREMD verwarf: der Treffer
           war gefunden und wurde nachtraeglich zerstoert. */
        var temuMetaBeleg = /^temu$/i.test(String(row.plattform || '')) && row.produkt_id &&
          String(row.produkt_id) === String(hit.produkt_id || '') && String(row.titel || '').length >= 40;
        if (!row.ean && !row.mpn && !row.sku && row.preis == null && !temuMetaBeleg) {
          logLine('  Beleg ' + label + ': Login-/Sperrseite ("' + String(row.titel).slice(0, 40) + '") - verworfen');
          return;
        }
        logLine('  Beleg ' + (hit.plattform || label) + ': ' +
          (row.ean ? 'EAN ' + row.ean : 'kein EAN-Feld gefunden') +
          (row.kennung_aus_quelltext ? ' (' + row.kennung_aus_quelltext + ' im Quelltext)' : '') +
          (row.preis != null ? ', ' + row.preis + ' EUR' : ''));
        if (row.ean) hit.ean = row.ean;
        if (row.mpn || row.sku) hit.mpn = row.mpn || row.sku;
        if (row.preis != null) hit.preis = row.preis;
        if (row.waehrung) hit.waehrung = row.waehrung;
        /* Marke und Titel der PRODUKTSEITE schlagen die Kachel: Otto zeigt
           die Marke gar nicht in der Kachel, und Kacheltitel sind gekuerzt -
           beides liess echte Treffer durchfallen bzw. falsche durch. */
        if (row.marke) hit.marke = row.marke;
        if (row.titel) hit.titel = row.titel;
        /* Die Masse der geoeffneten Seite mitnehmen. Genau sie wurden bisher
           weggeworfen - deshalb meldete die Pruefung "Treffer nennt keine
           Masse", obwohl die Produktseite sie fuehrt. Attribute zuerst: dort
           steht die Kette maschinenlesbar ("Produktabmessungen 70x70x73 cm"). */
        var mq = [row.masse_quelle, row.eigenschaften || row.attribute, row.eig_masse,
                  row.eig_belastbarkeit, row.beschreibung, row.slug, row.item_highlights,
                  row.bullet_1, row.bullet_2, row.bullet_3].filter(Boolean).join(' ');
        if (mq) hit.masse_text = mq;
        hit.beschreibung = row.beschreibung || hit.beschreibung || '';
        hit.material_text = [row.eig_material, row.beschreibung].filter(Boolean).join(' ');

        /* DAS war der gemeldete bol-Fehler: die Produktseite wurde geoeffnet,
           ausgelesen - und dann weggeworfen. saveRows stand ueberall sonst,
           nur nicht hier. Der Treffer blieb eine Kachelzeile und tauchte nie
           in den Listings auf ("findet es, ruft es nicht auf"). row.url traegt
           die Adresse NACH allen Weiterleitungen. */
        if (row.url) hit.url = row.url;
        /* Geoeffnete Seite mit WIDERSPRECHENDER Kennung (andere EAN/Masse/Marke)
           ist ein bewiesen anderer Artikel - Kaufland lieferte auf die
           Titelsuche 5 fremde casaria-Artikel. Als Wettbewerbszeile gespeichert
           floodeten die Listings und das Feld mit Fehltreffern. */
        if (m.bewerte(key, hit).stufe === 'FREMD') {
          logLine('  Beleg ' + (hit.plattform || label) + ': anderer Artikel - verworfen, nicht gespeichert');
          return;
        }
        return saveRows([row]);
      })
      .catch(function (e) {
        /* Frueher kommentarlos geschluckt - genau so verschwand ein bol-Treffer
           spurlos. Der Grund gehoert ins Protokoll, sonst raet man. */
        logLine('  Beleg ' + (hit.plattform || label) + ': nicht aufrufbar - ' +
                ((e && e.message) || e || 'unbekannt') + ' [' + hit.url + ']');
      })
      .then(function () {
        if (m.bewerte(key, hit).bestaetigt) belegt[platKey] = true;
        return sleep(300).then(function () { return step(kandidaten, i + 1); });
      });
  };

  return globalThis.LC.api.mapLimit(Object.keys(gruppen), PARALLEL_PLATTFORMEN, function (p) {
    return step(gruppen[p], 0);
  }).then(function () { return hits; });
}

// ------------------------------------------------------------------ Stammsatz (deubaxxl ZUERST)

/* Letzte Stufe der Stammsatz-Suche, wenn EAN/Modellnummer/SKU nichts ergaben:
   Titel-Eskalation (shopQueries), Kandidaten-Produktseiten oeffnen und mit
   LC.match gegen die Amazon-Daten pruefen. Liefert { shop, beleg } oder null. */
function sucheShopZeileLive(row) {
  var LCg = globalThis.LC;
  var key = LCg.match.produktSchluessel(row);
  // EAN/Nummer bewusst NICHT als Query - die hat findeDeubaArtikel schon erfolglos
  // probiert. Es bleibt die Leiter aus Produkttyp, Marke und Mass.
  var queries = LCg.search.shopQueries(Object.assign({}, key, { ean: '', mpn: '' }));
  var geoffnet = 0;                    // hartes Tab-Budget ueber alle Stufen
  var besterUnbestaetigt = null;

  var stufe = function (qi) {
    if (qi >= queries.length || geoffnet >= 4) {
      /* Ein unbestaetigter Kandidat wird NIE einfach genommen - "frueher oder
         spaeter bleibt er bei einem Competitor stehen" (LO, 05.08.2026).
         Er geht markiert nach oben, wo NUR der Ringschluss ueber Amazon ihn
         noch beweisen kann. Sonst: lieber kein Stammsatz als ein falscher. */
      if (besterUnbestaetigt) return Promise.resolve(Object.assign({ unbestaetigt: true }, besterUnbestaetigt));
      return Promise.resolve(null);
    }
    var qf = queries[qi];
    var url = LCg.search.searchUrl('deubaxxl', qf.q, qf.type);

    return setStatus({ current: 'Shop-Listing suchen: "' + qf.q + '"' })
      .then(function () { return logLine('Shop-Titelsuche ' + (qi + 1) + ': "' + qf.q + '"'); })
      .then(function () {
        return inTab(url, function (q, qt) {
          return globalThis.LC.search.extractSearchResults(document, location.href, q, qt, 10);
        }, [qf.q, qf.type]);
      })
      .then(function (hits) {
        logLine('Shop-Titelsuche ' + (qi + 1) + ': ' + ((hits && hits.length) || 0) + ' Roh-Treffer');
        (hits || []).slice(0, 5).forEach(function (h) {
          var hb = LCg.match.bewerte(key, h);
          logLine('  ' + (h.produkt_id || '?') + ' ' + String(h.titel || '').slice(0, 65) +
            ' -> ' + hb.stufe + ': ' + hb.grund);
        });
        /* Nach Fingerabdruck ordnen, NICHT nach Titelaehnlichkeit: bei einem
           generischen Amazon-Titel ("Casaria Garten Beistelltisch FSC") ist die
           Aehnlichkeit zum Shoptitel reines Rauschen - genau daran haben wir
           Hochbeete fuer Beistelltische gehalten. bewerte() vergleicht die
           Masse; wer der Kette widerspricht (Geschwistermodell 46x46x47 statt
           70x70x73), fliegt sofort raus statt einen der vier Tabs zu fressen. */
        var kandidaten = (hits || []).filter(function (h) { return h.url; })
          .map(function (h) { return { h: h, b: LCg.match.bewerte(key, h) }; })
          .filter(function (x) { return x.b.stufe !== 'FREMD'; })
          .sort(function (a, b) { return a.b.rang - b.b.rang || b.b.punkte - a.b.punkte; })
          .slice(0, 3)
          .map(function (x) { return x.h; });

        var pruefe = function (ki) {
          if (ki >= kandidaten.length || geoffnet >= 4) return null;
          geoffnet++;
          return inTab(kandidaten[ki].url, function () {
            return globalThis.LC.extract(document, location.href);
          }).then(function (shop) {
            if (shop && shop.titel) {
              /* deubaxxl-Titel fuehren die Marke nicht - sie steht im
                 Marken-FELD der Produktseite. Fuer den Markencheck davorsetzen. */
              var b = LCg.match.bewerte(key, Object.assign({}, shop, {
                titel: (shop.marke ? shop.marke + ' ' : '') + shop.titel,
                ean: shop.ean, mpn: shop.mpn || shop.sku
              }));
              logLine('  Shop-Kandidat ' + (shop.sku || shop.produkt_id || '?') +
                ' EAN ' + (shop.ean || '-') + ' -> ' + b.stufe + ': ' + b.grund);
              if (b.bestaetigt) return { shop: shop, beleg: b.label };
              if (b.stufe !== 'FREMD' && (b.stufe === 'MARKE_MASSE' || b.punkte >= 0.55) &&
                  (!besterUnbestaetigt || b.punkte > besterUnbestaetigt.punkte)) {
                besterUnbestaetigt = { shop: shop, beleg: 'unbestaetigt, Titel ' + Math.round(b.punkte * 100) + '%', punkte: b.punkte };
              }
            }
            return sleep(700).then(function () { return pruefe(ki + 1); });
          }).catch(function () { return pruefe(ki + 1); });
        };
        return pruefe(0);
      })
      .then(function (gefunden) {
        if (gefunden && gefunden.shop) return gefunden;
        return sleep(700).then(function () { return stufe(qi + 1); });
      })
      .catch(function () { return stufe(qi + 1); });
  };

  return stufe(0).then(function (gefunden) {
    if (gefunden) return gefunden;

    /* Shopware sortiert selbst praezise Dimensionsqueries teils hinter
       verwandte Produkte. Google als EINMALIGER Bruecken-Fallback; der Fund
       bleibt unbestaetigt und muss danach zwingend den Amazon-Ringschluss
       ueber seine Deuba-EAN bestehen. */
    return logLine('Shop-Titelsuche ohne Kandidat - Google site:deubaxxl.de')
      .then(function () { return resolveViaGoogle(key, 'deubaxxl'); })
      .then(function (hits) {
        var kandidaten = (hits || []).filter(function (h) { return h.url; })
          .map(function (h) { return { h: h, b: LCg.match.bewerte(key, h) }; })
          .filter(function (x) { return x.b.stufe !== 'FREMD'; })
          .sort(function (a, b) { return a.b.rang - b.b.rang || b.b.punkte - a.b.punkte; })
          .slice(0, 3).map(function (x) { return x.h; });

        logLine('Google-Deuba: ' + kandidaten.length + ' plausible Kandidat(en)');
        var pruefe = function (i) {
          if (i >= kandidaten.length || geoffnet >= 4) {
            return besterUnbestaetigt
              ? Object.assign({ unbestaetigt: true }, besterUnbestaetigt) : null;
          }
          geoffnet++;
          return inTab(kandidaten[i].url, function () {
            return globalThis.LC.extract(document, location.href);
          }).then(function (shop) {
            if (shop && shop.titel) {
              var b = LCg.match.bewerte(key, Object.assign({}, shop, {
                titel: (shop.marke ? shop.marke + ' ' : '') + shop.titel,
                marke: shop.marke,
                ean: shop.ean,
                mpn: shop.mpn || shop.sku,
                masse_text: [shop.eigenschaften, shop.masse_quelle].filter(Boolean).join(' '),
                url: shop.url
              }));
              logLine('  Google-Shop-Kandidat ' + (shop.sku || shop.produkt_id || '?') +
                ' EAN ' + (shop.ean || '-') + ' -> ' + b.stufe + ': ' + b.grund);
              if (b.bestaetigt) return { shop: shop, beleg: b.label };
              if (b.stufe !== 'FREMD' && (b.stufe === 'MARKE_MASSE' || b.punkte >= 0.55) &&
                  (!besterUnbestaetigt || b.punkte > besterUnbestaetigt.punkte)) {
                besterUnbestaetigt = {
                  shop: shop, beleg: 'unbestaetigt, ' + b.label + ', Titel ' +
                    Math.round(b.punkte * 100) + '%', punkte: b.punkte
                };
              }
            }
            return pruefe(i + 1);
          }).catch(function () { return pruefe(i + 1); });
        };
        return pruefe(0);
      })
      .catch(function () { return null; });
  });
}

/* Rueckwaerts-Beweis, wenn Amazon selbst keine EAN zeigt: die GTIN des
   Deuba-Kandidaten auf Amazon suchen. Landet die Suche wieder beim
   Start-ASIN, ist der Kreis geschlossen - Kandidat und Amazon-Listing sind
   derselbe Artikel. Negativ heisst nur "nicht beweisbar", nicht "falsch"
   (Amazon indexiert nicht jede EAN). */
function ringschluss(asin, ean) {
  var url = globalThis.LC.search.searchUrl('amazon', ean, 'ean');
  return setStatus({ current: 'Ringschluss: EAN ' + ean + ' auf Amazon suchen' })
    .then(function () {
      return inTab(url, function (q) {
        return globalThis.LC.search.extractSearchResults(document, location.href, q, 'ean', 5);
      }, [ean]);
    })
    .then(function (hits) {
      return (hits || []).some(function (h) {
        return String(h.produkt_id || '').toUpperCase() === asin;
      });
    })
    .catch(function () { return false; });
}

/* Der gefundene Shop-Preis ist selbst ein Vergleichstreffer - und zwar der
   wichtigste: der eigene Webshop ist ein moeglicher Preisanker fuer Amazon. */
function shopHitAus(master) {
  return {
    gesucht_am: new Date().toISOString(),
    suchbegriff: master.ean || master.sku || '',
    suchtyp: master.ean ? 'ean' : 'sku',
    plattform: 'deubaxxl',
    position: 1,
    produkt_id: master.sku || master.produkt_id || '',
    titel: master.titel,
    ean: master.ean || '',
    mpn: master.mpn || master.sku || '',
    preis: master.preis,
    waehrung: master.waehrung || 'EUR',
    gesponsert: '',
    url: master.url,
    treffer_gesamt: 1
  };
}

/* PFLICHT-SCHRITT 1 jeder Preisjagd, fuer ALLE Pfade (Buybox-Check UND
   Preisvergleich-Button): das eigene deubaxxl-Listing finden. Stufen:
   bereits erfasst -> Kennungen (EAN/Modellnummer/SKU, hart gegengeprueft)
   -> Titel-Eskalation mit geoeffneten Kandidatenseiten. Ergebnis:
   master   = Zeile, mit der ALLE weiteren Suchen laufen (null = nichts belegbar)
   herkunft = fuers Stammsatz-Feld, damit sichtbar bleibt worauf alles fusst
   shopHit  = Shop-Preis als fertiger Vergleichstreffer
   versuche = was probiert wurde (fuer die Fehlermeldung beim Abbruch) */
function stammsatz(row) {
  return get(['rows', 'eanMap']).then(function (d) {
    var eanMap = d.eanMap || {};
    /* Fingerabdruck statt Titel: liefert die EAN auch dann, wenn Amazon sie
       nicht als Attribut fuehrt, sondern nur im Bullettext ("EAN: 4251...").
       Das ist der haeufigste Fall und die staerkste Bruecke zum Shop - die
       GTIN-Pruefziffer macht den Fund sicher, nicht geraten. */
    var fp = globalThis.LC.match.produktSchluessel(row);
    var ean = row.ean || (row.produkt_id && eanMap[row.produkt_id]) ||
              (row.sku && eanMap[row.sku]) || fp.ean || '';
    row = Object.assign({}, row, { ean: ean });

    // Schon erfasst? (EAN ist der einzige Schluessel, der beide Welten verbindet.)
    var cache = (d.rows || []).filter(function (r) {
      return r.plattform === 'deubaxxl' && ean && r.ean === ean;
    })[0];
    if (cache) {
      return { master: cache, herkunft: 'deubaxxl ' + (cache.sku || '') + ' (bereits erfasst)',
               shopHit: shopHitAus(cache), versuche: [] };
    }

    return findeDeubaArtikel([
      { art: 'ean',    label: 'EAN',          wert: ean },
      { art: 'nummer', label: 'Modellnummer', wert: row.mpn || '' },
      { art: 'nummer', label: 'SKU',          wert: row.sku || '' }
    ]).then(function (fund) {
      if (fund.artikel) {
        var a = fund.artikel;
        logLine('Shop-Artikel gefunden: ' + (a.sku || a.produkt_id || '?') +
          ' via ' + a._gefundenUeber);
        return saveRows([a]).then(function () {
          return { master: a, herkunft: 'deubaxxl ' + (a.sku || a.produkt_id || '') + ' via ' + a._gefundenUeber,
                   shopHit: shopHitAus(a), versuche: fund.versuche };
        });
      }
      // Keine Kennung hat getroffen -> Titel-Eskalation als letzte Stufe.
      return sucheShopZeileLive(row).then(function (res) {
        if (!res || !res.shop) {
          logLine('ABBRUCH: kein Shop-Artikel (' + fund.versuche.join('; ') + ')');
        return { master: null, herkunft: '', shopHit: null,
                   versuche: fund.versuche.concat(['Titelsuche: kein belegbarer Shop-Treffer']) };
        }
        var nimm = function (beleg) {
          return saveRows([res.shop]).then(function () {
            return { master: res.shop,
                     herkunft: 'deubaxxl ' + (res.shop.sku || '') + ' via Titel (' + beleg + ')',
                     shopHit: shopHitAus(res.shop), versuche: fund.versuche };
          });
        };
        if (!res.unbestaetigt) return nimm(res.beleg);

        /* Ringschluss - der einzige Weg, einen unbestaetigten Kandidaten noch
           zu beweisen: seine GTIN (steht auf JEDER Deuba-Produktseite) auf
           Amazon suchen. Landet die Suche beim Start-ASIN, ist der Kreis
           geschlossen, obwohl Amazon selbst nie eine EAN gezeigt hat.
           Scheitert er: Kandidat VERWERFEN. Lieber kein Stammsatz als ein
           Competitor. */
        var asin = /^B0[A-Z0-9]{8}$/i.test(String(row.produkt_id || ''))
          ? String(row.produkt_id).toUpperCase() : '';
        if (!asin || !res.shop.ean) {
          return { master: null, herkunft: '', shopHit: null,
                   versuche: fund.versuche.concat(
                     ['Titel-Kandidat ' + (res.shop.sku || '?') + ' (' + res.beleg + ') nicht beweisbar - verworfen']) };
        }
        return ringschluss(asin, res.shop.ean).then(function (ok) {
          if (!ok) {
            return { master: null, herkunft: '', shopHit: null,
                     versuche: fund.versuche.concat(
                       ['Ringschluss: EAN ' + res.shop.ean + ' fuehrt auf Amazon nicht zu ' + asin + ' - verworfen']) };
          }
          // Bewiesen -> ASIN<->EAN dauerhaft lernen, naechster Lauf geht direkt.
          return seriell(function () {
            return get('eanMap').then(function (d2) {
              var map = d2.eanMap || {};
              map[asin] = res.shop.ean;
              return set({ eanMap: map });
            });
          }).then(function () {
            return nimm('EAN ' + res.shop.ean + ' fuehrt auf Amazon zurueck zu ' + asin + ' - bewiesen');
          });
        });
      });
    });
  }).then(function (result) {
    /* Eine einmal bewiesene Bruecke von der QUELLSEITE zum Deuba-Stammsatz
       dauerhaft merken. Vorher lernte der Cache fast nur ASIN->EAN; ein
       Einstieg ueber eBay, Otto oder Kaufland musste deshalb beim naechsten
       Lauf dieselbe teure und fehleranfaellige Titelleiter erneut nehmen. */
    if (!result || !result.master || !result.master.ean) return result;
    var masterEan = result.master.ean;
    return seriell(function () {
      return get('eanMap').then(function (d) {
        var map = d.eanMap || {};
        learnEan(map, row && row.produkt_id, masterEan);
        learnEan(map, row && row.sku, masterEan);
        learnEan(map, row && row.mpn, masterEan);
        return set({ eanMap: map });
      });
    }).then(function () {
      /* Auch die bereits erfasste Quellzeile vervollstaendigen. Damit ist die
         belegte EAN im UI/Export sichtbar und der naechste Lauf direkt. */
      if (row && row.url && row.plattform !== 'deubaxxl' && !row.ean) {
        return saveRows([Object.assign({}, row, { ean: masterEan })]);
      }
    }).then(function () { return result; });
  });
}

/* key = LC.match.produktSchluessel(...): Stammsatz mit EAN, Artikelnummer,
   Marke, Titel und Massen. */
/* SCHRITT 0 der Preisjagd: eine EAN in ein Preisvergleichsportal, alle
   Haendler mit Preis heraus. Das umgeht genau die Stellen, an denen die
   Direktsuche scheitert - Ottos EAN-Blindheit und Kauflands Bot-Wall - und
   kostet EINE Seitenladung statt sieben Suchen.
   Live 06.08.2026: guenstiger.de fand alle vier Test-EANs mit je 5-6
   Haendlerzeilen, darunter Kaufland, OTTO und eBay.
   Bewusst KEIN Ersatz, sondern eine Vorstufe: was das Portal nicht kennt,
   wird danach wie bisher direkt gesucht. */
function resolveViaEvidencePortals(key, platforms) {
  /* Der Sonderpfad lohnt nur fuer BOL: DE-Portale decken Otto/Kaufland/eBay
     gut ab, waehrend BOL im NL-Katalog lebt und im Firmennetz direkt blockt. */
  if (!key.ean || platforms.indexOf('bol') === -1) return Promise.resolve([]);
  var q = '"' + key.ean + '" (site:beslist.nl/p OR site:kieskeurig.nl)';
  var googleUrl = globalThis.LC.search.googleUrl(q);

  return setStatus({ current: 'NL-Preisportal: EAN ' + key.ean })
    .then(function () {
      return mitGoogleSperre(function () {
        return inTab(googleUrl, function () { return globalThis.LC.search.parseGoogle(document); });
      });
    })
    .then(function (results) {
      var candidates = (results || []).filter(function (row) {
        return row.url && /(^|\.)(beslist|kieskeurig)\.nl$/i.test(row.host || '');
      }).slice(0, 2);
      logLine('NL-Preisportal: ' + candidates.length + ' EAN-verankerte Produktseite(n) via Google');
      var rows = [];
      var step = function (i) {
        if (i >= candidates.length) return Promise.resolve(rows);
        return inTab(candidates[i].url, function (ean) {
          return globalThis.LC.search.parseEvidencePortal(document, location.href, ean);
        }, [key.ean]).then(function (found) {
          rows = rows.concat(found || []);
        }).catch(function () { /* naechstes Portal */ })
          .then(function () { return sleep(600); })
          .then(function () { return step(i + 1); });
      };
      return step(0);
    })
    .then(function (rows) {
      rows = (rows || []).filter(function (row) {
        return row.plattform && platforms.indexOf(row.plattform) > -1;
      });
      logLine('NL-Preisportal: ' + rows.length + ' passende Angebotszeile(n)' +
        (rows.length ? ' (' + rows.map(function (r) { return r.plattform; }).join(', ') + ')' : ''));
      return rows.map(function (row, index) {
        var plat = globalThis.LC.PLATFORMS.filter(function (p) { return p.id === row.plattform; })[0];
        return {
          gesucht_am: new Date().toISOString(), suchbegriff: key.ean, suchtyp: 'ean',
          plattform: (plat && plat.label) || row.plattform, position: index + 1,
          produkt_id: '', titel: row.titel || '', marke: '', ean: row.ean,
          preis: row.preis, waehrung: 'EUR', gesponsert: '', url: row.url,
          versand: row.versand || '', verkaeufer: row.shop || '',
          treffer_gesamt: rows.length, quelle: 'nl-preisportal',
          ean_beleg_url: row.ean_beleg_url, belegart: row.belegart
        };
      });
    })
    .catch(function (e) {
      logLine('NL-Preisportal: nicht verfuegbar (' + ((e && e.message) || 'Fehler') + ')');
      return [];
    });
}

function resolveViaAggregator(key, platforms) {
  if (!key.ean) {
    logLine('Preisportal uebersprungen: keine EAN im Stammsatz');
    return Promise.resolve({ hits: [], fehler: [], quelle: '' });
  }

  var quellen = globalThis.LC.search.AGGREGATOREN.map(function (a) { return a.id; });

  var versuch = function (qi) {
    if (qi >= quellen.length) return Promise.resolve({ hits: [], fehler: [], quelle: '' });
    var quelle = quellen[qi];
    var url = globalThis.LC.search.aggregatorUrl(quelle, key.ean);

    return setStatus({ current: quelle + ': EAN ' + key.ean })
      .then(function () {
        return inTab(url, function () {
          return globalThis.LC.search.parseAggregator(document, location.href);
        });
      })
      .then(function (zeilen) {
        logLine(quelle + ': ' + ((zeilen && zeilen.length) || 0) + ' Angebotszeilen gelesen' +
          (zeilen && zeilen.length
            ? ' (' + zeilen.map(function (z) { return z.plattform || z.shop; }).join(', ') + ')'
            : ''));
        zeilen = (zeilen || []).filter(function (z) {
          // Nur Plattformen, die tatsaechlich gefragt sind.
          return z.plattform && platforms.indexOf(z.plattform) > -1;
        });
        if (!zeilen.length) return sleep(600).then(function () { return versuch(qi + 1); });

        /* Kein Nachfiltern ueber den Titel: dieselbe Ware heisst bei Otto
           anders als bei Kaufland, ein Titelvergleich wuerde hier echte
           Treffer wegwerfen. Die Identitaet belegt spaeter belegeTreffer
           ueber die geoeffnete Produktseite und deren EAN. */
        var out = zeilen.map(function (z, n) {
          var plat = globalThis.LC.PLATFORMS.filter(function (p) { return p.id === z.plattform; })[0];
          return {
            gesucht_am: new Date().toISOString(),
            suchbegriff: key.ean,
            suchtyp: 'ean',
            plattform: (plat && plat.label) || z.plattform,
            position: n + 1,
            produkt_id: '',
            titel: z.titel || '',
            /* Erwartete Marke niemals als beobachtete Treffer-Marke ausgeben.
               Sie darf erst durch die geoeffnete Produktseite belegt werden. */
            marke: '',
            preis: z.preis,
            waehrung: 'EUR',
            gesponsert: '',
            // Der Klick-Link leitet auf die echte Produktseite um - genau die,
            // die belegeTreffer dann oeffnet und per EAN gegenprueft.
            url: z.url,
            versand: z.versand || '',
            verkaeufer: z.shop || '',
            treffer_gesamt: zeilen.length,
            quelle: quelle
          };
        }).filter(function (h) { return h.url; });

        if (!out.length) return sleep(600).then(function () { return versuch(qi + 1); });
        return { hits: out, fehler: [], quelle: quelle };
      })
      .catch(function (e) {
        return sleep(600).then(function () {
          return versuch(qi + 1);
        });
      });
  };

  return versuch(0).then(function (base) {
    var hatBol = (base.hits || []).some(function (hit) { return /^BOL$/i.test(hit.plattform || ''); });
    if (platforms.indexOf('bol') === -1 || hatBol) return base;
    return resolveViaEvidencePortals(key, platforms).then(function (nlHits) {
      if (!nlHits.length) return base;
      return {
        hits: (base.hits || []).concat(nlHits),
        fehler: base.fehler || [],
        quelle: [base.quelle, 'nl-preisportal'].filter(Boolean).join(' + ')
      };
    });
  });
}

/* STUFE 2, nur fuer die Plattformen, die weder das Preisportal noch ihre
   eigene Suche liefert. Live 06.08.2026 bewiesen: Otto und Kaufland sind per
   EAN ueber KEINE Suchmaschine auffindbar - "site:otto.de 4250525353426"
   ergibt null Treffer. Beide FUEHREN die Artikel, rendern die EAN aber nicht
   in den Index. Mit Marke + Titelwoertern kommt dieselbe Suche direkt auf die
   Produktseite. Google gibt die Ziel-URL nicht preis, der Link fuehrt beim
   Oeffnen im Tab aber dorthin - der Host im cite-Element reicht zum Sortieren. */
var GOOGLE_SITE = {
  otto: 'otto.de', kaufland: 'kaufland.de', bol: 'bol.com',
  temu: 'temu.com', ebay: 'ebay.de', deubaxxl: 'deubaxxl.de'
};

function resolveViaGoogle(key, platformId) {
  var host = GOOGLE_SITE[platformId];
  if (!host || !key.titel) return Promise.resolve([]);

  var q = globalThis.LC.search.googleSiteQuery(host, key);
  var url = globalThis.LC.search.googleUrl(q);

  return setStatus({ current: 'Google: ' + q.slice(0, 52) })
    .then(function () {
      return mitGoogleSperre(function () {
        return inTab(url, function () {
          return globalThis.LC.search.parseGoogle(document);
        });
      });
    })
    .then(function (treffer) {
      var plat = globalThis.LC.PLATFORMS.filter(function (p) { return p.id === platformId; })[0];
      return (treffer || [])
        .filter(function (t) { return t.host && t.host.indexOf(host) > -1 && t.url; })
        .slice(0, 3)
        .map(function (t, n) {
          return {
            gesucht_am: new Date().toISOString(),
            suchbegriff: q, suchtyp: 'sku',
            plattform: (plat && plat.label) || platformId,
            position: n + 1, produkt_id: '',
            titel: t.titel || '', marke: '',
            preis: t.preis, waehrung: t.preis != null ? 'EUR' : '',
            gesponsert: '', url: t.url, treffer_gesamt: treffer.length,
            quelle: 'google'
          };
        });
    })
    .catch(function () { return []; });
}

function sammlePreise(key, platforms) {
  var hits = [];
  var fehler = [];
  var queries = {};

  var hatBelegtenPreis = function (h) {
    var b = globalThis.LC.match.bewerte(key, h);
    return b.bestaetigt && h.preis != null && (!h.waehrung || h.waehrung === 'EUR');
  };

  /* Kandidaten aus EAN-, Titel-, Google- und Portalstufen sichtbar behalten,
     aber dieselbe Zielseite nicht mehrfach in den Export schreiben. */
  var sammle = function (list) {
    (list || []).forEach(function (h) {
      var id = (h.plattform || '') + '|' +
        (h.url || h.produkt_id || ((h.titel || '') + '|' + String(h.preis)));
      var alt = hits.findIndex(function (x) {
        var xid = (x.plattform || '') + '|' +
          (x.url || x.produkt_id || ((x.titel || '') + '|' + String(x.preis)));
        return xid === id;
      });
      if (alt > -1) hits[alt] = Object.assign({}, hits[alt], h);
      else hits.push(h);
    });
  };

  /* Eine Suchstufe gilt erst als erfolgreich, nachdem wenigstens ein Treffer
     auf der Produktseite identifiziert wurde und einen echten Preis traegt.
     Blosse Kacheln duerfen die naechste Stufe nicht mehr abschneiden. */
  var belegeStufe = function (list, label, stufe) {
    if (!list || !list.length) return Promise.resolve(false);
    list.forEach(function (h) { h.gesucht_am = new Date().toISOString(); });
    return belegeTreffer(key, list, label).then(function () {
      sammle(list);
      var n = list.filter(hatBelegtenPreis).length;
      logLine(label + ': ' + stufe + ' -> ' + n + ' belegte(r) Treffer mit Preis');
      return n > 0;
    });
  };

  var platformStep = function (pid) {
    if (abbruchAngefordert) return Promise.resolve();
    var label = (globalThis.LC.PLATFORMS.find(function (p) { return p.id === pid; }) || {}).label || pid;

    /* Erst EAN (exakt), und wenn die Plattform sie nicht kennt: Titel+Marke.
       Live 05.08.2026: die Amazon-EAN-Suche liefert je nach Katalogstand
       "keine Ergebnisse" - dann NICHT aufgeben, sondern per Titel suchen;
       die Identitaet sichert danach der Beleg-Schritt, nicht die Query. */
    var direkteQueries = globalThis.LC.search.targetQueries(pid, key);
    if (!direkteQueries.length) {
      fehler.push(label + ': keine brauchbare Suchanfrage');
      return Promise.resolve();
    }

    var suche = function (q) {
      queries[q.q] = 1;
      var url = globalThis.LC.search.searchUrl(pid, q.q, q.type);
      if (!url) return Promise.resolve(null);
      return inTab(url, function (qq, qt) {
        var found = globalThis.LC.search.extractSearchResults(document, location.href, qq, qt, 5);
        return {
          hits: found,
          diagnose: found.length ? null : {
            title: String(document.title || '').slice(0, 120),
            href: location.href,
            body: String((document.body && document.body.innerText) || '')
              .replace(/\s+/g, ' ').trim().slice(0, 220)
          }
        };
      }, [q.q, q.type]).then(function (paket) {
        if (Array.isArray(paket)) return paket; // Test-/Legacy-Harness
        var diag = paket && paket.diagnose;
        if (diag) {
          logLine(label + ': Leerseite "' + (diag.title || '?') + '" @ ' +
            String(diag.href || '').slice(0, 160) + ' | ' + (diag.body || 'kein Seitentext'));
          if (/temporarily blocked|access.+blocked|possible abuse|zugriff.+gesperrt/i.test(diag.body || '')) {
            throw new Error('Zugriff von dieser IP durch ' + label + ' blockiert; keine weiteren Requests');
          }
          /* Captcha-/Verifizierungswand (Temu zeigt sie in diesem Profil
             grundsaetzlich): sofort abbrechen statt drei Stufen lang gegen
             dieselbe Wand zu laufen. */
          if (/captcha|verifizier|verify you|bist du ein mensch|are you human|robot|sicherheitsüberprüfung|security check/i.test((diag.body || '') + ' ' + (diag.title || ''))) {
            throw new Error(label + ' zeigt eine Captcha-/Sicherheitswand; keine weiteren Requests');
          }
          if (pid === 'temu' && (/\/login\.html/i.test(diag.href || '') || /Temu\s*\|\s*Anmeldung/i.test(diag.title || ''))) {
            throw new Error('Temu verlangt in diesem Profil eine Anmeldung; keine weiteren Requests');
          }
        }
        return (paket && paket.hits) || [];
      });
    };

    var direkteStufen = function (qi) {
      if (abbruchAngefordert || qi >= direkteQueries.length) return Promise.resolve(false);
      var q = direkteQueries[qi], stufe = 'Stufe ' + (qi + 1);
      return setStatus({ current: 'Preise: ' + label + ' (' + (qi + 1) + '/' + direkteQueries.length + ')' })
        .then(function () {
          return logLine(label + ': ' + stufe + ' (' + q.type + ') "' + q.q + '"');
        })
        .then(function () { return qi ? sleep(300) : null; })
        .then(function () { return suche(q); })
        .then(function (res) {
          logLine(label + ': ' + stufe + ' -> ' + ((res && res.length) || 0) + ' Treffer');
          return belegeStufe(res, label, stufe);
        })
        .then(function (belegt) { return belegt ? true : direkteStufen(qi + 1); });
    };

    return direkteStufen(0)
      /* Findet die plattformeigene Suche nichts BELEGTES, ueber Google
         nachfassen -
         fuer Otto und Kaufland ist das der einzige belegte Weg: beide sind
         EAN-blind, finden den Artikel ueber Marke+Titel aber sehr wohl. */
      .then(function (belegt) {
        if (belegt) return true;
        if (!GOOGLE_SITE[pid]) {
          logLine(label + ': Stufe 3 entfaellt (kein Google-Site-Muster hinterlegt)');
          return false;
        }
        return sleep(700)
          .then(function () { return resolveViaGoogle(key, pid); })
          .then(function (r3) {
            logLine(label + ': Stufe 3 (Google site:) -> ' + ((r3 && r3.length) || 0) + ' Treffer');
            return belegeStufe(r3, label, 'Stufe 3');
          });
      })
      .then(function (belegt) {
        if (!belegt) {
          logLine(label + ': AUFGEGEBEN - alle Stufen ohne belegten Treffer');
          fehler.push(label + ': kein belegter Treffer');
        }
      })
      .catch(function (e) {
        fehler.push(label + ': ' + ((e && e.message) ? e.message.split('\n')[0] : 'Fehler'));
      });
  };

  /* Zielplattformen parallel (PARALLEL_PLATTFORMEN gleichzeitig): jede Plattform
     sieht weiterhin nur einen Tab nach dem anderen, nur unser Rechner wartet
     nicht mehr auf Otto, waehrend eBay laengst fertig waere. Google ist ueber
     mitGoogleSperre() serialisiert. */
  var alleParallel = function (list) {
    return globalThis.LC.api.mapLimit(list, PARALLEL_PLATTFORMEN, platformStep);
  };

  /* Erst das Preisportal, dann die Direktsuche - aber nur ein BELEGTER
     Portaltreffer darf eine Plattform aus der weiteren Suche entfernen. */
  return resolveViaAggregator(key, platforms).then(function (agg) {
    if (!agg.hits.length) return alleParallel(platforms);

    queries[key.ean] = 1;
    // Auch die Portaltreffer muessen belegt werden - der Klick-Link fuehrt auf
    // die echte Produktseite, dort steht die EAN.
    return belegeTreffer(key, agg.hits, agg.quelle).then(function () {
      sammle(agg.hits);
      var gefunden = {};
      agg.hits.filter(hatBelegtenPreis).forEach(function (h) { gefunden[h.plattform] = 1; });
      var offen = platforms.filter(function (pid) {
        var plat = globalThis.LC.PLATFORMS.filter(function (p) { return p.id === pid; })[0];
        return !gefunden[(plat && plat.label) || pid];
      });
      var uebersprungen = platforms.length - offen.length;
      if (uebersprungen > 0) {
        logLine(agg.quelle + ': ' + uebersprungen + ' Plattform(en) belegt - Direktsuche entfaellt');
      }
      return alleParallel(offen);
    });
  }).then(function () {
    return { hits: hits, fehler: fehler, queries: queries };
  });
}

// ------------------------------------------------------------------ Produktbetreuer-Check

/* AOD-Angebote, Buybox-Belege und Varianten-A+ fuer eine oder mehrere ASINs.
   Laeuft zwingend im Seitenkontext von Amazon (amazon-pro.js braucht DOMParser
   und Amazons eigene Session fuer den AOD-Ajax). */
function runProCheck(asins, origin, opts) {
  origin = origin || 'https://www.amazon.de';
  opts = opts || {};
  logReset('Buybox-Pruefung: ' + (asins || []).join(', '));
  var out = [];
  var errors = [];
  var trefferAlle = [];

  var step = function (i) {
    if (abbruchAngefordert || i >= asins.length) return Promise.resolve();
    var asin = asins[i];

    return setStatus({ current: 'ASIN ' + asin, done: i, total: asins.length })
      .then(function () {
        /* Ein Seitenbesuch, beide Ergebnisse: Angebote/Buybox UND die
           Listingdaten (Titel, Marke, EAN) - die brauchen wir gleich als
           Stammsatz fuer die Preisjagd. */
        return inTab(amazonProduktUrl(asin, origin), function () {
          return globalThis.LC.amazonPro.inspect(document, location.href, { variantAplus: true })
            .then(function (pro) {
              return { pro: pro, row: globalThis.LC.extract(document, location.href) };
            });
        });
      })
      .then(function (paket) {
        var res = paket && paket.pro;
        var row = (paket && paket.row) || {};
        if (!res || !res.asin) { errors.push(asin + ': nicht gelesen'); return; }
        var bb = res.buybox || {};
        var angebote = (res.angebote && res.angebote.offers) || [];
        var preise = angebote.map(function (o) { return o.preis; })
                             .filter(function (p) { return p != null; });
        var eintrag = {
          geprueft_am: new Date().toISOString(),
          asin: res.asin,
          buybox: bb.status || '',
          buybox_verkaeufer: bb.verkaeufer || '',
          beleg: 'Kaufblock=' + (bb.hat_kaufblock ? 'ja' : 'nein') +
                 ', Preisblock=' + (bb.hat_preisblock ? 'ja' : 'nein') +
                 ', AlleKaufoptionen=' + (bb.hat_alle_kaufoptionen ? 'ja' : 'nein'),
          aplus: res.aplus || '',
          angebote_anzahl: res.angebote ? res.angebote.anzahl : null,
          angebot_min: preise.length ? Math.min.apply(null, preise) : null,
          angebot_max: preise.length ? Math.max.apply(null, preise) : null,
          anbieter: angebote.map(function (o) {
            return (o.verkaeufer || '?') + (o.preis != null ? ' ' + o.preis.toFixed(2).replace('.', ',') + ' €' : '') +
                   (o.buybox ? ' [Buybox]' : '');
          }).join(' | '),
          varianten: (res.varianten || []).join(', '),
          varianten_ohne_aplus: (res.varianten_aplus || [])
            .filter(function (v) { return v.aplus === 'KEIN A+'; })
            .map(function (v) { return v.asin; }).join(', '),
          fehler: (res.angebote && res.angebote.fehler) || '',
          url: amazonProduktUrl(res.asin, origin)
        };
        recordSample(res.asin, {
          preis: row.preis, bsr: row.bsr, buybox: bb.status,
          anbieter: eintrag.angebote_anzahl, angebot_min: eintrag.angebot_min
        });

        /* Jetzt die eigentliche Frage: WO ist es guenstiger?
           SCHRITT 1 UND PFLICHT: den Artikel im eigenen Shop finden
           (erfasst -> Kennungen -> Titel-Eskalation). Erst danach wird
           irgendwo anders gesucht - mit den SHOP-Daten. */
        row.produkt_id = row.produkt_id || asin;
        return stammsatz(row).then(function (s) {
          var master = s.master;

          /* Kein Shop-Artikel = KEINE Preissuche. Mit dem generischen
             Amazon-Titel weiterzusuchen liefert nachweislich fremde Artikel
             (Hochbeet, Gartendusche, Sitzgruppe) - ein falscher Preis ist
             schlimmer als gar keiner. */
          if (!master) {
            eintrag.urteil = 'ABBRUCH: Artikel im Deuba-Shop nicht gefunden - ohne Stammsatz keine Preissuche';
            eintrag.stammsatz = 'nicht aufloesbar: ' + (s.versuche.join('; ') || 'keine Kennung am Amazon-Listing');
            out.push(eintrag);
            return;
          }

          var key = globalThis.LC.match.produktSchluessel(master);
          eintrag.stammsatz = s.herkunft +
            (key.ean ? ', EAN ' + key.ean : ', ohne EAN') +
            (key.masse.length ? ', Masse ' + key.masse.join('/') : '');

          /* deubaxxl ist jetzt Bezugspunkt, kein Suchziel mehr. Temu nur auf
             ausdruecklichen Wunsch (Plattform-Haken im Popup): dort steht in
             diesem Profil immer eine Captcha-Wand, jeder Lauf verlor damit
             einen Tab und eine Minute. */
          var plats = (opts.platforms && opts.platforms.length ? opts.platforms
            : globalThis.LC.PLATFORMS.map(function (p) { return p.id; }).filter(function (p) { return p !== 'temu'; }))
            .filter(function (p) { return p !== 'amazon' && p !== 'deubaxxl'; });

          return sammlePreise(key, plats)
            .then(function (pv) {
              var eigener = eintrag.angebot_min != null ? eintrag.angebot_min : row.preis;
              /* Der eigene Shop-Preis gehoert MIT in den Vergleich: er ist
                 der wahrscheinlichste Preisanker, gegen den Amazon rechnet. */
              var alleHits = s.shopHit ? [s.shopHit].concat(pv.hits) : pv.hits;
              var b = globalThis.LC.match.bewerteAlle(key, alleHits, eigener);

              eintrag.urteil = b.urteil;
              eintrag.kandidaten = b.treffer.length;
              eintrag.bestaetigte = b.treffer.filter(function (h) { return h.match_bestaetigt === 'ja'; }).length;
              /* Das ganze Wettbewerbsfeld mitschreiben, nicht nur den
                 guenstigsten - gerade die teureren Anbieter belegen, wo der
                 Markt liegt, und ob der von Amazon genannte Preis existiert. */
              eintrag.wettbewerb = b.feld;
              eintrag.anbieter_extern = b.anbieter_gesamt;
              eintrag.luecke = b.luecke;
              if (b.guenstigster) {
                eintrag.guenstigster_preis = b.guenstigster.preis;
                eintrag.guenstigster_gesamt = b.guenstigster.gesamt != null
                  ? b.guenstigster.gesamt : b.guenstigster.preis;
                eintrag.guenstigste_plattform = b.guenstigster.plattform;
                eintrag.guenstigster_beleg = b.guenstigster.match_grund;
                eintrag.guenstigster_url = b.guenstigster.url;
              }
              /* Auch die verworfenen Kandidaten mitschreiben - der Nutzer muss
                 sehen KOENNEN, was aussortiert wurde, sonst ist die Pruefung
                 eine Blackbox. */
              eintrag.verworfen = b.treffer.filter(function (h) { return h.match_bestaetigt !== 'ja'; })
                .slice(0, 6)
                .map(function (h) { return h.plattform + ': ' + h.match_grund; }).join(' | ');
              if (pv.fehler.length) {
                eintrag.fehler = [eintrag.fehler, pv.fehler.join('; ')].filter(Boolean).join(' | ');
              }
              trefferAlle = trefferAlle.concat(b.treffer);
              out.push(eintrag);
            });
        });
      })
      .catch(function (e) {
        errors.push(asin + ': ' + ((e && e.message) ? e.message.split('\n')[0] : 'Fehler'));
      })
      .then(function () { return sleep(600); })
      .then(function () { return step(i + 1); });
  };

  return step(0).then(function () {
    // seriell(): 'matches' schreibt auch runBatchSearch (seriell()-gesichert) -
    // ohne dieselbe Kette ueberschreiben sich ein zeitgleicher Preisvergleich
    // und diese Buybox-Pruefung gegenseitig (derselbe Bug wie bei saveRows,
    // Review 03.09.).
    return seriell(function () {
      return get(['pro', 'matches']).then(function (d) {
        var alt = (d.pro || []).filter(function (p) {
          return !out.some(function (o) { return o.asin === p.asin; });
        });
        /* Bewertete Treffer landen zusaetzlich im Blatt "Suchtreffer" - mit
           Begruendung. Dabei die Treffer der GERADE geprueften Suchbegriffe
           ersetzen statt blind anhaengen: ohne das wuchs die Liste bei jedem Lauf
           weiter und zeigte Treffer zu Artikeln, die laengst nicht mehr geprueft
           werden (die Gartenliege). */
        var neueBegriffe = {};
        trefferAlle.forEach(function (t) { if (t.suchbegriff) neueBegriffe[t.suchbegriff] = 1; });
        var alteMatches = (d.matches || []).filter(function (m) {
          return !neueBegriffe[m.suchbegriff];
        });
        return set({ pro: alt.concat(out), matches: alteMatches.concat(trefferAlle) });
      });
    });
  }).then(function () {
    /* Der Status beantwortet die Frage, die der Nutzer wirklich hat:
       nicht "ist die Buybox weg" (das sieht er selbst), sondern "wo ist es
       guenstiger". */
    var res = out.map(function (o) { return o.asin + ': ' + (o.urteil || 'kein Urteil'); }).join(' || ');
    if (!res) res = out.length + ' ASIN(s) geprueft';
    if (errors.length) res += ' | ' + errors.join('; ');
    if (quotaWarnung) { res += ' | SPEICHER VOLL: ' + quotaWarnung; quotaWarnung = ''; }
    if (abbruchAngefordert) res = 'Abgebrochen';
    var unterboten = out.some(function (o) { return /UNTERBOTEN/.test(o.urteil || ''); });
    return setStatus({
      running: false, current: '', done: asins.length, total: asins.length,
      result: res, ok: abbruchAngefordert ? false : (out.length > 0 && !unterboten)
    });
  });
}

// ------------------------------------------------------------------ Isolierter Live-Resolver-Test

function kompakterLiveTreffer(h) {
  return {
    plattform: h.plattform || '',
    produkt_id: h.produkt_id || '',
    titel: h.titel || '',
    ean: h.ean || '',
    mpn: h.mpn || '',
    preis: h.preis == null ? null : h.preis,
    waehrung: h.waehrung || '',
    match_stufe: h.match_stufe || '',
    match_bestaetigt: h.match_bestaetigt || '',
    match_grund: h.match_grund || '',
    quelle: h.quelle || '',
    url: h.url || ''
  };
}

/* Nur fuer einen fehlgeschlagenen isolierten Live-Test: zeigt, ob die
   Shop-Suche blockiert, umgeleitet oder mit neuem Markup gerendert wurde. */
function probeDeubaSuche(source) {
  var key = globalThis.LC.match.produktSchluessel(source || {});
  var queries = globalThis.LC.search.shopQueries(Object.assign({}, key, { ean: '', mpn: '' })).slice(0, 3);
  var out = [];
  var step = function (i) {
    if (i >= queries.length) return Promise.resolve(out);
    var q = queries[i];
    var url = globalThis.LC.search.searchUrl('deubaxxl', q.q, q.type);
    return inTab(url, function (query) {
      var links = Array.prototype.slice.call(document.querySelectorAll('a[href]'))
        .map(function (a) {
          return { text: String(a.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 100), href: a.href };
        })
        .filter(function (a) { return a.text || /\/\d{4,}\/?(?:[?#]|$)/.test(a.href); })
        .slice(0, 30);
      return {
        query: query,
        href: location.href,
        title: document.title,
        body: String((document.body && document.body.innerText) || '').replace(/\s+/g, ' ').trim().slice(0, 1800),
        counts: {
          vsai_item: document.querySelectorAll('a.vsai-item').length,
          product_box: document.querySelectorAll('.product-box').length,
          product_links: document.querySelectorAll('a[href*="/product/"], a[href*="/detail/"], a[href*="/artikel/"]').length,
          all_links: document.querySelectorAll('a[href]').length
        },
        products: Array.prototype.slice.call(document.querySelectorAll('.product-box')).slice(0, 3)
          .map(function (box) {
            return {
              tag: box.tagName,
              class_name: box.className,
              attributes: Array.prototype.slice.call(box.attributes || []).reduce(function (o, a) {
                o[a.name] = a.value; return o;
              }, {}),
              text: String(box.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 700),
              anchors: Array.prototype.slice.call(box.querySelectorAll('a[href]')).slice(0, 6)
                .map(function (a) { return { class_name: a.className, text: String(a.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 180), href: a.href }; }),
              prices: Array.prototype.slice.call(box.querySelectorAll('[class*="price"], [data-price]')).slice(0, 12)
                .map(function (e) { return { class_name: e.className, text: String(e.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 180) }; }),
              html: String(box.outerHTML || '').slice(0, 3500)
            };
          }),
        links: links
      };
    }, [q.q]).then(function (p) {
      out.push(p);
      return step(i + 1);
    }).catch(function (e) {
      out.push({ query: q.q, error: (e && e.message) || String(e) });
      return step(i + 1);
    });
  };
  return step(0);
}

/* End-to-End, aber in einem frischen Browserprofil: Amazon-Listing lesen,
   zwingend den Deuba-Stammsatz/EAN beweisen und erst danach die Zielplattformen
   durchsuchen. Der Bericht enthaelt Daten und Invarianten, nicht bloss Logs. */
function runLiveResolverTests(asins, eans, platforms, expect) {
  asins = (asins || []).map(function (a) { return String(a || '').toUpperCase(); })
    .filter(function (a) { return /^B0[A-Z0-9]{8}$/.test(a); });
  eans = (eans || []).map(function (e) { return String(e || '').replace(/\D/g, ''); })
    .filter(function (e) { return /^\d{8}$|^\d{12,14}$/.test(e); });
  platforms = (platforms || []).filter(function (p) {
    return ['ebay', 'kaufland', 'otto', 'bol', 'temu'].indexOf(p) > -1;
  });
  if (!asins.length && !eans.length) asins = ['B078Y6TKG4'];
  if (!platforms.length) platforms = ['ebay', 'kaufland', 'otto'];
  expect = (expect || []).filter(function (p) { return platforms.indexOf(p) > -1; });

  var report = {
    gestartet_am: new Date().toISOString(),
    code_stand: CODE_STAND,
    extension_version: MANIFEST_INFO.version || '',
    asins: asins,
    eans: eans,
    plattformen: platforms,
    erwartet_belegt: expect,
    faelle: []
  };

  var fall = function (testfall) {
    var asin = testfall.art === 'asin' ? testfall.wert : '';
    var ean = testfall.art === 'ean' ? testfall.wert : '';
    var r = {
      eingabeart: testfall.art, eingabe: testfall.wert, asin: asin, ean: ean,
      gestartet_am: new Date().toISOString(),
      checks: {}, source: null, master: null, treffer: [], fehler: [], protokoll: []
    };
    var masterKey = null;

    return logReset('LIVE-TEST: ' + testfall.art.toUpperCase() + ' ' + testfall.wert)
      .then(function () {
        if (testfall.art === 'ean') {
          return { plattform: 'eingabe', ean: ean, titel: '', produkt_id: '' };
        }
        return inTab(amazonProduktUrl(asin), function () {
          return globalThis.LC.extract(document, location.href);
        });
      })
      .then(function (source) {
        var sourceKey = source ? globalThis.LC.match.produktSchluessel(source) : null;
        r.source = source ? {
          plattform: source.plattform, produkt_id: source.produkt_id,
          titel: source.titel, ean: source.ean, mpn: source.mpn,
          sku: source.sku, marke: source.marke, preis: source.preis,
          kategorie: source.kategorie, slug: source.slug,
          masse: sourceKey.masse, typ: sourceKey.typ, typ_belegt: sourceKey.typ_belegt,
          url: source.url
        } : null;
        r.checks.quelle_aufgeloest = testfall.art === 'ean'
          ? !!(source && source.ean === ean)
          : !!(source && source.titel);
        r.checks.amazon_listing_gelesen = testfall.art === 'asin'
          ? r.checks.quelle_aufgeloest : null;
        if (!r.checks.quelle_aufgeloest) throw new Error(
          testfall.art === 'asin' ? 'Amazon-Listing nicht lesbar' : 'EAN-Eingabe ungueltig');
        if (asin) source.produkt_id = source.produkt_id || asin;
        return stammsatz(source);
      })
      .then(function (s) {
        r.checks.deuba_stammsatz_gefunden = !!(s && s.master);
        if (!s || !s.master) {
          r.fehler = r.fehler.concat((s && s.versuche) || ['kein Deuba-Stammsatz']);
          return probeDeubaSuche(r.source).then(function (probe) {
            r.shop_probe = probe;
            return null;
          });
        }
        masterKey = globalThis.LC.match.produktSchluessel(s.master);
        r.master = {
          produkt_id: s.master.produkt_id, sku: s.master.sku, ean: masterKey.ean,
          marke: s.master.marke, titel: s.master.titel, preis: s.master.preis,
          masse: masterKey.masse, herkunft: s.herkunft, url: s.master.url
        };
        r.checks.deuba_ean_gueltig = /^\d{8}$|^\d{12,14}$/.test(masterKey.ean || '');
        r.checks.source_ean_widerspruchsfrei = !r.source.ean || r.source.ean === masterKey.ean;
        if (!r.checks.deuba_ean_gueltig) {
          r.fehler.push('Deuba-Stammsatz ohne gueltige EAN');
          return null;
        }
        return sammlePreise(masterKey, platforms).then(function (pv) {
          var alle = s.shopHit ? [s.shopHit].concat(pv.hits) : pv.hits;
          var bewertet = globalThis.LC.match.bewerteAlle(masterKey, alle, r.source.preis);
          r.treffer = bewertet.treffer.map(kompakterLiveTreffer);
          r.urteil = bewertet.urteil;
          r.fehler = r.fehler.concat(pv.fehler || []);
          r.checks.kein_schwacher_treffer_bestaetigt = !r.treffer.some(function (h) {
            return h.match_bestaetigt === 'ja' &&
                   ['EAN', 'MPN', 'SHOPTITEL', 'FINGERABDRUCK'].indexOf(h.match_stufe) === -1;
          });
          r.checks.bestaetigte_haben_preis = !r.treffer.some(function (h) {
            return h.match_bestaetigt === 'ja' && h.preis == null;
          });
          var belegt = {};
          r.treffer.filter(function (h) { return h.match_bestaetigt === 'ja'; })
            .forEach(function (h) {
              var p = globalThis.LC.PLATFORMS.filter(function (x) { return x.label === h.plattform; })[0];
              if (p) belegt[p.id] = true;
            });
          r.fehlende_erwartete_plattformen = expect.filter(function (p) { return !belegt[p]; });
          r.checks.erwartete_plattformen_belegt = !r.fehlende_erwartete_plattformen.length;
        });
      })
      .catch(function (e) {
        r.fehler.push((e && e.message) || String(e));
      })
      /* logLine serialisiert asynchron; vor dem Bericht die Kette leerlaufen
         lassen, sonst landet nur die Kopfzeile im JSON. */
      .then(function () { return logKette; })
      .then(function () { return get('log'); })
      .then(function (d) {
        r.protokoll = d.log || [];
        r.beendet_am = new Date().toISOString();
        r.ok = !!(r.checks.quelle_aufgeloest &&
                  r.checks.deuba_stammsatz_gefunden &&
                  r.checks.deuba_ean_gueltig &&
                  r.checks.source_ean_widerspruchsfrei &&
                  r.checks.kein_schwacher_treffer_bestaetigt !== false &&
                  r.checks.bestaetigte_haben_preis !== false &&
                  r.checks.erwartete_plattformen_belegt !== false);
        report.faelle.push(r);
      });
  };

  var testfaelle = asins.map(function (a) { return { art: 'asin', wert: a }; })
    .concat(eans.map(function (e) { return { art: 'ean', wert: e }; }));
  var step = function (i) {
    if (i >= testfaelle.length) return Promise.resolve();
    return fall(testfaelle[i]).then(function () { return step(i + 1); });
  };

  return step(0).then(function () {
    report.beendet_am = new Date().toISOString();
    report.ok = report.faelle.length === testfaelle.length &&
      report.faelle.every(function (f) { return f.ok; });
    return report;
  });
}

function sendeLiveTestBericht(reportUrl, report) {
  var u;
  try { u = new URL(reportUrl); } catch (e) { return Promise.reject(new Error('ungueltige Report-URL')); }
  if ((u.hostname !== '127.0.0.1' && u.hostname !== 'localhost') || u.pathname !== '/result') {
    return Promise.reject(new Error('Report-URL muss lokaler Test-Runner sein'));
  }
  return fetch(u.href, {
    method: 'POST', credentials: 'omit',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(report)
  }).then(function (res) {
    if (!res.ok) throw new Error('Test-Runner HTTP ' + res.status);
    return report;
  });
}

/* Test-only Netzwerk-Inventur. Sie zeichnet bewusst keine Header, Cookies,
   Request-Bodies oder Storage-Daten auf. Die debugger-Berechtigung wird vom
   Runner nur der wegwerfbaren [TEST]-Kopie hinzugefuegt; das Produktivmanifest
   bleibt unveraendert. */
function runLiveApiDiscovery(platformId, seed) {
  platformId = String(platformId || '').toLowerCase().trim();
  seed = String(seed || '').replace(/\s+/g, ' ').trim() || 'gartenstuhl';
  var report = {
    gestartet_am: new Date().toISOString(), code_stand: CODE_STAND,
    testart: 'api-discovery', plattform: platformId, seed: seed,
    endpoints: [], antworten: [], ui: null, checks: {}, fehler: [], ok: false,
    datenschutz: 'Keine Header, Cookies, Request-Bodies oder Browser-Storage erfasst'
  };
  if (platformId !== 'kaufland') {
    report.fehler.push('API-Discovery ist derzeit nur fuer Kaufland freigegeben');
    return Promise.resolve(report);
  }
  if (!chrome.debugger) {
    report.fehler.push('chrome.debugger ist im Test-Build nicht verfuegbar');
    return Promise.resolve(report);
  }

  var tabId = null, attached = false, listener = null;
  var requests = Object.create(null), endpoints = Object.create(null);
  var bodyPromises = [];
  var interesting = function (url) {
    try {
      var u = new URL(url);
      return /^www\.kaufland\.de$/i.test(u.hostname) &&
        (/^\/api\//i.test(u.pathname) || /^\/s\/?$/i.test(u.pathname));
    } catch (e) { return false; }
  };
  var safeUrl = function (url) {
    try {
      var u = new URL(url);
      Array.from(u.searchParams.keys()).forEach(function (key) {
        if (/(token|session|sess|csrf|auth|key|signature|sig|credential)/i.test(key)) {
          u.searchParams.set(key, '[REDACTED]');
        }
      });
      u.hash = '';
      return u.href;
    } catch (e) { return String(url || '').slice(0, 1000); }
  };
  var command = function (method, params) {
    return new Promise(function (resolve, reject) {
      chrome.debugger.sendCommand({ tabId: tabId }, method, params || {}, function (result) {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(result || {});
      });
    });
  };
  var attach = function () {
    return new Promise(function (resolve, reject) {
      chrome.debugger.attach({ tabId: tabId }, '1.3', function () {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else { attached = true; resolve(); }
      });
    });
  };
  var detach = function () {
    if (!attached) return Promise.resolve();
    return new Promise(function (resolve) {
      chrome.debugger.detach({ tabId: tabId }, function () {
        void chrome.runtime.lastError;
        attached = false;
        resolve();
      });
    });
  };
  var navigate = function (url) {
    return new Promise(function (resolve, reject) {
      chrome.tabs.update(tabId, { url: url }, function () {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve();
      });
    }).then(function () { return waitForComplete(tabId, 45000); });
  };

  return new Promise(function (resolve, reject) {
    chrome.tabs.create({ url: 'about:blank', active: false }, function (tab) {
      if (chrome.runtime.lastError || !tab) return reject(new Error('Test-Tab konnte nicht geoeffnet werden'));
      tabId = tab.id;
      resolve();
    });
  }).then(function () {
    return attach();
  }).then(function () {
    listener = function (source, method, params) {
      if (!source || source.tabId !== tabId || !params) return;
      if (method === 'Network.requestWillBeSent' && params.request && interesting(params.request.url)) {
        requests[params.requestId] = {
          url: safeUrl(params.request.url), method: params.request.method || 'GET',
          resource_typ: params.type || '', status: null, mime_typ: ''
        };
      }
      if (method === 'Network.responseReceived' && params.response && interesting(params.response.url)) {
        var row = requests[params.requestId] || {
          url: safeUrl(params.response.url), method: 'GET', resource_typ: params.type || ''
        };
        row.status = params.response.status;
        row.mime_typ = params.response.mimeType || '';
        requests[params.requestId] = row;
        endpoints[row.method + ' ' + row.url] = row;
      }
      if (method === 'Network.loadingFinished' && requests[params.requestId]) {
        var req = requests[params.requestId];
        if ((req.status >= 200 && req.status < 400) &&
            (/json/i.test(req.mime_typ || '') || /\/api\//i.test(req.url || ''))) {
          var bodyPromise = command('Network.getResponseBody', { requestId: params.requestId })
            .then(function (body) {
              var text = body && body.body ? String(body.body) : '';
              if (!text || (body && body.base64Encoded)) return;
              report.antworten.push({
                url: req.url, status: req.status, mime_typ: req.mime_typ,
                body_auszug: text.slice(0, 8000), gekuerzt: text.length > 8000
              });
            }).catch(function () { /* Antwort kann nach Navigation verfallen */ });
          bodyPromises.push(bodyPromise);
        }
      }
    };
    chrome.debugger.onEvent.addListener(listener);
    return command('Network.enable');
  }).then(function () {
    return navigate('https://www.kaufland.de/');
  }).then(function () { return sleep(2500); })
    .then(function () {
      return chrome.scripting.executeScript({
        target: { tabId: tabId }, world: 'MAIN',
        func: async function (wert) {
          var pause = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
          var sichtbar = function (el) {
            if (!el) return false;
            var s = getComputedStyle(el), b = el.getBoundingClientRect();
            return s.display !== 'none' && s.visibility !== 'hidden' && b.width > 0 && b.height > 0;
          };
          var input = Array.from(document.querySelectorAll(
            'input[type="search"], input[name="search_value"], input[placeholder*="Such" i], ' +
            '[data-testid*="search" i] input, [data-test*="search" i] input'
          )).filter(sichtbar)[0];
          if (!input) return { ok: false, title: document.title, href: location.href, fehler: 'Suchfeld fehlt' };
          var setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
          /* Lazy Homepage-Widgets (u.a. trendy-search-terms) einmal in den
             Viewport bringen, ohne sie anzuklicken. */
          window.scrollTo(0, Math.max(0, document.documentElement.scrollHeight - innerHeight));
          await pause(2200);
          window.scrollTo(0, 0);
          await pause(500);
          var trendsProbe = null;
          try {
            var trendsRes = await fetch('/api/home-page/frontend/bff/v1/trendy-search-terms' +
              '?storefront=de&numberOfSearchTerms=24', {
                credentials: 'same-origin', headers: { Accept: 'application/json' }
              });
            trendsProbe = {
              status: trendsRes.status,
              body: String(await trendsRes.text()).slice(0, 4000)
            };
          } catch (trendsError) {
            trendsProbe = { status: null, error: String(trendsError && trendsError.message || trendsError) };
          }
          input.focus();
          setter.call(input, '');
          input.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
          await pause(1200);
          setter.call(input, wert);
          input.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'insertText', data: wert }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
          input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: wert.slice(-1) }));
          await pause(3500);
          return { ok: true, title: document.title, href: location.href, input: input.value, trends_probe: trendsProbe };
        },
        args: [seed]
      });
    }).then(function (frames) {
      report.ui = frames && frames[0] ? frames[0].result : null;
      return sleep(1000);
    }).then(function () {
      var searchUrl = globalThis.LC.search.searchUrl('kaufland', seed, 'sku') ||
        ('https://www.kaufland.de/s/?search_value=' + encodeURIComponent(seed));
      return navigate(searchUrl);
    }).then(function () { return sleep(5000); })
    .then(function () {
      return chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: function () {
          return performance.getEntriesByType('resource').map(function (x) { return x.name; })
            .filter(function (x) { return /kaufland\.de.*(api|suggest|trend|search|graphql|query|complete|recommend)/i.test(x); });
        }
      }).catch(function () { return []; });
    }).then(function (frames) {
      var urls = frames && frames[0] ? frames[0].result : [];
      (urls || []).forEach(function (url) {
        if (!interesting(url)) return;
        var row = { url: safeUrl(url), method: 'GET', resource_typ: 'PerformanceResourceTiming', status: null, mime_typ: '' };
        endpoints[row.method + ' ' + row.url] = endpoints[row.method + ' ' + row.url] || row;
      });
      return sleep(750);
    }).then(function () { return Promise.all(bodyPromises); })
    .then(function () {
      report.endpoints = Object.keys(endpoints).map(function (key) { return endpoints[key]; })
        .sort(function (a, b) { return a.url.localeCompare(b.url); });
      report.checks.autocomplete_endpoint = report.endpoints.some(function (x) {
        return /\/api\/search\/v1\/auto-suggestions/i.test(x.url);
      });
      report.checks.trends_endpoint = report.endpoints.some(function (x) {
        return /\/api\/(search\/v1\/search-trends|home-page\/frontend\/bff\/v1\/trendy-search-terms)/i.test(x.url);
      });
      report.checks.search_backend_endpoint = report.endpoints.some(function (x) {
        return /\/api\/(product-tiles|search\/(?!v1\/(auto-suggestions|search-trends)))/i.test(x.url);
      });
      report.checks.antwort_erfasst = report.antworten.length > 0;
      var answerSeen = Object.create(null);
      report.antworten = report.antworten.filter(function (row) {
        var key = row.url + '|' + row.status + '|' + row.body_auszug;
        if (answerSeen[key]) return false;
        answerSeen[key] = 1;
        return true;
      });
      report.ok = report.checks.autocomplete_endpoint && report.checks.antwort_erfasst;
    }).catch(function (e) {
      report.fehler.push((e && e.message) || String(e));
    }).then(function () {
      if (listener) chrome.debugger.onEvent.removeListener(listener);
      return detach();
    }).then(function () {
      if (tabId != null) return closeTab(tabId);
    }).then(function () {
      report.beendet_am = new Date().toISOString();
      return report;
    });
}

function runLiveKeywordTest(seed, platforms) {
  seed = String(seed || '').trim();
  var pid = (platforms || []).filter(function (p) {
    return p === 'kaufland' || globalThis.LC.api.hasSuggest(p);
  })[0] || 'kaufland';
  var report = {
    gestartet_am: new Date().toISOString(), code_stand: CODE_STAND,
    testart: 'keyword-demand-pipeline', seed: seed, plattform: pid,
    keywords: [], belege: [], api_belege: [], laeufe: [], marktdaten: [], auswertung: null,
    checks: {}, fehler: []
  };
  if (!seed) return Promise.resolve(Object.assign(report, { ok: false, fehler: ['Seed fehlt'] }));

  return logReset('LIVE-KEYWORD-TEST: ' + pid + ' / ' + seed)
    .then(function () {
      return runKeywords([seed], [pid], { tief: false, delay: 450 });
    })
    .then(function () {
      return get(['keywords', 'keywordEvidence', 'keywordRuns', 'keywordSerpMeasurements', 'keywordApiEvidence']);
    })
    .then(function (data) {
      report.belege = (data.keywordEvidence || []).filter(function (row) {
        return row.plattform_id === pid && row.seed === seed;
      });
      report.laeufe = (data.keywordRuns || []).filter(function (row) {
        return row.plattform_id === pid && row.seed === seed;
      });
      report.marktdaten = (data.keywordSerpMeasurements || []).filter(function (row) {
        return row.plattform_id === pid && row.seed === seed;
      });
      report.api_belege = (data.keywordApiEvidence || []).filter(function (row) {
        return row.plattform_id === pid && row.seed === seed;
      });
      var rows = (data.keywords || []).filter(function (row) {
        return row.plattform_id === pid && row.seed === seed;
      });
      report.auswertung = rows[0] || null;
      report.keywords = rows.slice(0, 20).map(function (row) { return row.keyword; });
      report.checks.vorschlaege_vorhanden = report.keywords.length > 0;
      report.checks.seed_bezogen = report.keywords.some(function (k) {
        return String(k).toLowerCase().indexOf(seed.toLowerCase().split(/\s+/)[0]) > -1;
      });
      report.checks.echte_raenge = report.belege.length > 0 && report.belege.every(function (row) {
        return row.position >= 1 && row.position <= row.antwort_anzahl &&
          row.such_prefix === seed && !!row.beleg_url && !!row.lauf_id;
      });
      report.checks.laufhistorie = report.laeufe.length === 1 && report.laeufe[0].beobachtungen === report.belege.length;
      report.checks.direkte_serp_messung = report.marktdaten.length >= 1 && report.marktdaten.every(function (row) {
        return row.gemessen_am && row.beleg_url && row.sichtbare_treffer != null && !row.blockiert;
      });
      report.checks.demand_graph = !!(report.auswertung &&
        report.auswertung.demand_graph_index_0_100 != null &&
        report.auswertung.confidence_0_100 != null &&
        report.auswertung.search_volume === '');
      var apiIds = Object.create(null);
      report.api_belege.forEach(function (row) { apiIds[row.abruf_id] = row; });
      report.checks.api_belege_nachvollziehbar = report.api_belege.length > 0 && report.belege.every(function (row) {
        var api = apiIds[row.api_abruf_id];
        return !!(api && api.request_url && api.abgerufen_am && api.http_status === 200 &&
          api.antwort_hash_sha256 && api.antwort_auszug);
      });
      report.datenquelle = pid === 'kaufland'
        ? 'Kaufland Autocomplete (Browser-UI)' : pid + ' Autocomplete';
      report.belegart = 'First-Party-Autocomplete + direkte SERP-Messung; kein erfundenes Suchvolumen';
      report.ok = report.checks.vorschlaege_vorhanden && report.checks.seed_bezogen &&
        report.checks.echte_raenge && report.checks.laufhistorie &&
        report.checks.direkte_serp_messung && report.checks.demand_graph &&
        report.checks.api_belege_nachvollziehbar;
    })
    .catch(function (e) {
      report.fehler.push((e && e.message) || String(e));
      report.ok = false;
    })
    .then(function () { return logKette; })
    .then(function () { return get('log'); })
    .then(function (d) {
      report.protokoll = d.log || [];
      report.beendet_am = new Date().toISOString();
      return report;
    });
}

function runLivePageProbe(url) {
  var u;
  try { u = new URL(url); } catch (e) {
    return Promise.resolve({ ok: false, fehler: ['ungueltige Probe-URL'] });
  }
  if (!/(^|\.)temu\.com$/i.test(u.hostname)) {
    return Promise.resolve({ ok: false, fehler: ['Probe ist derzeit nur fuer Temu freigegeben'] });
  }
  var report = {
    gestartet_am: new Date().toISOString(), code_stand: CODE_STAND,
    testart: 'page-probe', url: u.href, row: null, diagnose: null, ok: false
  };
  return logReset('LIVE-SEITENPROBE: ' + u.hostname)
    .then(function () {
      return inTab(u.href, function () {
        var row = globalThis.LC.extract(document, location.href);
        var jsonLd = Array.from(document.querySelectorAll('script[type="application/ld+json"]'))
          .map(function (x) { return String(x.textContent || '').slice(0, 6000); }).slice(0, 4);
        var preisTexte = Array.from(document.querySelectorAll(
          '[data-type="price"], [itemprop="price"], meta[property="product:price:amount"]'
        )).slice(0, 20).map(function (x) {
          return String(x.getAttribute('content') || x.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 200);
        }).filter(Boolean);
        var bilder = Array.from(document.images).map(function (x) {
          return { alt: String(x.alt || '').slice(0, 180), src: String(x.currentSrc || x.src || '').slice(0, 500) };
        }).filter(function (x) { return x.alt || x.src; }).slice(0, 30);
        return {
          row: row,
          diagnose: {
            title: document.title, href: location.href,
            body: String((document.body && document.body.innerText) || '')
              .replace(/\s+/g, ' ').trim().slice(0, 5000),
            json_ld: jsonLd, preis_texte: preisTexte, bilder: bilder
          }
        };
      });
    })
    .then(function (paket) {
      report.row = paket && paket.row;
      report.diagnose = paket && paket.diagnose;
      report.ok = !!(report.row && report.row.titel && report.row.produkt_id);
    })
    .catch(function (e) {
      report.fehler = [(e && e.message) || String(e)];
    })
    .then(function () { return logKette; })
    .then(function () { return get('log'); })
    .then(function (d) {
      report.protokoll = d.log || [];
      report.beendet_am = new Date().toISOString();
      return report;
    });
}

function runLiveTemuFixture(ean, url) {
  ean = String(ean || '').replace(/\D/g, '');
  var report = {
    gestartet_am: new Date().toISOString(), code_stand: CODE_STAND,
    testart: 'temu-identity-fixture', ean: ean, url: url,
    master: null, temu: null, bewertung: null, checks: {}, fehler: [], ok: false
  };
  if (!/^\d{8}$|^\d{12,14}$/.test(ean)) {
    report.fehler.push('ungueltige EAN'); return Promise.resolve(report);
  }
  return logReset('LIVE-TEMU-FIXTURE: ' + ean)
    .then(function () {
      return inTab(url, function () { return globalThis.LC.extract(document, location.href); });
    })
    .then(function (row) {
      report.temu = row;
      report.checks.temu_goods_id_gelesen = /^\d{10,}$/.test(row.produkt_id || '');
      if (!report.checks.temu_goods_id_gelesen) throw new Error('Temu Goods-ID nicht lesbar');
      return stammsatz(row).then(function (s) { return { s: s, row: row }; });
    })
    .then(function (paket) {
      var s = paket.s, row = paket.row;
      report.checks.deuba_stammsatz_gefunden = !!(s && s.master);
      if (!s || !s.master) throw new Error('Deuba-Stammsatz nicht gefunden');
      var key = globalThis.LC.match.produktSchluessel(s.master);
      report.master = {
        produkt_id: s.master.produkt_id, sku: s.master.sku, ean: key.ean,
        titel: s.master.titel, marke: s.master.marke, masse: key.masse,
        materialien: key.materialien, set_menge: key.set_menge, url: s.master.url
      };
      var sourceKey = globalThis.LC.match.produktSchluessel(row);
      var b = globalThis.LC.match.bewerte(sourceKey, s.master);
      report.bewertung = {
        stufe: b.stufe, bestaetigt: b.bestaetigt, punkte: b.punkte, grund: b.label
      };
      report.checks.fingerabdruck_bestaetigt = b.stufe === 'FINGERABDRUCK' && b.bestaetigt;
      report.checks.erwartete_ean_gefunden = key.ean === ean;
      report.checks.preis_verfuegbar = row.preis != null;
      report.ok = report.checks.deuba_stammsatz_gefunden &&
        report.checks.temu_goods_id_gelesen && report.checks.fingerabdruck_bestaetigt &&
        report.checks.erwartete_ean_gefunden;
    })
    .catch(function (e) { report.fehler.push((e && e.message) || String(e)); })
    .then(function () { return logKette; })
    .then(function () { return get('log'); })
    .then(function (d) {
      report.protokoll = d.log || [];
      report.beendet_am = new Date().toISOString();
      return report;
    });
}

// ------------------------------------------------------------------ Spiegel-Ordner-Handle
//
// Das im Popup gewaehlte DirectoryHandle liegt in IndexedDB ('lc-backup'/
// 'handles', geschrieben von popup.js). Der Worker liest es fuer den Spiegel
// (spiegelSchreiben/spiegelLoeschen oben) - er kann NICHT um Erlaubnis fragen
// (keine Nutzergeste), nur pruefen, ob sie schon da ist. Alles andere holt
// LC.backup.spiegelSync im Popup nach.
function autoBackupIdbGetHandle() {
  return new Promise(function (res, rej) {
    var req = indexedDB.open('lc-backup', 1);
    req.onupgradeneeded = function () { req.result.createObjectStore('handles'); };
    req.onsuccess = function () {
      var db = req.result;
      var r = db.transaction('handles', 'readonly').objectStore('handles').get('dir');
      r.onsuccess = function () { res(r.result || null); };
      r.onerror = function () { rej(r.error); };
    };
    req.onerror = function () { rej(req.error); };
  });
}

// ------------------------------------------------------------------ Nachrichten

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  // Opportunistischer Auto-Sicherung-Check: fire-and-forget, nie awaiten,
  // darf die eigentliche Nachrichtenverarbeitung nie verzoegern oder stoeren.
  // Kein periodischer Fullbackup: der autoritative Disk-Store schreibt direkt.

  /* Einheitlicher Zugriff fuer Content-Scripts und Popup. Im Ordner-Modus
     landen wachsende Messdaten direkt auf Disk; ohne Ordner bleibt das alte
     chrome.storage.local-Verhalten erhalten. */
  if (msg && msg.type === 'lcStoreGet') {
    // prefix: 'cal:' oder ['cal:', ...] - liefert alle passenden Keys plus msg.keys
    var pGet = msg.prefix
      ? keysMitPrefix([].concat(msg.prefix)).then(function (ks) { return get(ks.concat(msg.keys || [])); })
      : get(msg.keys == null ? null : msg.keys);
    pGet.then(function (d) { sendResponse({ ok: true, data: d || {} }); })
      .catch(function (e) { sendResponse({ ok: false, data: {}, error: e.message }); });
    return true;
  }
  if (msg && msg.type === 'lcStoreSet') {
    set(msg.data || {}).then(function () { sendResponse({ ok: true }); })
      .catch(function (e) { sendResponse({ ok: false, error: e.message }); });
    return true;
  }
  if (msg && msg.type === 'lcStoreRemove') {
    var rm = Array.isArray(msg.keys) ? msg.keys : [msg.keys];
    /* IMMER auch aus storage.local entfernen - auch Disk-Keys: eine lokale
       Ghost-Kopie (Direkt-Write, Wake-up-Race) wuerde sonst bei der naechsten
       Migration wiederbelebt (Audit 03.09., R5). */
    var p = diskBereit.then(function () {
      return new Promise(function (res) { chrome.storage.local.remove(rm, function () { void chrome.runtime.lastError; res(); }); });
    });
    if (diskModus) p = p.then(function () { return diskRemove(rm); });
    p.then(function () { sendResponse({ ok: true }); }).catch(function (e) { sendResponse({ ok: false, error: e.message }); });
    return true;
  }
  if (msg && msg.type === 'lcDiskMigrieren') {
    diskBereit.then(diskMigrieren).then(function (n) { sendResponse({ ok: true, migrated: n }); })
      .catch(function (e) { sendResponse({ ok: false, error: e.message }); });
    return true;
  }
  /* Spiegel-Abgleich (Popup): 'lcSpiegelAlles' nach der Ordnerwahl -> alles
     neu kopieren; 'lcSpiegelErledigt' nach dem Abgleich -> erledigte Keys
     aus lcSpiegelDirty/lcSpiegelLoeschen austragen. */
  if (msg && msg.type === 'lcSpiegelAlles') {
    spiegelAn = true; spiegelRootP = null;
    spiegelMerken('lcSpiegelDirty', ['*']).then(function () { sendResponse({ ok: true }); });
    return true;
  }
  if (msg && msg.type === 'lcSpiegelErledigt') {
    spiegelMerken('lcSpiegelDirty', [].concat(msg.dirty || []), true)
      .then(function () { return spiegelMerken('lcSpiegelLoeschen', [].concat(msg.loeschen || []), true); })
      .then(function () { sendResponse({ ok: true }); });
    return true;
  }

  /* Jeden Auftrag protokollieren, bevor irgendetwas laeuft. Damit ist sofort
     unterscheidbar, ob ein Klick gar nicht ankam oder ob die Suche ankam und
     ergebnislos blieb - vorher sah beides gleich aus. */
  // Nur echte Auftraege loggen: histSample/saveRows kommen bei normalem
  // Amazon-Browsen im Sekundentakt und wuerden den 300-Zeilen-Ringpuffer
  // (= die Diagnose des letzten Laufs) verdraengen (Review 31.08.)
  if (msg && ['batchSearch', 'checkVariants', 'keywords', 'proCheck', 'deepGrab', 'stammsatz'].indexOf(msg.type) > -1) logLine('Auftrag: ' + msg.type);

  /* Proxy fuer members.helium10.com / research-tools.helium10.com: Cookies
     werden bei Cross-Site-Fetch aus dem Content-Script wegen SameSite=Lax
     nicht mitgesendet - der Service-Worker sieht sie dagegen als Extension
     mit host_permissions und darf sie schicken. */
  if (msg && msg.type === 'h10Fetch') {
    var url = msg.url || '', init = msg.init || {};
    // h10api.pacvue.com: Berechtigungsliste der Erweiterung (shared/h10.js features())
    if (!/^https:\/\/((members|research-tools|control-center)\.helium10\.com|h10api\.pacvue\.com)\//.test(url)) {
      sendResponse({ ok: false, status: 0, body: '', data: null, error: 'blockiert: ' + url });
      return false;
    }
    fetch(url, {
      method: init.method || 'GET',
      credentials: init.credentials || 'include',
      headers: init.headers || { 'Accept': 'application/json' },
      body: init.body
    }).then(function (res) {
      return res.text().then(function (body) {
        var data = null; try { data = body ? JSON.parse(body) : null; } catch (e) { /* HTML-Fehlerseite */ }
        sendResponse({ ok: res.ok, status: res.status, body: body, data: data });
      });
    }).catch(function (e) { sendResponse({ ok: false, status: 0, body: '', data: null, error: (e && e.message) || String(e) }); });
    return true;   // async
  }

  if (msg && msg.type === 'liveSelfTest') {
    if (!IST_LIVE_TEST_BUILD) {
      sendResponse({ ok: false, error: 'Live-Test ist nur im isolierten Test-Build erlaubt' });
      return false;
    }
    runLiveResolverTests(msg.asins, msg.eans, msg.platforms, msg.expect)
      .then(function (report) { return sendeLiveTestBericht(msg.reportUrl, report); })
      .then(function (report) { sendResponse({ ok: report.ok }); })
      .catch(function (e) { sendResponse({ ok: false, error: (e && e.message) || String(e) }); });
    return true;
  }

  if (msg && msg.type === 'liveKeywordSelfTest') {
    if (!IST_LIVE_TEST_BUILD) {
      sendResponse({ ok: false, error: 'Live-Test ist nur im isolierten Test-Build erlaubt' });
      return false;
    }
    runLiveKeywordTest(msg.keyword, msg.platforms)
      .then(function (report) { return sendeLiveTestBericht(msg.reportUrl, report); })
      .then(function (report) { sendResponse({ ok: report.ok }); })
      .catch(function (e) { sendResponse({ ok: false, error: (e && e.message) || String(e) }); });
    return true;
  }

  if (msg && msg.type === 'liveApiDiscovery') {
    if (!IST_LIVE_TEST_BUILD) {
      sendResponse({ ok: false, error: 'API-Discovery ist nur im isolierten Test-Build erlaubt' });
      return false;
    }
    runLiveApiDiscovery(msg.discoverApi, msg.keyword)
      .then(function (report) { return sendeLiveTestBericht(msg.reportUrl, report); })
      .then(function (report) { sendResponse({ ok: report.ok }); })
      .catch(function (e) { sendResponse({ ok: false, error: (e && e.message) || String(e) }); });
    return true;
  }

  if (msg && msg.type === 'livePageProbe') {
    if (!IST_LIVE_TEST_BUILD) {
      sendResponse({ ok: false, error: 'Live-Test ist nur im isolierten Test-Build erlaubt' });
      return false;
    }
    runLivePageProbe(msg.probeUrl)
      .then(function (report) { return sendeLiveTestBericht(msg.reportUrl, report); })
      .then(function (report) { sendResponse({ ok: report.ok }); })
      .catch(function (e) { sendResponse({ ok: false, error: (e && e.message) || String(e) }); });
    return true;
  }

  if (msg && msg.type === 'liveTemuFixture') {
    if (!IST_LIVE_TEST_BUILD) {
      sendResponse({ ok: false, error: 'Live-Test ist nur im isolierten Test-Build erlaubt' });
      return false;
    }
    runLiveTemuFixture((msg.eans || [])[0], msg.probeUrl)
      .then(function (report) { return sendeLiveTestBericht(msg.reportUrl, report); })
      .then(function (report) { sendResponse({ ok: report.ok }); })
      .catch(function (e) { sendResponse({ ok: false, error: (e && e.message) || String(e) }); });
    return true;
  }

  /* Abbruch fuer lange Laeufe (Preisjagd/Keyword-Ernte/Buybox-Pruefung): das
     Popup sendet diese Nachricht auf Klick, der Lauf prueft das Flag vor
     jedem Schritt (siehe abbruchAngefordert-Checks in run* unten). Ohne das
     blieb ein einmal gestarteter Lauf bis zu seinem natuerlichen Ende
     unerreichbar - bei 20+ Tabs teils viele Minuten (Review 03.09.). */
  if (msg && msg.type === 'lcAbbruch') {
    abbruchAngefordert = true;
    sendResponse({ ok: true });
    return false;
  }

  if (msg && msg.type === 'batchSearch') {
    abbruchAngefordert = false;
    setStatus({ running: true, query: msg.query || msg.ean, qtype: msg.qtype, done: 0,
                total: msg.platforms.length, current: '', result: '', ok: null, laeuftSeit: new Date().toISOString() })
      .then(function () {
        return runBatchSearch(msg.query, msg.qtype, msg.platforms, {
          sourcePreis: msg.sourcePreis, sourceLabel: msg.sourceLabel,
          perPlatform: !!msg.perPlatform, ean: msg.ean, titel: msg.titel, marke: msg.marke,
          mpn: msg.mpn, sku: msg.sku, produktId: msg.produktId
        });
      })
      .catch(function (e) {
        logLine('FEHLER: ' + ((e && e.message) ? e.message.split(String.fromCharCode(10))[0] : e));
        return setStatus({ running: false, result: 'Fehler: ' + e.message, ok: false });
      });
    sendResponse({ started: true });
    return false;
  }

  if (msg && msg.type === 'checkVariants') {
    setStatus({ running: true, done: 0, total: msg.asins.length, current: '', result: '', ok: null, laeuftSeit: new Date().toISOString() })
      .then(function () { return runCheckVariants(msg.asins); })
      .catch(function (e) {
        logLine('FEHLER: ' + ((e && e.message) ? e.message.split(String.fromCharCode(10))[0] : e));
        return setStatus({ running: false, result: 'Fehler: ' + e.message, ok: false });
      });
    sendResponse({ started: true });
    return false;
  }

  if (msg && msg.type === 'deepGrab') {
    runDeepGrab(msg.url)
      .then(function (row) { sendResponse({ ok: true, titel: row.titel }); })
      .catch(function (e) { sendResponse({ ok: false, error: e.message.split('\n')[0] }); });
    return true; // async sendResponse
  }

  if (msg && msg.type === 'keywords') {
    abbruchAngefordert = false;
    setStatus({ running: true, done: 0, total: (msg.seeds || []).length * (msg.platforms || []).length,
                current: '', result: '', ok: null, laeuftSeit: new Date().toISOString() })
      .then(function () { return runKeywords(msg.seeds, msg.platforms, { tief: !!msg.tief }); })
      .catch(function (e) {
        logLine('FEHLER: ' + ((e && e.message) ? e.message.split(String.fromCharCode(10))[0] : e));
        return setStatus({ running: false, result: 'Fehler: ' + e.message, ok: false });
      });
    sendResponse({ started: true });
    return false;
  }

  if (msg && msg.type === 'proCheck') {
    abbruchAngefordert = false;
    setStatus({ running: true, done: 0, total: msg.asins.length, current: '', result: '', ok: null, laeuftSeit: new Date().toISOString() })
      .then(function () { return runProCheck(msg.asins, msg.origin, { platforms: msg.platforms }); })
      .catch(function (e) {
        logLine('FEHLER: ' + ((e && e.message) ? e.message.split(String.fromCharCode(10))[0] : e));
        return setStatus({ running: false, result: 'Fehler: ' + e.message, ok: false });
      });
    sendResponse({ started: true });
    return false;
  }

  if (msg && msg.type === 'saveRows') {
    saveRows(msg.rows)
      .then(function () { sendResponse({ ok: true }); })
      .catch(function (e) { sendResponse({ ok: false, error: e.message }); });
    return true;
  }

  /* Von dp-buybox.js: Bestand nachtraeglich ans juengste Sample haengen. Laeuft
     ueber die histKette, damit es nie mit recordSample um den Key konkurriert. */
  if (msg && msg.type === 'histBestand') {
    var bAsin = String(msg.asin || '').toUpperCase();
    if (/^[A-Z0-9]{10}$/.test(bAsin) && msg.wert != null) {
      var bKey = 'hist:' + bAsin, bWert = Number(msg.wert);
      histKette = histKette.then(function () { return get(bKey); }).then(function (d) {
        var list = d[bKey] || [], last = list[list.length - 1];
        if (!last || Date.now() - Date.parse(last[0]) > 2 * 60 * 1000 || last[6] === bWert) return;
        last[6] = bWert;
        var o = {}; o[bKey] = list;
        return set(o);
      }).catch(function () { /* Verlauf darf nichts blockieren */ });
    }
    return false;
  }

  /* Vom Seiten-Panel (onpage.js): ein Verlaufs-Sample ohne Erfassen. */
  if (msg && msg.type === 'histSample') {
    /* Die Verlaufsreihe (bis 2.000 Samples, im Ordner-Modus ein Datei-Read)
       kommt nur noch zurueck, wenn der Absender sie braucht (onpage.js Panel:
       wantHist). Quick View (60 Kacheln je Suche) und Auto-Research
       ignorierten die Antwort und zahlten den Read trotzdem (Audit 03.09., P4). */
    var hs = recordSample(msg.asin, msg.sample || {});
    if (!msg.wantHist) {
      hs.then(function () { sendResponse({ ok: true }); }, function (e) { sendResponse({ ok: false, error: e.message }); });
      return true;
    }
    hs.then(function () { return get('hist:' + String(msg.asin || '').toUpperCase()); })
      .then(function (d) { sendResponse({ ok: true, hist: d['hist:' + String(msg.asin || '').toUpperCase()] || [] }); })
      .catch(function (e) { sendResponse({ ok: false, error: e.message }); });
    return true;
  }
});

/* Nach Extension-Reload/-Update die Content-Scripts in SCHON OFFENE Tabs
   nachinjizieren - sonst muss jede Amazon-Seite von Hand neu geladen werden,
   bis wieder etwas reagiert (LO, 30.08.). Chrome injiziert content_scripts
   nur beim Seitenladen; hier holen wir das fuer bestehende Tabs nach.
   Generisch ueber das Manifest, damit neue Eintraege automatisch mitkommen.
   Alte (verwaiste) Script-Kontexte stellen sich selbst ab: dark.js/onpage.js
   feuern beim Start ein Event, auf das ihre Vorgaenger hoeren.
   Rechte: nur scripting + vorhandene host_permissions, kein "tabs". */
chrome.runtime.onInstalled.addListener(function () {
  (chrome.runtime.getManifest().content_scripts || []).forEach(function (cs) {
    chrome.tabs.query({ url: cs.matches }, function (tabs) {
      if (chrome.runtime.lastError) return;
      (tabs || []).forEach(function (tab) {
        if (cs.css && cs.css.length) {
          chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: cs.css })
            .catch(function () { /* Tab nicht injizierbar (chrome://, PDF, discarded) */ });
        }
        if (cs.js && cs.js.length) {
          chrome.scripting.executeScript({ target: { tabId: tab.id }, files: cs.js })
            .catch(function () { /* egal */ });
        }
      });
    });
  });
});
