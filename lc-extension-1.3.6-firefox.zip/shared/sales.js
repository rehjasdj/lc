/* Verkaufsschaetz-Engine (LC.sales): BSR -> Verkaeufe/Monat -> x Preis = Umsatz.

   ARBEITSTEILUNG - das ist der Kern (Umbau 01.09.2026):

   1) FORM der Kurve kommt aus OEFFENTLICHEN Daten, nicht aus unseren Punkten.
      Die Beziehung BSR->Verkaeufe ist KEINE Gerade im log-log: sie wird zu
      hohen Raengen hin deutlich steiler. Gemessen an LOs echten H10-Werten
      (Garten DE) betraegt die Steigung -0.54 im Top-Bereich und -4.55 jenseits
      Rang 10.000; die veroeffentlichte Nova-Tabelle zeigt dieselbe Kruemmung.
      Eine einzige Potenzkurve MUSS deshalb oben unterschaetzen und unten
      ueberschaetzen - genau das waren die grossen Ausreisser (16.200 statt
      25.314 bei Rang 3, 110 statt 34 bei Rang 11.407).
      Darum: feste Stuetzpunkte je Kategorie, log-log-Interpolation dazwischen.

   2) HOEHE der Kurve kommt aus UNSEREN Daten. Schon ein einziger eigener Punkt
      verschiebt die ganze Kategorie-Kurve auf das richtige Niveau (gewichteter
      Median der Verhaeltnisse ist/Tabelle). Die Steigung wird NICHT mehr aus
      unseren Punkten geschaetzt - dafuer sind Badge-Werte zu verrauscht.

   3) EIGENER MESSWERT der ASIN (Seller Central 'm' / Helium 10 'h') schlaegt
      alles: er liefert den Wert, die Kurvenform nur die Umrechnung auf den
      heutigen Rang.

   Ergebnis ist immer EINE Zahl, keine Spanne.

   QUELLEN der Tabelle (oeffentlich, ohne Konto):
   - novadata.io/amazon-sales-estimator: Rang-Baender je Kategorie fuer
     amazon.com (Home & Kitchen als Basis; hier als geometrische Bandmitten).
   - Marktfaktor Deutschland 0.20: amzprep.com nennt fuer Rang 5.000 210
     Einheiten/Monat in den USA gegen 42 in Deutschland (= 0.20). Unabhaengig
     bestaetigt an LOs 9 echten Garten-Werten: Nova x 0.20 trifft Rang 320 ->
     1.600 (echt 1.527/1.827), Rang 2.236 -> 500 (echt 535), Rang 11.180 -> 120
     (echt 123). Der oft zitierte DE-Faktor 0.5 ist damit widerlegt.
   - Kategorie-Multiplikatoren in der Groessenordnung des oeffentlichen
     nexscope-ai/Amazon-Skills (Electronics 1.2, Toys 1.1, Sport 0.9,
     Bekleidung 0.8, Buecher 0.7, Rest 1.0).

   Laeuft wie shared/api.js im Addon (Content-Script + Popup); ohne LC bleibt
   das Modul inaktiv. */
(function () {
  'use strict';
  var LC = globalThis.LC || (typeof window !== 'undefined' ? window.LC : null);
  if (!LC) return;

  // ---------------------------------------------------------------- Kurventabelle
  // [Rang, Einheiten/Monat] fuer amazon.com, Kategorie-Basis Home & Kitchen.
  // Bandmitten geometrisch aus den Nova-Baendern (1-100, 101-1K, 1K-5K,
  // 5K-25K, 25K-100K, 100K+).
  // Rang 1 = 90.000/Monat: amzprep.com nennt fuer Home & Kitchen 3.000
  // Einheiten/TAG auf Platz 1. Ohne diesen Punkt lief die Extrapolation im
  // Spitzenbereich zu flach (Rang 3 wurde um Faktor 3,6 unterschaetzt).
  var KURVE_US = [[1, 90000], [10, 20000], [320, 8000], [2236, 2500], [11180, 600], [50000, 120], [200000, 20]];
  var MARKT_DE = 0.20;

  // Kategorie-Multiplikator relativ zu Home & Kitchen. Treffer per Teilstring
  // auf der deutschen Kategoriebezeichnung; unbekannt -> 1.0 (die Hoehe holt
  // sich die Kalibrierung ohnehin aus den eigenen Punkten).
  var KAT_MULT = [
    [/elektronik|computer|foto|handy|hifi/, 1.2],
    [/spielzeug|spiele|games/, 1.1],
    [/k(ue|ü)che|haushalt|wohnen|garten|baumarkt|heimwerk/, 1.0],
    [/sport|freizeit|auto|motorrad/, 0.9],
    [/bekleidung|schuhe|schmuck|mode|koffer/, 0.8],
    [/b(ue|ü)cher|buch|kindle|musik|dvd/, 0.7]
  ];
  function katMult(kat) {
    var k = String(kat || '');
    for (var i = 0; i < KAT_MULT.length; i++) if (KAT_MULT[i][0].test(k)) return KAT_MULT[i][1];
    return 1;
  }

  /* Tabellenwert fuer einen Rang: log-log-Interpolation zwischen den
     Stuetzpunkten, ausserhalb mit der Steigung des Randsegments extrapoliert. */
  // Stuetzpunkte einmal logarithmieren - kurveBasis laeuft je Schaetzung ueber
  // bis zu 300 Kalibrierpunkte, 14 Math.log je Aufruf waren reine Wiederholung.
  var KURVE_LX = KURVE_US.map(function (p) { return Math.log(p[0]); });
  var KURVE_LY = KURVE_US.map(function (p) { return Math.log(p[1]); });
  function kurveBasis(bsr, kat) {
    if (!(bsr > 0)) return null;
    var lx = KURVE_LX, ly = KURVE_LY;
    var x = Math.log(bsr), i;
    if (x <= lx[0]) i = 0;
    else if (x >= lx[lx.length - 1]) i = lx.length - 2;
    else { for (i = 0; i < lx.length - 1; i++) { if (x <= lx[i + 1]) break; } }
    var b = (ly[i + 1] - ly[i]) / (lx[i + 1] - lx[i]);
    var menge = Math.exp(ly[i] + b * (x - lx[i])) * MARKT_DE * katMult(kat);
    return menge > 0 ? menge : null;
  }

  // ---------------------------------------------------------------- Niveau
  // Automatische Paare altern: Gewicht 1 frisch, linear auf 0.3 bei 90 Tagen.
  function alterGewicht(ts) {
    var tage = (Date.now() - (ts || 0)) / 86400000;
    if (tage <= 0) return 1;
    if (tage >= 90) return 0.3;
    return 1 - 0.7 * (tage / 90);
  }

  /* VARIANTEN-AUFSCHLAG fuer Badge-Paare: Amazons "X+ Mal gekauft" zaehlt nur
     die GEWAEHLTE Variante, Seller Central und H10 die ganze Familie. Wert 2.5
     an LOs echten Garten-Daten kalibriert. Fuer 'm'/'h' kein Aufschlag. */
  var VARIANTEN_AUFSCHLAG = 2.5;

  function gewichteterMedian(elems) {
    if (!elems.length) return null;
    var s = elems.slice().sort(function (a, b) { return a.v - b.v; });
    var sw = 0, ak = 0;
    s.forEach(function (e) { sw += e.w; });
    for (var i = 0; i < s.length; i++) { ak += s[i].w; if (ak >= sw / 2) return s[i].v; }
    return s[s.length - 1].v;
  }

  /* Niveaufaktor: gewichteter Median von (eigener Wert / Tabellenwert). Robust
     gegen Ausreisser - ein einzelner Badge-Eimer kann die Kurve nicht kippen.
     paar = [bsr, menge, ts, quelle?]; 'm' Seller Central (Gewicht 3),
     'h' Helium 10 (2), sonst Badge (Altersgewicht, mit Varianten-Aufschlag). */
  /* Plausibilitaetsfenster JE PUNKT, nicht erst am Ergebnis. Ein Paar, dessen
     Verhaeltnis um mehr als Faktor 10 von der Tabelle abweicht, ist kein
     verrauschter Messwert - es ist die falsche RANG-SKALA: ein Unterkategorie-
     Rang, der unter der Hauptkategorie abgelegt wurde. Live-Beleg (LO 01.09.,
     cal:garten): "Rang 31 -> 2 Verkaufe", "Rang 8 -> 7", "Rang 2 -> 153" - in
     Garten waeren das Zehntausende. 14 der 20 Punkte lagen so, der gewichtete
     Median folgte damit der Mehrheit auf der falschen Skala und druckte das
     Niveau auf 0.124: BSR 3453 wurde als 42 statt 535 angezeigt.
     Die Punkte bleiben gespeichert - sie zaehlen nur nicht als Hauptkategorie-
     Beleg. Gerechnet wird ausschliesslich mit dem Oberkategorie-BSR. */
  var PUNKT_MIN = 0.1, PUNKT_MAX = 10;

  /* RANGABHAENGIGES Niveau (LO 02.09. "bei niedrigen Sales ist der BSR immer
     zu hoch"): das Verhaeltnis H10/Tabelle ist NICHT konstant, es faellt mit
     dem Rang - an LOs 7 echten Garten-Werten von 2.9 (Rang 3) auf ~1.0 (Rang
     11.000). Ein einziger Faktor aus dem mittleren Bereich (wo 3.453 -> 550
     stimmt) hebt deshalb Rang 11.180 auf 190 statt 123.
     Darum wiegt jeder Punkt zusaetzlich mit seiner Naehe zum gesuchten Rang
     (Gauss ueber die log10-Distanz, Breite 0.8 Dekaden). Leave-one-out an den
     7 Werten: mittlerer Fehlerfaktor 2.02 -> 1.50, Rang 11.180: 190 -> 130.
     Ohne Rang (Kalibrier-Tabelle im Popup) bleibt es der globale Median. */
  var NIVEAU_BREITE_DEKADEN = 0.8;
  function niveauAus(paare, kat, rang) {
    if (!paare || !paare.length) return null;
    var el = [];
    var lr = rang > 0 ? Math.log(rang) / Math.LN10 : null;
    paare.forEach(function (p) {
      if (!(p[0] > 0) || !(p[1] > 0)) return;
      var tab = kurveBasis(p[0], kat);
      if (!tab) return;
      var q = p[3];
      var menge = (q === 'm' || q === 'h') ? p[1] : p[1] * VARIANTEN_AUFSCHLAG;
      var v = menge / tab;
      if (!(v > PUNKT_MIN && v < PUNKT_MAX)) return;
      var w = q === 'm' ? 3 : q === 'h' ? 2 : alterGewicht(p[2]);
      if (lr != null) {
        var d = (Math.log(p[0]) / Math.LN10 - lr) / NIVEAU_BREITE_DEKADEN;
        w *= Math.exp(-0.5 * d * d);
      }
      el.push({ v: v, w: w, roh: q === 'm' ? 3 : q === 'h' ? 2 : alterGewicht(p[2]) });
    });
    /* WENIG BELEG IN DER NAEHE -> zur Tabelle hin daempfen (LO 03.09.: cal:
       baumarkt hatte EINEN H10-Punkt bei Rang 467.306, der fuer Rang 3.453 ein
       Niveau von 3,74 erzwang - 1.300 statt 340). Die Gauss-Gewichte sagen,
       wie viel Evidenz am gesuchten Rang wirklich liegt: Summe ~1 = ein voller
       Punkt in der Naehe, darunter mischt sich der Median im log-Raum mit 1.0
       (= reine Tabelle). Ab EINEM vollen Punkt Naehe-Gewicht wirkt der Median
       ungedaempft - ein H10-/Seller-Central-Wert ist eine exakte Messung und
       zaehlt an seinem Rang voll. Ohne Rang (Popup-Tabelle) unveraendert. */
    if (lr != null && el.length) {
      var naehe = 0;
      el.forEach(function (e) { naehe += e.w / e.roh; });   // reines Naehe-Gewicht, ohne Quellenfaktor
      var vLokal = gewichteterMedian(el);
      var anteil = Math.min(1, naehe);
      var vGedaempft = Math.exp(anteil * Math.log(vLokal));
      if (!(vGedaempft > PUNKT_MIN && vGedaempft < PUNKT_MAX)) return null;
      return { wert: vGedaempft, n: el.length, naehe: Math.round(naehe * 100) / 100 };
    }
    if (!el.length) return null;
    var v = gewichteterMedian(el);
    if (!(v > PUNKT_MIN && v < PUNKT_MAX)) return null;
    return { wert: v, n: el.length };
  }

  function rund(est) {
    return est >= 1000 ? Math.round(est / 100) * 100 : (est >= 100 ? Math.round(est / 10) * 10 : Math.round(est));
  }

  function kategorieNorm(k) { return String(k == null ? '' : k).toLowerCase().trim(); }

  function faktorAus(calFaktor, kat) {
    calFaktor = calFaktor || {};
    var roh = calFaktor[kat] != null ? calFaktor[kat] : calFaktor['*'];
    var f = Number(roh);
    return roh != null && isFinite(f) && f > 0 ? f : 1;
  }

  /* Alle Kategorien zusammen als Rueckfall: heisst die Kategorie auf der Seite
     mal anders (Unterkategorie, Schreibweise), stuende sonst 0 Punkte da. */
  function poolPaare() {
    var out = [];
    var kats = (typeof CACHE !== 'undefined' && CACHE && CACHE.kats) || null;
    if (!kats) return out;
    Object.keys(kats).forEach(function (k) { out = out.concat(kats[k] || []); });
    return out;
  }

  /* Eine Zahl, keine Spanne. quelle: 'kalibriert' (Tabelle + eigenes Niveau),
     'kalibriertAlle' (Niveau aus allen Kategorien), 'tabelle' (nur oeffentliche
     Tabelle, noch kein eigener Punkt). */
  function schaetzung(bsr, paare, faktor, kat) {
    var tab = kurveBasis(bsr, kat);
    if (tab == null) return null;
    var niv = niveauAus(paare, kat, bsr), quelle = 'kalibriert', n = paare ? paare.length : 0;
    if (!niv) {
      var pool = poolPaare();
      var nivP = pool.length ? niveauAus(pool, kat, bsr) : null;
      if (nivP) { niv = nivP; quelle = 'kalibriertAlle'; n = pool.length; }
      else { quelle = 'tabelle'; n = 0; }
    }
    var menge = tab * (niv ? niv.wert : 1) * faktor;
    if (!(menge >= 1)) return null;
    return { menge: rund(menge), quelle: quelle, paare: n, faktor: faktor,
      niveau: niv ? Math.round(niv.wert * 100) / 100 : 1, tabelle: rund(tab) };
  }
  // ---------------------------------------------------------------- Speicher-Cache
  // cal:*-Keys + calFaktor einmal beim Laden lesen, danach per storage.onChanged
  // aktuell halten - schaetzeSync() braucht dann keinen eigenen Storage-Zugriff.
  // tabs: dieselben Tabellen MIT ASIN-Schluessel - merken() prueft dagegen,
  // ob ein Paar unveraendert ist, ohne den Speicher zu lesen.
  var CACHE = { kats: Object.create(null), tabs: Object.create(null), faktor: {} };

  /* prefix (optional): zusaetzlich alle Keys mit diesem Praefix - der
     Background filtert, der Tab bekommt nur die cal:-Tabellen.
     KEIN Fallback auf chrome.storage.local: die cal:-Tabellen liegen im
     OPFS-Store des Workers, lokal gibt es sie nicht. Genau dieser Fallback
     lieferte eine leere Tabelle, die merken() als "1. Datenpunkt"
     zurueckschrieb (LO 03.09.). Fehler werden laut gemeldet. */
  function storeGet(keys, prefix) {
    return new Promise(function (res, rej) {
      try {
        chrome.runtime.sendMessage({ type: 'lcStoreGet', keys: keys == null ? null : keys, prefix: prefix || undefined }, function (rr) {
          var err = chrome.runtime.lastError;
          if (!err && rr && rr.ok) return res(rr.data || {});
          rej(new Error((err && err.message) || (rr && rr.error) || 'Speicher nicht erreichbar'));
        });
      } catch (e) { rej(e); }
    });
  }
  function storeSet(obj) {
    return new Promise(function (res, rej) {
      try {
        chrome.runtime.sendMessage({ type: 'lcStoreSet', data: obj }, function (r) {
          var err = chrome.runtime.lastError;
          if (!err && r && r.ok) return res(r);
          rej(new Error((err && err.message) || (r && r.error) || 'Speichern fehlgeschlagen'));
        });
      } catch (e) { rej(e); }
    });
  }

  function cacheAufbauen(d) {
    var kats = Object.create(null), tabs = Object.create(null);
    Object.keys(d || {}).forEach(function (k) {
      if (k.indexOf('cal:') !== 0) return;
      var kat = kategorieNorm(k.slice(4));
      var tab = d[k] || {};
      tabs[kat] = tab;
      kats[kat] = Object.keys(tab).map(function (a) { return tab[a]; })
        .filter(function (p) { return Array.isArray(p) && p[0] > 0 && p[1] > 0; });
    });
    CACHE.kats = kats;
    CACHE.tabs = tabs;
    CACHE.faktor = (d && d.calFaktor && typeof d.calFaktor === 'object') ? d.calFaktor : {};
    CACHE.autoLernen = !d || d.lcAutoLearn !== false;   // Popup-Toggle, Standard AN
  }

  /* NUR cal:* + zwei Einstellungen laden. Vorher get(null): bei jedem Amazon-
     Seitenaufruf wanderte der GESAMTE Bestand (keywords 5,7 MB, Evidence
     2,7 MB, alle Verlaeufe) per Message in den Tab - und im Ordner-Modus
     nach jedem hist:-Write noch einmal (lcDiskChanged an alle Tabs). Das war
     der Lag auf den Suchseiten (LO 03.09.). */
  var CAL_KEYS = ['calFaktor', 'lcAutoLearn'];
  function cacheLaden() {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return Promise.resolve(CACHE);
    return storeGet(CAL_KEYS, 'cal:').then(function (d) { cacheAufbauen(d); return CACHE; });
  }
  var istCalKey = function (k) { return String(k).indexOf('cal:') === 0 || CAL_KEYS.indexOf(k) >= 0; };

  var bereitPromise = cacheLaden();

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
      var nachladen = function () { cacheLaden().catch(function (e) { console.warn('[LC] Schätzer-Cache', e); }); };
      chrome.storage.onChanged.addListener(function (ch, area) {
        if (area !== 'local') return;
        if (Object.keys(ch).some(istCalKey)) nachladen();
      });
      chrome.runtime.onMessage.addListener(function (msg) {
        // Disk-Store meldet JEDEN Write (auch hist:* im Sekundentakt) - nur cal:* interessiert
        if (msg && msg.type === 'lcDiskChanged' && (!Array.isArray(msg.keys) || msg.keys.some(istCalKey))) nachladen();
      });
    }
  } catch (e) { /* kein storage im Test-Kontext */ }

  // ---------------------------------------------------------------- API
  function leseKategorie(kat) {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      return Promise.resolve({ paare: [], faktor: 1 });
    }
    var key = 'cal:' + kat;
    return storeGet([key, 'calFaktor']).then(function (d) {
        var tab = (d && d[key]) || {};
        var paare = Object.keys(tab).map(function (a) { return tab[a]; })
          .filter(function (p) { return Array.isArray(p) && p[0] > 0 && p[1] > 0; });
        return { paare: paare, faktor: faktorAus(d && d.calFaktor, kat), tab: tab };
    });
  }

  /* Erst wenn der Cache steht rechnen: direkt nach einem Extension-Reload lief
     die erste Panel-Berechnung sonst gegen einen leeren Cache - kein Pool,
     also Startkurve, also exakt der Badge-Wert. Genau das sah aus wie ein
     zurueckgesetzter Schaetzer (LO 01.09.). */
  function bereitDann(fn) {
    return bereitPromise.catch(function () { return null; }).then(fn);
  }

  function schaetze(bsr, hauptkategorie) {
    var kat = kategorieNorm(hauptkategorie);
    return bereitDann(function () { return leseKategorie(kat); })
      .then(function (d) { return schaetzung(bsr, d.paare, d.faktor, kat); });
  }

  /* Schaetzung MIT eigenem Messpunkt dieser ASIN: ein H10-Klick ('h') oder eine
     Seller-Central-Zahl ('m') fuer genau diese ASIN ist die beste Information,
     die es gibt. Der Wert kommt vom Messpunkt, die Kurvenform rechnet ihn nur
     auf den heutigen Rang um: menge = wert * tabelle(heute) / tabelle(damals).
     Steht der Rang noch, kommt exakt der gemessene Wert heraus. */
  function schaetzeAsin(bsr, hauptkategorie, asin) {
    var kat = kategorieNorm(hauptkategorie);
    return bereitDann(function () { return leseKategorie(kat); }).then(function (d) {
      var e = asin && d.tab && d.tab[asin];
      if (e && (e[3] === 'h' || e[3] === 'm') && e[1] > 0 && e[0] > 0 && bsr > 0) {
        var jetztT = kurveBasis(bsr, kat), damalsT = kurveBasis(e[0], kat);
        if (jetztT && damalsT) {
          var menge = e[1] * (jetztT / damalsT);
          if (menge >= 1) {
            return { menge: rund(menge * d.faktor), quelle: 'eigen', eigenArt: e[3],
              ankerWert: e[1], ankerBsr: e[0], ankerTs: e[2],
              paare: d.paare.length, faktor: d.faktor };
          }
        }
      }
      return schaetzung(bsr, d.paare, d.faktor, kat);
    });
  }

  /* Ein Kalibrier-Paar ablegen - zentrale Lern-API fuer dp-sales (Produktseite)
     UND serp-quickview (parst fremde DP-HTML nebenbei mit). Race-sicher: frisch
     lesen, nur den eigenen Eintrag setzen. MAX 300 je Kategorie, manuelle
     'm'-Paare (Seller Central) werden nie weggeraeumt. Gibt die neue
     Paar-Anzahl der Kategorie zurueck (fuer den Lern-Chip). */
  var MERK_MAX = 300;
  function merken(hauptkategorie, asin, bsr, kaufzahl, quelle) {
    var kat = kategorieNorm(hauptkategorie);
    if (!kat || !asin || !(bsr > 0) || !(kaufzahl > 0)) return Promise.resolve(null);
    // Popup-Toggle "sammelt automatisch": blockt nur STILLE Auto-Paare (Badge/
    // Quick-View, quelle undefined) - bewusste Aktionen ('h' Klick, 'm' Import) immer.
    if (!quelle && CACHE.autoLernen === false) return Promise.resolve(null);
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return Promise.resolve(null);
    var key = 'cal:' + kat;
    /* Unveraendertes Auto-Paar (gleicher Rang, gleiche Kaufzahl, juenger als
       ein Tag) nicht neu schreiben: jeder Variantenwechsel/Reload loeste sonst
       einen Disk-Write plus Cache-Nachladen in allen Tabs aus, nur um den
       Zeitstempel zu erneuern (Audit 03.09., P2). Gegen den Cache geprueft -
       kein Read noetig. */
    var altC = !quelle && CACHE.tabs[kat] && CACHE.tabs[kat][asin];
    if (altC && altC[0] === bsr && altC[1] === kaufzahl && Date.now() - (altC[2] || 0) < 86400000) {
      return Promise.resolve(Object.keys(CACHE.tabs[kat]).length);
    }
    var eintrag = (quelle === 'm' || quelle === 'h') ? [bsr, kaufzahl, Date.now(), quelle] : [bsr, kaufzahl, Date.now()];
    var rang = function (q) { return q === 'm' ? 2 : q === 'h' ? 1 : 0; };
    return storeGet(key).then(function (d) {
        var tab = (d && d[key]) || {};
        // Kein Downgrade: ein Seller-Central-/H10-Eintrag desselben ASIN wird
        // nicht von einem Badge-Eimer ueberschrieben (LO 01.09.).
        var alt = tab[asin];
        if (!alt || rang(eintrag[3]) >= rang(alt[3])) tab[asin] = eintrag;
        var keys = Object.keys(tab);
        if (keys.length > MERK_MAX) {
          var auto = keys.filter(function (k) { return tab[k][3] !== 'm' && tab[k][3] !== 'h'; });
          auto.sort(function (x, y) { return tab[x][2] - tab[y][2]; });
          auto.slice(0, keys.length - MERK_MAX).forEach(function (k) { delete tab[k]; });
        }
        var o = {}; o[key] = tab;
        return storeSet(o).then(function () { return Object.keys(tab).length; });
    }).catch(function (e) {
      // Orphan-Kontext (Extension neu geladen) oder Speicherfehler: kein Chip,
      // keine unbehandelte Rejection je Kachel (serp-quickview ruft ohne .catch)
      console.warn('[LC] Schätzer merken', e && e.message);
      return null;
    });
  }

  function schaetzeSync(bsr, hauptkategorie) {
    var kat = kategorieNorm(hauptkategorie);
    var paare = CACHE.kats[kat] || [];
    return schaetzung(bsr, paare, faktorAus(CACHE.faktor, kat), kat);
  }

  /* Batch-Variante fuer Bestseller-Listen (onpage.js): dort stehen Rang (= BSR
     der Listen-Kategorie) und Kaufzahl an Dutzenden Kacheln gleichzeitig - ein
     einziges RMW statt 50 parallelen merken()-Aufrufen, die sich gegenseitig
     die Eintraege wegschreiben wuerden. Gleiche Regeln: Auto-Quelle, Toggle-
     Gate, kein Downgrade, 'm'/'h' nie wegraeumen. */
  function merkenViele(hauptkategorie, liste) {
    var kat = kategorieNorm(hauptkategorie);
    if (!kat || !liste || !liste.length) return Promise.resolve(0);
    if (CACHE.autoLernen === false) return Promise.resolve(0);
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return Promise.resolve(0);
    var key = 'cal:' + kat, jetzt = Date.now();
    return storeGet(key).then(function (d) {
        var tab = (d && d[key]) || {}, neu = 0;
        liste.forEach(function (e) {
          if (!e || !e.asin || !(e.bsr > 0) || !(e.kz > 0)) return;
          var alt = tab[e.asin];
          if (alt && (alt[3] === 'm' || alt[3] === 'h')) return;   // kein Downgrade
          if (!alt) neu++;
          tab[e.asin] = [e.bsr, e.kz, jetzt];
        });
        var keys = Object.keys(tab);
        if (keys.length > MERK_MAX) {
          var auto = keys.filter(function (k) { return tab[k][3] !== 'm' && tab[k][3] !== 'h'; });
          auto.sort(function (x, y) { return tab[x][2] - tab[y][2]; });
          auto.slice(0, keys.length - MERK_MAX).forEach(function (k) { delete tab[k]; });
        }
        var o = {}; o[key] = tab;
        return storeSet(o).then(function () { return neu; });
    }).catch(function (e) {
      console.warn('[LC] Schätzer merkenViele', e && e.message);
      return 0;
    });
  }

  LC.sales = {
    schaetze: schaetze,
    schaetzeAsin: schaetzeAsin,
    schaetzeSync: schaetzeSync,
    merken: merken,
    merkenViele: merkenViele,
    kurveBasis: kurveBasis,
    niveauAus: niveauAus,
    rund: rund,
    bereit: function () { return bereitPromise; }
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = LC.sales;
})();
