/* Verlaufs-Chart (Keepa-artig) fuer die Karte auf der Produktseite - ersetzt die
   Mini-Sparkline aus onpage.js ueber LC.onpage.chart(container, samples, ui).

   samples = [[iso, preis, bsr, buyboxCode, anbieter, angebotMin, bestand?], ...]
   aus dem lokalen Verlauf (hist:<ASIN>, background.js). buyboxCode 2 = Buybox
   unterdrueckt. Kurven (SERIEN-Konfig, feste Farben - auf hell UND dunkel lesbar):
     - Buybox (idx 1) #e47911 mit Flaeche, Angebot min. (idx 5, AOD-Gesamtmarkt)
       #2e8b57 mit Luecken statt Ueberbrueckung - beide auf der Preisachse
     - BSR (idx 2) #7c7cd0 gestrichelt, eigene Achse rechts INVERTIERT (kleiner
       Rang oben)
     - Anbieterzahl (idx 4) #999 und Bestand (idx 6) #b8860b als normierte
       Stufenlinien, eigene Skala, default ausgeblendet (Bestand nur ab 2 Werten)
     - Buybox-unterdrueckt-Zeitraeume als dezente rote Flaeche im Hintergrund,
       zusaetzlich rote Punkte auf der Buybox-Linie
   Legende zum Ein-/Ausblenden je Kurve (sichtbar{}, IIFE-Ebene, ueberlebt den
   Neuaufbau, gilt fuer inline+Overlay gleich). Keine Requests, kein eigenes
   CSS ausser den paar Overlay-/Legende-Inline-Styles: Texte mit fill=
   "currentColor", Gitter mit stroke="currentColor" -> Dark Mode groesstenteils
   gratis.

   Fenster = Zeitraum + Zoom in EINEM Modell (zoomState[asin] = {t0,t1} in ms,
   IIFE-Ebene, ueberlebt den 800ms-Panel-Neuaufbau): die Zeitraum-Links (24h/7T/
   30T/90T/1J/Alles) setzen zoomState direkt (Fenster = letzte Messung minus
   Zeitraum), Drag im SVG + Mausrad um den Cursor + die Zeitstrahl-Leiste unter
   dem Chart (Keepa/Highcharts-Navigator: Track = kompletter Datenbestand, Fenster
   darin ziehbar/verschiebbar) schreiben denselben zoomState - eine Quelle der
   Wahrheit. Aktiver Zeitraum-Link ist nur fett, wenn das Fenster ihm entspricht;
   nach freiem Zoom keiner. "Zoom zuruecksetzen" + Doppelklick loeschen das Fenster.
   Beim allerersten Rendern einer ASIN ohne zoomState wird einmalig ein Start-
   Fenster aus dem gemerkten Zeitraum (chrome.storage lcChartRange) abgeleitet.

   Popup: Chip "Gross anzeigen" oeffnet ein Singleton-Overlay an document.body
   (nicht im Panel - abraeumen() darf es nicht greifen), render() wird darin nur
   groesser (Breite/Hoehe parametrisiert) mit denselben Gesten aufgerufen. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};

  var NS = 'http://www.w3.org/2000/svg';
  var RANGES = [['1', '24h'], ['7', '7T'], ['30', '30T'], ['90', '90T'], ['365', '1J'], ['alles', 'Alles']];
  var TAGE = { '1': 1, '7': 7, '30': 30, '90': 90, '365': 365 };  // Tage je Zeitraum-Key (fuer 'alles' kein Eintrag)
  var range = null;                                               // null = noch nicht aus dem Speicher gelesen
  var zoomState = {};                                              // asin -> {t0,t1} in ms, ueberlebt den 800ms-Neuaufbau
  var initialisiert = {};                                          // asin -> true nach dem ersten Rendern (Start-Fenster
                                                                    // aus range nur EINMAL ableiten, sonst ueberschreibt
                                                                    // range bei jedem Neuaufbau einen manuellen Zoom)
  var SERIEN = [                                                   // Kurven-Konfig: id/Label/Sample-Index/Farbe/Default-an
    { id: 'preis', label: 'Buybox', idx: 1, farbe: '#e47911', an: true },
    { id: 'angebot', label: 'Angebot min.', idx: 5, farbe: '#2e8b57', an: true },
    { id: 'bsr', label: 'BSR', idx: 2, farbe: '#7c7cd0', an: true },
    { id: 'anbieter', label: 'Anbieter', idx: 4, farbe: '#999', an: false },
    { id: 'bestand', label: 'Bestand', idx: 6, farbe: '#b8860b', an: false }
  ];
  var sichtbar = {};                                               // id -> an/aus, IIFE-Ebene, ueberlebt den Neuaufbau
  SERIEN.forEach(function (s) { sichtbar[s.id] = s.an; });

  var sv = function (tag, attrs) {
    var e = document.createElementNS(NS, tag);
    for (var k in attrs) if (attrs[k] != null) e.setAttribute(k, attrs[k]);
    return e;
  };
  var t = function (s) { return Date.parse(s[0]); };
  var datum = function (ui, ms) { var d = new Date(ms); return ui.tag(d) + d.getFullYear(); };

  // ------------------------------------------------------------ Vollbild-Overlay
  // Singleton an document.body - wird nur EINMAL erzeugt, ueberlebt jeden Panel-Neuaufbau.
  var overlayEl = null, overlayBody = null;

  function overlaySchliessen() {
    if (overlayEl) overlayEl.style.display = 'none';
  }

  function overlayAufbauen() {
    if (overlayEl) return;                                        // idempotent: Listener nur einmal, nicht pro Oeffnen
    overlayEl = document.createElement('div');
    overlayEl.id = 'lc-chart-overlay';
    // data-lc-keep: nimmt Overlay + Kinder aus der Dark-Mode-Grundregel aus
    // (die wuerde die Inline-Farben ueberschreiben), ohne dass abraeumen()
    // ([data-lc]-Selektor) das Overlay beim Panel-Neuaufbau loescht.
    overlayEl.setAttribute('data-lc-keep', '1');
    overlayEl.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:2147483647;display:none;align-items:center;justify-content:center;padding:16px';
    overlayEl.addEventListener('click', function (ev) { if (ev.target === overlayEl) overlaySchliessen(); });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape' && overlayEl.style.display !== 'none') overlaySchliessen();
    });

    var box = document.createElement('div');
    box.style.cssText = 'position:relative;background:var(--lc-card,#fff);color:var(--lc-fg,#0F1111);' +
      'border:1px solid var(--lc-line,#E7E7E7);border-radius:8px;box-shadow:0 8px 32px rgba(0,0,0,.4);' +
      'width:90vw;height:90vh;max-width:1500px;padding:16px 20px;overflow:auto;font-family:"Amazon Ember",Arial,sans-serif';

    var close = document.createElement('span');
    close.textContent = '×';
    close.title = 'Schließen (Esc)';
    close.style.cssText = 'position:absolute;top:4px;right:14px;cursor:pointer;font-size:28px;line-height:1;color:#565959;user-select:none';
    close.addEventListener('mouseenter', function () { close.style.color = '#C7511F'; });
    close.addEventListener('mouseleave', function () { close.style.color = '#565959'; });
    close.addEventListener('click', overlaySchliessen);

    overlayBody = document.createElement('div');
    overlayBody.style.cssText = 'margin-top:8px';

    box.appendChild(close); box.appendChild(overlayBody);
    overlayEl.appendChild(box);
    document.body.appendChild(overlayEl);
  }

  function overlayOeffnen(asin, all, ui) {
    overlayAufbauen();
    overlayEl.style.display = 'flex';
    render(overlayBody, all, ui, asin, { w: 1200, h: 560, overlay: true });
  }

  function render(container, all, ui, asin, dims) {
    dims = dims || {};
    var W = dims.w || 400, H_ = dims.h || 200, PL = 58, PR = 48, PT = 8, PB = 18;      // viewBox -> bei 300 px Breite ~150 px hoch
    var PH = H_ - PT - PB, PW = W - PL - PR;

    container.innerHTML = '';

    // -- Fenster (= Zeitraum + Zoom, EIN Modell): Track/Grenzen sind immer der
    // volle Datenbestand (all[0]..all[letzte]). zoomState haelt das sichtbare
    // Fenster je ASIN. Beim allerersten Rendern einer ASIN ohne zoomState wird
    // einmalig aus dem gemerkten Zeitraum (range) ein Start-Fenster abgeleitet
    // und in zoomState geschrieben - danach ist zoomState die einzige Quelle
    // der Wahrheit (sonst wuerde z.B. ein Wheel-Zoom auf "Alles" beim naechsten
    // Neuaufbau durch den alten range-Wert wieder eingeengt, LO-Feedback 31.08.).
    var basisT0 = t(all[0]), basisT1 = Math.max(basisT0 + 1, t(all[all.length - 1]));
    var zoom = asin ? zoomState[asin] : null;
    if (!zoom && asin && !initialisiert[asin] && range && range !== 'alles' && TAGE[range]) {
      zoomState[asin] = { t0: Math.max(basisT0, basisT1 - TAGE[range] * 864e5), t1: basisT1 };
      zoom = zoomState[asin];
    }
    if (asin) initialisiert[asin] = true;
    var t0 = basisT0, t1 = basisT1;
    if (zoom) { t0 = Math.max(basisT0, zoom.t0); t1 = Math.min(basisT1, zoom.t1); if (t1 <= t0) t1 = Math.min(basisT1, t0 + 1); }
    var pts = all.filter(function (s) { var tt = t(s); return tt >= t0 && tt <= t1; });
    var hinweis = pts.length < 2 ? ' · nur ' + pts.length + (pts.length === 1 ? ' Messung' : ' Messungen') + ' im Ausschnitt' : '';

    var TOLERANZ = 60000;                                          // 1 Minute Toleranz gegen Rundung beim Preset-Vergleich
    var eingeschraenkt = t0 > basisT0 || t1 < basisT1;
    var presetAktiv = function (key) {
      if (key === 'alles') return !eingeschraenkt;
      if (!eingeschraenkt) return false;
      var soll = TAGE[key] * 864e5;
      return Math.abs(t1 - basisT1) < TOLERANZ && Math.abs((t1 - t0) - soll) < TOLERANZ;
    };

    // -- Zeitraum-Links + Zoom-Reset + Vollbild
    var row = ui.el('div', 'a-size-small lc-chart-range');
    RANGES.forEach(function (r, i) {
      if (i) row.appendChild(document.createTextNode(' · '));
      var a = ui.el('a', 'a-link-normal' + (presetAktiv(r[0]) ? ' a-text-bold' : ''), r[1]);
      a.href = '#'; a.title = 'Verlauf der letzten ' + (r[0] === 'alles' ? 'Aufrufe komplett' : r[1]) + ' zeigen';
      a.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        range = r[0];
        try { chrome.storage.local.set({ lcChartRange: range }); } catch (e) { /* Speicher weg - egal */ }
        if (asin) {
          if (r[0] === 'alles') delete zoomState[asin];
          else zoomState[asin] = { t0: Math.max(basisT0, basisT1 - TAGE[r[0]] * 864e5), t1: basisT1 };
        }
        render(container, all, ui, asin, dims);
      });
      row.appendChild(a);
    });
    if (eingeschraenkt) {
      row.appendChild(document.createTextNode(' · '));
      var zr = ui.el('a', 'a-link-normal', 'Zoom zurücksetzen');
      zr.href = '#'; zr.title = 'Zeitachse wieder auf den vollen Zeitraum stellen';
      zr.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        if (asin) delete zoomState[asin];
        range = 'alles';
        try { chrome.storage.local.set({ lcChartRange: range }); } catch (e) { /* egal */ }
        render(container, all, ui, asin, dims);
      });
      row.appendChild(zr);
    }
    if (!dims.overlay) {
      row.appendChild(document.createTextNode(' · '));
      var gross = ui.el('a', 'a-link-normal', 'Groß anzeigen ⛶');
      gross.href = '#'; gross.title = 'Verlauf groß in einem Overlay anzeigen';
      gross.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        overlayOeffnen(asin, all, ui);
      });
      row.appendChild(gross);
    }
    container.appendChild(row);

    // -- Legende: farbiges Kaestchen + Name je Kurve, klickbar zum Ein-/Ausblenden
    var legRow = ui.el('div', 'a-size-mini lc-chart-legende');
    legRow.style.cssText = 'display:flex;flex-wrap:wrap;gap:4px 10px;margin:4px 0 2px;align-items:center';
    SERIEN.forEach(function (ser) {
      var an = !!sichtbar[ser.id];
      // Ehrlich zeigen, WARUM eine Kurve fehlt (LO 01.09. "ich seh nur 1 kurve"):
      // ohne Werte im Verlauf gibt es nichts zu zeichnen - ausgegraut + erklaert.
      var hatDaten = pts.some(function (s) { return s[ser.idx] != null; });
      var item = ui.el('span', 'lc-chart-leg-item');
      item.style.cssText = 'cursor:pointer;display:inline-flex;align-items:center;gap:4px;opacity:' + (!hatDaten ? '.3' : an ? '1' : '.45');
      var swatch = document.createElement('span');
      swatch.style.cssText = 'display:inline-block;width:9px;height:9px;border-radius:2px;background:' + ser.farbe;
      item.appendChild(swatch);
      item.appendChild(document.createTextNode(ser.label + (hatDaten ? '' : ' (keine Daten)')));
      item.title = hatDaten ? (an ? 'Ausblenden: ' : 'Einblenden: ') + ser.label
        : 'Noch keine Werte im Verlauf – ' +
          (ser.id === 'angebot' ? 'entsteht, wenn die Angebotsliste (AOD) der Seite geladen wurde'
           : ser.id === 'bestand' ? 'entsteht, wenn Amazon „Nur noch X auf Lager" zeigt'
           : 'entsteht bei künftigen Seitenbesuchen');
      item.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        sichtbar[ser.id] = !sichtbar[ser.id];
        render(container, all, ui, asin, dims);
      });
      legRow.appendChild(item);
    });
    container.appendChild(legRow);

    // -- Skalen
    var x = function (s) { return PL + PW * (t(s) - t0) / (t1 - t0); };
    var xZuT = function (xv) { return t0 + (xv - PL) / PW * (t1 - t0); };
    var minmax = function (vals) { return vals.length ? { mn: Math.min.apply(null, vals), mx: Math.max.apply(null, vals) } : null; };
    var werte = function (idx) { return pts.map(function (s) { return s[idx]; }).filter(function (v) { return v != null; }); };
    var pr = minmax(werte(1).concat(werte(5)));                  // Buybox + Angebot min. auf einer Achse
    var bs = minmax(werte(2));
    var anbieterSkala = minmax(werte(4));
    var bestandWerte = werte(6);
    var bestandSkala = bestandWerte.length >= 2 ? minmax(bestandWerte) : null;   // oft lueckenhaft - erst ab 2 Werten zeichnen
    var yOf = function (sc, invert) {
      return function (v) {
        var f = sc.mx === sc.mn ? 0.5 : (v - sc.mn) / (sc.mx - sc.mn);
        if (invert) f = 1 - f;
        return PT + PH * (1 - f);
      };
    };
    var yPr = pr ? yOf(pr, false) : null, yBs = bs ? yOf(bs, true) : null;
    var yAnbieter = anbieterSkala ? yOf(anbieterSkala, false) : null;
    var yBestand = bestandSkala ? yOf(bestandSkala, false) : null;
    var pfad = function (idx, y, luecken) {
      if (luecken) {                                              // Lauf abbrechen statt ueber Nullwerte hinwegzuzeichnen
        var d = '', offen = false;
        pts.forEach(function (s) {
          if (s[idx] == null) { offen = false; return; }
          d += (offen ? 'L' : 'M') + x(s).toFixed(1) + ' ' + y(s[idx]).toFixed(1) + ' ';
          offen = true;
        });
        return d.trim();
      }
      var v = pts.filter(function (s) { return s[idx] != null; });
      if (v.length < 2) return '';
      return v.map(function (s, i) { return (i ? 'L' : 'M') + x(s).toFixed(1) + ' ' + y(s[idx]).toFixed(1); }).join(' ');
    };
    var pfadStufe = function (idx, y) {                            // Stufenlinie fuer Anbieter/Bestand
      var v = pts.filter(function (s) { return s[idx] != null; });
      if (v.length < 2) return '';
      var d = 'M' + x(v[0]).toFixed(1) + ' ' + y(v[0][idx]).toFixed(1);
      for (var i = 1; i < v.length; i++) {
        d += ' L' + x(v[i]).toFixed(1) + ' ' + y(v[i - 1][idx]).toFixed(1) + ' L' + x(v[i]).toFixed(1) + ' ' + y(v[i][idx]).toFixed(1);
      }
      return d;
    };

    // -- SVG
    var svg = sv('svg', { viewBox: '0 0 ' + W + ' ' + H_, 'data-lc': '1', class: 'lc-chart' });
    svg.setAttribute('style', 'display:block;width:100%;height:auto;margin-top:2px;cursor:crosshair');
    // Buybox-unterdrueckt-Zeitraeume (Code 2) als dezente rote Flaeche im Hintergrund -
    // ZUERST gezeichnet, damit Gitter/Kurven optisch darueber liegen
    var bbBand = function (lauf) {
      svg.appendChild(sv('rect', { x: x(lauf.von).toFixed(1), y: PT, width: Math.max(2, x(lauf.bis) - x(lauf.von)).toFixed(1), height: PH, fill: '#B12704', opacity: '.08' }));
    };
    var bbLauf = null;
    pts.forEach(function (s) {
      if (s[3] === 2) { if (!bbLauf) bbLauf = { von: s, bis: s }; else bbLauf.bis = s; }
      else if (bbLauf) { bbBand(bbLauf); bbLauf = null; }
    });
    if (bbLauf) bbBand(bbLauf);
    for (var g = 1; g <= 3; g++) {                                // feines Gitter, 3 Linien
      var gy = (PT + PH * g / 4).toFixed(1);
      svg.appendChild(sv('line', { x1: PL, x2: W - PR, y1: gy, y2: gy, stroke: 'currentColor', opacity: '.15', 'stroke-width': '1' }));
    }
    if (sichtbar.anbieter && yAnbieter) {
      var dAnbieter = pfadStufe(4, yAnbieter);
      if (dAnbieter) svg.appendChild(sv('path', { d: dAnbieter, fill: 'none', stroke: '#999', 'stroke-width': '1.25', class: 'lc-chart-anbieter' }));
    }
    if (sichtbar.bestand && yBestand) {
      var dBestand = pfadStufe(6, yBestand);
      if (dBestand) svg.appendChild(sv('path', { d: dBestand, fill: 'none', stroke: '#b8860b', 'stroke-width': '1.25', class: 'lc-chart-bestand' }));
    }
    var dPr = yPr ? pfad(1, yPr) : '';
    if (sichtbar.preis && dPr) {
      var v1 = pts.filter(function (s) { return s[1] != null; });
      svg.appendChild(sv('path', { d: dPr + ' L' + x(v1[v1.length - 1]).toFixed(1) + ' ' + (PT + PH) + ' L' + x(v1[0]).toFixed(1) + ' ' + (PT + PH) + ' Z',
        fill: '#e47911', opacity: '.12', stroke: 'none', class: 'lc-chart-area' }));
    }
    var dBs = yBs ? pfad(2, yBs) : '';
    if (sichtbar.bsr && dBs) svg.appendChild(sv('path', { d: dBs, fill: 'none', stroke: '#7c7cd0', 'stroke-width': '1.5', 'stroke-dasharray': '4 3', class: 'lc-chart-bsr' }));
    var dAn = yPr ? pfad(5, yPr, true) : '';                       // Angebot min.: Luecken lassen statt drueberzeichnen
    if (sichtbar.angebot && dAn) svg.appendChild(sv('path', { d: dAn, fill: 'none', stroke: '#2e8b57', 'stroke-width': '1.25', class: 'lc-chart-angebot' }));
    if (sichtbar.preis && dPr) svg.appendChild(sv('path', { d: dPr, fill: 'none', stroke: '#e47911', 'stroke-width': '2', 'stroke-linejoin': 'round', class: 'lc-chart-preis' }));
    pts.forEach(function (s) {
      if (s[3] !== 2) return;
      var c = sv('circle', { cx: x(s).toFixed(1), cy: (yPr && s[1] != null ? yPr(s[1]) : PT + PH / 2).toFixed(1), r: '4', fill: '#B12704', class: 'lc-chart-bb' });
      var ti = sv('title'); ti.textContent = 'Buybox unterdrückt ' + datum(ui, t(s)); c.appendChild(ti);
      svg.appendChild(c);
    });
    // Achsentexte: fill=currentColor, damit Dark Mode nichts ueberschreiben muss
    var text = function (str, tx, ty, anchor) {
      var e = sv('text', { x: tx, y: ty, fill: 'currentColor', 'text-anchor': anchor, class: 'a-size-mini lc-chart-label' });
      e.textContent = str; return e;
    };
    if (pr) { svg.appendChild(text(ui.eur(pr.mx), 2, PT + 10, 'start')); svg.appendChild(text(ui.eur(pr.mn), 2, PT + PH, 'start')); }
    if (bs) { svg.appendChild(text(ui.nf(bs.mn), W - 2, PT + 10, 'end')); svg.appendChild(text(ui.nf(bs.mx), W - 2, PT + PH, 'end')); }
    svg.appendChild(text(ui.tag(new Date(t0)), PL, H_ - 4, 'start'));
    svg.appendChild(text(ui.tag(new Date((t0 + t1) / 2)), PL + PW / 2, H_ - 4, 'middle'));
    svg.appendChild(text(ui.tag(new Date(t1)), PL + PW, H_ - 4, 'end'));
    var hover = sv('line', { y1: PT, y2: PT + PH, x1: PL, x2: PL, stroke: 'currentColor', opacity: '.5', 'stroke-dasharray': '2 2', visibility: 'hidden', class: 'lc-chart-hover' });
    svg.appendChild(hover);
    var auswahl = sv('rect', { x: PL, y: PT, width: 0, height: PH, fill: '#007185', opacity: '.15', stroke: '#007185', 'stroke-width': '1', 'stroke-dasharray': '3 2', visibility: 'hidden' });
    svg.appendChild(auswahl);
    container.appendChild(svg);

    // -- Zeitstrahl/Scroll-Leiste: Track ist immer der KOMPLETTE Datenbestand
    // (basisT0..basisT1 = all[0]..all[letzte]), das aktuelle Fenster (t0..t1)
    // darin per Drag verschieb- und an den Raendern ziehbar. Schreibt denselben
    // zoomState wie die Chart-Gesten oben und die Zeitraum-Links - eine Quelle
    // der Wahrheit.
    var navH = 14;
    var navSvg = sv('svg', { viewBox: '0 0 ' + W + ' ' + navH, 'data-lc': '1', class: 'lc-chart-nav' });
    navSvg.setAttribute('style', 'display:block;width:100%;height:' + navH + 'px;margin-top:6px;cursor:pointer');
    navSvg.appendChild(sv('rect', { x: PL, y: 0, width: PW, height: navH, fill: 'var(--lc-card,#fff)', stroke: 'var(--lc-line,#E7E7E7)' }));
    var navX = function (tt) { return PL + PW * (tt - basisT0) / (basisT1 - basisT0); };
    var navZuT = function (px) { return basisT0 + (px - PL) / PW * (basisT1 - basisT0); };
    var navWin = sv('rect', { x: navX(t0).toFixed(1), y: 0.5, width: Math.max(1, navX(t1) - navX(t0)).toFixed(1), height: navH - 1, fill: '#007185', opacity: '.18', stroke: '#007185', 'stroke-width': '1' });
    navSvg.appendChild(navWin);
    container.appendChild(navSvg);

    var navPxVonEvent = function (ev) {
      var rect = navSvg.getBoundingClientRect ? navSvg.getBoundingClientRect() : { left: 0, width: 0 };
      return (ev.clientX - rect.left) * (rect.width ? W / rect.width : 1);
    };
    var griffNav = Math.max(6, PW * 0.02);                         // Griffzone an den Fensterraendern
    var navModusBei = function (px) {
      var x0 = navX(t0), x1 = navX(t1);
      if (Math.abs(px - x0) <= griffNav) return 'links';
      if (Math.abs(px - x1) <= griffNav) return 'rechts';
      if (px >= x0 && px <= x1) return 'verschieben';
      return 'springen';
    };
    var navDrag = null;                                            // {modus, offset, t0, t1} waehrend des Ziehens
    navSvg.addEventListener('pointermove', function (ev) {
      if (navDrag) return;                                         // Cursor waehrend des Ziehens nicht neu bestimmen
      var m = navModusBei(navPxVonEvent(ev));
      navSvg.style.cursor = (m === 'links' || m === 'rechts') ? 'ew-resize' : (m === 'verschieben' ? 'grab' : 'pointer');
    });
    navSvg.addEventListener('pointerdown', function (ev) {
      if (ev.button !== 0) return;
      ev.preventDefault();
      var px = navPxVonEvent(ev), modus = navModusBei(px);
      if (modus === 'springen') {                                  // Klick ausserhalb des Fensters - dort zentrieren
        var breite = t1 - t0;
        var neuT0 = Math.max(basisT0, Math.min(basisT1 - breite, navZuT(px) - breite / 2));
        if (asin) {
          if (neuT0 <= basisT0 && neuT0 + breite >= basisT1) delete zoomState[asin];
          else zoomState[asin] = { t0: neuT0, t1: neuT0 + breite };
        }
        render(container, all, ui, asin, dims);
        return;
      }
      navDrag = { modus: modus, offset: modus === 'verschieben' ? navZuT(px) - t0 : 0 };
      try { navSvg.setPointerCapture(ev.pointerId); } catch (e) { /* egal */ }
      navSvg.style.cursor = modus === 'verschieben' ? 'grabbing' : 'ew-resize';
    });
    navSvg.addEventListener('pointermove', function (ev) {
      if (!navDrag) return;
      var px = navPxVonEvent(ev), breite = t1 - t0;
      var neuT0 = t0, neuT1 = t1;
      if (navDrag.modus === 'links') neuT0 = Math.min(t1 - 1000, Math.max(basisT0, navZuT(px)));
      else if (navDrag.modus === 'rechts') neuT1 = Math.max(t0 + 1000, Math.min(basisT1, navZuT(px)));
      else { neuT0 = Math.max(basisT0, Math.min(basisT1 - breite, navZuT(px) - navDrag.offset)); neuT1 = neuT0 + breite; }
      navWin.setAttribute('x', navX(neuT0).toFixed(1));
      navWin.setAttribute('width', Math.max(1, navX(neuT1) - navX(neuT0)).toFixed(1));
      navDrag.t0 = neuT0; navDrag.t1 = neuT1;
    });
    navSvg.addEventListener('pointerup', function (ev) {
      if (!navDrag) return;
      var geaendert = navDrag.t0 != null;
      var neuT0 = geaendert ? navDrag.t0 : t0, neuT1 = geaendert ? navDrag.t1 : t1;
      navDrag = null;
      try { navSvg.releasePointerCapture(ev.pointerId); } catch (e) { /* egal */ }
      if (!geaendert) return;                                      // reiner Klick, kein Ziehen - kein Zoom-Wechsel
      if (asin) {
        if (neuT0 <= basisT0 && neuT1 >= basisT1) delete zoomState[asin];
        else zoomState[asin] = { t0: neuT0, t1: neuT1 };
      }
      render(container, all, ui, asin, dims);
    });

    // -- Zeile unter dem Chart: Zusammenfassung, bei Hover die naechste Messung
    var span = function (sc, fmt) { return sc ? (sc.mn === sc.mx ? fmt(sc.mn) : fmt(sc.mn) + '–' + fmt(sc.mx)) : '–'; };
    var teile = [];
    if (sichtbar.preis) teile.push('Buybox ' + span(minmax(werte(1)), ui.eur));
    if (sichtbar.angebot) teile.push('Angebot min. ' + span(minmax(werte(5)), ui.eur));
    if (sichtbar.bsr) teile.push('BSR ' + span(bs, ui.nf));
    if (sichtbar.anbieter) teile.push('Anbieter ' + span(anbieterSkala, ui.nf));
    if (sichtbar.bestand) teile.push('Bestand ' + span(bestandSkala, ui.nf));
    var zusammen = pts.length + ' Messungen seit ' + ui.tag(new Date(t0)) + (teile.length ? ' · ' + teile.join(' · ') : '') + hinweis;
    var info = ui.el('div', 'a-size-mini lc-k lc-chart-info', ui.esc(zusammen));
    info.title = 'Nur eigene Aufrufe dieser Seite (kein Crawl). Maus über den Chart zeigt die einzelne Messung, ziehen zoomt, Mausrad zoomt um den Cursor.';
    container.appendChild(info);

    var xVonEvent = function (ev) {
      var rect = svg.getBoundingClientRect ? svg.getBoundingClientRect() : { left: 0, width: 0 };
      return (ev.clientX - rect.left) * (rect.width ? W / rect.width : 1);
    };
    svg.addEventListener('mousemove', function (ev) {
      var xv = xVonEvent(ev);
      var best = pts[0], bd = Infinity;
      pts.forEach(function (s) { var d = Math.abs(x(s) - xv); if (d < bd) { bd = d; best = s; } });
      if (!best) return;
      hover.setAttribute('x1', x(best).toFixed(1)); hover.setAttribute('x2', x(best).toFixed(1)); hover.setAttribute('visibility', 'visible');
      var teileHover = [];
      if (sichtbar.preis && best[1] != null) teileHover.push('Buybox ' + ui.eur(best[1]));
      if (sichtbar.angebot && best[5] != null) teileHover.push('Angebot min. ' + ui.eur(best[5]));
      if (sichtbar.bsr && best[2] != null) teileHover.push('BSR ' + ui.nf(best[2]));
      if (sichtbar.anbieter && best[4] != null) teileHover.push('Anbieter ' + ui.nf(best[4]));
      if (sichtbar.bestand && best[6] != null) teileHover.push('Bestand ' + ui.nf(best[6]));
      info.textContent = datum(ui, t(best)) + (teileHover.length ? ' · ' + teileHover.join(' · ') : '') +
        (best[3] === 2 ? ' · Buybox unterdrückt' : '');
    });
    svg.addEventListener('mouseleave', function () { hover.setAttribute('visibility', 'hidden'); info.textContent = zusammen; });

    // -- Zoom: Drag-Auswahl (Pointer Capture -> braucht keinen document-Listener,
    // stirbt automatisch mit dem SVG beim naechsten Neuaufbau)
    var dragVon = null;
    var schwelle = Math.max(4, PW * 0.01);
    svg.addEventListener('pointerdown', function (ev) {
      if (ev.button !== 0) return;
      ev.preventDefault();
      dragVon = xVonEvent(ev);
      try { svg.setPointerCapture(ev.pointerId); } catch (e) { /* egal */ }
      auswahl.setAttribute('x', dragVon.toFixed(1)); auswahl.setAttribute('width', '0'); auswahl.setAttribute('visibility', 'visible');
    });
    svg.addEventListener('pointermove', function (ev) {
      if (dragVon == null) return;
      var cur = xVonEvent(ev);
      var lo = Math.min(dragVon, cur), hi = Math.max(dragVon, cur);
      auswahl.setAttribute('x', lo.toFixed(1)); auswahl.setAttribute('width', (hi - lo).toFixed(1));
    });
    svg.addEventListener('pointerup', function (ev) {
      if (dragVon == null) return;
      var von = dragVon, cur = xVonEvent(ev);
      dragVon = null;
      auswahl.setAttribute('visibility', 'hidden');
      try { svg.releasePointerCapture(ev.pointerId); } catch (e) { /* egal */ }
      if (Math.abs(cur - von) < schwelle) return;                 // Klick, kein Zoom
      var tA = Math.max(basisT0, xZuT(Math.min(von, cur)));
      var tB = Math.min(basisT1, xZuT(Math.max(von, cur)));
      if (tB - tA < 1000) return;                                 // Mindestfenster 1s
      if (asin) zoomState[asin] = { t0: tA, t1: tB };
      render(container, all, ui, asin, dims);
    });
    svg.addEventListener('dblclick', function (ev) {
      ev.preventDefault();
      if (asin && zoomState[asin]) { delete zoomState[asin]; render(container, all, ui, asin, dims); }
    });
    svg.addEventListener('wheel', function (ev) {
      ev.preventDefault();
      var tCursor = xZuT(xVonEvent(ev));
      var faktor = ev.deltaY < 0 ? 0.8 : 1.25;                     // rauf = rein, runter = raus
      var neuT0 = Math.max(basisT0, tCursor - (tCursor - t0) * faktor);
      var neuT1 = Math.min(basisT1, tCursor + (t1 - tCursor) * faktor);
      if (neuT1 - neuT0 < 1000) return;
      if (asin) {
        if (neuT0 <= basisT0 && neuT1 >= basisT1) delete zoomState[asin];
        else zoomState[asin] = { t0: neuT0, t1: neuT1 };
      }
      render(container, all, ui, asin, dims);
    }, { passive: false });

    // Overlay-Inhalt darf kein data-lc tragen - sonst greift onpage.js' abraeumen()
    // (document.querySelectorAll('[data-lc]')) beim naechsten Panel-Neuaufbau durch
    // und reisst das offene Popup leer, obwohl es gar nicht im Panel haengt.
    if (dims.overlay) {
      container.querySelectorAll('[data-lc]').forEach(function (n) { n.removeAttribute('data-lc'); });
    }
  }

  /* Optional: H10-BSR-Historie holen und als (unsichtbar in Preis, aber sichtbar in BSR) synthetische
     Samples einmischen. Nur wenn Toggle an. Cache 24 h. */
  function mitH10(asin, samples) {
    if (!LC.h10 || !LC.h10.ready) return Promise.resolve(samples);
    return LC.h10.ready().then(function (login) {
      if (!login) return samples;
      return LC.h10.cache('bsrchart:' + asin, 24 * 60, function () { return LC.h10.bsrChart(asin, 'amazon.de', { fullHistory: true }); }).then(function (res) {
        if (!res || !res.ok) return samples;
        var arr = (res.data && res.data.results && (res.data.results.bsrHistory || res.data.results.bsrChart)) || [];
        var extra = arr.map(function (x) {
          // bsr-chart liefert {start,end,value} (shared/h10.js); Sekunden oder Millisekunden tolerieren
          var ts = x.timestamp || x.date || x.start || x.end; if (typeof ts === 'string') ts = Date.parse(ts) / 1000;
          if (ts > 1e11) ts = ts / 1000;
          if (!ts || x.value == null) return null;
          return [new Date(ts * 1000).toISOString(), null, x.value, 0, null, null];   // preis=null -> ignoriert; nur BSR
        }).filter(Boolean);
        if (!extra.length) return samples;
        var alle = samples.concat(extra).sort(function (a, b) { return Date.parse(a[0]) - Date.parse(b[0]); });
        return alle;
      }).catch(function () { return samples; });
    });
  }

  H.chart = function (container, samples, ui) {
    if (!container || !ui) return;
    var pts = (samples || []).filter(function (s) { return s && s[0] && (s[1] != null || s[2] != null); });
    container.innerHTML = '';
    if (pts.length < 2) {
      container.appendChild(ui.el('span', 'lc-k', pts.length + ' Messung – die Kurve entsteht mit jedem Aufruf dieser Seite'));
      return;
    }
    var asin = document.querySelector('#ASIN, input[name="ASIN"]');
    asin = asin ? (asin.value || asin.getAttribute('value')) : (location.pathname.match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})/) || [])[1];
    var renderMit = function (all) { render(container, all, ui, asin); };
    var run = function (pts2) { if (range != null) renderMit(pts2); else { try { chrome.storage.local.get('lcChartRange', function (d) { range = d && d.lcChartRange || 'alles'; renderMit(pts2); }); } catch (e) { range = 'alles'; renderMit(pts2); } } };
    if (asin && LC.h10 && LC.h10.ready) mitH10(asin, pts).then(run);
    else run(pts);                                                // ohne H10 sofort synchron rendern
  };
})();
