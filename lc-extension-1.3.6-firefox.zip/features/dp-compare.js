/* ASIN-Vergleicher (nach Helium10 "Cerebro Compare"/Keepa "Compare"): bis zu
   vier ASINs nebeneinander stellen und die kaufentscheidenden Felder
   gegenueberstellen (Titel, Preis, BSR, Bewertung, Bullets/Bilder-Anzahl, A+,
   EAN, Marke). Aktuelle Seite liefert ihre Werte live aus ctx.row; fuer die
   uebrigen ASINs kommen die Werte aus dem lokalen Listing-Speicher (rows[],
   gefuellt durch "Listing erfassen") - fehlt eine ASIN, steht "erfassen" als
   Hinweis in der Zelle. Speicher: chrome.storage.local "compare" = [asin,...].
   Keine Requests, keine Rechte. Nur ui.el/ui.chip (data-lc, Scrape-Filter). */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];

  var MAX = 4;
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  var kurz = function (s, n) { s = clean(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
  var mdEsc = function (s) { return String(s == null ? '' : s).replace(/\|/g, '\\|').replace(/\r?\n+/g, ' '); };

  var listener = null, aktiv = null;

  /* EIN Listener modulweit: andere Tabs/Popup aendern "compare" -> neu zeichnen.
     Nur wenn die sichtbare Produktseite noch dieselbe ASIN zeigt. */
  function hoeren(ui) {
    if (listener) return;
    listener = function (ch, area) {
      if (area !== 'local' || (!ch.compare && !ch.rows)) return;
      if (aktiv && ui.aktuelleAsin() === aktiv.asin) aktiv.render();
    };
    try { chrome.storage.onChanged.addListener(listener); } catch (e) { listener = null; }
  }

  /* Werte pro ASIN: aktuelle Seite hat Vorrang (live), sonst rows[<asin>].
     Feld fehlt oder Datensatz fehlt -> null. */
  function feld(x, key) {
    if (!x) return null;
    var v = x[key];
    return v == null || v === '' ? null : v;
  }

  var SPALTEN = [
    { key: 'titel', label: 'Titel', text: function (x) { return x && x.titel ? kurz(x.titel, 60) : null; } },
    { key: 'preis', label: 'Preis', text: function (x, ui) { var v = feld(x, 'preis'); return v == null ? null : ui.eur(Number(v)); }, mono: true },
    { key: 'bsr', label: 'BSR', text: function (x, ui) { var v = feld(x, 'bsr'); return v == null ? null : ui.nf(Number(v)); } },
    { key: 'bewertung', label: 'Ø ★', text: function (x) {
      var bw = feld(x, 'bewertung'); if (!bw) return null;
      var n = feld(x, 'anzahl_bewertungen');
      return bw + ' ★ (' + (n || '?') + ')';
    } },
    { key: 'bullets_anzahl', label: 'Bullets', text: function (x) { var v = feld(x, 'bullets_anzahl'); return v == null ? null : String(v); } },
    { key: 'bilder_anzahl', label: 'Bilder', text: function (x) { var v = feld(x, 'bilder_anzahl'); return v == null ? null : String(v); } },
    { key: 'aplus', label: 'A+', text: function (x) { return feld(x, 'aplus'); } },
    { key: 'ean', label: 'EAN', text: function (x) { return feld(x, 'ean'); }, mono: true },
    { key: 'marke', label: 'Marke', text: function (x) { return feld(x, 'marke'); } }
  ];

  function tabelle(list, byAsin, ui) {
    var tab = ui.el('table', 'lc-cmp a-spacing-top-mini');
    // Kopfzeile: leere Ecke + ASIN pro Spalte (mono, verlinkt auf /dp/)
    var thead = ui.el('tr');
    thead.appendChild(ui.el('th', 'lc-k'));
    list.forEach(function (a) {
      thead.appendChild(ui.el('th', 'a-text-left',
        '<a class="a-link-normal lc-mono" href="/dp/' + ui.esc(a) + '">' + ui.esc(a) + '</a>'));
    });
    tab.appendChild(thead);
    SPALTEN.forEach(function (sp) {
      var tr = ui.el('tr');
      tr.appendChild(ui.el('th', 'a-text-left lc-k', ui.esc(sp.label)));
      list.forEach(function (a) {
        var x = byAsin[a];
        var t = sp.text(x, ui);
        var td = ui.el('td');
        if (t == null) {
          td.innerHTML = x && Object.keys(x).length
            ? '<span class="lc-k">–</span>'
            : '<span class="lc-k">erfassen</span>';
        } else {
          td.innerHTML = sp.mono ? '<span class="lc-mono">' + ui.esc(t) + '</span>' : ui.esc(t);
        }
        tr.appendChild(td);
      });
      tab.appendChild(tr);
    });
    return tab;
  }

  function markdown(list, byAsin, ui) {
    var head = '| Feld ' + list.map(function (a) { return '| ' + mdEsc(a); }).join(' ') + ' |';
    var sep = '|---' + list.map(function () { return '|---'; }).join('') + '|';
    var body = SPALTEN.map(function (sp) {
      var cells = list.map(function (a) {
        var t = sp.text(byAsin[a], ui);
        return '| ' + (t == null ? '' : mdEsc(t));
      }).join(' ');
      return '| ' + mdEsc(sp.label) + ' ' + cells + ' |';
    }).join('\n');
    return head + '\n' + sep + '\n' + body;
  }

  H.panel.push(function (ctx) {
    var ui = ctx.ui;
    if (!ui || !ctx.asin || typeof ctx.sec !== 'function') return;
    var asin = ctx.asin, r = ctx.row || {};
    hoeren(ui);
    var box = ctx.sec('Vergleich', 'twister');

    /* Schnappschuss der Vergleichsfelder je ASIN unter cmp:<ASIN>. Ohne ihn waren
       die Werte der ersten ASIN weg, sobald man die zweite Seite oeffnete: die
       Liste hatte nur ASINs, und rows[] ist nur gefuellt, wenn man im Popup
       "Diese Seite erfassen" geklickt hat (und dort heisst die ASIN produkt_id). */
    var snapshot = function (x) {
      var o = {};
      SPALTEN.forEach(function (sp) { if (x[sp.key] != null) o[sp.key] = x[sp.key]; });
      if (x.anzahl_bewertungen != null) o.anzahl_bewertungen = x.anzahl_bewertungen;
      return o;
    };
    var render = function () {
      ui.storage('compare').then(function (d0) {
        var list = (Array.isArray(d0.compare) ? d0.compare : []).slice(0, MAX);
        return ui.storage(['rows'].concat(list.map(function (a) { return 'cmp:' + a; }))).then(function (d) {
          d.compare = list; return d;
        });
      }).then(function (d) {
        if (ui.aktuelleAsin() !== asin || !box.isConnected) return;
        var list = d.compare;
        var byAsin = {};
        (Array.isArray(d.rows) ? d.rows : []).forEach(function (x) {
          var a = x && (x.asin || x.produkt_id);
          if (a && !byAsin[a]) byAsin[a] = x;
        });
        list.forEach(function (a) { if (d['cmp:' + a]) byAsin[a] = d['cmp:' + a]; });   // Schnappschuss vor rows
        byAsin[asin] = r;    // live vor gespeichert
        // Selbstheilung: ASIN steht im Vergleich (z. B. vor dem Fix hinzugefuegt), hat aber
        // keinen Schnappschuss -> jetzt, wo ihre Seite offen ist, nachtragen.
        if (list.indexOf(asin) >= 0 && !d['cmp:' + asin]) {
          var heal = {}; heal['cmp:' + asin] = snapshot(r);
          ui.storageSet(heal).catch(function (e) { console.warn('[LC] Vergleich reparieren', e); });
        }

        box.innerHTML = '';
        var drin = list.indexOf(asin) >= 0;
        var voll = !drin && list.length >= MAX;
        var kopf = ui.el('div', 'a-section lc-row');

        var addChip = ui.chip(
          drin ? '☒ im Vergleich' : ('☐ zu Vergleich hinzufügen (' + list.length + '/' + MAX + ')'),
          drin ? 'ok' : (list.length ? 'mut' : 'bad'),
          drin ? 'aus dem Vergleich nehmen'
               : (voll ? 'Vergleich voll – max. ' + MAX + ' ASINs' : 'diese ASIN zum Vergleich hinzufügen')
        );
        addChip.classList.add('lc-copy');
        if (voll) addChip.style.opacity = '0.6';
        addChip.addEventListener('click', function (ev) {
          ev.preventDefault(); ev.stopPropagation();
          if (voll) return;
          var neu = drin ? list.filter(function (a) { return a !== asin; })
                         : list.concat([asin]);
          if (drin) {
            ui.storageRemove('cmp:' + asin).then(function () { return ui.storageSet({ compare: neu }); })
              .catch(function (e) { console.warn('[LC] Vergleich entfernen', e); });
          } else {
            var o = { compare: neu }; o['cmp:' + asin] = snapshot(r);
            ui.storageSet(o).catch(function (e) { console.warn('[LC] Vergleich speichern', e); });
          }
        });
        kopf.appendChild(addChip);

        if (list.length) {
          var mdChip = ui.chip('als Markdown kopieren', 'mut', 'Vergleichstabelle als Markdown in die Zwischenablage');
          mdChip.classList.add('lc-copy');
          mdChip.addEventListener('click', function (ev) {
            ev.preventDefault(); ev.stopPropagation();
            var text = markdown(list, byAsin, ui);
            if (navigator.clipboard && navigator.clipboard.writeText) {
              navigator.clipboard.writeText(text).then(function () {
                mdChip.innerHTML = 'kopiert ✓';
                setTimeout(function () { mdChip.innerHTML = 'als Markdown kopieren'; }, 1200);
              }).catch(function () { /* keine Zwischenablage */ });
            }
          });
          kopf.appendChild(mdChip);

          var leerChip = ui.chip('leeren', 'mut', 'Vergleich zurücksetzen');
          leerChip.classList.add('lc-copy');
          leerChip.addEventListener('click', function (ev) {
            ev.preventDefault(); ev.stopPropagation();
            ui.storageRemove(list.map(function (a) { return 'cmp:' + a; }))
              .then(function () { return ui.storageSet({ compare: [] }); })
              .catch(function (e) { console.warn('[LC] Vergleich leeren', e); });
          });
          kopf.appendChild(leerChip);
        }
        box.appendChild(kopf);

        if (list.length) box.appendChild(tabelle(list, byAsin, ui));
      }).catch(function (e) { console.warn('[LC] Compare', e); });
    };

    aktiv = { asin: asin, render: render };
    render();
  });
})();
