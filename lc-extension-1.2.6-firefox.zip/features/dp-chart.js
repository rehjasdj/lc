/* Verlaufs-Chart (Keepa-artig) fuer die Karte auf der Produktseite - ersetzt die
   Mini-Sparkline aus onpage.js ueber LC.onpage.chart(container, samples, ui).

   samples = [[iso, preis, bsr, buyboxCode, anbieter, angebotMin], ...] aus dem
   lokalen Verlauf (hist:<ASIN>, background.js). buyboxCode 2 = Buybox unterdrueckt.
     - Preis: Linie #C7511F mit Flaeche, linke Achse (min/max)
     - guenstigstes Angebot der AOD-Liste (ALLE Anbieter inkl. eigener/gebraucht,
       so bildet onpage.js angebotMin): duenne Linie #007185 auf der Preisachse
     - BSR: gestrichelt #8D9096, rechte Achse INVERTIERT (kleiner Rang oben)
     - rote Punkte, wo die Buybox unterdrueckt war
   Zeitraum 30/90/Alles (chrome.storage.local lcChartRange), Hover zeigt die
   naechste Messung unter dem Chart. Keine Requests, kein eigenes CSS: Texte mit
   fill="currentColor", Gitter mit stroke="currentColor" -> Dark Mode gratis. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};

  var NS = 'http://www.w3.org/2000/svg';
  var W = 400, H_ = 200, PL = 58, PR = 48, PT = 8, PB = 18;      // viewBox 400x200 -> bei 300 px Breite ~150 px hoch
  var PH = H_ - PT - PB, PW = W - PL - PR;
  var RANGES = [['30', '30 Tage'], ['90', '90 Tage'], ['alles', 'Alles']];
  var range = null;                                               // null = noch nicht aus dem Speicher gelesen

  var sv = function (tag, attrs) {
    var e = document.createElementNS(NS, tag);
    for (var k in attrs) if (attrs[k] != null) e.setAttribute(k, attrs[k]);
    return e;
  };
  var t = function (s) { return Date.parse(s[0]); };
  var datum = function (ui, ms) { var d = new Date(ms); return ui.tag(d) + d.getFullYear(); };

  function render(container, all, ui) {
    container.innerHTML = '';
    var tage = { '30': 30, '90': 90 }[range];
    var pts = tage ? all.filter(function (s) { return t(s) >= Date.now() - tage * 864e5; }) : all;
    var hinweis = '';
    if (pts.length < 2) { hinweis = ' · im Zeitraum nur ' + pts.length + ' Messung, daher alles'; pts = all; }

    // -- Zeitraum-Links
    var row = ui.el('div', 'a-size-small lc-chart-range');
    RANGES.forEach(function (r, i) {
      if (i) row.appendChild(document.createTextNode(' · '));
      var a = ui.el('a', 'a-link-normal' + (r[0] === range ? ' a-text-bold' : ''), r[1]);
      a.href = '#'; a.title = 'Verlauf der letzten ' + (r[0] === 'alles' ? 'Aufrufe komplett' : r[1]) + ' zeigen';
      a.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        range = r[0];
        try { chrome.storage.local.set({ lcChartRange: range }); } catch (e) { /* Speicher weg - egal */ }
        render(container, all, ui);
      });
      row.appendChild(a);
    });
    container.appendChild(row);

    // -- Skalen
    var t0 = t(pts[0]), t1 = Math.max(t0 + 1, t(pts[pts.length - 1]));
    var x = function (s) { return PL + PW * (t(s) - t0) / (t1 - t0); };
    var minmax = function (vals) { return vals.length ? { mn: Math.min.apply(null, vals), mx: Math.max.apply(null, vals) } : null; };
    var werte = function (idx) { return pts.map(function (s) { return s[idx]; }).filter(function (v) { return v != null; }); };
    var pr = minmax(werte(1).concat(werte(5)));                  // Preis + Fremdangebot auf einer Achse
    var bs = minmax(werte(2));
    var yOf = function (sc, invert) {
      return function (v) {
        var f = sc.mx === sc.mn ? 0.5 : (v - sc.mn) / (sc.mx - sc.mn);
        if (invert) f = 1 - f;
        return PT + PH * (1 - f);
      };
    };
    var yPr = pr ? yOf(pr, false) : null, yBs = bs ? yOf(bs, true) : null;
    var pfad = function (idx, y) {
      var v = pts.filter(function (s) { return s[idx] != null; });
      if (v.length < 2) return '';
      return v.map(function (s, i) { return (i ? 'L' : 'M') + x(s).toFixed(1) + ' ' + y(s[idx]).toFixed(1); }).join(' ');
    };

    // -- SVG
    var svg = sv('svg', { viewBox: '0 0 ' + W + ' ' + H_, 'data-lc': '1', class: 'lc-chart' });
    svg.setAttribute('style', 'display:block;width:100%;height:auto;margin-top:2px;cursor:crosshair');
    for (var g = 1; g <= 3; g++) {                                // feines Gitter, 3 Linien
      var gy = (PT + PH * g / 4).toFixed(1);
      svg.appendChild(sv('line', { x1: PL, x2: W - PR, y1: gy, y2: gy, stroke: 'currentColor', opacity: '.15', 'stroke-width': '1' }));
    }
    var dPr = yPr ? pfad(1, yPr) : '';
    if (dPr) {
      var v1 = pts.filter(function (s) { return s[1] != null; });
      svg.appendChild(sv('path', { d: dPr + ' L' + x(v1[v1.length - 1]).toFixed(1) + ' ' + (PT + PH) + ' L' + x(v1[0]).toFixed(1) + ' ' + (PT + PH) + ' Z',
        fill: '#C7511F', opacity: '.12', stroke: 'none', class: 'lc-chart-area' }));
    }
    var dBs = yBs ? pfad(2, yBs) : '';
    if (dBs) svg.appendChild(sv('path', { d: dBs, fill: 'none', stroke: '#8D9096', 'stroke-width': '1.5', 'stroke-dasharray': '4 3', class: 'lc-chart-bsr' }));
    var dAn = yPr ? pfad(5, yPr) : '';
    if (dAn) svg.appendChild(sv('path', { d: dAn, fill: 'none', stroke: '#007185', 'stroke-width': '1', class: 'lc-chart-angebot' }));
    if (dPr) svg.appendChild(sv('path', { d: dPr, fill: 'none', stroke: '#C7511F', 'stroke-width': '2', 'stroke-linejoin': 'round', class: 'lc-chart-preis' }));
    pts.forEach(function (s) {
      if (s[3] !== 2) return;
      var c = sv('circle', { cx: x(s).toFixed(1), cy: (yPr && s[1] != null ? yPr(s[1]) : PT + PH / 2).toFixed(1), r: '4', fill: '#B12704', class: 'lc-chart-bb' });
      var ti = sv('title'); ti.textContent = 'Buybox unterdrückt ' + datum(ui, t(s)); c.appendChild(ti);
      svg.appendChild(c);
    });
    // Achsentexte: fill=currentColor, damit Dark Mode nichts ueberschreiben muss
    var text = function (str, tx, ty, anchor) {
      var e = sv('text', { x: tx, y: ty, fill: 'currentColor', 'text-anchor': anchor, class: 'a-size-mini lc-chart-label' });
      e.textContent = str; return e;
    };
    if (pr) { svg.appendChild(text(ui.eur(pr.mx), 2, PT + 10, 'start')); svg.appendChild(text(ui.eur(pr.mn), 2, PT + PH, 'start')); }
    if (bs) { svg.appendChild(text(ui.nf(bs.mn), W - 2, PT + 10, 'end')); svg.appendChild(text(ui.nf(bs.mx), W - 2, PT + PH, 'end')); }
    svg.appendChild(text(ui.tag(new Date(t0)), PL, H_ - 4, 'start'));
    svg.appendChild(text(ui.tag(new Date((t0 + t1) / 2)), PL + PW / 2, H_ - 4, 'middle'));
    svg.appendChild(text(ui.tag(new Date(t1)), PL + PW, H_ - 4, 'end'));
    var hover = sv('line', { y1: PT, y2: PT + PH, x1: PL, x2: PL, stroke: 'currentColor', opacity: '.5', 'stroke-dasharray': '2 2', visibility: 'hidden', class: 'lc-chart-hover' });
    svg.appendChild(hover);
    container.appendChild(svg);

    // -- Zeile unter dem Chart: Zusammenfassung, bei Hover die naechste Messung
    var span = function (sc, fmt) { return sc ? (sc.mn === sc.mx ? fmt(sc.mn) : fmt(sc.mn) + '–' + fmt(sc.mx)) : '–'; };
    var zusammen = pts.length + ' Messungen seit ' + ui.tag(new Date(t0)) + ' · Preis ' + span(pr, ui.eur) + ' · BSR ' + span(bs, ui.nf) + hinweis;
    var info = ui.el('div', 'a-size-mini lc-k lc-chart-info', ui.esc(zusammen));
    info.title = 'Nur eigene Aufrufe dieser Seite (kein Crawl). Maus über den Chart zeigt die einzelne Messung.';
    container.appendChild(info);
    svg.addEventListener('mousemove', function (ev) {
      var rect = svg.getBoundingClientRect ? svg.getBoundingClientRect() : { left: 0, width: 0 };
      var xv = (ev.clientX - rect.left) * (rect.width ? W / rect.width : 1);
      var best = pts[0], bd = Infinity;
      pts.forEach(function (s) { var d = Math.abs(x(s) - xv); if (d < bd) { bd = d; best = s; } });
      hover.setAttribute('x1', x(best).toFixed(1)); hover.setAttribute('x2', x(best).toFixed(1)); hover.setAttribute('visibility', 'visible');
      info.textContent = datum(ui, t(best)) + ' · Preis ' + ui.eur(best[1]) + ' · BSR ' + ui.nf(best[2]) +
        (best[4] != null ? ' · ' + best[4] + ' Anbieter' : '') +
        (best[5] != null ? ' · günstigstes Angebot (alle Anbieter) ' + ui.eur(best[5]) : '') +
        (best[3] === 2 ? ' · Buybox unterdrückt' : '');
    });
    svg.addEventListener('mouseleave', function () { hover.setAttribute('visibility', 'hidden'); info.textContent = zusammen; });
  }

  /* Optional: H10-BSR-Historie holen und als (unsichtbar in Preis, aber sichtbar in BSR) synthetische
     Samples einmischen. Nur wenn Toggle an. Cache 24 h. */
  function mitH10(asin, samples) {
    if (!LC.h10 || !LC.h10.ready) return Promise.resolve(samples);
    return LC.h10.ready().then(function (login) {
      if (!login) return samples;
      return LC.h10.cache('bsrchart:' + asin, 24 * 60, function () { return LC.h10.bsrChart(asin, 'amazon.de', { fullHistory: true }); }).then(function (res) {
        if (!res || !res.ok) return samples;
        var arr = (res.data && res.data.results && (res.data.results.bsrHistory || res.data.results.bsrChart)) || [];
        var extra = arr.map(function (x) {
          // bsr-chart liefert {start,end,value} (shared/h10.js); Sekunden oder Millisekunden tolerieren
          var ts = x.timestamp || x.date || x.start || x.end; if (typeof ts === 'string') ts = Date.parse(ts) / 1000;
          if (ts > 1e11) ts = ts / 1000;
          if (!ts || x.value == null) return null;
          return [new Date(ts * 1000).toISOString(), null, x.value, 0, null, null];   // preis=null -> ignoriert; nur BSR
        }).filter(Boolean);
        if (!extra.length) return samples;
        var alle = samples.concat(extra).sort(function (a, b) { return Date.parse(a[0]) - Date.parse(b[0]); });
        return alle;
      }).catch(function () { return samples; });
    });
  }

  H.chart = function (container, samples, ui) {
    if (!container || !ui) return;
    var pts = (samples || []).filter(function (s) { return s && s[0] && (s[1] != null || s[2] != null); });
    container.innerHTML = '';
    if (pts.length < 2) {
      container.appendChild(ui.el('span', 'lc-k', pts.length + ' Messung – die Kurve entsteht mit jedem Aufruf dieser Seite'));
      return;
    }
    var renderMit = function (all) { render(container, all, ui); };
    var asin = document.querySelector('#ASIN, input[name="ASIN"]');
    asin = asin ? (asin.value || asin.getAttribute('value')) : (location.pathname.match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})/) || [])[1];
    var run = function (pts2) { if (range != null) renderMit(pts2); else { try { chrome.storage.local.get('lcChartRange', function (d) { range = d && d.lcChartRange || 'alles'; renderMit(pts2); }); } catch (e) { range = 'alles'; renderMit(pts2); } } };
    if (asin && LC.h10 && LC.h10.ready) mitH10(asin, pts).then(run);
    else run(pts);                                                // ohne H10 sofort synchron rendern
  };
})();
