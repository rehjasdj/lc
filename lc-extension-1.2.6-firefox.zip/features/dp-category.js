/* Deep-Dive der Bestseller-Kategorie: einen Klick-Chip neben unserem BSR-Chip
   an der Breadcrumb der Hauptkategorie ("Top 10 anzeigen"). Klick -> same-origin
   Fetch der Bestseller-Liste, DOMParser, erste 10 Kacheln
   (.zg-grid-general-faceout / [data-testid="grid-deal-card"]), Sektion unter
   "Info zu diesem Artikel" mit Titel-Link/Preis/Sterne, Kopfzeile mit
   Preis-Median und Marken-Top-3. Cache 24 h in "topcat:<hrefslug>".
   Captcha -> Chip wird zu "Amazon bremst" (bad). Nur bei sichtbarem Tab.
   Rechte: keine neuen (amazon.de freigegeben). */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];

  var TTL = 24 * 60 * 60 * 1000;
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  // Preis: "32,99 €" / "1.234,50 €" -> 32.99 / 1234.50
  var num = function (s) {
    var m = String(s == null ? '' : s).match(/([\d\.]+),(\d+)/);
    if (!m) return null;
    var n = parseFloat(m[1].replace(/\./g, '') + '.' + m[2]);
    return isFinite(n) ? n : null;
  };
  // Slug: /ref=... und Query weg, Host weg -> stabiler Cache-Schluessel
  var slug = function (href) {
    return String(href || '').split('?')[0].replace(/\/ref=[^/]*\/?$/, '').replace(/^https?:\/\/[^/]+/, '');
  };

  function parseTiles(html) {
    if (/captcha|validateCaptcha|automatische Zugriffe/i.test(html)) throw new Error('captcha');
    var doc = new DOMParser().parseFromString(html, 'text/html');
    var tiles = doc.querySelectorAll('.zg-grid-general-faceout, [data-testid="grid-deal-card"]');
    var out = [];
    for (var i = 0; i < tiles.length && out.length < 10; i++) {
      var t = tiles[i];
      var link = t.querySelector('a[href*="/dp/"]');
      var m = link && (link.getAttribute('href') || '').match(/\/dp\/([A-Z0-9]{10})/i);
      if (!m) continue;
      // Titel: Amazons Truncate-Span oder title-Attribut, sonst Link-Text
      var titelEl = t.querySelector('.p13n-sc-truncate-desktop-type2, ._cDEzb_p13n-sc-css-line-clamp-4_2q2cKs, a[href*="/dp/"] div[title], a[href*="/dp/"] span');
      var titel = clean((titelEl && titelEl.getAttribute && titelEl.getAttribute('title')) || (titelEl && titelEl.textContent) || link.getAttribute('title') || link.textContent);
      var preisTxt = clean((t.querySelector('.p13n-sc-price, ._cDEzb_p13n-sc-price_3mJ9Z, .a-color-price') || {}).textContent);
      var starsEl = t.querySelector('.a-icon-alt, [aria-label*="Sterne"]');
      var starsTxt = clean((starsEl && (starsEl.getAttribute('aria-label') || starsEl.textContent)) || '');
      var sm = starsTxt.match(/(\d[.,]\d)/);
      // Marke: "von X" gewinnt, sonst erstes Wort des Titels
      var brandMatch = clean(t.textContent).match(/\bvon\s+([A-ZÄÖÜ][\w\-]+(?:\s+[A-ZÄÖÜ][\w\-]+)?)/);
      var brand = brandMatch ? brandMatch[1] : (titel.split(/\s+/)[0] || '');
      out.push({
        asin: m[1].toUpperCase(),
        titel: titel,
        preis: num(preisTxt),
        sterne: sm ? parseFloat(sm[1].replace(',', '.')) : null,
        marke: brand
      });
    }
    return out;
  }

  function rendern(ui, ctx, kat, items, trig) {
    var box = typeof ctx.sec === 'function' ? ctx.sec('Top 10 in ' + kat, 'bullets') : null;
    if (!box) { trig.textContent = 'kein Andockpunkt'; return; }
    if (!items.length) { box.innerHTML = '<span class="lc-k">keine Kacheln gefunden</span>'; trig.textContent = 'leer'; return; }
    var preise = items.map(function (x) { return x.preis; }).filter(function (p) { return p != null; }).sort(function (a, b) { return a - b; });
    var median = preise.length ? preise[Math.floor(preise.length / 2)] : null;
    var markZ = {};
    items.forEach(function (x) { if (x.marke) markZ[x.marke] = (markZ[x.marke] || 0) + 1; });
    var top3 = Object.keys(markZ).sort(function (a, b) { return markZ[b] - markZ[a]; }).slice(0, 3)
      .map(function (m) { return m + ' ' + Math.round(100 * markZ[m] / items.length) + ' %'; });
    var head = ui.el('div', 'a-section a-spacing-mini lc-row');
    if (median != null) head.appendChild(ui.chip('<span class="lc-k">Preis-Median</span> ' + ui.esc(ui.eur(median)) +
      ' <span class="lc-k">(' + ui.esc(ui.eur(preise[0])) + '–' + ui.esc(ui.eur(preise[preise.length - 1])) + ')</span>',
      'mut', preise.length + ' Preise gelesen'));
    if (top3.length) head.appendChild(ui.chip('<span class="lc-k">Marken</span> ' + ui.esc(top3.join(' · ')), 'mut',
      'Top-3-Marken in den ersten ' + items.length + ' Kacheln'));
    box.appendChild(head);
    var list = ui.el('ul', 'lc-offers');
    items.forEach(function (x, idx) {
      var li = ui.el('li');
      var links = ui.el('span');
      var a = ui.el('a', 'a-link-normal', (idx + 1) + '. ' + ui.esc(x.titel || x.asin));
      a.href = '/dp/' + x.asin;
      links.appendChild(a);
      if (x.marke && ui.EIGEN.test(x.marke)) { links.appendChild(document.createTextNode(' ')); links.appendChild(ui.chip('EIGEN', 'ok', 'Eigene Marke: ' + x.marke)); }
      li.appendChild(links);
      var meta = ui.el('span', 'lc-mono', (x.preis != null ? ui.esc(ui.eur(x.preis)) : '<span class="lc-k">–</span>') +
        (x.sterne != null ? ' <span class="lc-k">' + x.sterne.toFixed(1).replace('.', ',') + ' ★</span>' : ''));
      li.appendChild(meta);
      list.appendChild(li);
    });
    box.appendChild(list);
    if (trig && trig.parentNode) trig.remove();
  }

  H.panel.push(function (ctx) {
    var ui = ctx.ui;
    if (!ui || !ctx.row || !ctx.row.bsr || !ctx.row.bsr_kategorie) return;
    if (typeof document.visibilityState === 'string' && document.visibilityState !== 'visible') return;

    var kat = clean(ctx.row.bsr_kategorie);
    // Passenden BSR-Chip in der Breadcrumb finden (Hauptkategorie)
    var lis = document.querySelectorAll('#wayfinding-breadcrumbs_feature_div li');
    var bsrChip = null, href = '';
    for (var i = 0; i < lis.length; i++) {
      var a = lis[i].querySelector('a:not(.lc-chip)');
      if (!a || clean(a.textContent).toLowerCase() !== kat.toLowerCase()) continue;
      bsrChip = lis[i].querySelector('a.lc-chip[href*="/gp/bestsellers/"]');
      if (bsrChip) { href = bsrChip.getAttribute('href') || ''; break; }
    }
    if (!bsrChip || !href) return;
    // Idempotent innerhalb desselben panel()-Laufs
    if (bsrChip.parentNode.querySelector('.lc-topcat-trigger')) return;

    var trig = ui.chip('Bestseller-Liste →', 'mut', 'Amazon-Bestseller-Kategorie in neuem Tab öffnen. Kacheln lädt Amazon clientseitig – deshalb kein Vorschau-Auszug hier; die Kopfzeile unserer Extension sammelt Preis-Median/Ø ★/Badges direkt auf der Zielseite.', href);
    trig.setAttribute('target', '_blank'); trig.setAttribute('rel', 'noopener');
    trig.classList.add('lc-topcat-trigger');
    bsrChip.insertAdjacentElement('afterend', trig);
    return;   // Kein fetch/parse mehr - Bestseller-Seite rendert Kacheln clientseitig, siehe onpage.js serp()

    var laufend = false;
    trig.addEventListener('click', function (ev) {
      ev.preventDefault(); ev.stopPropagation();
      if (laufend) return;
      laufend = true;
      trig.textContent = 'lädt …';
      trig.classList.remove('lc-copy');
      var key = 'topcat:' + slug(href);

      ui.storage(key).then(function (d) {
        var c = d && d[key];
        if (c && c.items && Date.now() - c.ts < TTL) return rendern(ui, ctx, kat, c.items, trig);
        return fetch(href, { credentials: 'same-origin' }).then(function (r) { return r.text(); }).then(function (html) {
          var items = parseTiles(html);
          var o = {}; o[key] = { ts: Date.now(), items: items };
          try { chrome.storage.local.set(o); } catch (e) { /* Speicher voll -> egal, wir zeigen trotzdem */ }
          rendern(ui, ctx, kat, items, trig);
        });
      }).catch(function (e) {
        if (e && e.message === 'captcha') {
          trig.className = 'lc-chip bad lc-topcat-trigger';
          trig.textContent = 'Amazon bremst';
        } else {
          console.warn('[LC] dp-category', e);
          trig.className = 'lc-chip bad lc-topcat-trigger';
          trig.textContent = 'Fehler';
        }
      });
    });
  });
})();
