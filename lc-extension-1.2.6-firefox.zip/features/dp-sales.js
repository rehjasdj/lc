/* Verkaufsschaetzer (nach Helium 10 "30-Day Sales" / Keepa "Monthly Sold"), aber
   ohne fremde Tabelle: Jede Produktseite mit Amazons Kaufzahl-Badge UND
   Hauptkategorie-BSR liefert ein (BSR, Kaufzahl)-Paar, gespeichert je
   Hauptkategorie in cal:<kategorie>. Fehlt das Badge, wird aus >= 5 Paaren eine
   Potenzfunktion (log-log-Fit) geschaetzt und als "geschaetzt" ausgewiesen.
   Die Kaufzahl ist ein Untergrenzen-Eimer ("200+"), die Schaetzung entsprechend
   grob - deshalb steht die Zahl der Paare immer daneben. Keine Rechte. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  var MAX = 300;

  // Amazons Badge: "50+ Mal im letzten Monat gekauft", "1 Tsd.+ Mal ..." - ui.KAUF_RE kennt Tsd./Mio.
  function kaufzahl(ui) {
    var t = clean((document.querySelector('#socialProofingAsinFaceout_feature_div, #socialProofingBadge_feature_div') || {}).textContent);
    var m = t.match(ui.KAUF_RE);
    return m ? ui.mapZahl(m[1], m[2]) : null;
  }
  function hauptkategorie(r) {
    var k = clean(r.bsr_kategorie) || clean(r.kategorie).split(/[>›»]/)[0];
    return k.toLowerCase();
  }
  function fit(pairs) {   // ln(kauf) = a + b*ln(bsr)
    var n = pairs.length, sx = 0, sy = 0, sxx = 0, sxy = 0;
    pairs.forEach(function (p) { var x = Math.log(p[0]), y = Math.log(p[1]); sx += x; sy += y; sxx += x * x; sxy += x * y; });
    var den = n * sxx - sx * sx;
    if (!den) return null;
    var b = (n * sxy - sx * sy) / den, a = (sy - b * sx) / n;
    return { a: a, b: b };
  }

  H.panel.push(function (ctx) {
    var ui = ctx.ui, r = ctx.row || {};
    if (!ui || !ctx.secQ || !ctx.asin) return;
    var bsr = parseInt(String(r.bsr == null ? '' : r.bsr).replace(/\D/g, ''), 10);
    var kat = hauptkategorie(r);
    if (!isFinite(bsr) || bsr <= 0 || !kat) return;
    var key = 'cal:' + kat, kz = kaufzahl(ui);
    ui.storage(key).then(function (d) {
      var tab = (d && d[key]) || {};
      if (kz != null) {
        /* Frisch lesen und nur den EIGENEN Eintrag setzen: cal:<kategorie> ist
           ein geteilter Key - zwei parallel offene Produktseiten derselben
           Kategorie ueberschrieben sich sonst gegenseitig (Review 31.08.). */
        var eintrag = [bsr, kz, Date.now()];
        ui.storage(key).then(function (d2) {
          var frisch = (d2 && d2[key]) || {};
          frisch[ctx.asin] = eintrag;
          var keys = Object.keys(frisch);
          if (keys.length > MAX) {
            keys.sort(function (x, y) { return frisch[x][2] - frisch[y][2]; }).slice(0, keys.length - MAX).forEach(function (k) { delete frisch[k]; });
          }
          var o = {}; o[key] = frisch; chrome.storage.local.set(o);
        });
        return;   // echte Kaufzahl zeigt dp-buybox.js schon
      }
      var pairs = Object.keys(tab).map(function (k) { return tab[k]; }).filter(function (p) { return p[0] > 0 && p[1] > 0; });
      if (pairs.length < 5) return;   // zu wenig Vergleichsdaten -> lieber nichts zeigen
      var f = fit(pairs);
      if (!f || f.b >= 0) return;   // steigende Kurve = Datenmuell, lieber nichts zeigen
      var est = Math.exp(f.a + f.b * Math.log(bsr));
      var rund = est >= 1000 ? Math.round(est / 100) * 100 : (est >= 100 ? Math.round(est / 10) * 10 : Math.round(est));
      ctx.secQ.appendChild(ui.chip('≈ ' + ui.nf(rund) + ' <span class="lc-k">/ Monat (geschätzt aus ' + pairs.length + ' Paaren)</span>', '',
        'BSR→Verkäufe-Schätzung aus gespeicherten (BSR, Kaufzahl)-Paaren der Hauptkategorie „' + kat + '" – Größenordnung, kein Messwert'));
    }).catch(function (e) { console.warn('[LC] Schätzer', e); });
  });
})();
