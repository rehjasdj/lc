/* Helium10-Zusatzdaten fuer die Produktseite - optionaler Andockpunkt.

   Standardmaessig AUS. Erst wenn im Popup die Checkbox "Helium 10 Zusatzdaten"
   an ist, spricht dieses Feature members.helium10.com an. Ohne Toggle bleibt
   die Extension zu 100 % lokal - die Non-Online-Variante ist der Default.

   Auth: Wir nutzen die Session-Cookies des laufenden H10-Logins in Chrome.
   Kein API-Key, kein Datenverkehr wenn der Nutzer nicht selbst H10-Kunde ist.

   Rechte: members.helium10.com + research-tools.helium10.com muessen in
   host_permissions stehen. Ist das nicht der Fall, meldet fetch einen
   Netzwerkfehler und wir zeigen einen Hinweis - kein Crash.

   Setzt shared/h10.js voraus (LC.h10). Hakt sich in LC.onpage.panel ein. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC || !LC.h10) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];

  var HOST_ALIAS = 'amazon.de';  // Content-Script laeuft nur auf amazon.de
  var CACHE_MIN = 15;             // pro ASIN + Feld einmal alle 15 min

  /* Login-Check: LC.h10.ready() (memoisiert, ein check-login je Seitenaufbau) -
     dp-chart/dp-keywords/dp-reviews nutzen denselben; kein zweiter Request von hier. */

  /* Kleiner Datei-lokaler Cache. Die Antworten landen NICHT in chrome.storage,
     damit sie nach dem Tab-Schliessen weg sind - das war eine Bewusstseinsfrage:
     Fremdanbieter-Antworten sollen sich nicht in unserem Speicher sammeln. */
  var mem = Object.create(null);
  function cached(key, fn) {
    var e = mem[key];
    if (e && Date.now() - e.at < CACHE_MIN * 60 * 1000) return Promise.resolve(e.value);
    return fn().then(function (v) { mem[key] = { at: Date.now(), value: v }; return v; });
  }

  function pill(ui, label, wert, titel) {
    var chip = ui.chip(ui.esc(label) + ' <b>' + ui.esc(wert) + '</b>', 'mut', titel);
    return chip;
  }

  H.panel.push(function (ctx) {
    var ui = ctx.ui, asin = ctx.asin;
    if (!ui || !asin) return;
    if (document.querySelector('.lc-h10-chip')) return;                        // schon verteilt

    ui.storage('lcH10Enabled').then(function (d) {
      if (!d.lcH10Enabled) return;                                              // Toggle aus - kein Netz
      LC.h10.ready().then(function (login) {
        if (!login || ui.aktuelleAsin() !== ctx.asin) return;                  // ohne Login still, andere Sektionen zeigen ohnehin nichts H10
        var HOST = 'amazon.de';

        // -- Variante-Anteil: kleiner Chip in der Listing-Chip-Reihe (secQ) - neben "5 Bullets"
        if (ctx.secQ) {
          cached('child:' + asin, function () { return LC.h10.childSalesPerformance(asin, HOST); }).then(function (res) {
            if (!res.ok || ui.aktuelleAsin() !== ctx.asin) return;
            var data = res.data && res.data.results && res.data.results.data;
            var e = data && data[asin];
            if (!e || e.performance == null) return;
            var chip = ui.chip('<span class="lc-k">Variante</span> ' + Math.round(e.performance * 100) + ' %',
              'mut', 'H10-Schätzung: Anteil dieser ASIN an den Verkäufen des Parent ' + (e.parentAsin || asin));
            chip.classList.add('lc-h10-chip');
            ctx.secQ.appendChild(chip);
          });
        }

        // -- Sales-Estimator als Klick-Chip in der Buybox-Zeile - neben "500+ / Monat"
        if (ctx.bbRow) {
          var chip = ui.chip('<span class="lc-k">H10 Sales/30 T</span> abrufen ⟳', '', 'Klick: Verkaufsschätzung aus Helium 10 - kostet einen von 10 Free-Abrufen im Monat');
          chip.classList.add('lc-h10-chip', 'lc-copy');
          chip.addEventListener('click', function (ev) {
            ev.preventDefault(); ev.stopPropagation();
            if (chip.dataset.laeuft) return; chip.dataset.laeuft = '1';
            chip.innerHTML = '<span class="lc-k">H10 Sales/30 T</span> lädt …';
            cached('sales:' + asin, function () { return LC.h10.salesEstimator(asin, HOST); }).then(function (res) {
              if (!res || !res.ok) throw new Error('HTTP ' + (res && res.status));
              var d = res.data || {};
              var val = d.last30DaysSales != null ? d.last30DaysSales : (d.results && d.results.last30DaysSales);
              var left = d.userData && d.userData.usesLeft;
              chip.className = 'lc-chip ok lc-h10-chip';
              chip.innerHTML = '<span class="lc-k">H10 Sales/30 T</span> ' + ui.nf(val || 0) + (left != null ? ' <span class="lc-k">· noch ' + left + '/Monat</span>' : '');
            }).catch(function (e) {
              chip.className = 'lc-chip bad lc-h10-chip';
              chip.innerHTML = '<span class="lc-k">H10 Sales</span> Fehler: ' + ui.esc(e.message || 'kein Netz');
              delete chip.dataset.laeuft;
            });
          });
          ctx.bbRow.appendChild(chip);
        }

        // -- Konto/Plan als kleine Fussnote am Ende der Karte
        if (ctx.card) {
          var fuss = ui.el('div', 'a-size-mini a-color-secondary a-spacing-top-mini lc-h10-chip',
            'H10 · Konto ' + ui.esc(String(login.accountId)) + ' · Plan ' + ui.esc(login.planLabel || login.plan));
          ctx.card.appendChild(fuss);
        }
      });
    }).catch(function (e) { console.warn('[LC] dp-h10', e); });
  });
})();
