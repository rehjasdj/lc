/* Marge-Rechner (nach Helium 10 "Profitability Calculator"), lokal und ohne
   Gebuehrentabelle: Verkaufspreis brutto (von der Seite vorbelegt), Einkauf/
   Versand/Verpackung netto, Amazon-Provision % (Standard 15) und USt %
   (Standard 19) -> Gewinn, Marge, ROI und Break-even-Preis, live beim Tippen.
     netto = preis / (1 + USt);  provision = preis * prov (Amazon rechnet brutto)
     gewinn = netto - provision - einkauf - versand - verpackung
     marge = gewinn / netto;  ROI = gewinn / (einkauf + versand + verpackung)
   Eingaben je ASIN in calc:<ASIN>, Provision/USt zusaetzlich als calc:defaults.
   "Versand durch" ist nur Beschriftung - die FBA-Gebuehr traegt der Nutzer
   selbst unter Versand ein. Keine Requests, keine Rechte. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];

  var FELDER = [
    { k: 'preis',      t: 'Verkaufspreis € (brutto)', tip: 'Amazon-Verkaufspreis inkl. USt – von der Seite vorbelegt, zum Durchspielen änderbar' },
    { k: 'einkauf',    t: 'Einkauf € (netto)',        tip: 'Einkaufspreis je Stück ohne USt' },
    { k: 'versand',    t: 'Versand/Logistik €',       tip: 'Versand je Stück netto – bei FBA die FBA-Gebühr hier eintragen' },
    { k: 'verpackung', t: 'Verpackung/Sonstiges €',   tip: 'Verpackung, Retourenanteil, sonstige Stückkosten netto' },
    { k: 'prov',       t: 'Amazon-Provision %',       tip: 'Verkaufsgebühr in % vom Bruttopreis – kategorieabhängig, teils nach Preis gestaffelt (Seller Central → Verkaufsgebühren amazon.de). Vorbelegt 15, zuletzt eingegebener Wert wird gemerkt' },
    { k: 'ust',        t: 'USt %',                    tip: 'Umsatzsteuer in % (Standard 19) – wird als Vorgabe gemerkt' }
  ];
  var GEMERKT = ['einkauf', 'versand', 'verpackung', 'prov', 'ust'];
  // "1.299,00" -> 1299 (Tausenderpunkt nur entfernen, wenn ein Komma da ist; "12.5" bleibt 12.5)
  var zahl = function (v) { var s = String(v == null ? '' : v).trim(); if (s.indexOf(',') >= 0) s = s.replace(/\./g, ''); var n = parseFloat(s.replace(',', '.')); return isFinite(n) ? n : null; };
  var txt = function (n) { return n == null ? '' : String(n).replace('.', ','); };
  var pct = function (n) { return n == null ? '–' : n.toFixed(1).replace('.', ',') + ' %'; };

  function rechnen(v) {
    var u = (v.ust || 0) / 100, p = (v.prov || 0) / 100;
    var kosten = (v.einkauf || 0) + (v.versand || 0) + (v.verpackung || 0);
    var netto = v.preis / (1 + u), provision = v.preis * p;
    var gewinn = netto - provision - kosten;
    var anteil = 1 / (1 + u) - p;   // was je Brutto-Euro nach USt und Provision bleibt
    return { netto: netto, provision: provision, kosten: kosten, gewinn: gewinn,
      marge: netto > 0 ? 100 * gewinn / netto : null,
      roi: kosten > 0 ? 100 * gewinn / kosten : null,
      be: anteil > 0 ? kosten / anteil : null };
  }
  H.profit = { rechnen: rechnen };

  H.panel.push(function (ctx) {
    var ui = ctx.ui, asin = ctx.asin, r = ctx.row || {};
    if (!ui || typeof ctx.sec !== 'function' || !asin) return;
    if (ctx.card && ctx.card.querySelector('.lc-profit')) return;
    var box = ctx.sec('Marge');
    box.classList.add('lc-profit');
    var form = ui.el('div', 'lc-row'); box.appendChild(form);
    var inp = {};
    var feld = function (k, t, tip, ctrl) {
      var w = ui.el('div');
      var lab = ui.el('label', 'a-size-small a-color-secondary', ui.esc(t));
      lab.htmlFor = ctrl.id = 'lc-profit-' + k; lab.title = tip; lab.style.display = 'block';
      ctrl.title = tip;
      w.appendChild(lab); w.appendChild(ctrl); form.appendChild(w);
      return ctrl;
    };
    FELDER.forEach(function (f) {
      var i = ui.el('input', 'a-input-text a-width-small');
      i.type = 'text'; i.autocomplete = 'off'; i.setAttribute('inputmode', 'decimal');
      inp[f.k] = feld(f.k, f.t, f.tip, i);
    });
    var sel = ui.el('select', 'a-native-dropdown');
    ['Verkäufer', 'FBA'].forEach(function (o) { var op = ui.el('option', '', ui.esc(o)); op.value = o; sel.appendChild(op); });
    feld('durch', 'Versand durch', 'Nur Beschriftung – die Versand- bzw. FBA-Gebühr trägst du oben unter Versand ein', sel);
    var out = ui.el('div', 'lc-row a-spacing-top-small'); box.appendChild(out);

    inp.preis.value = r.preis == null ? '' : txt(Number(r.preis).toFixed(2));
    inp.prov.value = '15'; inp.ust.value = '19';

    var zeigen = function () {
      var v = {}; FELDER.forEach(function (f) { v[f.k] = zahl(inp[f.k].value); });
      out.innerHTML = '';
      if (v.preis == null || v.preis <= 0) { out.appendChild(ui.chip('Verkaufspreis fehlt', 'mut', 'Ohne Verkaufspreis keine Rechnung')); return; }
      if (v.einkauf == null) { out.appendChild(ui.chip('Einkauf fehlt', 'mut', 'Einkaufspreis netto eintragen – dann rechnet es')); return; }
      var e = rechnen(v);
      out.appendChild(ui.chip('<span class="lc-k">Gewinn</span> ' + ui.esc(ui.eur(e.gewinn)), e.gewinn >= 0 ? 'ok' : 'bad',
        'Netto ' + ui.eur(e.netto) + ' − Provision ' + ui.eur(e.provision) + ' − Kosten ' + ui.eur(e.kosten) + ' (Einkauf + Versand + Verpackung)'));
      out.appendChild(ui.chip('<span class="lc-k">Marge</span> ' + pct(e.marge), e.marge == null ? 'mut' : (e.marge >= 20 ? 'ok' : (e.marge < 0 ? 'bad' : '')),
        'Gewinn / Nettoumsatz (' + ui.eur(e.netto) + ')'));
      out.appendChild(ui.chip('<span class="lc-k">ROI</span> ' + pct(e.roi), 'mut', 'Gewinn / eingesetztes Kapital (Einkauf + Versand + Verpackung = ' + ui.eur(e.kosten) + ')'));
      out.appendChild(ui.chip('<span class="lc-k">Break-even</span> ' + (e.be == null ? '–' : ui.esc(ui.eur(e.be))), 'mut',
        e.be == null ? 'USt und Provision fressen den ganzen Preis – kein Break-even' : 'Bruttopreis, bei dem der Gewinn genau 0 € ist'));
    };
    var merken = function () {
      var d = { durch: sel.value }, o = {};
      GEMERKT.forEach(function (k) { d[k] = zahl(inp[k].value); });
      o['calc:' + asin] = d;
      o['calc:defaults'] = { prov: d.prov, ust: d.ust };
      try { chrome.storage.local.set(o); } catch (e) { /* Storage weg */ }
    };
    FELDER.forEach(function (f) { inp[f.k].addEventListener('input', function () { zeigen(); if (f.k !== 'preis') merken(); }); });
    sel.addEventListener('change', merken);
    zeigen();

    // Gemerkte Werte: erst globale Vorgaben (Provision/USt), dann die der ASIN
    ui.storage(['calc:' + asin, 'calc:defaults']).then(function (d) {
      if (ui.aktuelleAsin() !== asin || !box.isConnected) return;
      var g = d['calc:defaults'] || {}, m = d['calc:' + asin] || {};
      if (g.prov != null) inp.prov.value = txt(g.prov);
      if (g.ust != null) inp.ust.value = txt(g.ust);
      GEMERKT.forEach(function (k) { if (m[k] != null) inp[k].value = txt(m[k]); });
      if (m.durch) sel.value = m.durch;
      zeigen();
    }).catch(function () { /* ohne Speicher eben mit Standardwerten */ });
  });
})();
