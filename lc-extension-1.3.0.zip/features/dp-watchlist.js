/* Watchlist (nach Keepa "Tracking", aber rein lokal): ASINs merken, auf der
   Produktseite ein Chip hinter dem ASIN-Kopier-Chip (☆ Beobachten / ★ Beobachtet),
   in der Karte eine Sektion mit allen beobachteten ASINs samt letztem Preis/BSR
   aus dem lokalen Verlauf (hist:<ASIN>), ein Knopf fuer die Sammelpruefung
   (proCheck) und in der Suche ein "★ beobachtet"-Chip an jeder beobachteten Kachel.
   Speicher: chrome.storage.local "watch" = [{asin, titel, preis, bsr, ts}].
   Keine Requests, keine Rechte. Nur ui.el/ui.chip (data-lc, Scrape-Filter). */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || []; H.serp = H.serp || [];

  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  var num = function (s) { var n = parseInt(String(s == null ? '' : s).replace(/\D/g, ''), 10); return isFinite(n) && n > 0 ? n : null; };
  var kurz = function (s, n) { s = clean(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };

  var watch = [], geladen = false, listener = null, ui = null;
  var aktiv = null;   // Zustand der sichtbaren Produktseite: {asin, render}
  var serpNeu = null; // Neuzeichnen der Suchseite nach Aenderung

  // ---- Speicher ---------------------------------------------------------------
  function laden() {
    if (geladen) return Promise.resolve(watch);
    return ui.storage('watch').then(function (d) {
      watch = Array.isArray(d.watch) ? d.watch : []; geladen = true; return watch;
    }).catch(function () { geladen = true; return watch; });
  }
  function speichern(list) {
    watch = list;
    try { chrome.storage.local.set({ watch: list }); } catch (e) { /* Storage weg */ }
  }
  var drin = function (asin) { return watch.some(function (w) { return w.asin === asin; }); };
  var ohne = function (asin) { return watch.filter(function (w) { return w.asin !== asin; }); };

  /* EIN Listener fuer alle Seiten: andere Tabs/Popup aendern "watch" -> neu zeichnen.
     Auf der Produktseite nur, wenn noch dieselbe ASIN sichtbar ist. */
  function hoeren() {
    if (listener) return;
    listener = function (ch, area) {
      if (area !== 'local' || !ch.watch) return;
      watch = Array.isArray(ch.watch.newValue) ? ch.watch.newValue : []; geladen = true;
      if (aktiv && ui.aktuelleAsin() === aktiv.asin) aktiv.render();
      if (serpNeu) serpNeu();
    };
    try { chrome.storage.onChanged.addListener(listener); } catch (e) { listener = null; }
  }

  // ---- Produktseite -----------------------------------------------------------
  H.panel.push(function (ctx) {
    ui = ctx.ui;
    if (!ui || !ctx.asin) return;
    var asin = ctx.asin, r = ctx.row || {};
    hoeren();

    // Chip direkt HINTER dem ASIN-Kopier-Chip (Geschwister von #productTitle)
    var anker = null, n = ctx.titleEl ? ctx.titleEl.nextElementSibling : null;
    while (n && n.hasAttribute('data-lc')) { if (n.classList.contains('lc-copy')) { anker = n; break; } n = n.nextElementSibling; }
    anker = anker || ctx.titleEl;
    var chip = ui.chip('☆ Beobachten', '', 'ASIN lokal beobachten: Preis/BSR-Verlauf, Sammelprüfung, Markierung in der Suche');
    chip.classList.add('lc-copy', 'lc-watch-chip');
    if (anker) anker.insertAdjacentElement('afterend', chip);
    var chipOptik = function () {
      var ist = drin(asin);
      chip.className = 'lc-chip lc-copy lc-watch-chip' + (ist ? ' ok' : '');
      chip.innerHTML = ist ? '★ Beobachtet' : '☆ Beobachten';
    };
    chip.addEventListener('click', function (ev) {
      ev.preventDefault(); ev.stopPropagation();
      laden().then(function () {
        if (drin(asin)) speichern(ohne(asin));
        else speichern(watch.concat([{ asin: asin, titel: kurz(r.titel, 80), preis: r.preis == null ? null : Number(r.preis), bsr: num(r.bsr), ts: Date.now() }]));
        chipOptik(); render();
      });
    });

    // Knopf: Sammelpruefung aller beobachteten ASINs (Buybox/Preis, wie "Buybox-Check")
    var knopf = ui.button('Alle beobachteten prüfen', false, 'Buybox-/Preis-Check für alle beobachteten ASINs starten', function (b) {
      var asins = watch.map(function (w) { return w.asin; });
      if (!asins.length) { ctx.status.textContent = 'Keine beobachteten ASINs.'; return; }
      b.disabled = true;
      ui.send({ type: 'proCheck', asins: asins, origin: location.origin });
      ctx.status.textContent = 'Prüfung für ' + asins.length + ' beobachtete ASIN' + (asins.length === 1 ? '' : 's') + ' gestartet – Ergebnis im Popup und unter dem Preis.';
      setTimeout(function () { b.disabled = false; }, 8000);
    });
    if (ctx.stack) ctx.stack.appendChild(knopf);

    // Sektion "Beobachtet (n)" - nur bei n > 0, bei jeder Aenderung komplett neu
    var sec = null;
    var render = function () {
      if (sec) { if (sec.previousElementSibling && sec.previousElementSibling.tagName === 'H3') sec.previousElementSibling.remove(); sec.remove(); sec = null; }
      knopf.style.display = watch.length ? '' : 'none';
      if (!watch.length || typeof ctx.sec !== 'function') return;
      var list = watch.slice();
      var box = sec = ctx.sec('Beobachtet (' + list.length + ')');
      var keys = list.map(function (w) { return 'hist:' + w.asin; });
      ui.storage(keys).then(function (d) {
        if (sec !== box || ui.aktuelleAsin() !== asin) return;   // inzwischen neu gezeichnet / Variante gewechselt
        list.forEach(function (w) {
          var h = d['hist:' + w.asin], last = Array.isArray(h) && h.length ? h[h.length - 1] : null;
          var preis = last && last[1] != null ? last[1] : w.preis, bsr = last && last[2] != null ? last[2] : w.bsr;
          var wann = last ? new Date(last[0]) : new Date(w.ts || 0);
          var zeile = ui.el('div', 'lc-row a-spacing-micro' + (w.asin === asin ? ' lc-ok' : ''),
            '<a class="a-link-normal" href="/dp/' + ui.esc(w.asin) + '" title="' + ui.esc(w.titel || w.asin) + '">' + ui.esc(kurz(w.titel || w.asin, 48)) + '</a>' +
            '<span class="lc-mono lc-k">' + ui.esc(w.asin) + '</span>' +
            '<span class="lc-mono" title="letzter gemessener Preis">' + ui.esc(ui.eur(preis)) + '</span>' +
            '<span class="lc-k" title="letzter Bestseller-Rang">BSR ' + ui.esc(ui.nf(bsr)) + '</span>' +
            '<span class="lc-k" title="Datum der letzten Messung">' + ui.esc(ui.tag(wann)) + '</span>');
          var x = ui.chip('✕', 'mut', 'aus der Beobachtung entfernen');
          x.classList.add('lc-copy');
          x.addEventListener('click', function (ev) {
            ev.preventDefault(); ev.stopPropagation();
            speichern(ohne(w.asin)); chipOptik(); render();
          });
          zeile.appendChild(x);
          box.appendChild(zeile);
        });
      }).catch(function (e) { console.warn('[LC] Watchlist', e); });
    };
    aktiv = { asin: asin, render: function () { chipOptik(); render(); } };
    laden().then(function () { if (ui.aktuelleAsin() === asin) aktiv.render(); }).catch(function () { /* ohne Speicher nichts zu zeigen */ });
  });

  // ---- Suchseite --------------------------------------------------------------
  H.serp.push(function (ctx) {
    ui = ctx.ui;
    if (!ui) return;
    hoeren();
    serpNeu = function () {
      var set = {}; watch.forEach(function (w) { set[w.asin] = 1; });
      var n = 0;
      ctx.tiles.forEach(function (t) {
        if (!t.badges) return;
        var da = t.badges.querySelector('.lc-watch');
        if (!set[t.asin]) { if (da) da.remove(); return; }
        n++;
        if (da) return;
        var c = ui.chip('★ beobachtet', 'ok', 'steht auf der lokalen Beobachtungsliste');
        c.classList.add('lc-watch');
        t.badges.appendChild(c);
      });
      var alt = ctx.head.querySelector('.lc-watch-head');
      if (alt) alt.remove();
      if (n) {
        var hc = ui.chip(n + ' <span class="lc-k">beobachtete hier</span>', 'ok', n + ' Treffer dieser Seite stehen auf der Beobachtungsliste');
        hc.classList.add('lc-watch-head');
        ctx.head.insertBefore(hc, ctx.head.querySelector('.lc-sp'));
      }
    };
    laden().then(serpNeu).catch(function () { /* ohne Speicher keine Markierung */ });
  });

  /* ---- Auto-Research (LO 01.09. "er holt keine auto daten"): stuendlich,
     solange irgendein Amazon-Tab offen ist, alle beobachteten ASINs per
     fetch messen - BSR/Preis/Buybox in den Verlauf (hist:, via background-
     Kette) und Kaufzahl+BSR als Kalibrier-Punkt (macht quickview.lesen()
     intern). Lock ueber arLast-Zeitstempel (sofort gesetzt - ein zweiter Tab
     im RMW-Fenster misst schlimmstenfalls doppelt, recordSample dedupliziert).
     Gate: derselbe lcAutoLearn-Toggle wie das passive Sammeln. Cookielos
     (organisch); max 40 ASINs, 1,5 s Abstand - sanfter als jeder Nutzer. */
  var AR_INTERVALL = 3600 * 1000, AR_GAP = 1500, AR_MAX = 40;
  function autoResearch() {
    var uiH = LC.onpage && LC.onpage.ui;
    var lesen = LC.onpage && LC.onpage.quickview && LC.onpage.quickview.lesen;
    if (!uiH || !lesen) return;
    uiH.storage(['lcAutoResearch', 'arLast', 'watch']).then(function (d) {
      if (d.lcAutoResearch === false) return;   // eigener Toggle - Auto-Research macht echte Abrufe
      if (Date.now() - (d.arLast || 0) < AR_INTERVALL) return;
      var liste = Array.isArray(d.watch) ? d.watch : [];
      if (!liste.length) return;
      try { chrome.storage.local.set({ arLast: Date.now() }); } catch (e) { return; }
      var i = 0;
      (function next() {
        if (i >= liste.length || i >= AR_MAX) return;
        var w = liste[i++];
        if (!w || !w.asin) return next();
        fetch('/dp/' + w.asin, { credentials: 'omit' })
          .then(function (r) { return r.ok ? r.text() : null; })
          .then(function (html) {
            if (!html) return;
            var dta = lesen(html, w.asin);   // lernt Kalibrier-Punkt selbst mit
            if (dta && !dta.leer) {
              try {
                chrome.runtime.sendMessage({ type: 'histSample', asin: w.asin,
                  sample: { preis: dta.preis, bsr: dta.bsr, buybox: dta.buybox } });
              } catch (e) { /* Kontext weg */ }
            }
          })
          .catch(function () { /* einzelner Fehlschlag egal */ })
          .then(function () { setTimeout(next, AR_GAP); });
      })();
    }).catch(function () { /* Speicher weg */ });
  }
  setTimeout(autoResearch, 20 * 1000);           // kurz nach Seitenladen einmal pruefen
  var arIv = setInterval(autoResearch, 5 * 60 * 1000);
  // Orphan-Stop NUR bei echter Nachinjektion: onpage.js feuert das Event auch
  // beim allerersten Laden (laeuft NACH dieser Datei) - das darf den frischen
  // Timer nicht killen, deshalb Zeitfenster statt once-Listener.
  var arStart = Date.now();
  document.addEventListener('lc-onpage-neu', function () {
    if (Date.now() - arStart > 5000) clearInterval(arIv);
  });
})();
