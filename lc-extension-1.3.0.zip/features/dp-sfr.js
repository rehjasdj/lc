/* SFR (Amazon Search Frequency Rank) in der Keyword-Abdeckung anzeigen.
   Voraussetzung: Popup hat eine Brand-Analytics-CSV geladen (storage.sfr).
   Aktion: An jedem Keyword-Chip in #lc-kw-sec eine SFR-Zahl ergaenzen;
   sobald die Rang-Tabelle (rangCheck in dp-keywords.js) auftaucht, dort
   zusaetzlich eine "SFR"-Spalte hinter der letzten anhaengen.
   Farblogik: unter 10000 gruen (lc-ok), unter 50000 mut (lc-k), sonst leer.
   Bei Mehrwort-Keywords gewinnt die kleinste Zahl (Wort- oder Phrasen-Match).
   Rechte: keine neuen - alles ueber ui.el/ui.chip (data-lc). */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];

  // Kleinste Zahl gewinnt: erst die ganze Phrase probieren, dann Einzelwoerter.
  function lookup(sfr, kw) {
    kw = String(kw || '').toLowerCase().trim();
    if (!kw || !sfr) return null;
    var best = null;
    var pruef = function (k) {
      var v = sfr[k];
      if (typeof v === 'number' && isFinite(v) && (best == null || v < best)) best = v;
    };
    pruef(kw);
    kw.split(/\s+/).forEach(pruef);
    return best;
  }
  function klasse(v) {
    if (v == null) return null;
    if (v < 10000) return 'lc-ok';
    if (v < 50000) return 'lc-k';
    return null;   // >= 50000: leer, wie gefordert
  }
  H.sfrLookup = lookup;

  H.panel.push(function (ctx) {
    var ui = ctx.ui, asin = ctx.asin;
    if (!ui) return;
    ui.storage('sfr').then(function (d) {
      var sfr = d && d.sfr;
      if (!sfr || typeof sfr !== 'object') return;
      // dp-keywords baut #lc-kw-sec asynchron (Storage-Lesen + Lauf-Auswahl).
      // Kurzes Pollen reicht - Verlassen, sobald wir die Sektion einmal befuellt haben.
      var t0 = Date.now(), fertig = false;
      var check = function () {
        if (ui.aktuelleAsin && ui.aktuelleAsin() !== asin) return;
        var box = document.getElementById('lc-kw-sec');
        if (box && !fertig) {
          fertig = true;
          chipsErweitern(box, sfr, ui);
          tabelleBeobachten(box, sfr, ui);
        }
        if (Date.now() - t0 > 10000) return;
        setTimeout(check, 60);
      };
      check();
    }).catch(function (e) { console.warn('[LC] dp-sfr', e); });
  });

  // Chip-Reihe: jeden Keyword-Chip mit "SFR <Zahl>" ergaenzen (nur bei Farbklasse).
  function chipsErweitern(box, sfr, ui) {
    var chips = box.querySelectorAll('.lc-row .lc-chip');
    Array.prototype.forEach.call(chips, function (c) {
      if (c.dataset.lcSfr) return;
      var tn = c.childNodes[0];
      var kw = (tn && tn.nodeType === 3 ? tn.textContent : c.textContent).trim();
      var v = lookup(sfr, kw);
      c.dataset.lcSfr = v == null ? '' : String(v);
      var k = klasse(v);
      if (!k) return;
      var badge = ui.el('span', 'lc-k', ' · SFR ');
      badge.appendChild(ui.el('span', k, ui.nf(v)));
      c.appendChild(badge);
      c.title = (c.title || '') + ' · SFR ' + ui.nf(v);
    });
  }

  // Sobald rangCheck in dp-keywords.js eine table.lc-kw baut, SFR-Spalte anhaengen.
  function tabelleBeobachten(box, sfr, ui) {
    var einbauen = function (tab) {
      if (!tab || tab.dataset.lcSfr) return;
      tab.dataset.lcSfr = '1';
      var head = tab.querySelector('thead tr');
      if (head) {
        var th = ui.el('th', 'lc-num');
        th.textContent = 'SFR';
        th.title = 'Amazon Brand Analytics - Search Frequency Rank (kleinste Zahl = meiste Suchen)';
        head.appendChild(th);
      }
      Array.prototype.forEach.call(tab.querySelectorAll('tbody tr'), function (tr) {
        var kw = (tr.cells[0] && tr.cells[0].textContent || '').trim();
        var v = lookup(sfr, kw);
        var td = ui.el('td', 'lc-num');
        var k = klasse(v);
        if (v != null && k) td.innerHTML = '<span class="' + k + '">' + ui.nf(v) + '</span>';
        tr.appendChild(td);
      });
    };
    // Falls schon da (Reload nach Rang-Check): sofort einbauen.
    einbauen(box.querySelector('table.lc-kw'));
    var mo = new MutationObserver(function () {
      // Ein anderer Keyword-Lauf ersetzt auch die Chip-Reihe im selben Container.
      chipsErweitern(box, sfr, ui);
      einbauen(box.querySelector('table.lc-kw'));
    });
    mo.observe(box, { childList: true, subtree: true });
  }
})();
