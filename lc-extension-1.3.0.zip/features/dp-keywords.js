/* Keyword-Abdeckung + Rang-Check auf der Produktseite (Ersatz fuer Helium 10
   Listing-Analyzer-Keywords / Cerebro-light) - eigene wie fremde Listings.
     1) Abdeckung, ohne Netz: ein vom Nutzer gewaehlter Amazon-Keyword-Lauf
        (Rohbelege per lauf_id neu verdichtet) gegen Titel / Highlights / Bullets /
        Beschreibung. voll = Phrase in einem Feld, teil = alle Woerter verstreut,
        fehlt. Niemals Keywords verschiedener Laeufe vermischen.
     2) Rang-Check nur auf Klick: Top 15 SERPs same-origin nacheinander (>= 600 ms,
        max. 15 Requests je Klick), organische Position dieser ASIN, beste eigene
        Marke, Anzeige. Verlauf in 'krank:<ASIN>' (max. 30 je Keyword) -> Delta.
   Rechte: keine neuen. Alles ueber ui.el/ui.chip (data-lc, Scrape-Filter). */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];

  var TOP = 25, RANG = 15, GAP = 600, MAXHIST = 30;
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  // Beschreibung kann HTML enthalten - Tags raus, Umlaute bleiben
  var text = function (s) { return clean(String(s == null ? '' : s).replace(/<[^>]+>/g, ' ')).toLowerCase(); };
  var CSS = [
    'table.lc-kw{width:100%;border-collapse:collapse;font-size:12px;line-height:17px;margin-top:8px}',
    'table.lc-kw th{text-align:left;font-weight:700;color:#565959;border-bottom:1px solid #E7E7E7;padding:2px 4px 2px 0;white-space:nowrap}',
    'table.lc-kw td{padding:2px 4px 2px 0;border-top:1px solid #F0F2F2;vertical-align:top}',
    'table.lc-kw .lc-num{text-align:right;white-space:nowrap}',
    '#lc-kw-sec .lc-row{margin:6px 0}',
    '#lc-kw-sec .lc-kw-run{display:flex;align-items:center;gap:8px;margin:0 0 8px}',
    '#lc-kw-sec .lc-kw-run label{font-size:12px;font-weight:700;white-space:nowrap}',
    '#lc-kw-sec .lc-kw-run select{flex:1;min-width:0;max-width:680px;padding:4px 28px 4px 7px;border:1px solid #888C8C;border-radius:7px;background:#F0F2F2;color:#0F1111;font:12px "Amazon Ember",Arial,sans-serif}',
    'html.lc-dark #lc-kw-sec .lc-kw-run select{background:var(--lc-card);color:var(--lc-fg);border-color:var(--lc-line)}',
    /* Aufklappbares Detail je Keyword: <summary> traegt die Chip-Optik weiter
       (lc-chip + ok/bad -> dark.css greift), UA-Marker weg sonst zerreisst es */
    '#lc-kw-sec details.lc-kw-det{display:inline-block;vertical-align:top;margin:2px}',
    '#lc-kw-sec details.lc-kw-det>summary{list-style:none;cursor:pointer}',
    '#lc-kw-sec details.lc-kw-det>summary::-webkit-details-marker{display:none}',
    '#lc-kw-sec .lc-kw-body{font-size:12px;line-height:17px;padding:6px 8px;border:1px solid #E7E7E7;border-radius:6px;margin:4px 0;max-width:520px}',
    'html.lc-dark #lc-kw-sec .lc-kw-body{border-color:var(--lc-line)}'
  ].join('\n');
  var offen = {};   // '<asin>|<kw>' -> true; ueberlebt den Varianten-Rebuild (IIFE-Ebene)
  var platinumAn = false;   // Popup-Toggle lcH10Platinum (LO 31.08.); wirkt nur zusammen mit lcH10Enabled
  var anonAn = true;        // Popup-Toggle lcNoCookies: Messfetches ohne Cookies (organisch), Standard AN
  var gewaehlterLauf = ''; // Auswahl ueberlebt Varianten-Rebuilds innerhalb derselben Seite

  var plattformId = function (r) { return (r && (r.plattform_id || String(r.plattform || '').toLowerCase())) || ''; };

  // Nur einzeln belegte Amazon-Laeufe anbieten. Ein Seed kann mehrfach gelaufen
  // sein; deshalb ist lauf_id (nicht seed oder batch_id) die Auswahlgrenze.
  function laeufe(data) {
    var anzahl = Object.create(null), gesehen = Object.create(null);
    (data.keywordEvidence || []).forEach(function (row) {
      if (row && row.lauf_id) anzahl[row.lauf_id] = (anzahl[row.lauf_id] || 0) + 1;
    });
    return (data.keywordRuns || []).filter(function (run) {
      if (!run || !run.lauf_id || plattformId(run) !== 'amazon' || !anzahl[run.lauf_id] || gesehen[run.lauf_id]) return false;
      gesehen[run.lauf_id] = 1;
      return true;
    }).map(function (run) {
      return { run: run, anzahl: anzahl[run.lauf_id] };
    }).sort(function (a, b) {
      return String(b.run.beendet_am || b.run.gestartet_am || '').localeCompare(String(a.run.beendet_am || a.run.gestartet_am || '')) ||
        String(b.run.lauf_id).localeCompare(String(a.run.lauf_id));
    });
  }

  function keywordsFuerLauf(data, laufId) {
    var evidence = (data.keywordEvidence || []).filter(function (row) { return row && row.lauf_id === laufId; });
    var runs = (data.keywordRuns || []).filter(function (run) { return run && run.lauf_id === laufId; });
    var serp = (data.keywordSerpMeasurements || []).filter(function (row) { return row && row.lauf_id === laufId; });
    return LC.api.aggregateEvidence(evidence, runs, serp);
  }

  function laufLabel(eintrag) {
    var run = eintrag.run, d = new Date(run.gestartet_am || run.beendet_am || '');
    var wann = isNaN(d.getTime()) ? 'ohne Datum' :
      ('0' + d.getDate()).slice(-2) + '.' + ('0' + (d.getMonth() + 1)).slice(-2) + '.' + d.getFullYear() + ' ' +
      ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
    return clean(run.seed || '(ohne Seed)') + ' · ' + (run.modus || 'Lauf') + ' · ' + wann + ' · ' + eintrag.anzahl + ' Belege';
  }

  // ---- Keywords verdichten: eine Zeile je Wort, max Demand, min Position -----
  function topKeywords(list, n) {
    var map = {};
    (list || []).forEach(function (k) {
      // nur Amazon-Messungen: eBay/Kaufland-Demand gehoert nicht in die Amazon-Abdeckung
      if (k.plattform && !/amazon/i.test(k.plattform)) return;
      var kw = clean(k.keyword).toLowerCase();
      if (!kw) return;
      var e = map[kw] || (map[kw] = { keyword: kw, demand: 0, pos: null });
      // Quellzeile mit dem hoechsten Demand behalten: die aggregierte Zeile ist
      // reich (confidence, trend, serp_*) und fuellt das aufklappbare Detail
      if ((Number(k.demand_graph_index_0_100) || 0) >= e.demand) e.src = k;
      e.demand = Math.max(e.demand, Number(k.demand_graph_index_0_100) || 0);
      if (k.beste_position != null && k.beste_position !== '') {
        e.pos = e.pos == null ? Number(k.beste_position) : Math.min(e.pos, Number(k.beste_position));
      }
    });
    return Object.keys(map).map(function (k) { return map[k]; })
      .sort(function (a, b) { return b.demand - a.demand || (a.pos || 99) - (b.pos || 99) || a.keyword.localeCompare(b.keyword); })
      .slice(0, n);
  }

  // ---- Abdeckung -------------------------------------------------------------
  function felder(r) {
    var b = [];
    for (var i = 1; i <= 8; i++) if (r['bullet_' + i]) b.push(r['bullet_' + i]);
    // ' | ' als Trenner, damit keine Phrase ueber zwei Bullets hinweg "trifft"
    return [['Titel', text(r.titel)], ['Highlights', text(r.item_highlights)], ['Bullets', text(b.join(' | '))], ['Beschreibung', text(r.beschreibung)]];
  }
  function abdeckung(kw, f, gesamt) {
    var wo = f.filter(function (x) { return x[1] && x[1].indexOf(kw) >= 0; }).map(function (x) { return x[0]; });
    if (wo.length) return { stufe: 'voll', wo: wo };
    var w = kw.split(' ').filter(Boolean);
    // ponytail: Teilstring je Wort ("tisch" trifft "esstisch") - reicht als Hinweis
    var alle = w.length > 1 && w.every(function (x) { return gesamt.indexOf(x) >= 0; });
    return { stufe: alle ? 'teil' : 'fehlt', wo: [] };
  }

  // ---- Detail je Keyword (aufklappbar): Fundstellen + Messdaten -------------
  /* LO 30.08.: "Abdeckung checkt gar nicht ob das Keyword passt" - stimmt, es
     ist ein reiner Textvorkommen-Check, und die Keywords haengen am Messlauf,
     nicht an dieser ASIN. Ein "fehlt" kann also auch "passt gar nicht" heissen.
     Das Detail liefert das Pruefmaterial: wo genau es im Listing steht (bei
     "teil" sieht man, ob "tisch" nur in "esstisch" steckt), die vorhandenen
     Messdaten und ein SERP-Link zum Selbstpruefen. Null neue Requests. */
  function fundstellen(kw, r, esc) {
    var quellen = [['Titel', r.titel], ['Highlights', r.item_highlights]];
    for (var i = 1; i <= 8; i++) if (r['bullet_' + i]) quellen.push(['Bullet ' + i, r['bullet_' + i]]);
    quellen.push(['Beschreibung', String(r.beschreibung == null ? '' : r.beschreibung).replace(/<[^>]+>/g, ' ')]);
    var woerter = kw.split(' ').filter(Boolean), out = [];
    quellen.forEach(function (q) {
      var roh = clean(q[1]);
      if (!roh) return;
      var lo = roh.toLowerCase();
      var suche = lo.indexOf(kw) >= 0 ? [kw] : woerter.filter(function (w) { return lo.indexOf(w) >= 0; });
      suche.forEach(function (s) {
        var p = lo.indexOf(s), a = Math.max(0, p - 40), b = Math.min(roh.length, p + s.length + 40);
        out.push({
          feld: q[0],
          html: (a > 0 ? '…' : '') + esc(roh.slice(a, p)) + '<b>' + esc(roh.slice(p, p + s.length)) + '</b>' + esc(roh.slice(p + s.length, b)) + (b < roh.length ? '…' : '')
        });
      });
    });
    return out;
  }

  function detailBody(ctx, k, r) {
    var ui = ctx.ui;
    var body = ui.el('div', 'lc-kw-body');
    // 1) Fundstellen mit Kontext - das eigentliche Pruefmaterial
    var st = fundstellen(k.keyword, r, ui.esc);
    if (st.length) {
      st.slice(0, 6).forEach(function (s) {
        body.appendChild(ui.el('div', 'a-size-small', '<span class="lc-k">' + ui.esc(s.feld) + ':</span> „' + s.html + '"'));
      });
    } else body.appendChild(ui.el('div', 'a-size-small lc-bad', 'kommt im Listing nicht vor'));
    // 2) Messdaten aus der aggregierten keywords-Zeile (topKeywords behaelt sie als k.src)
    var s = k.src || {};
    var teile = ['Demand <b>' + k.demand + '</b>/100'];
    if (s.confidence_0_100 != null) teile.push('Confidence ' + ui.esc(String(s.confidence_0_100)) + '/100');
    if (k.pos != null) teile.push('beste Autocomplete-Pos. ' + k.pos);
    if (s.beobachtungen != null) teile.push(ui.esc(String(s.beobachtungen)) + ' Beobachtungen');
    if (s.zeitraum) teile.push(ui.esc(String(s.zeitraum)));
    body.appendChild(ui.el('div', 'a-size-small a-spacing-top-mini lc-k', teile.join(' · ')));
    if (s.serp_gemessen_am) {
      body.appendChild(ui.el('div', 'a-size-small lc-k', 'SERP-Messung: ' +
        (s.serp_gesamt_text ? ui.esc(String(s.serp_gesamt_text)) + ' · ' : '') +
        (s.serp_anzeigen != null ? ui.esc(String(s.serp_anzeigen)) + ' Anzeigen · ' : '') +
        (s.serp_preis_median != null ? 'Median ' + ui.eur(s.serp_preis_median) + ' · ' : '') +
        ui.esc(String(s.serp_gemessen_am).slice(0, 10))));
    }
    // 3) letzter Rang-Check dieser ASIN fuer dieses Keyword (falls je gemessen)
    ui.storage('krank:' + ctx.asin).then(function (d) {
      var hist = d && d['krank:' + ctx.asin] && d['krank:' + ctx.asin][k.keyword];
      if (!hist || !hist.length) return;
      var l = hist[hist.length - 1];
      body.appendChild(ui.el('div', 'a-size-small lc-k',
        'Rang-Check: zuletzt ' + (l[1] == null ? 'nicht auf Seite 1' : 'Pos. ' + l[1]) + ' am ' + ui.tag(new Date(l[0]))));
    }).catch(function () { /* egal */ });
    // 4) H10-Suchvolumen, lazy beim Aufklappen (gleicher Cache-Key wie rangCheck)
    if (LC.h10 && LC.h10.ready) {
      var slot = ui.el('div', 'a-size-small lc-k', 'H10-Suchvolumen …');
      body.appendChild(slot);
      LC.h10.ready().then(function (login) {
        if (!login) { slot.remove(); return; }
        return LC.h10.cache('sv:amazon.de:' + k.keyword, 7 * 24 * 60, function () { return LC.h10.searchVolume(k.keyword, 'amazon.de'); }).then(function (res) {
          var d = res && res.data && res.data.results && res.data.results.data;
          var sv = d ? (d.exact != null ? d.exact : d.broad) : null;
          slot.innerHTML = sv == null ? 'H10-Suchvolumen: –' : 'H10-Suchvolumen: <b>' + ui.nf(sv) + '</b>';
        });
      }).catch(function () { slot.textContent = 'H10-Suchvolumen: Fehler'; });
    }
    /* 4b) Platinum-Zusatz (eigener Popup-Toggle, LO 31.08.): Google-Trends-
       Jahresverlauf als Block-Sparkline + letzter CPC. Auf Free-Plaenen
       antworten die Endpunkte mit 402/403 - dann steht hier ein ehrlicher
       Hinweis statt einer Zahl. Antwortformate defensiv geparst (rekursive
       Zahlenreihen-Suche), 7-Tage-Cache; Fehlantworten cacht LC.h10.cache
       seit dem Review-Fix nicht mehr. */
    if (platinumAn && LC.h10 && LC.h10.ready && LC.h10.googleTrends) {
      var pslot = ui.el('div', 'a-size-small lc-k', 'H10 Platinum …');
      body.appendChild(pslot);
      LC.h10.ready().then(function (login) {
        if (!login) { pslot.remove(); return; }
        var reiheSuchen = function (o, test, tiefe) {
          if (tiefe > 3 || !o) return null;
          if (Array.isArray(o) && o.length > 2 && o.every(test)) return o;
          if (typeof o === 'object') {
            var kk = Object.keys(o);
            for (var ii = 0; ii < kk.length; ii++) {
              var t = reiheSuchen(o[kk[ii]], test, tiefe + 1);
              if (t) return t;
            }
          }
          return null;
        };
        var gt = LC.h10.cache('gt:' + k.keyword, 7 * 24 * 60, function () { return LC.h10.googleTrends(login.accountId, k.keyword); })
          .then(function (res) {
            var reihe = reiheSuchen(res && res.data, function (x) { return typeof x === 'number' || (x && typeof x.value === 'number'); }, 0);
            if (!reihe) return null;
            var werte = reihe.map(function (x) { return typeof x === 'number' ? x : x.value; });
            var mx = Math.max.apply(null, werte) || 1;
            var B = '▁▂▃▄▅▆▇█';
            var spark = werte.slice(-24).map(function (v) { return B[Math.max(0, Math.min(7, Math.round(v / mx * 7)))]; }).join('');
            var delta = werte.length > 1 && werte[0] ? Math.round((werte[werte.length - 1] - werte[0]) / werte[0] * 100) : null;
            return 'Trend ' + spark + (delta == null ? '' : ' <span class="' + (delta >= 0 ? 'lc-ok' : 'lc-bad') + '">' + (delta >= 0 ? '+' : '') + delta + '%</span><span class="lc-k"> / Jahr</span>');
          }).catch(function () { return null; });
        var cpc = LC.h10.cpcHistory
          ? LC.h10.cache('cpc:' + k.keyword, 7 * 24 * 60, function () { return LC.h10.cpcHistory(login.accountId, k.keyword, 'amazon.de'); })
            .then(function (res) {
              var reihe = reiheSuchen(res && res.data, function (x) { return x && (typeof x.cpc === 'number' || typeof x.value === 'number'); }, 0);
              if (!reihe) return null;
              var l = reihe[reihe.length - 1];
              return 'CPC ~' + ui.eur(typeof l.cpc === 'number' ? l.cpc : l.value);
            }).catch(function () { return null; })
          : Promise.resolve(null);
        Promise.all([gt, cpc]).then(function (teile2) {
          var txt = teile2.filter(Boolean).join(' · ');
          if (txt) pslot.innerHTML = txt;
          else pslot.textContent = 'H10 Platinum: keine Daten (Plan reicht nicht?)';
        });
      }).catch(function () { pslot.textContent = 'H10 Platinum: Fehler'; });
    }
    // 5) Selbstpruef-Link (same-origin, keine Permission)
    var a = ui.el('a', 'a-link-normal a-size-small', 'SERP öffnen ↗');
    a.href = '/s?k=' + encodeURIComponent(k.keyword); a.target = '_blank'; a.rel = 'noopener';
    body.appendChild(ui.el('div', 'a-spacing-top-mini')).appendChild(a);
    return body;
  }

  // ---- SERP lesen (statisches HTML, gleiche Selektoren wie onpage.js/search.js)
  function serpLesen(html) {
    // NUR echte Blockseiten-Marker (validateCaptcha-Formular / opfcaptcha-Bild):
    // das blosse Wort "captcha" steht in fast jedem normalen Amazon-Quelltext -
    // LO bekam staendig Fehlalarme, obwohl die Suche normal ging (31.08.)
    if (/validateCaptcha|opfcaptcha/i.test(html)) throw new Error('captcha');
    var doc = new DOMParser().parseFromString(html, 'text/html');
    /* Mehrere Layouts abdecken: das abgerufene HTML traegt nicht immer
       data-component-type="s-search-result" wie die live gerenderte Seite -
       damit scheiterte JEDE Zeile mit "SERP leer oder Layout unbekannt"
       (LO 01.09.). Erste Auswahl, die Kacheln liefert, gewinnt; danach nach
       ASIN entdoppeln, damit verschachtelte Treffer die Position nicht
       verschieben. */
    var SEL = [
      'div[data-component-type="s-search-result"][data-asin]:not([data-asin=""])',
      'div.s-result-item[data-asin]:not([data-asin=""])',
      '.s-main-slot [data-asin]:not([data-asin=""])',
      '[role="listitem"][data-asin]:not([data-asin=""])',
      '[data-asin]:not([data-asin=""])'
    ];
    var roh = [];
    for (var si = 0; si < SEL.length && !roh.length; si++) {
      roh = Array.prototype.slice.call(doc.querySelectorAll(SEL[si]));
    }
    var gesehen = {}, tiles = [];
    roh.forEach(function (t) {
      var a = (t.getAttribute('data-asin') || '').toUpperCase();
      if (!/^[A-Z0-9]{10}$/.test(a) || gesehen[a]) return;
      gesehen[a] = 1; tiles.push(t);
    });
    // Leere/unbekannte SERP ist KEIN Captcha: nur diese eine Zeile scheitert
    // ("Fehler"), der Lauf stoppt nicht mehr komplett mit falscher Meldung
    if (!tiles.length && !doc.getElementById('noResultsTitle')) throw new Error('SERP leer oder Layout unbekannt');
    var org = [], ads = [];
    tiles.forEach(function (t) {
      var ad = /(^|\s)AdHolder(\s|$)/.test(t.className) ||
        !!t.querySelector('[data-component-type="sp-sponsored-result"], .puis-sponsored-label-text') ||
        /\bGesponsert\b/.test(t.textContent || '');
      (ad ? ads : org).push({ asin: t.getAttribute('data-asin').toUpperCase(), titel: clean((t.querySelector('h2') || {}).textContent || '') });
    });
    return { org: org, ads: ads };
  }
  function auswerten(s, asin, EIGEN) {
    var pos = null, eigen = null;
    s.org.forEach(function (t, i) {
      if (pos == null && t.asin === asin) pos = i + 1;
      if (eigen == null && EIGEN.test(t.titel)) eigen = i + 1;
    });
    return { pos: pos, eigen: eigen, ad: s.ads.some(function (t) { return t.asin === asin; }), ads: s.ads.length };
  }
  function delta(pos, prev) {
    if (prev === undefined || (pos == null && prev == null)) return '';
    if (pos == null) return ' <span class="lc-bad">▼ von ' + prev + '</span>';
    if (prev == null) return ' <span class="lc-ok">▲ neu</span>';
    if (pos < prev) return ' <span class="lc-ok">▲ von ' + prev + '</span>';
    if (pos > prev) return ' <span class="lc-bad">▼ von ' + prev + '</span>';
    return ' <span class="lc-k">=</span>';
  }

  // ---- Rang-Check: sequenziell, Ergebnis zeilenweise in die Tabelle -----------
  function rangCheck(ctx, kws, box, btn) {
    var ui = ctx.ui, asin = ctx.asin, key = 'krank:' + asin;
    var input = btn.querySelector('input'), label = btn.querySelector('.a-button-text');
    input.disabled = true;
    var alt = box.querySelector('table.lc-kw, .lc-kw-msg');
    while (alt) { alt.remove(); alt = box.querySelector('table.lc-kw, .lc-kw-msg'); }
    var tab = ui.el('table', 'lc-kw', '<thead><tr><th>Keyword</th><th class="lc-num">Demand</th><th class="lc-num">SV (H10)</th><th class="lc-num">Pos. dieses Listing</th><th class="lc-num">beste eigene Pos.</th><th>Anzeige</th></tr></thead>');
    var tb = ui.el('tbody'); tab.appendChild(tb);
    kws.forEach(function (k) {
      tb.appendChild(ui.el('tr', '', '<td>' + ui.esc(k.keyword) + '</td><td class="lc-num lc-mono">' + k.demand + '</td><td class="lc-num lc-h10sv">…</td><td class="lc-num">…</td><td class="lc-num">…</td><td>…</td>'));
    });
    box.appendChild(tab);
    var zelle = function (tr, i, html) { tr.cells[i].innerHTML = html; };
    var jetzt = new Date().toISOString(), captcha = false;

    // -- H10-Suchvolumen (7 T Cache) je Keyword parallel (max 2) in die SV-Spalte der Tabelle
    if (LC.h10 && LC.h10.ready) {
      LC.h10.ready().then(function (login) {
        if (!login || ui.aktuelleAsin() !== asin) return;
        var host = 'amazon.de', si = 0, l = 0, MAX = 2;
        function schleife() {
          while (l < MAX && si < kws.length) {
            (function (kw, tr) {
              l++;
              LC.h10.cache('sv:' + host + ':' + kw.keyword, 7 * 24 * 60, function () { return LC.h10.searchVolume(kw.keyword, host); })
                .then(function (res) {
                  var d = res && res.data && res.data.results && res.data.results.data;
                  var sv = d ? (d.exact != null ? d.exact : (d.broad != null ? d.broad : null)) : null;
                  tr.cells[2].innerHTML = sv == null ? '<span class="lc-k">–</span>' : '<b>' + ui.nf(sv) + '</b>';
                  if (sv != null) tr.cells[2].title = 'exact ' + ui.nf(d.exact || 0) + ', broad ' + ui.nf(d.broad || 0);
                }).catch(function () { tr.cells[2].innerHTML = '<span class="lc-bad">?</span>'; })
                .then(function () { l--; schleife(); });
            })(kws[si], tb.rows[si]); si++;
          }
        }
        schleife();
      });
    }

    // Ohne Cookies = ohne Login, Verlauf und Standort-Personalisierung -> die
    // echte organische Reihenfolge. Blockt Amazon die anonyme Abfrage (Consent-/
    // Robot-Seite), einmal personalisiert nachfassen und das ehrlich ausweisen.
    /* KEIN Fallback auf die eingeloggte Sitzung (LO 01.09.): ein Rang, der mit
       Login, Kaufverlauf und Standort gemessen wurde, ist nicht der organische
       Rang - dann lieber gar kein Wert als ein falscher. Ohne Cookies sieht
       Amazon einen anonymen Erstbesucher; genau das wollen wir messen. */
    function serpHolen(keyword) {
      var url = location.origin + '/s?k=' + encodeURIComponent(keyword);
      return fetch(url, { credentials: anonAn ? 'omit' : 'include' })
        .then(function (r) { return r.text(); })
        .then(function (html) { return { treffer: serpLesen(html), neutral: anonAn }; });
    }

    ui.storage(key).then(function (d) {
      var hist = (d && d[key]) || {};
      var i = 0, neutralN = 0, persN = 0;
      var next = function () {
        // aktuelleAsin-Guard: nach Variantenwechsel nicht weiter fetchen und
        // vor allem keine Raenge auf die FALSCHE ASIN schreiben (Review 31.08.)
        if (i >= kws.length || captcha || ui.aktuelleAsin() !== asin) return null;
        var k = kws[i], tr = tb.rows[i]; i++;
        label.textContent = 'Ränge prüfen ' + i + '/' + kws.length;
        return new Promise(function (res) { setTimeout(res, i === 1 ? 0 : GAP); })
          .then(function () { return serpHolen(k.keyword); })
          .then(function (g) {
            if (g.neutral) neutralN++; else persN++;
            var e = auswerten(g.treffer, asin, ui.EIGEN);
            if (!g.neutral) tr.cells[3].title = 'personalisiert gemessen – Amazon blockte die anonyme Abfrage';
            var reihe = hist[k.keyword] || [], prev = reihe.length ? reihe[reihe.length - 1][1] : undefined;
            hist[k.keyword] = reihe.concat([[jetzt, e.pos]]).slice(-MAXHIST);
            zelle(tr, 3, (e.pos == null ? '–' : '<b>' + e.pos + '</b>') + delta(e.pos, prev));
            zelle(tr, 4, e.eigen == null ? '–' : String(e.eigen));
            zelle(tr, 5, e.ad ? '<span class="lc-ok">ja</span>' : '<span class="lc-k">–</span>');
            tr.cells[5].title = e.ads + ' Anzeigen auf Seite 1';
          })
          .catch(function (err) {
            if (err && err.message === 'captcha') { captcha = true; return; }
            console.warn('[LC] Rang-Check', k.keyword, err);
            zelle(tr, 3, '<span class="lc-bad">Fehler</span>'); zelle(tr, 4, ''); zelle(tr, 5, '');
          })
          .then(next);
      };
      return Promise.resolve(next()).then(function () {
        // frisch lesen und je Keyword mergen: waehrend der ~9s Laufzeit kann
        // ein zweiter Tab denselben Key geschrieben haben (Review 31.08.)
        return ui.storage(key).then(function (d2) {
          var basis = (d2 && d2[key]) || {};
          Object.keys(hist).forEach(function (kw) { basis[kw] = hist[kw]; });
          var o = {}; o[key] = basis;
          chrome.storage.local.set(o);
        });
      });
    }).catch(function (e) { console.warn('[LC] Rang-Check', e); }).then(function () {
      var msg = ui.el('div', 'lc-k lc-kw-msg');
      if (captcha) msg.appendChild(ui.chip('Amazon zeigt Captcha – später erneut', 'bad'));
      else msg.textContent = 'Stand ' + ui.tag(new Date()) + ' · „–" = nicht auf Seite 1 · Delta zur vorherigen Messung' +
        (anonAn ? ' · ohne Login/Cookies gemessen (organisch)'
          : ' · personalisiert gemessen (No-Cookies-Schalter im Popup ist aus)');
      box.appendChild(msg);
      label.textContent = 'Ränge erneut prüfen (Top ' + kws.length + ')';
      input.disabled = false;
    });
  }

  H.kwCheck = { top: topKeywords, abdeckung: abdeckung, felder: felder, serpLesen: serpLesen, auswerten: auswerten, delta: delta,
    laeufe: laeufe, keywordsFuerLauf: keywordsFuerLauf };

  // ---- Hook ---------------------------------------------------------------
  H.panel.push(function (ctx) {
    var ui = ctx.ui, r = ctx.row || {};
    if (!ui || !ctx.asin || typeof ctx.sec !== 'function') return;
    if (document.getElementById('lc-kw-sec')) return;           // schon da (Sicherheitsnetz)
    if (!document.getElementById('lc-kw-css')) {
      var st = ui.el('style', '', CSS); st.id = 'lc-kw-css';
      (document.head || document.documentElement).appendChild(st);
    }
    ui.storage(['keywordEvidence', 'keywordRuns', 'keywordSerpMeasurements', 'lcH10Platinum', 'lcNoCookies']).then(function (d) {
      platinumAn = !!d.lcH10Platinum;
      anonAn = d.lcNoCookies !== false;
      if (ui.aktuelleAsin() !== ctx.asin) return;               // Variante inzwischen gewechselt
      var verfuegbar = laeufe(d);
      if (!verfuegbar.length) {
        var leer = ctx.sec('Keyword-Abdeckung', 'bullets'); leer.id = 'lc-kw-sec';
        leer.appendChild(ui.chip('kein einzelner Amazon-Keyword-Lauf vorhanden – im Popup „Demand-Daten messen"', 'mut'));
        return;
      }
      if (!verfuegbar.some(function (x) { return x.run.lauf_id === gewaehlterLauf; })) gewaehlterLauf = verfuegbar[0].run.lauf_id;

      var box = ctx.sec('Keyword-Abdeckung', 'bullets'); box.id = 'lc-kw-sec';
      var heading = box.previousElementSibling;
      var auswahl = ui.el('div', 'lc-kw-run');
      var label = ui.el('label', '', 'Keyword-Lauf'); label.htmlFor = 'lc-kw-run-select';
      var select = ui.el('select', 'lc-kw-run-select'); select.id = 'lc-kw-run-select';
      verfuegbar.forEach(function (x) {
        var option = ui.el('option'); option.value = x.run.lauf_id; option.textContent = laufLabel(x);
        option.title = x.run.lauf_id; select.appendChild(option);
      });
      select.value = gewaehlterLauf;
      auswahl.appendChild(label); auswahl.appendChild(select); box.appendChild(auswahl);

      var inhalt = ui.el('div', 'lc-kw-run-content'); box.appendChild(inhalt);
      var generation = 0;
      function renderLauf() {
        var meineGeneration = ++generation;
        gewaehlterLauf = select.value;
        inhalt.innerHTML = '';
        var kws = topKeywords(keywordsFuerLauf(d, gewaehlterLauf), TOP);
        if (!kws.length) {
          if (heading) heading.textContent = 'Keyword-Abdeckung';
          inhalt.appendChild(ui.chip('dieser Lauf enthält keine Amazon-Keywords', 'mut'));
          return;
        }
        var f = felder(r), gesamt = f.map(function (x) { return x[1]; }).join(' | ');
        var n = { voll: 0, teil: 0, fehlt: 0 }, fehlt = [];
        kws.forEach(function (k) { k.a = abdeckung(k.keyword, f, gesamt); n[k.a.stufe]++; if (k.a.stufe === 'fehlt') fehlt.push(k); });
        if (heading) heading.textContent = 'Keyword-Abdeckung ' + n.voll + '/' + kws.length;
        var hinweis = fehlt.length ? ' · fehlt mit höchstem Demand: ' + fehlt.slice(0, 3).map(function (k) { return k.keyword + ' (' + k.demand + ')'; }).join(', ') : '';
        inhalt.appendChild(ui.el('div', 'lc-k', ui.esc('voll ' + n.voll + ' · teil ' + n.teil + ' · fehlt ' + n.fehlt + hinweis)));
        var row = ui.el('div', 'lc-row');
        kws.forEach(function (k) {
          var a = k.a, titel = a.wo.indexOf('Titel') >= 0;
          var info = 'Demand ' + k.demand + (k.pos != null ? ' · beste Autocomplete-Pos. ' + k.pos : '') + ' · ' +
            (a.stufe === 'voll' ? 'voll in ' + a.wo.join(', ') : a.stufe === 'teil' ? 'alle Wörter im Listing, aber nicht als Phrase' : 'fehlt im Listing') +
            ' · Klick für Fundstellen & Messdaten';
          var det = ui.el('details', 'lc-kw-det');
          var sum = ui.el('summary', 'lc-chip ' + (a.stufe === 'voll' ? 'ok' : (a.stufe === 'teil' ? '' : 'bad')),
            ui.esc(k.keyword) + (titel ? ' <span class="lc-k">Titel</span>' : ''));
          sum.title = info;
          det.appendChild(sum);
          var gefuellt = false, fuellen = function () { gefuellt = true; det.appendChild(detailBody(ctx, k, r)); };
          det.addEventListener('toggle', function () {
            offen[ctx.asin + '|' + gewaehlterLauf + '|' + k.keyword] = det.open;
            if (det.open && !gefuellt) fuellen();
          });
          if (offen[ctx.asin + '|' + gewaehlterLauf + '|' + k.keyword]) { det.open = true; fuellen(); }
          row.appendChild(det);
        });
        inhalt.appendChild(row);

        if (LC.h10 && LC.h10.ready) {
          LC.h10.ready().then(function (login) {
            if (!login || meineGeneration !== generation || ui.aktuelleAsin() !== ctx.asin) return;
            var host = 'amazon.de';
            LC.h10.cache('topkw:' + ctx.asin, 24 * 60, function () { return LC.h10.topKeywords(ctx.asin, host); }).then(function (res) {
              if (meineGeneration !== generation) return;
              var arr = res && res.data && res.data.results && res.data.results.data;
              if (!arr || !arr.length) return;
              var rrow = ui.el('div', 'lc-row a-spacing-top-small');
              rrow.appendChild(ui.el('span', 'lc-k', 'Auch relevant (H10 Amazon-Suggest): '));
              arr.slice(0, 15).forEach(function (kw) { rrow.appendChild(ui.chip(ui.esc(kw), 'mut', 'Aus Amazons intern gelernten verwandten Suchbegriffen')); });
              inhalt.appendChild(rrow);
            }).catch(function () { /* egal */ });
          });
        }

        var rang = kws.slice(0, RANG);
        var btn = ui.button('Ränge prüfen (Top ' + rang.length + ')', false,
          rang.length + ' Suchseiten dieses Laufs nacheinander laden (' + GAP + ' ms Abstand) und die organische Position dieser ASIN je Keyword lesen',
          function () {
            select.disabled = true;
            rangCheck(ctx, rang, inhalt, btn);
            var input = btn.querySelector('input');
            var frei = setInterval(function () {
              if (!input.disabled || !document.documentElement.contains(select)) { clearInterval(frei); select.disabled = false; }
            }, 100);
          });
        inhalt.appendChild(btn);
      }
      select.addEventListener('change', renderLauf);
      renderLauf();
    }).catch(function (e) { console.warn('[LC] Keyword-Abdeckung', e); });
  });
})();
