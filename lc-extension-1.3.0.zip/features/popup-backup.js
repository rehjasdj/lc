/* Datensicherung: exportiert ALLES aus chrome.storage.local als JSON,
   importiert mit Diff-Vorschau. Zusaetzlich Storage-Statistik (Bytes je Prefix).
   Ausgenommen: aod:*, qv:* (fluechtiger Detail-Cache) und h10:* (Login-Session
   von Helium 10 - kein sinnvoller Backup-Wert).
   Nur reine Logik plus eine mount() zum Anhaengen der UI - die eigentliche
   Verdrahtung macht popup.js. */
'use strict';
(function () {
  var LC = globalThis.LC = globalThis.LC || {};
  // Cache und Session-Auth - werden nie mitgesichert.
  var AUS = /^(aod:|qv:|h10:)/;

  function alleKeys() {
    return new Promise(function (res) {
      try { chrome.storage.local.get(null, function (all) { res(all || {}); }); }
      catch (e) { res({}); }
    });
  }

  function exportObject() {
    return alleKeys().then(function (all) {
      var out = {};
      Object.keys(all).forEach(function (k) {
        if (!AUS.test(k)) out[k] = all[k];
      });
      return out;
    });
  }

  function validate(obj) {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) {
      return 'Kein gueltiges Backup-Objekt (erwartet: JSON-Objekt).';
    }
    var keys = Object.keys(obj);
    if (!keys.length) return 'Backup ist leer.';
    if (!keys.every(function (k) { return typeof k === 'string' && k.length > 0; })) {
      return 'Ungueltige Schluessel im Backup.';
    }
    return null;
  }

  function berechneDiff(neu, alt) {
    var out = { neu: 0, ueberschrieben: 0, gesamt: 0 };
    Object.keys(neu).forEach(function (k) {
      out.gesamt++;
      if (k in alt) out.ueberschrieben++; else out.neu++;
    });
    return out;
  }

  function importObject(obj) {
    var fehler = validate(obj);
    if (fehler) return Promise.reject(new Error(fehler));
    return alleKeys().then(function (alt) {
      var d = berechneDiff(obj, alt);
      return new Promise(function (res, rej) {
        try {
          chrome.storage.local.set(obj, function () {
            if (chrome.runtime && chrome.runtime.lastError) {
              return rej(new Error(chrome.runtime.lastError.message || 'Storage-Fehler'));
            }
            res(d);
          });
        } catch (e) { rej(e); }
      });
    });
  }

  function bytesOf(v) {
    try { return new TextEncoder().encode(JSON.stringify(v)).length; }
    catch (e) {
      try { return String(JSON.stringify(v)).length; }
      catch (_) { return 0; }
    }
  }

  function stats() {
    return alleKeys().then(function (all) {
      var by = {};
      Object.keys(all).forEach(function (k) {
        var m = k.match(/^([^:]+):/);
        var p = m ? m[1] + ':*' : k;
        by[p] = (by[p] || 0) + bytesOf(all[k]);
      });
      return by;
    });
  }

  function heute() {
    var d = new Date();
    var mm = String(d.getMonth() + 1).padStart(2, '0');
    var tt = String(d.getDate()).padStart(2, '0');
    return d.getFullYear() + '-' + mm + '-' + tt;
  }

  function defaultFilename() { return 'lc-backup-' + heute() + '.json'; }

  LC.backup = {
    exportObject: exportObject,
    importObject: importObject,
    validate: validate,
    stats: stats,
    defaultFilename: defaultFilename
  };
})();
