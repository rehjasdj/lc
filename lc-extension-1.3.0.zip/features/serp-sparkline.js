/* Mini-Sparkline an jeder Suchseiten-Kachel: Preis (oder BSR als Fallback) ueber
   Zeit als 60x24-SVG, direkt nach der lc-badges-Zeile. Datenquelle:
     - qv:<ASIN>.samples aus dem Serp-Quick-View-Modul (Historie [[iso,preis], ...])
     - sonst hist:<ASIN> aus dem lokalen Verlauf (background.js)
   Rechte: keine. Kein Netz. Idempotent. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.serp = H.serp || [];

  var NS = 'http://www.w3.org/2000/svg';
  var W = 60, HGT = 24, P = 2;

  // liefert { pts: [[t, wert], ...], bsr: true wenn die Kurve BSR statt Preis zeigt }
  function series(qv, hist) {
    var pts = [], seen = {}, istBsr = false;
    var push = function (iso, v) {
      if (iso == null || v == null) return;
      var t = Date.parse(iso), n = Number(v);
      if (!isFinite(t) || !isFinite(n)) return;
      if (seen[t]) return;
      seen[t] = 1; pts.push([t, n]);
    };
    if (qv && Array.isArray(qv.samples) && qv.samples.length) qv.samples.forEach(function (s) { if (s) push(s[0], s[1]); });
    else if (qv && qv.ts && qv.preis != null) push(new Date(qv.ts).toISOString(), qv.preis);
    if (pts.length < 2 && Array.isArray(hist)) {
      // hist: [iso, preis, bsr, ...] – bevorzugt Preis, sonst BSR
      var preisPts = [], bsrPts = [];
      hist.forEach(function (s) {
        if (!s || s[0] == null) return;
        if (s[1] != null) preisPts.push([Date.parse(s[0]), Number(s[1])]);
        if (s[2] != null) bsrPts.push([Date.parse(s[0]), Number(s[2])]);   // BSR aus ALLEN Samples, auch denen mit Preis
      });
      var src = preisPts.length >= 2 ? preisPts : bsrPts;
      if (src === bsrPts) { pts = []; seen = {}; istBsr = true; }        // keine Euro-Punkte in eine Rang-Kurve mischen
      src.forEach(function (p) { if (!seen[p[0]]) { seen[p[0]] = 1; pts.push(p); } });
    }
    pts.sort(function (a, b) { return a[0] - b[0]; });
    return { pts: pts, bsr: istBsr };
  }

  function sparkline(pts) {
    var svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 ' + W + ' ' + HGT);
    svg.setAttribute('class', 'lc-serp-spark a-size-mini');
    svg.setAttribute('width', W); svg.setAttribute('height', HGT);
    svg.setAttribute('data-lc', '1');
    svg.setAttribute('style', 'display:inline-block;vertical-align:middle;margin-left:6px');
    var t0 = pts[0][0], t1 = Math.max(t0 + 1, pts[pts.length - 1][0]);
    var vs = pts.map(function (p) { return p[1]; });
    var mn = Math.min.apply(null, vs), mx = Math.max.apply(null, vs);
    var x = function (p) { return P + (W - 2 * P) * (p[0] - t0) / (t1 - t0); };
    var y = function (p) {
      var f = mx === mn ? 0.5 : (p[1] - mn) / (mx - mn);
      return P + (HGT - 2 * P) * (1 - f);
    };
    var d = pts.map(function (p, i) { return (i ? 'L' : 'M') + x(p).toFixed(1) + ' ' + y(p).toFixed(1); }).join(' ');
    var path = document.createElementNS(NS, 'path');
    path.setAttribute('d', d);
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke', 'currentColor');
    path.setAttribute('stroke-width', '1.2');
    path.setAttribute('stroke-linejoin', 'round');
    svg.appendChild(path);
    return svg;
  }

  H.serp.push(function (ctx) {
    var ui = ctx.ui;
    var tiles = ctx.tiles;
    var keys = [];
    tiles.forEach(function (t) { keys.push('qv:' + t.asin); keys.push('hist:' + t.asin); });
    if (!keys.length) return;
    ui.storage(keys).then(function (d) {
      var mit = 0;
      tiles.forEach(function (t) {
        if (!t.badges) return;
        var vorhanden = t.badges.nextElementSibling;
        if (vorhanden && vorhanden.classList && vorhanden.classList.contains('lc-serp-spark')) { mit++; return; }
        // Direktdaten aus dem Kachel-Attribut (aktueller Quick View) mitnehmen
        var qv = d['qv:' + t.asin] || null;
        try {
          var direkt = t.tile.getAttribute('data-lc-qv-data');
          if (direkt) {
            var dj = JSON.parse(direkt);
            if (dj && (dj.preis != null || dj.samples)) qv = qv || dj;
          }
        } catch (e) { /* egal */ }
        var s = series(qv, d['hist:' + t.asin]), pts = s.pts;
        if (pts.length < 2) return;
        var svg = sparkline(pts);
        // Tooltip bei SVG nur ueber ein <title>-Kind, nicht ueber das title-Attribut
        var ti = document.createElementNS(NS, 'title');
        ti.textContent = pts.length + ' Messungen (' + (s.bsr ? 'BSR' : 'Preis') + ')';
        svg.appendChild(ti);
        t.badges.insertAdjacentElement('afterend', svg);
        mit++;
      });
      // Kopf-Chip
      var alt = ctx.head.querySelector('.lc-serp-spark-head');
      if (alt) alt.remove();
      var chip = ui.chip('<span class="lc-k">Sparklines:</span> ' + mit + '/' + tiles.length + ' <span class="lc-k">Kacheln haben Verlauf</span>',
        'mut', 'Kleiner Preisverlauf je Kachel aus Quick-View-Historie oder lokalem Verlauf');
      chip.classList.add('lc-serp-spark-head');
      var anker = ctx.head.querySelector('.lc-sp');
      ctx.head.insertBefore(chip, anker || null);
    }).catch(function (e) { console.warn('[LC] serp-sparkline', e); });
  });
})();
