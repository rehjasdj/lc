/* Varianten-Liste (nach Seller Assistant "Variation Viewer"): alle Kind-ASINs
   mit Auspraegung aus Amazons Twister-JSON im Seitenquelltext
   (dimensionValuesDisplayData, parentAsin, variationDisplayLabels - verifiziert
   27.08.2026), Fallback #twister li[data-asin]. Preise je Variante stehen nicht
   im JSON - dafuer waere je ASIN ein Fetch noetig, bewusst weggelassen.
   Keine Requests, keine Rechte. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };

  function twister() {
    var out = { asins: {}, parent: '', labels: {} };
    var scripts = document.querySelectorAll('script');
    for (var i = 0; i < scripts.length; i++) {
      var t = scripts[i].textContent || '';
      if (t.indexOf('dimensionValuesDisplayData') < 0) continue;
      var m = t.match(/"dimensionValuesDisplayData"\s*:\s*(\{[^{}]*\})/);
      if (m) { try { out.asins = JSON.parse(m[1]); } catch (e) { /* JSON kaputt -> Fallback */ } }
      var p = t.match(/"parentAsin"\s*:\s*"([A-Z0-9]{10})"/); if (p) out.parent = p[1];
      var l = t.match(/"variationDisplayLabels"\s*:\s*(\{[^{}]*\})/);
      if (l) { try { out.labels = JSON.parse(l[1]); } catch (e) { /* egal */ } }
      // Dimensionen in Amazons Reihenfolge + alle Werte je Dimension -> Variation-Theme (LO 30.08.)
      var dm = t.match(/"dimensions"\s*:\s*(\[[^\]]*\])/);
      if (dm) { try { out.dims = JSON.parse(dm[1]); } catch (e) { /* egal */ } }
      var vv = t.match(/"variationValues"\s*:\s*(\{(?:[^{}]|\[[^\]]*\])*\})/);
      if (vv) { try { out.values = JSON.parse(vv[1]); } catch (e) { /* egal */ } }
      if (Object.keys(out.asins).length) break;
    }
    if (!Object.keys(out.asins).length) {
      Array.prototype.forEach.call(document.querySelectorAll('#twister li[data-asin], #twister_feature_div li[data-asin]'), function (li) {
        var a = li.getAttribute('data-asin'); if (!a) return;
        out.asins[a] = [clean(li.getAttribute('title') || li.textContent).replace(/^Klicken, um .*? auszuwählen\s*/i, '')];
      });
    }
    return out;
  }

  H.panel.push(function (ctx) {
    var ui = ctx.ui;
    if (!ui || typeof ctx.sec !== 'function') return;
    var tw = twister();
    var asins = Object.keys(tw.asins);
    if (asins.length < 2) return;
    var labels = Object.keys(tw.labels).map(function (k) { return tw.labels[k]; }).join(' / ');
    var box = ctx.sec('Varianten (' + asins.length + ')' + (labels ? ' · ' + labels : ''), 'twister');
    var cur = String(ctx.asin || '').toUpperCase();

    /* Variation-Theme: Twister-Dimensionsschluessel -> Amazons Theme-Name (Seller
       Central). Mehrere Dimensionen = kombiniertes Theme (z. B. Farbe x Groesse ->
       ColorSize/SizeColor; welche Reihenfolge die Kategorie erlaubt, steht im
       Kategorie-Template - deshalb beide nennen). */
    var THEME = { color_name: 'Color', size_name: 'Size', style_name: 'Style', item_package_quantity: 'ItemPackageQuantity',
      number_of_items: 'NumberOfItems', pattern_name: 'Pattern', material_type: 'Material', unit_count: 'UnitCount',
      flavor_name: 'Flavor', scent_name: 'Scent', model_name: 'Model', item_shape: 'Shape', wattage: 'Wattage',
      capacity: 'Capacity', size_per_pearl: 'Size', configuration: 'Configuration', fit_type: 'FitType', team_name: 'Team',
      item_display_length: 'Length', item_thickness: 'Thickness', item_weight: 'Weight', edition: 'Edition',
      hardware_platform: 'Platform', platform_for_display: 'Platform', item_length: 'Length', diameter: 'Diameter' };
    var dims = Array.isArray(tw.dims) && tw.dims.length ? tw.dims : Object.keys(tw.labels || {});
    if (dims.length) {
      var namen = dims.map(function (k) { return THEME[k] || k.replace(/(^|_)(\w)/g, function (_, a, c) { return c.toUpperCase(); }); });
      var kombis = namen.length > 1 ? [namen.join(''), namen.slice().reverse().join('')] : namen;
      var teile = dims.map(function (k, i) {
        var werte = (tw.values && tw.values[k]) || [];
        return '<b>' + ui.esc((tw.labels && tw.labels[k]) || k) + '</b> <span class="lc-mono">' + ui.esc(k) + '</span>' +
          (werte.length ? ' · ' + werte.length + ' Werte: ' + ui.esc(werte.slice(0, 12).join(', ')) + (werte.length > 12 ? ' …' : '') : '');
      });
      var trow = ui.el('div', 'lc-row a-spacing-small');
      // 'mut', nicht 'ok': die THEME-Namen sind abgeleitet, nicht gegen Amazons Kategorie-Templates verifiziert
      trow.appendChild(ui.chip('<span class="lc-k">Variation-Theme</span> ' + ui.esc(kombis.join(' / ')) + (dims.length > 1 ? ' <span class="lc-k">(' + dims.length + ' Dimensionen)</span>' : ''), 'mut',
        'Dimensionsschlüssel aus dem Twister-JSON der Seite: ' + dims.join(' × ') + ' – den gültigen Theme-Namen' + (dims.length > 1 ? ' und die Reihenfolge' : '') + ' im Kategorie-Template (Seller Central) prüfen'));
      var thCopy = ui.chip('Theme kopieren', 'mut lc-copy', 'Theme-Name(n) in die Zwischenablage');
      thCopy.addEventListener('click', function () {
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(kombis.join(' / ')).then(function () { thCopy.textContent = 'kopiert ✓'; });
      });
      trow.appendChild(thCopy);
      box.appendChild(trow);
      box.appendChild(ui.el('div', 'lc-k', teile.join('<br>')));
    }
    box.appendChild(ui.el('div', 'lc-k', (tw.parent ? '<div>Parent <span class="lc-mono">' + ui.esc(tw.parent) + '</span></div>' : '') +
      asins.map(function (a) {
        var v = tw.asins[a]; var txt = Array.isArray(v) ? v.join(' · ') : clean(v);
        var ist = a.toUpperCase() === cur;
        return '<div' + (ist ? ' class="a-text-bold lc-ok"' : '') + '><a class="a-link-normal lc-mono" href="/dp/' + ui.esc(a) + '">' + ui.esc(a) + '</a> ' + ui.esc(txt) + (ist ? ' ← diese' : '') + '</div>';
      }).join('')));
    var cp = ui.chip('alle ASINs kopieren', 'mut lc-copy', 'Kind-ASINs zeilenweise in die Zwischenablage');
    cp.addEventListener('click', function () {
      var text = asins.join('\n');
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function () { cp.textContent = 'kopiert ✓'; });
    });
    box.appendChild(cp);
  });
})();
