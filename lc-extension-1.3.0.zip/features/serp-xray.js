/* Xray fuer die Suchseite (nach Helium 10 Xray / Xray Keywords): Kopf-Chip
   "Xray" klappt unter der Kopfzeile eine Box auf mit
     - Summen (Treffer, Ø Preis, Ø ★, Median Rezensionen, Σ Kaufzahl, Umsatz-
       Untergrenze, FBA-Anteil sobald Quick-View-Daten da sind),
     - sortierbarer Wettbewerber-Tabelle aller Kacheln,
     - Titelwoertern der organischen Top 20 (fehlende Woerter in eigenen Titeln rot),
   und merkt die beste organische Position eigener Kacheln je Keyword
   (krank:serp:<keyword>) - Chip im Kopf zeigt die Entwicklung.
   Daten: ctx.tiles bzw. H.serpExport.zeilen() (inkl. Quick View). Kein Netz. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.serp = H.serp || [];

  var ui = null, letzterCtx = null, box = null;
  var offen = false, offenGelesen = null;            // Box-Zustand (storage lcXray), einmal gelesen
  var sortKey = 'pos', sortDir = 1;
  var hist = null, histKey = '';                     // Rang-Verlauf im Speicher: ein Lesen je Keyword, kein Doppel-Eintrag bei schnellen Durchlaeufen
  var SECHS_H = 6 * 60 * 60 * 1000;
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  // "1.234", "12,3 Tsd.", "1000+" oder schon Zahl -> ganze Zahl (Kaufzahl-Untergrenze bleibt Untergrenze)
  var ganz = function (v) {
    if (v == null || v === '') return null;
    if (typeof v === 'number') return isFinite(v) ? v : null;
    var m = String(v).match(/([\d.,]+)\s*(Tsd\.|Mio\.)?/);
    return m ? ui.mapZahl(m[1], m[2]) : null;
  };
  var dez = function (v) { var n = typeof v === 'number' ? v : parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(n) ? n : null; };
  var de = function (n, k) { return n == null ? '–' : n.toFixed(k).replace('.', ','); };

  var CSS = [
    '.lc-xray{font-size:12px;line-height:17px;color:#0F1111}',
    '.lc-xray .lc-row{margin-bottom:4px}',
    '.lc-xray h3{font-size:13px;margin:12px 0 6px;color:#0F1111}',
    '.lc-xray .lc-xray-tab{overflow-x:auto;margin-top:8px}',
    '.lc-xray table{border-collapse:collapse;width:100%;white-space:nowrap}',
    '.lc-xray th,.lc-xray td{padding:3px 6px;border-bottom:1px solid #E7E7E7;text-align:left;vertical-align:top}',
    '.lc-xray th{cursor:pointer;color:#565959;user-select:none}.lc-xray th:hover{color:#C7511F}',
    '.lc-xray .lc-num{text-align:right;font-variant-numeric:tabular-nums}'
  ].join('\n');

  // ---- Daten ----------------------------------------------------------------
  var STOP = {};
  ('mit für fuer und der die das aus cm kg von im in den dem des ein eine einer eines auf zu zum zur bis oder als bei an am ist sind ' +
   'nicht ca inkl inklusive ohne stück stk set mm ml the and for with pcs pack').split(' ').forEach(function (w) { STOP[w] = 1; });
  function tokens(titel) {
    return String(titel || '').toLowerCase().replace(/[^a-z0-9äöüß]+/g, ' ').split(' ')
      .filter(function (w) { return w.length >= 3 && !STOP[w] && !/^\d+$/.test(w); });
  }

  function zeilen(ctx) {
    var ex = H.serpExport && H.serpExport.zeilen ? H.serpExport.zeilen() : [];
    if (ex.length === ctx.tiles.length && (!ex.length || ex[0].asin === ctx.tiles[0].asin)) return ex;
    return ctx.tiles.map(function (t) {                 // ohne serp-export.js: dieselben Felder selbst lesen
      var qv = {};
      try { qv = JSON.parse(t.tile.getAttribute('data-lc-qv-data') || '{}') || {}; } catch (e) { qv = {}; }
      var bewA = t.tile.querySelector('a[aria-label*="Bewertung"], span[aria-label*="Bewertung"]');
      return {
        pos: t.pos, org: t.org == null ? '' : t.org, asin: t.asin, titel: clean(t.titel), preis: t.preis, rating: t.rating,
        bewertungen: bewA ? (clean(bewA.getAttribute('aria-label')).match(/^([\d.]+)/) || [])[1] || '' : '',
        kauf: t.kauf || '', anzeige: t.gesponsert ? 'ja' : '', badge: clean((t.tile.querySelector('.a-badge-text') || {}).textContent),
        eigen: t.istEigen ? 'ja' : '', bsr: qv.bsr || '', bsr_kategorie: qv.bsr_kategorie || '', verkaeufer: qv.verkaeufer || '',
        seit: qv.seit || '', varianten: qv.varianten > 1 ? qv.varianten : ''
      };
    });
  }

  // ---- Verkaeufe/Umsatz je Zeile: echte Kaufzahl vom Tile, sonst BSR-Schaetzung
  // ueber LC.sales (von parallelem Agent gebaut) - immer defensiv guarden ------
  function schaetzVerkauf(r) {
    var k = ganz(r.kauf);
    if (k != null) return { menge: k, schaetzung: false };
    var bsr = ganz(r.bsr);
    if (bsr == null || !LC.sales || !LC.sales.schaetzeSync) return null;
    var s = LC.sales.schaetzeSync(bsr, r.bsr_kategorie || '');
    return s && s.menge != null ? { menge: s.menge, schaetzung: true, quelle: s.quelle, paare: s.paare, faktor: s.faktor } : null;
  }
  function schaetzUmsatz(r) {
    var v = schaetzVerkauf(r), p = dez(r.preis);
    return v && p != null ? { betrag: v.menge * p, schaetzung: v.schaetzung } : null;
  }

  // ---- Summen ---------------------------------------------------------------
  function summen(rows, ctx) {
    var row = ui.el('div', 'lc-row');
    var add = function (html, title, kind) { row.appendChild(ui.chip(html, kind || 'mut', title)); };
    var preise = [], sterne = [], rez = [], kauf = 0, kaufN = 0, umsatz = 0, umsatzN = 0;
    rows.forEach(function (r) {
      var p = dez(r.preis), s = dez(r.rating), b = ganz(r.bewertungen), k = ganz(r.kauf);
      if (p != null) preise.push(p);
      if (s != null) sterne.push(s);
      if (b != null) rez.push(b);
      if (k != null) { kauf += k; kaufN++; if (p != null) { umsatz += k * p; umsatzN++; } }
    });
    var avg = function (a) { return a.reduce(function (x, y) { return x + y; }, 0) / a.length; };
    add(rows.length + ' <span class="lc-k">Treffer</span>');
    if (preise.length) add('<span class="lc-k">Ø Preis</span> ' + ui.esc(ui.eur(avg(preise))), preise.length + ' Kachelpreise');
    if (sterne.length) add('<span class="lc-k">Ø</span> ' + de(avg(sterne), 2) + ' ★', sterne.length + ' bewertete Treffer');
    if (rez.length) {
      rez.sort(function (a, b) { return a - b; });
      add('<span class="lc-k">Median Rezensionen</span> ' + ui.nf(rez[Math.floor(rez.length / 2)]), rez.length + ' Treffer mit Rezensionszahl');
    }
    if (kaufN) add('<span class="lc-k">Σ Kaufzahl</span> ' + ui.nf(kauf) + '+', kaufN + ' Treffer mit Kaufzahl (Amazon nennt Untergrenzen)');
    if (umsatzN) add('<span class="lc-k">Umsatz/Monat</span> ≥ ' + ui.esc(ui.eur(umsatz)), 'Σ Kaufzahl × Preis über ' + umsatzN + ' Treffer mit beiden Werten – Untergrenze', '');
    var fba = 0, verk = 0;                              // FBA steckt nur in den Quick-View-Daten der Kachel
    ctx.tiles.forEach(function (t) {
      try {
        var qv = JSON.parse(t.tile.getAttribute('data-lc-qv-data') || 'null');
        if (qv && qv.verkaeufer) { verk++; if (qv.fba) fba++; }
      } catch (e) { /* keine Quick-View-Daten */ }
    });
    if (verk) add('<span class="lc-k">FBA</span> ' + Math.round(100 * fba / verk) + '% <span class="lc-k">(' + fba + '/' + verk + ')</span>', 'Anteil "Versand durch Amazon" unter den Treffern mit Quick-View-Daten');
    return row;
  }

  // ---- Markt-Uebersicht (zusaetzlich zu summen(), nur Kennzahlen ohne Ueber-
  // schneidung: Ø ★ und Σ Kaufzahl gibt's schon in summen()) ------------------
  function marktUebersicht(rows) {
    var row = ui.el('div', 'lc-row');
    var add = function (html, title) { row.appendChild(ui.chip(html, 'mut', title)); };
    var preise = [];
    rows.forEach(function (r) { var p = dez(r.preis); if (p != null) preise.push(p); });
    if (preise.length >= 2) {
      preise.sort(function (a, b) { return a - b; });
      var median = preise[Math.floor(preise.length / 2)];
      add('<span class="lc-k">Preisspanne</span> ' + ui.esc(ui.eur(preise[0])) + ' – ' + ui.esc(ui.eur(median)) + ' – ' + ui.esc(ui.eur(preise[preise.length - 1])),
        'Min – Median – Max über ' + preise.length + ' Kachelpreise');
    }
    var mitBadge = rows.filter(function (r) { return ganz(r.kauf) != null; }).length;
    if (rows.length) add('<span class="lc-k">Kaufzahl-Badge</span> ' + Math.round(100 * mitBadge / rows.length) + '% <span class="lc-k">(' + mitBadge + '/' + rows.length + ')</span>',
      'Anteil Treffer mit sichtbarer "X im letzten Monat gekauft"-Angabe am Tile');
    var gesamt = 0, gesamtN = 0, geschaetzt = false;
    rows.forEach(function (r) {
      var u = schaetzUmsatz(r);
      if (u) { gesamt += u.betrag; gesamtN++; if (u.schaetzung) geschaetzt = true; }
    });
    if (gesamtN) add('<span class="lc-k">Gesamtumsatz/Monat</span> ' + (geschaetzt ? '<span class="lc-k">≈</span> ' : '<span class="lc-k">≥</span> ') + ui.esc(ui.eur(gesamt)),
      'Summe Verkäufe/Mon × Preis über ' + gesamtN + ' Treffer (echte Kaufzahl wo vorhanden, sonst BSR-Schätzung via LC.sales)');
    return row;
  }

  // ---- Nischen-Indikator (Heuristik, kein Amazon-Wert - volle Formel im Tooltip) --
  function nischenChip(rows) {
    var nachfrage = 0, nachfrageN = 0, rez = [];
    rows.forEach(function (r) {
      var v = schaetzVerkauf(r);
      if (v) { nachfrage += v.menge; nachfrageN++; }
      var b = ganz(r.bewertungen);
      if (b != null) rez.push(b);
    });
    if (nachfrageN < 5) return null;                    // zu wenig Datengrundlage fuer eine Aussage
    rez.sort(function (a, b) { return a - b; });
    var medRez = rez.length ? rez[Math.floor(rez.length / 2)] : 0;
    var score = 5 + 2 * (Math.log10(nachfrage + 1) - 2) - 1.5 * (Math.log10(medRez + 1) - 2);
    score = Math.max(0, Math.min(10, score));
    var kind = score >= 7 ? 'ok' : (score <= 3 ? 'bad' : 'mut');
    var title = 'Heuristik, kein Amazon-Wert. Formel: 5 + 2·(log10(Nachfrage+1)−2) − 1,5·(log10(Median Rezensionen+1)−2), geklemmt auf 0–10. ' +
      'Nachfrage = Σ Verkäufe/Mon dieser Seite (echte Kaufzahl + BSR-Schätzung) = ' + ui.nf(nachfrage) + '. ' +
      'Konkurrenzhärte = Median Rezensionsanzahl = ' + ui.nf(medRez) + '. Grundlage: ' + nachfrageN + ' Treffer mit Kaufzahl.';
    return ui.chip('<span class="lc-k">Nische</span> ' + de(score, 1) + '/10', kind, title);
  }

  // ---- Tabelle --------------------------------------------------------------
  var NUM = { pos: 1, preis: 1, rating: 1, bewertungen: 1, kauf: 1, umsatz: 1, bsr: 1, seit: 1, varianten: 1 };
  var SPALTEN = [['pos', 'Pos'], ['anzeige', 'Anz.'], ['asin', 'ASIN'], ['titel', 'Titel'], ['preis', 'Preis'], ['rating', '★'],
    ['bewertungen', 'Rezensionen'], ['kauf', 'Verkäufe/Mon'], ['umsatz', 'Umsatz/Mon'], ['bsr', 'BSR'], ['verkaeufer', 'Verkäufer'], ['seit', 'seit'],
    ['varianten', 'Var.'], ['badge', 'Badge']];
  function wert(r, k) {
    if (k === 'preis' || k === 'rating') return dez(r[k]);
    if (k === 'kauf') { var v = schaetzVerkauf(r); return v ? v.menge : null; }
    if (k === 'umsatz') { var u = schaetzUmsatz(r); return u ? u.betrag : null; }
    return NUM[k] ? ganz(r[k]) : clean(r[k]);
  }
  function zelle(r, k) {
    var v = r[k], e = ui.esc;
    switch (k) {
      case 'pos': return '<td class="lc-num" title="' + (r.org === '' ? 'Anzeige' : 'organische Position ' + e(r.org)) + '">' + e(v) + '</td>';
      case 'asin': return '<td><a class="a-link-normal lc-mono" href="/dp/' + e(v) + '">' + e(v) + '</a></td>';
      case 'titel': v = clean(v); return '<td title="' + e(v) + '">' + e(v.length > 60 ? v.slice(0, 60) + '…' : v) + '</td>';
      case 'preis': return '<td class="lc-num">' + e(ui.eur(dez(v))) + '</td>';
      case 'rating': return '<td class="lc-num">' + de(dez(v), 1) + '</td>';
      case 'bewertungen': case 'bsr': return '<td class="lc-num">' + ui.nf(ganz(v)) + '</td>';
      case 'kauf': {                                    // echte Kaufzahl vom Tile, sonst BSR-Schaetzung (≈)
        var vv = schaetzVerkauf(r);
        if (!vv) return '<td class="lc-num">–</td>';
        if (!vv.schaetzung) return '<td class="lc-num">' + ui.nf(vv.menge) + '+</td>';
        var tt = 'Schätzung aus BSR' + (r.bsr_kategorie ? ' (' + e(r.bsr_kategorie) + ')' : '') + (vv.quelle ? ', Quelle ' + e(vv.quelle) : '') +
          (vv.paare != null ? ', ' + ui.nf(vv.paare) + ' Vergleichspaare' : '') + (vv.faktor != null ? ', Faktor ' + de(vv.faktor, 2) : '');
        return '<td class="lc-num" title="' + tt + '"><span class="lc-k">≈</span> ' + ui.nf(vv.menge) + '</td>';
      }
      case 'umsatz': {                                  // Verkäufe/Mon (Zeile) × Preis - echt (≥) oder geschaetzt (≈)
        var uu = schaetzUmsatz(r);
        if (!uu) return '<td class="lc-num">–</td>';
        return '<td class="lc-num">' + (uu.schaetzung ? '<span class="lc-k">≈</span> ' : '<span class="lc-k">≥</span> ') + e(ui.eur(uu.betrag)) + '</td>';
      }
      default: return '<td' + (NUM[k] ? ' class="lc-num"' : '') + '>' + e(v == null ? '' : v) + '</td>';
    }
  }
  function tabelle(rows) {
    var sorted = rows.slice().sort(function (a, b) {
      var x = wert(a, sortKey), y = wert(b, sortKey);
      var xe = x == null || x === '', ye = y == null || y === '';
      if (xe || ye) return xe === ye ? 0 : (xe ? 1 : -1);                    // Leeres immer ans Ende
      return (NUM[sortKey] ? x - y : String(x).localeCompare(String(y), 'de')) * sortDir;
    });
    var html = '<table><thead><tr>' + SPALTEN.map(function (s) {
      return '<th data-k="' + s[0] + '"' + (NUM[s[0]] ? ' class="lc-num"' : '') + '>' + s[1] + (s[0] === sortKey ? (sortDir > 0 ? ' ▲' : ' ▼') : '') + '</th>';
    }).join('') + '</tr></thead><tbody>';
    sorted.forEach(function (r) {
      html += '<tr' + (r.eigen ? ' class="lc-ok"' : '') + '>' + SPALTEN.map(function (s) { return zelle(r, s[0]); }).join('') + '</tr>';
    });
    return ui.el('div', 'lc-xray-tab', html + '</tbody></table>');
  }

  // ---- Titelwoerter der organischen Top 20 ------------------------------------
  function woerter(ctx) {
    var wrap = ui.el('div');
    var top = ctx.tiles.filter(function (t) { return t.org != null && t.org <= 20; });
    if (!top.length) return wrap;
    var eigene = {}, hatEigene = false;
    ctx.tiles.forEach(function (t) { if (t.istEigen) { hatEigene = true; tokens(t.titel).forEach(function (w) { eigene[w] = 1; }); } });
    var wz = {}, bz = {};                               // Dokument-Haeufigkeit: in wie vielen Titeln kommt es vor
    top.forEach(function (t) {
      var tk = tokens(t.titel), seen = {};
      tk.forEach(function (w, i) {
        if (!seen[w]) { seen[w] = 1; wz[w] = (wz[w] || 0) + 1; }
        if (i) { var b = tk[i - 1] + ' ' + w; if (!seen[b]) { seen[b] = 1; bz[b] = (bz[b] || 0) + 1; } }
      });
    });
    var top_n = function (m, n) {
      return Object.keys(m).sort(function (a, b) { return m[b] - m[a] || a.localeCompare(b, 'de'); }).slice(0, n);
    };
    var fehlt = function (w) { return hatEigene && w.split(' ').some(function (x) { return !eigene[x]; }); };
    var row = function (keys, m) {
      var r = ui.el('div', 'lc-row');
      keys.forEach(function (k) {
        r.appendChild(ui.chip(ui.esc(k) + ' <span class="lc-k">' + m[k] + '</span>', fehlt(k) ? 'bad' : 'mut',
          fehlt(k) ? 'fehlt in euren Titeln' : 'in ' + m[k] + ' von ' + top.length + ' Titeln'));
      });
      return r;
    };
    wrap.appendChild(ui.el('h3', 'a-text-bold', 'Titelwörter der Top 20'));
    wrap.appendChild(row(top_n(wz, 15), wz));
    var bg = top_n(bz, 8).filter(function (b) { return bz[b] > 1; });
    if (bg.length) wrap.appendChild(row(bg, bz));
    return wrap;
  }

  // ---- Eigene Rang-Entwicklung ------------------------------------------------
  function rang(ctx) {
    if (!ctx.keyword) return;
    // Bestseller-Listen sind keine Suche; Seite 2+ zaehlt org wieder ab 1 (wie serp-ranktracker.js)
    if (/^bestseller:/i.test(ctx.keyword)) return;
    var pg = 1; try { pg = parseInt(new URL(location.href).searchParams.get('page'), 10) || 1; } catch (e) { /* 1 */ }
    if (pg > 1) return;
    var best = null;
    ctx.tiles.forEach(function (t) { if (t.istEigen && t.org != null && (!best || t.org < best.org)) best = t; });
    if (!best) return;
    var key = 'krank:serp:' + ctx.keyword.toLowerCase();
    var p = histKey === key ? Promise.resolve() : ui.storage(key).then(function (d) { hist = Array.isArray(d[key]) ? d[key] : []; histKey = key; });
    p.then(function () {
      var now = new Date(), last = hist[hist.length - 1];
      if (!(last && now - new Date(last[0]) < SECHS_H && last[1] === best.org)) {
        hist.push([now.toISOString(), best.org, best.asin]);
        if (hist.length > 60) hist = hist.slice(-60);
        /* Vor dem Schreiben frisch lesen: die In-Memory-Kopie friert nach dem
           ersten Lesen ein - ein zweiter Tab mit derselben Suche wuerde sonst
           ueberschrieben (Review 31.08., Muster aus serp-ranktracker). */
        var mine = hist[hist.length - 1];
        ui.storage(key).then(function (d3) {
          var extern = Array.isArray(d3[key]) ? d3[key] : [];
          var eLast = extern[extern.length - 1];
          if (!(eLast && eLast[0] === mine[0] && eLast[1] === mine[1])) extern.push(mine);
          if (extern.length > 60) extern = extern.slice(-60);
          hist = extern;
          var o = {}; o[key] = extern;
          chrome.storage.local.set(o, function () { void chrome.runtime.lastError; });
        });
      }
      var vorher = null;                                // letzte Messung mit anderer Position
      for (var i = hist.length - 1; i >= 0 && !vorher; i--) if (hist[i][1] !== best.org) vorher = hist[i];
      var html = '<span class="lc-k">eigene Pos.</span> ' + best.org + ' ', kind = 'mut', title = 'beste organische Position eigener Kacheln, ' + hist.length + ' Messungen';
      if (vorher) {
        var besser = best.org < vorher[1];
        kind = besser ? 'ok' : 'bad';
        html += '<span class="lc-k">(' + (besser ? '▲' : '▼') + ' von ' + vorher[1] + ' am ' + ui.tag(new Date(vorher[0])) + ')</span>';
      } else html += '<span class="lc-k">(' + (hist.length > 1 ? 'unverändert seit ' + ui.tag(new Date(hist[0][0])) : 'neu') + ')</span>';
      var c = ctx.head.querySelector('[data-lc-xray-rank]');
      if (!c) {
        c = ui.chip(html, kind, title); c.setAttribute('data-lc-xray-rank', '1');
        ctx.head.insertBefore(c, ctx.head.querySelector('.lc-sp'));
      } else { c.innerHTML = html; c.className = 'lc-chip ' + kind; c.title = title; }
    }).catch(function (e) { console.warn('[LC] Xray Rang', e); });
  }

  // ---- Box + Kopf-Chip ---------------------------------------------------------
  function render() {
    var ctx = letzterCtx, inner = box.querySelector('.a-box-inner');
    inner.innerHTML = '';
    var rows = zeilen(ctx);
    inner.appendChild(summen(rows, ctx));
    inner.appendChild(marktUebersicht(rows));
    var nische = nischenChip(rows);
    if (nische) { var nr = ui.el('div', 'lc-row'); nr.appendChild(nische); inner.appendChild(nr); }
    inner.appendChild(tabelle(rows));
    inner.appendChild(woerter(ctx));
  }
  function zeigen() {
    box.style.display = offen ? '' : 'none';
    var c = letzterCtx.head.querySelector('[data-lc-xray]');
    if (c) c.className = 'lc-chip lc-copy' + (offen ? ' ok' : '');
  }
  function boxAnlegen(ctx) {
    if (!document.getElementById('lc-xray-css')) {
      var st = ui.el('style', '', CSS); st.id = 'lc-xray-css';
      (document.head || document.documentElement).appendChild(st);
    }
    box = ui.el('div', 'a-box a-spacing-base lc-xray'); box.setAttribute('data-lc-xray-box', '1');
    box.style.display = 'none';
    box.appendChild(ui.el('div', 'a-box-inner'));
    box.addEventListener('click', function (ev) {                       // Sortierung per Spaltenkopf
      var th = ev.target.closest ? ev.target.closest('th[data-k]') : null;
      if (!th || !box.contains(th)) return;
      var k = th.getAttribute('data-k');
      if (k === sortKey) sortDir = -sortDir; else { sortKey = k; sortDir = 1; }
      render();
    });
    ctx.head.insertAdjacentElement('afterend', box);
  }

  H.serp.push(function (ctx) {
    ui = ctx.ui; letzterCtx = ctx;
    if (!box || !box.isConnected) boxAnlegen(ctx);
    if (!ctx.head.querySelector('[data-lc-xray]')) {                   // Kopf wird je Durchlauf geleert
      var c = ui.chip('Xray', '', 'Wettbewerber-Tabelle, Summen und Titelwörter dieser Suche auf-/zuklappen');
      c.setAttribute('data-lc-xray', '1'); c.classList.add('lc-copy');
      c.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        offen = !offen;
        chrome.storage.local.set({ lcXray: offen }, function () { void chrome.runtime.lastError; });
        zeigen();
      });
      ctx.head.insertBefore(c, ctx.head.querySelector('.lc-sp'));
    }
    render();
    if (!offenGelesen) offenGelesen = ui.storage('lcXray').then(function (d) { offen = !!d.lcXray; }).catch(function () { /* zu */ });
    offenGelesen.then(zeigen);
    rang(ctx);
  });
  H.xray = { tokens: tokens };                                          // fuer Selbsttests
})();
