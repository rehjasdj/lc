/* Listing Checker - On-Page-Ansicht fuer amazon.de (Content-Script).

   Laeuft automatisch, ohne Klick, auf Produkt- und Suchseiten ("ich will direkt
   auf der Amazon-Seite die Sachen sehen" - LO, 26.08.2026).

   Gestaltungsregel (LO, 27.08.2026): NAHTLOS in Amazons Design - aber sichtbar.
   Also nicht eine Karte, in der alles steht, sondern jede Zahl DORT, wo Amazon
   das Thema ohnehin zeigt, als deutlich erkennbarer Chip:
     - BSR-Rang an der Breadcrumb-Kategorie, zu der er gehoert - verlinkt auf
       Amazons Bestseller-Liste dieser Kategorie (wie Helium)
     - Zeichenzaehler direkt hinter Titel und Item Highlights
     - Buybox-Status und Anbieterzahl oben in der Buybox
     - Fremdpreise unter dem Amazon-Preis
     - Verlauf, Anbieterliste, Listing-Qualitaet und Aktionen als Amazon-Karte
       (a-box) unter der Buybox, Knoepfe im Buybox-Markup
   Chips nutzen Amazons Markup/Schrift; die Farbfamilie ist Amazons Gelb/Gruen/
   Rot, damit man sie sofort als "unsere" Angaben erkennt.

   Alles Eingefuegte traegt data-lc="1": shared/extract.js filtert das beim
   Lesen heraus (sonst stand "Titel 65/75" im Scrape), und beim Variantenwechsel
   (Amazon rendert Titel/Breadcrumb per Ajax neu) wird alles abgeraeumt und fuer
   die neue ASIN neu aufgebaut.

   Netz: NUR DOM-Lesen plus genau EIN AOD-Abruf je sichtbarer Produktseite
   (derselbe Request wie Amazons "Weitere Angebote"; 15 min zwischengespeichert).
   Unsichtbare Automations-Tabs (inTab) bekommen kein Panel und keinen Request.
   Rechte: keine neuen - amazon.de ist freigegeben.
   Setzt shared/extract.js, search.js, match.js, amazon-pro.js voraus (Manifest). */
(function () {
  'use strict';
  if (window.top !== window) return;                       // keine iframes
  var LC = globalThis.LC;
  if (!LC || !LC.extract || !LC.amazonPro) return;

  /* Andockpunkte fuer Zusatzmodule (features/*.js, im Manifest VOR onpage.js):
       LC.onpage.panel.push(function (ctx) {...})   Produktseite, nach dem Aufbau
       LC.onpage.serp.push(function (ctx) {...})    Suchseite, nach jedem Durchlauf
                                                     (ctx.head wird je Durchlauf geleert - Kopf-Chips neu anhaengen)
       LC.onpage.chart = function (container, samples, ui) {...}  ersetzt die Verlaufskurve
     ctx.ui = Helfer (el, chip, copyChip, button, esc, eur, nf, tag, clean, storage, send, EIGEN).
     Alles, was ein Modul einfuegt, MUSS ueber ui.el/ui.chip entstehen (data-lc), sonst
     landet es im Scrape und ueberlebt den Variantenwechsel. */
  var HOOKS = LC.onpage = LC.onpage || {};
  HOOKS.panel = HOOKS.panel || []; HOOKS.serp = HOOKS.serp || [];
  var hookRun = function (list, ctx) {
    list.forEach(function (h) { try { h(ctx); } catch (e) { console.warn('[LC] Modul-Fehler', e); } });
  };

  var EIGEN = /casaria|monzana|gardebruk|deuba/i;
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  var eur = function (p) { return p == null ? '–' : Number(p).toFixed(2).replace('.', ',') + ' €'; };
  var tag = function (t) { return ('0' + t.getDate()).slice(-2) + '.' + ('0' + (t.getMonth() + 1)).slice(-2) + '.'; };
  var nf = function (n) { return n == null ? '–' : String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var el = function (tagName, cls, html) {
    var e = document.createElement(tagName);
    if (cls) e.className = cls;
    if (html != null) e.innerHTML = html;
    e.setAttribute('data-lc', '1');
    return e;
  };
  var chip = function (html, kind, title, href) {
    var c = el(href ? 'a' : 'span', 'lc-chip' + (kind ? ' ' + kind : '') + (href ? ' a-link-normal' : ''), html);
    if (title) c.title = title;
    if (href) { c.href = href; }
    return c;
  };
  var send = function (msg) {
    return new Promise(function (res) {
      try { chrome.runtime.sendMessage(msg, function (r) { void chrome.runtime.lastError; res(r); }); }
      catch (e) { res(null); }
    });
  };
  var storage = function (keys) {
    return new Promise(function (res) { chrome.storage.local.get(keys, function (d) { res(d || {}); }); });
  };
  var mapZahl = function (roh, einheit) {
    var n = parseFloat(String(roh).replace(/\./g, '').replace(',', '.'));
    if (!isFinite(n)) return null;
    if (/Tsd/i.test(einheit || '')) n *= 1000;
    else if (/Mio/i.test(einheit || '')) n *= 1000000;
    return Math.round(n);
  };
  var KAUF_RE = /([\d.,]+)\s*(Tsd\.|Mio\.)?\+?\s*(?:Mal )?im (?:letzten|vergangenen) Monat gekauft/i;
  /* Kaufzahl-Badge der Produktseite robust finden (LO 01.09.: feste IDs griffen
     nicht mehr, "er lernt nicht"). Erst social-proofing-Container in allen
     Schreibweisen, dann als Fallback die DP-Mittelspalte mit der strengen RE -
     NICHT der ganze Body, sonst zaehlen Karussell-Kacheln fremder Produkte.
     doc-Parameter: serp-quickview parst fremde DP-HTML mit demselben Finder. */
  var kaufBadge = function (doc) {
    doc = doc || document;
    var container = doc.querySelectorAll('[id*="socialProofing" i], [id*="social-proofing" i], [class*="social-proofing" i], [data-csa-c-content-id*="social" i]');
    for (var i = 0; i < container.length; i++) {
      var t = clean(container[i].textContent || '');
      if (!/gekauft/i.test(t)) continue;
      var m = t.match(KAUF_RE) || t.match(/([\d.,]+)\s*(Tsd\.|Mio\.)?\s*\+/);
      if (m) return { zahl: mapZahl(m[1], m[2]), text: clean(m[0]) };
    }
    var mitte = doc.querySelector('#centerCol, #ppd');
    if (mitte) {
      var m2 = clean(mitte.textContent || '').match(KAUF_RE);
      if (m2) return { zahl: mapZahl(m2[1], m2[2]), text: clean(m2[0]) };
    }
    return null;
  };

  /* Chips: Amazons Schrift und Radien, Farbfamilie Amazon-Gelb (Buttons),
     Erfolgsgruen (#007600 "Auf Lager") und Preisrot (#B12704). Alles andere
     kommt aus Amazons eigenen Klassen (a-box, a-button, a-size-*, a-color-*). */
  var CSS = [
    '.lc-chip{display:inline-block;padding:1px 7px;margin:0 0 0 6px;border-radius:3px;font-size:12px;line-height:17px;font-weight:700;',
    ' color:#0F1111;background:#FEF3D9;border:1px solid #E9B84D;vertical-align:middle;white-space:nowrap;font-family:"Amazon Ember",Arial,sans-serif;text-decoration:none}',
    'a.lc-chip:hover{border-color:#C7511F;color:#C7511F;text-decoration:none}',
    '.lc-chip.ok{background:#E7F5EA;border-color:#8CC7A0;color:#007600}',
    '.lc-chip.bad{background:#FDECEC;border-color:#E9A0A0;color:#B12704}',
    '.lc-chip.mut{background:#F7F8F8;border-color:#D5D9D9;color:#565959;font-weight:400}',
    '.lc-chip .lc-k{font-weight:400;color:#565959}',
    '.lc-chip.lc-copy{cursor:pointer}.lc-chip.lc-copy:hover{border-color:#C7511F;color:#C7511F}',
    '.lc-mono{font-family:"Courier New",monospace;font-variant-numeric:tabular-nums}',
    '.lc-row{display:flex;flex-wrap:wrap;gap:6px 8px;align-items:center}',
    /* Karte/Bloecke: nichts darf rechts rausragen - Chips und Tabellen brechen um */
    '#lc-card,.lc-block{overflow-wrap:anywhere}',
    '#lc-card .lc-chip,.lc-block .lc-chip{white-space:normal;max-width:100%;text-align:left}',
    '#lc-card table,.lc-block table{width:100%;table-layout:fixed;border-collapse:collapse}',
    '#lc-card td,#lc-card th,.lc-block td,.lc-block th{overflow-wrap:anywhere;vertical-align:top}',
    '#lc-card svg,.lc-block svg{max-width:100%}',
    '.lc-block h3{font-size:15px;margin:0 0 8px;color:#0F1111}.lc-block .lc-block-tag{margin-bottom:2px;letter-spacing:.3px;text-transform:uppercase}',
    '.lc-row .lc-chip{margin:0}',
    '#lc-card .lc-head{display:flex;align-items:center;gap:6px;margin-bottom:8px}',
    '#lc-card .lc-head .lc-sp{flex:1}',
    /* Score-Kopf (Zahl + Balken), Pruefliste (offene Punkte zuerst), Aufklapp-Link */
    '.lc-score{display:flex;align-items:center;gap:10px;margin:2px 0 8px}.lc-score b{font-size:22px;line-height:24px;font-weight:700}.lc-score b .lc-k{font-size:13px;font-weight:400}',
    '.lc-bar{flex:1;height:8px;border-radius:4px;background:#E7E7E7;overflow:hidden}.lc-bar i{display:block;height:100%;background:#007600}.lc-bar.warn i{background:#E9B84D}.lc-bar.bad i{background:#B12704}',
    '.lc-check{font-size:12px;line-height:18px;color:#0F1111}.lc-check>div{display:flex;gap:6px;align-items:baseline;padding:1px 0}.lc-check .lc-t{flex:1}',
    '.lc-ok{color:#007600;font-weight:700}.lc-bad{color:#B12704;font-weight:700}',
    '.lc-more{display:inline-block;margin-top:4px;font-size:12px;color:#007185;cursor:pointer}.lc-more:hover{text-decoration:underline;color:#C7511F}',
    '#lc-card ul.lc-offers{margin:0;padding:0;list-style:none}',
    '#lc-card ul.lc-offers li{display:flex;justify-content:space-between;gap:8px;font-size:13px;line-height:19px;padding:2px 0;border-top:1px solid #F0F2F2}',
    '#lc-card ul.lc-offers li:first-child{border-top:0}',
    '#lc-card ul.lc-offers li.eigen{color:#007600;font-weight:700}#lc-card ul.lc-offers li.unter{color:#B12704}',
    '#lc-card svg{display:block;width:100%;height:60px;margin-top:2px}',
    '#lc-card .lc-k{color:#565959;font-size:12px}',
    '#lc-card .a-button-stack{margin-top:10px}',
    '#lc-card h3{font-size:13px;margin:12px 0 6px;padding-top:10px;border-top:1px solid #E7E7E7;color:#0F1111}',
    '#lc-card h3:first-of-type{margin-top:0;padding-top:0;border-top:0}',
    '.lc-score{display:flex;align-items:center;gap:10px;margin:2px 0 8px}.lc-score b{font-size:22px;line-height:24px;font-weight:700}.lc-score b .lc-k{font-size:13px;font-weight:400}',
    '.lc-bar{flex:1;height:8px;border-radius:4px;background:#E7E7E7;overflow:hidden}.lc-bar i{display:block;height:100%;background:#007600}.lc-bar.warn i{background:#E9B84D}.lc-bar.bad i{background:#B12704}',
    '.lc-check{font-size:12px;line-height:18px;color:#0F1111}.lc-check>div{display:flex;gap:6px;align-items:baseline;padding:1px 0}.lc-check .lc-t{flex:1}',
    '.lc-ok{color:#007600;font-weight:700}.lc-bad{color:#B12704;font-weight:700}',
    '.lc-more{display:inline-block;margin-top:4px;font-size:12px;color:#007185;cursor:pointer}.lc-more:hover{text-decoration:underline;color:#C7511F}',
    '.lc-status{font-size:12px;color:#565959;margin-top:6px;min-height:14px}',
    '.lc-badges{display:flex;flex-wrap:wrap;gap:3px 8px;align-items:center;margin:3px 0 3px}',
    '.lc-badges .lc-chip{margin:0}',
    '.lc-badges .lc-asin{font-size:12px;color:#565959}',
    '.lc-badges .lc-asin b{font-family:"Courier New",monospace;color:#007185;cursor:pointer;font-weight:400}',
    '.lc-badges .lc-asin b:hover{text-decoration:underline;color:#C7511F}',
    '.lc-tile-eigen{box-shadow:inset 4px 0 0 #007600}',
    '.lc-serp-head{font-size:13px;line-height:19px;color:#0F1111;padding:8px 0 6px;border-bottom:1px solid #E7E7E7;margin-bottom:8px;display:flex;gap:6px;flex-wrap:wrap;align-items:center}',
    '.lc-serp-head .lc-sp{flex:1}',
    '.lc-dark-toggle{color:#007185;cursor:pointer;white-space:nowrap;font-size:12px}.lc-dark-toggle:hover{color:#C7511F;text-decoration:underline}',
    '.lc-dark-toggle::before{content:"";display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:4px;vertical-align:-1px;background:#232f3e;box-shadow:inset -3px -2px 0 0 #f3d27a}',
    'html.lc-dark .lc-dark-toggle::before{background:#f3d27a;box-shadow:none}'
    /* Das Dark-Theme selbst (echte Farben, kein Invert) liegt in dark.css und wird
       von dark.js bei document_start geschaltet - hier nur der Umschalter. */
  ].join('\n');

  function styles() {
    if (document.getElementById('lc-css')) return;
    var st = document.createElement('style'); st.id = 'lc-css'; st.textContent = CSS;
    (document.head || document.documentElement).appendChild(st);
  }

  // ------------------------------------------------------------ Dark Mode

  var darkAn = document.documentElement.classList.contains('lc-dark');   // dark.js war schon da
  function darkAnwenden(on) {
    darkAn = !!on;
    document.documentElement.classList.toggle('lc-dark', darkAn);
    document.querySelectorAll('.lc-dark-toggle').forEach(function (t) { t.textContent = darkAn ? 'Hell' : 'Dunkel'; });
  }
  function darkToggle() {
    var t = el('span', 'lc-dark-toggle', darkAn ? 'Hell' : 'Dunkel');
    t.title = 'Amazon-Seite dunkel/hell (wird gemerkt)';
    t.addEventListener('click', function (ev) {
      ev.preventDefault(); ev.stopPropagation();
      darkAnwenden(!darkAn);
      chrome.storage.local.set({ lcDark: darkAn });
    });
    return t;
  }
  var darkInit = storage('lcDark').then(function (d) { darkAnwenden(d.lcDark == null ? darkAn : !!d.lcDark); });

  var copyChip = function (asin) {
    var c = chip('<span class="lc-mono">' + esc(asin) + '</span> ⧉', 'mut lc-copy', 'ASIN kopieren');
    c.addEventListener('click', function (ev) {
      ev.preventDefault(); ev.stopPropagation();
      navigator.clipboard.writeText(asin).then(function () {
        c.innerHTML = '<span class="lc-mono">' + esc(asin) + '</span> ✓';
        setTimeout(function () { c.innerHTML = '<span class="lc-mono">' + esc(asin) + '</span> ⧉'; }, 1200);
      });
    });
    return c;
  };

  /* Text-Kopier-Chip (Titel, Highlights, Bullets, Beschreibung) - wie der ASIN-Chip */
  var textChip = function (label, text, title) {
    var c = chip(esc(label) + ' ⧉', 'mut lc-copy', title || (label + ' in die Zwischenablage'));
    c.addEventListener('click', function (ev) {
      ev.preventDefault(); ev.stopPropagation();
      navigator.clipboard.writeText(text || '').then(function () {
        c.innerHTML = esc(label) + ' ✓';
        setTimeout(function () { c.innerHTML = esc(label) + ' ⧉'; }, 1200);
      });
    });
    return c;
  };

  /* Amazons eigenes Knopf-Markup (wie "In den Einkaufswagen"): a-button-span12
     gestapelt, damit nichts abgeschnitten wird. */
  var button = function (text, primary, title, fn) {
    var wrap = el('span', 'a-button a-spacing-small a-button-span12 ' + (primary ? 'a-button-primary' : 'a-button-base'));
    var in2 = el('span', 'a-button-inner');
    var input = el('input', 'a-button-input'); input.type = 'button'; input.title = title; input.setAttribute('aria-label', text);
    var txt = el('span', 'a-button-text', esc(text)); txt.setAttribute('aria-hidden', 'true');
    in2.appendChild(input); in2.appendChild(txt); wrap.appendChild(in2);
    input.addEventListener('click', function () { fn(input); });
    return wrap;
  };
  HOOKS.ui = { el: el, chip: chip, copyChip: copyChip, textChip: textChip, button: button, esc: esc, eur: eur, nf: nf, tag: tag, clean: clean,
    storage: storage, send: send, EIGEN: EIGEN, mapZahl: mapZahl, KAUF_RE: KAUF_RE, kaufBadge: kaufBadge,
    aktuelleAsin: function () { return aktuelleAsin; } };

  // ------------------------------------------------------------ Produktseite

  function abraeumen() {
    document.querySelectorAll('[data-lc]').forEach(function (n) { n.remove(); });
    document.querySelectorAll('.lc-tile-eigen').forEach(function (n) { n.classList.remove('lc-tile-eigen'); });
  }

  var aktuelleAsin = '';
  var onChangedHandler = null;
  var aodLauf = {};      // asin -> laufendes AOD-Promise: Twister-Rebuilds teilen sich EINEN Abruf
  var panelFehler = {};  // asin -> Fehlversuche ohne Titel (sonst 800ms-Dauerschleife, Review 31.08.)

  function panel() {
    var asin = LC.amazonPro.getAsin(document, location.href);
    if (!asin) return;
    styles();
    abraeumen();
    aktuelleAsin = asin;
    var r = LC.extract(document, location.href);
    if (!r || !r.titel) { panelFehler[asin] = (panelFehler[asin] || 0) + 1; return; }
    panelFehler[asin] = 0;
    var bbx = LC.amazonPro.buyboxOnPage(document);
    var ok = function (b) { return b ? 'ok' : 'bad'; };

    // -- 1. Titel und Highlights: Zaehler als GESCHWISTER (nicht im Textknoten)
    var tl = (r.titel || '').length, hl = (r.item_highlights || '').length;
    var titleEl = document.getElementById('productTitle');
    if (titleEl) {
      titleEl.insertAdjacentElement('afterend', textChip('Titel', r.titel));
      titleEl.insertAdjacentElement('afterend', copyChip(asin));
      titleEl.insertAdjacentElement('afterend', chip('<span class="lc-k">Titel</span> ' + tl + '/75', ok(tl <= 75), 'Titelzeichen (max. 75 seit 27.07.2026)'));
    }
    var hlEl = document.querySelector('#titleSection .dp-title-differentiators, .dp-title-differentiators');
    var hlChip = chip('<span class="lc-k">Highlights</span> ' + hl + '/125', ok(hl <= 125 && hl > 0), hl ? 'Item-Highlights-Zeichen (max. 125)' : 'keine Item Highlights gefunden');
    if (hlEl) {
      var hlRow = el('div', 'a-section a-spacing-none'); hlRow.appendChild(hlChip);
      if (hl) hlRow.appendChild(textChip('Highlights', r.item_highlights));
      hlRow.querySelector('.lc-chip').style.marginLeft = '0';
      hlEl.insertAdjacentElement('afterend', hlRow);
    } else if (titleEl) titleEl.insertAdjacentElement('afterend', hlChip);

    // -- 2. BSR: an die Breadcrumb-Kategorie, verlinkt auf Amazons Bestseller-Liste
    var bsr = (r.bsr_text || '').split(' | ').map(function (t) {
      var m = t.match(/^Nr\. (\d+) in (.+)$/);
      return m ? { rang: Number(m[1]), kat: clean(m[2]) } : null;
    }).filter(Boolean);
    /* Amazons Detailtabelle verlinkt jede Rang-Kategorie auf /gp/bestsellers/...
       ("Siehe Top 100 in Garten", "Esstische"). Daraus die Links holen. */
    var bsLinks = {};
    document.querySelectorAll('a[href*="/gp/bestsellers/"]').forEach(function (a) {
      var t = clean(a.textContent).replace(/^Siehe Top \d+ in\s+/i, '');
      if (t && !bsLinks[t.toLowerCase()]) bsLinks[t.toLowerCase()] = a.getAttribute('href');
    });
    var bsrChip = function (b, mitKat) {
      var href = bsLinks[b.kat.toLowerCase()] || '';
      return chip('<span class="lc-k">BSR</span> ' + nf(b.rang) + (mitKat ? ' <span class="lc-k">in ' + esc(b.kat) + '</span>' : ''), '',
        (href ? 'Bestseller-Liste „' + b.kat + '" öffnen' : 'Bestseller-Rang in ' + b.kat), href);
    };
    var crumbs = document.querySelectorAll('#wayfinding-breadcrumbs_feature_div li a');
    var crumbList = document.querySelector('#wayfinding-breadcrumbs_feature_div ul');
    var rest = [];
    bsr.forEach(function (b) {
      var hit = null;
      Array.prototype.forEach.call(crumbs, function (a) {
        if (!hit && clean(a.textContent).toLowerCase() === b.kat.toLowerCase()) hit = a;
      });
      if (hit) hit.insertAdjacentElement('afterend', bsrChip(b, false));
      else rest.push(b);
    });
    if (crumbList && (rest.length || !bsr.length)) {
      var li = el('li'); var span = el('span', 'a-list-item');
      if (rest.length) rest.forEach(function (b) { span.appendChild(bsrChip(b, true)); });
      else span.appendChild(chip('<span class="lc-k">BSR</span> kein Rang', 'mut'));
      li.appendChild(span); crumbList.appendChild(li);
    } else if (!crumbList && titleEl) {
      bsr.forEach(function (b) { titleEl.insertAdjacentElement('afterend', bsrChip(b, true)); });
    }

    // -- 2b. Bullets/Beschreibung: Kopier-Chips direkt unter "Info zu diesem Artikel"
    var fb = document.querySelector('#feature-bullets, #featurebullets_feature_div');
    if (fb) {
      var bl = [];
      for (var bi = 1; bi <= 8; bi++) { if (clean(r['bullet_' + bi])) bl.push(clean(r['bullet_' + bi])); }
      if (!bl.length) Array.prototype.forEach.call(fb.querySelectorAll('li span.a-list-item'), function (li) { var t = clean(li.textContent); if (t) bl.push(t); });
      var fbRow = el('div', 'a-section a-spacing-small lc-row');
      fbRow.appendChild(chip(bl.length + ' <span class="lc-k">Bullets</span> · Ø ' + (bl.length ? Math.round(bl.reduce(function (a, b) { return a + b.length; }, 0) / bl.length) : 0) + ' <span class="lc-k">Zeichen</span>',
        bl.length >= 5 ? 'ok' : 'bad', bl.map(function (b, i) { return (i + 1) + ': ' + b.length + ' Zeichen'; }).join(' · ')));
      fbRow.appendChild(textChip('Bullets', bl.map(function (b, i) { return (i + 1) + '. ' + b; }).join('\n'), 'alle Bullets nummeriert in die Zwischenablage'));
      /* Einzeln kopieren: ein ⧉ DIREKT hinter jedem Bullet statt der B1-B8-Reihe
         (LO, 30.08.). Text wird VOR dem Anhaengen gelesen; beim Scrape ist der
         Chip unschaedlich, weil extract.js [data-lc] aus dem Klon entfernt. */
      Array.prototype.forEach.call(fb.querySelectorAll('li span.a-list-item'), function (sp) {
        var t = clean(sp.textContent);
        if (!t) return;
        sp.appendChild(textChip('', t, 'diesen Bullet (' + t.length + ' Zeichen) kopieren'));
      });
      if (clean(r.beschreibung)) fbRow.appendChild(textChip('Beschreibung', clean(r.beschreibung)));
      fbRow.appendChild(textChip('Alles', [r.titel, r.item_highlights].concat(bl).concat([clean(r.beschreibung)]).filter(Boolean).join('\n\n'), 'Titel, Highlights, Bullets und Beschreibung zusammen'));
      fb.appendChild(fbRow);
    }

    // -- 3. Buybox: Status + Anbieter oben in der Buybox
    var buybox = document.getElementById('buybox') || document.getElementById('desktop_buybox');
    var bbRow = el('div', 'a-section a-spacing-small lc-row');
    var bbText = bbx.status === 'UNTERDRUECKT' ? 'Buybox unterdrückt' : (bbx.status === 'ja' ? 'Buybox' : (bbx.status === 'nicht verfuegbar' ? 'nicht verfügbar' : 'Buybox ' + (bbx.status || '?')));
    bbRow.appendChild(chip(esc(bbText) + (bbx.status === 'ja' && bbx.verkaeufer ? ' <span class="lc-k">' + esc(bbx.verkaeufer) + '</span>' : ''),
      bbx.status === 'ja' ? 'ok' : (bbx.status === 'UNTERDRUECKT' ? 'bad' : ''), 'Kaufblock=' + (bbx.hat_kaufblock ? 'ja' : 'nein') + ', Alle-Kaufoptionen=' + (bbx.hat_alle_kaufoptionen ? 'ja' : 'nein')));
    var aodChip = chip('<span class="lc-k">Anbieter</span> …', 'mut');
    bbRow.appendChild(aodChip);
    if (buybox) buybox.prepend(bbRow);

    // -- 4. Fremdpreise unter dem Amazon-Preis
    var priceBlock = document.getElementById('corePriceDisplay_desktop_feature_div') || document.getElementById('corePrice_feature_div');
    var priceRow = el('div', 'a-section a-spacing-top-micro lc-row');
    if (priceBlock) priceBlock.appendChild(priceRow);

    // -- 5. Karte unter der Buybox: Anbieterliste, Andere, Verlauf, Qualitaet, Aktionen
    var card = el('div', 'a-box a-spacing-base'); card.id = 'lc-card';
    var inner = el('div', 'a-box-inner'); card.appendChild(inner);
    var dbb = document.getElementById('desktop_buybox');
    if (dbb && dbb.parentNode) dbb.insertAdjacentElement('afterend', card);
    else if (document.getElementById('rightCol')) document.getElementById('rightCol').appendChild(card);
    else if (priceBlock) priceBlock.insertAdjacentElement('afterend', card);
    var head = el('div', 'lc-head');
    head.appendChild(el('span', 'a-size-base a-text-bold', 'Listing Checker'));
    head.appendChild(copyChip(asin));
    head.appendChild(el('span', 'lc-sp'));
    head.appendChild(darkToggle());
    inner.appendChild(head);
    var stack = null;
    /* Sektion: ohne `wo` in der Karte; mit `wo` als eigene a-box an Amazons Stelle
       ('bullets' unter "Info zu diesem Artikel", 'reviews' vor den Kundenrezensionen,
       'twister' unter der Variantenwahl) - nicht alles in der rechten Spalte
       (LO, 29.08.2026). Fehlt der Anker: Karte. */
    var ANKER = {
      bullets: ['#featurebullets_feature_div', '#feature-bullets', '#productOverview_feature_div'],
      reviews: ['#reviewsMedley', '#customerReviews', '#cm-cr-dp-review-list'],
      twister: ['#twister_feature_div', '#twister', '#variation_color_name']
    };
    var sec = function (title, wo) {
      var h = el('h3', 'a-text-bold', esc(title)), b = el('div', 'a-section a-spacing-none');
      var ziel = null;
      (ANKER[wo] || []).some(function (q) { ziel = document.querySelector(q); return !!ziel; });
      if (ziel) {
        var box = el('div', 'a-box a-spacing-medium lc-block'), bi = el('div', 'a-box-inner');
        box.appendChild(bi);
        bi.appendChild(el('div', 'a-size-mini lc-k lc-block-tag', 'Listing Checker'));
        bi.appendChild(h); bi.appendChild(b);
        // hinter den bereits eingefuegten lc-Bloecken einhaengen, sonst steht jede spaetere Sektion ueber der frueheren
        var after = ziel;
        if (wo !== 'reviews') while (after.nextElementSibling && after.nextElementSibling.classList.contains('lc-block')) after = after.nextElementSibling;
        after.insertAdjacentElement(wo === 'reviews' ? 'beforebegin' : 'afterend', box);
        return b;
      }
      if (stack) { inner.insertBefore(h, stack); inner.insertBefore(b, stack); }
      else { inner.appendChild(h); inner.appendChild(b); }
      return b;
    };
    var secAod = sec('Alle Anbieter');
    secAod.innerHTML = '<span class="lc-k">lade Angebote …</span>';
    var secFremd = sec('Andere Plattformen');
    var secHist = sec('Verlauf');
    var secQ = sec('Listing');
    secQ.className = 'a-section a-spacing-none lc-row';
    if (!fb) secQ.appendChild(chip((r.bullets_anzahl || 0) + ' Bullets', ok((r.bullets_anzahl || 0) >= 5)));   // sonst steht es schon in fbRow
    secQ.appendChild(chip((r.bilder_anzahl || 0) + ' Bilder', ok((r.bilder_anzahl || 0) >= 6)));
    secQ.appendChild(chip(esc(r.aplus || '?'), ok(r.aplus !== 'KEIN A+')));
    secQ.appendChild(r.ean ? chip('<span class="lc-k">EAN</span> <span class="lc-mono">' + esc(r.ean) + '</span>', 'mut') : chip('keine EAN', 'bad'));
    if (r.bewertung) secQ.appendChild(chip(esc(r.bewertung) + ' ★ <span class="lc-k">(' + esc(r.anzahl_bewertungen || '?') + ')</span>', 'mut'));
    var warnText = clean(r.warnungen || '').split(';').map(clean).filter(function (w) {
      /* Der rote EAN-Chip zeigt diesen Zustand bereits; nicht direkt darunter
         ein zweites, nacktes „keine EAN“ ausgeben. */
      return !(!r.ean && /^keine EAN$/i.test(w));
    }).filter(Boolean).join('; ');
    if (warnText) inner.appendChild(el('div', 'lc-k a-spacing-top-mini', esc(warnText)));
    stack = el('div', 'a-button-stack'); inner.appendChild(stack);
    var status = el('div', 'lc-status'); inner.appendChild(status);

    // -- Alle Anbieter (AOD): einmal je Seite, 15 min Cache
    var aod = function () {
      var key = 'aod:' + asin;
      return storage(key).then(function (d) {
        var cc = d[key];
        if (cc && Date.now() - cc.ts < 15 * 60 * 1000) {
          // Negativ-Cache: nach Captcha/Fehler NICHT bei jedem Rebuild neu
          // gegen die Wand laufen (Review 31.08.)
          if (cc.fehler) throw new Error(cc.fehler);
          return cc.angebote;
        }
        // In-Flight-Dedupe: schnelles Twister-Klicken loeste sonst parallele
        // AOD-Requests aus ("genau EIN Abruf je Seite" stand nur im Kommentar)
        if (aodLauf[asin]) return aodLauf[asin];
        aodLauf[asin] = LC.amazonPro.fetchOffers(asin, location.origin).then(function (a) {
          var o = {}; o[key] = { ts: Date.now(), angebote: a };
          chrome.storage.local.set(o);
          return a;
        }).catch(function (e) {
          var o = {}; o[key] = { ts: Date.now(), angebote: null, fehler: (e && e.message) || 'Fehler' };
          chrome.storage.local.set(o);
          throw e;
        }).finally(function () { delete aodLauf[asin]; });
        return aodLauf[asin];
      });
    };
    var anbieterZahl = null, angebotMin = null;
    aod().then(function (a) {
      var offers = (a && a.offers) || [];
      anbieterZahl = a ? a.anzahl : null;
      var preise = offers.map(function (o) { return o.preis; }).filter(function (p) { return p != null; });
      angebotMin = preise.length ? Math.min.apply(null, preise) : null;
      var eigene = offers.filter(function (o) { return EIGEN.test(o.verkaeufer || ''); });
      var eigenerMin = eigene.length ? Math.min.apply(null, eigene.map(function (o) { return o.preis == null ? Infinity : o.preis; })) : null;
      var fremdUnter = offers.filter(function (o) {
        return !EIGEN.test(o.verkaeufer || '') && o.preis != null && eigenerMin != null && o.preis < eigenerMin;
      });
      aodChip.className = 'lc-chip ' + (fremdUnter.length ? 'bad' : (eigene.length ? 'ok' : ''));
      aodChip.innerHTML = (anbieterZahl == null ? '?' : anbieterZahl) + ' <span class="lc-k">Anbieter</span>' +
        (angebotMin != null ? ' <span class="lc-k">ab</span> ' + esc(eur(angebotMin)) : '') +
        (fremdUnter.length ? ' · ' + fremdUnter.length + ' Fremde günstiger' : '');
      secAod.innerHTML = offers.length
        ? '<ul class="lc-offers">' + offers.slice(0, 8).map(function (o) {
            var cls = EIGEN.test(o.verkaeufer || '') ? 'eigen' : (eigenerMin != null && o.preis != null && o.preis < eigenerMin ? 'unter' : '');
            return '<li class="' + cls + '"><span>' + (o.buybox ? '★ ' : '') + esc(o.verkaeufer || '?') +
              (o.zustand && !/^neu$/i.test(o.zustand) ? ' <span class="lc-k">' + esc(o.zustand) + '</span>' : '') +
              '</span><span class="lc-mono">' + esc(eur(o.preis)) + '</span></li>';
          }).join('') + '</ul>'
        : '<span class="lc-k">keine Angebotsliste (' + (anbieterZahl == null ? 'AOD leer' : anbieterZahl + ' Anbieter') + ')</span>';
    }).catch(function (e) {
      aodChip.innerHTML = '<span class="lc-k">Anbieter</span> ?';
      secAod.innerHTML = '<span class="lc-k">Angebote nicht lesbar (' + esc((e && e.message) || 'Fehler') + ')</span>';
    }).then(function () {
      if (aktuelleAsin !== asin) return null;               // Variante inzwischen gewechselt
      return send({ type: 'histSample', asin: asin, sample: {
        preis: r.preis, bsr: r.bsr, buybox: r.buybox, anbieter: anbieterZahl, angebot_min: angebotMin
      } });
    }).then(function (resp) {
      if (resp && resp.hist) return verlauf(resp.hist);
      // Background nicht erreichbar (Worker beendet / Extension neu geladen): Verlauf aus dem Speicher
      return storage('hist:' + asin).then(function (d) { if (aktuelleAsin === asin) verlauf(d['hist:' + asin] || []); });
    });

    // -- Fremdpreise / letzte Buybox-Pruefung aus dem lokalen Speicher
    var fremd = function () {
      storage(['pro', 'matches', 'eanMap', 'rows']).then(function (d) {
        if (aktuelleAsin !== asin) return;
        var ean = r.ean || (d.eanMap || {})[asin] || '';
        var pro = (d.pro || []).filter(function (p) { return p.asin === asin; })
          .sort(function (a, b) { return String(b.geprueft_am).localeCompare(String(a.geprueft_am)); })[0];
        var best = {};
        (d.matches || []).forEach(function (m) {
          if (m.match_bestaetigt !== 'ja' || m.preis == null) return;
          if (!(ean && (m.ean === ean || m.suchbegriff === ean))) return;
          var p = m.plattform || '?';
          if (!best[p] || m.preis < best[p].preis) best[p] = m;
        });
        var shop = (d.rows || []).filter(function (x) { return x.plattform === 'deubaxxl' && ean && x.ean === ean && x.preis != null; })[0];
        priceRow.innerHTML = '';
        var teile = [];
        if (shop) {
          priceRow.appendChild(chip('<span class="lc-k">Shop</span> ' + esc(eur(shop.preis)), 'mut', 'eigener Webshop - zählt nicht als Wettbewerb'));
          teile.push('<span class="lc-k">Shop</span> ' + esc(eur(shop.preis)));
        }
        Object.keys(best).sort(function (a, b) { return best[a].preis - best[b].preis; }).forEach(function (p) {
          var m = best[p];
          var unter = r.preis != null && m.preis < r.preis;
          priceRow.appendChild(chip(esc(p) + ' ' + esc(eur(m.preis)), unter ? 'bad' : 'ok', (m.match_stufe || '') + ' – ' + (m.match_grund || ''), m.url));
          teile.push('<a class="a-link-normal" href="' + esc(m.url) + '" target="_blank">' + esc(p) + ' <span class="lc-mono' + (unter ? ' a-color-price' : '') + '">' + esc(eur(m.preis)) + '</span></a>');
        });
        var html = teile.length ? teile.join(' · ') : '<span class="lc-k">noch kein Preisvergleich – „Buybox-Check" unten</span>';
        if (pro) {
          html += '<br><span class="' + (/UNTERBOTEN/.test(pro.urteil || '') ? 'a-color-price' : 'lc-k') + '">' + esc(pro.urteil || '') + '</span>' +
            ' <span class="lc-k">(Stand ' + esc(tag(new Date(pro.geprueft_am))) + ')</span>';
        }
        secFremd.innerHTML = html;
      });
    };
    fremd();
    if (onChangedHandler) chrome.storage.onChanged.removeListener(onChangedHandler);
    onChangedHandler = function (ch, area) {
      if (area !== 'local') return;
      if (ch.pro || ch.matches || ch.rows) fremd();
      if (ch.lcDark) darkAnwenden(!!ch.lcDark.newValue);
      if (ch.searchStatus) {
        var s = ch.searchStatus.newValue || {};
        if (s.running) status.textContent = 'Prüfung läuft: ' + (s.current || '…');
        else if (s.result) status.textContent = s.result;
      }
    };
    chrome.storage.onChanged.addListener(onChangedHandler);

    // -- Verlauf: Preis (Amazon-Orange), BSR (grau, invertiert), rote Punkte = Buybox weg
    function verlauf(samples) {
      if (HOOKS.chart) { try { return HOOKS.chart(secHist, samples, HOOKS.ui); } catch (e) { console.warn('[LC] Chart-Modul', e); } }
      var pts = samples.filter(function (s) { return s[1] != null || s[2] != null; });
      if (pts.length < 2) {
        secHist.innerHTML = '<span class="lc-k">' + pts.length + ' Messung – die Kurve entsteht mit jedem Aufruf dieser Seite</span>';
        return;
      }
      var W = 260, H = 60, P = 4;
      var t0 = Date.parse(pts[0][0]), t1 = Math.max(t0 + 1, Date.parse(pts[pts.length - 1][0]));
      var x = function (s) { return P + (W - 2 * P) * ((Date.parse(s[0]) - t0) / (t1 - t0)); };
      var ns = 'http://www.w3.org/2000/svg';
      var svg = document.createElementNS(ns, 'svg');
      svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
      var gezeichnet = false;
      var line = function (idx, stroke, dash, invert) {
        var vals = pts.filter(function (s) { return s[idx] != null; });
        if (vals.length < 2) return null;
        var mn = Math.min.apply(null, vals.map(function (s) { return s[idx]; }));
        var mx = Math.max.apply(null, vals.map(function (s) { return s[idx]; }));
        var y = function (val) {
          var f = mx === mn ? 0.5 : (val - mn) / (mx - mn);
          if (invert) f = 1 - f;
          return H - P - (H - 2 * P) * f;
        };
        /* Eine horizontale Linie bei identischen Werten behauptet optisch eine
           Zeitreihe, obwohl nichts passiert ist. Dann nur den Textstatus zeigen. */
        if (mx !== mn) {
          var d = vals.map(function (s, i) { return (i ? 'L' : 'M') + x(s).toFixed(1) + ' ' + y(s[idx]).toFixed(1); }).join(' ');
          var p = document.createElementNS(ns, 'path');
          p.setAttribute('d', d); p.setAttribute('fill', 'none'); p.setAttribute('stroke', stroke);
          p.setAttribute('stroke-width', '1.5'); if (dash) p.setAttribute('stroke-dasharray', '3 2');
          svg.appendChild(p); gezeichnet = true;
        }
        return { mn: mn, mx: mx, y: y, gleich: mx === mn };
      };
      var bsrL = line(2, '#8D9096', true, true);
      var prL = line(1, '#C7511F', false, false);
      pts.forEach(function (s) {
        if (s[3] !== 2) return;
        var ci = document.createElementNS(ns, 'circle');
        ci.setAttribute('cx', x(s).toFixed(1));
        ci.setAttribute('cy', (prL && s[1] != null ? prL.y(s[1]) : H / 2).toFixed(1));
        ci.setAttribute('r', '2.5'); ci.setAttribute('fill', '#B12704');
        var t = document.createElementNS(ns, 'title'); t.textContent = 'Buybox unterdrückt ' + s[0].slice(0, 10);
        ci.appendChild(t); svg.appendChild(ci); gezeichnet = true;
      });
      secHist.innerHTML = '';
      if (gezeichnet) secHist.appendChild(svg);
      secHist.appendChild(el('div', 'lc-k', esc(pts.length + ' Messungen seit ' + tag(new Date(t0)) +
        (prL ? (prL.gleich ? ' · Preis unverändert ' + eur(prL.mn) : ' · Preis ' + eur(prL.mn) + '–' + eur(prL.mx)) : '') +
        (bsrL ? (bsrL.gleich ? ' · BSR unverändert ' + nf(bsrL.mn) : ' · BSR ' + nf(bsrL.mn) + '–' + nf(bsrL.mx)) : '') + ' · nur eigene Aufrufe')));
    }

    // -- Aktionen
    stack.appendChild(button('Buybox-Check', true, 'Stammsatz im Shop suchen, alle Plattformen parallel auf günstigere Preise prüfen', function (b) {
      b.disabled = true;
      send({ type: 'proCheck', asins: [asin], origin: location.origin });
      status.textContent = 'Buybox-Check gestartet – Ergebnis erscheint unter dem Preis und hier.';
      setTimeout(function () { b.disabled = false; }, 8000);
    }));
    stack.appendChild(button('Listing erfassen', false, 'Volles Listing in den Reiter "Listings" (Excel/ChatGPT-Export)', function (b) {
      b.disabled = true;
      send({ type: 'saveRows', rows: [LC.extract(document, location.href)] }).then(function (resp) {
        status.textContent = resp && resp.ok ? 'Erfasst – im Popup unter Listings.' : 'Erfassen fehlgeschlagen.';
        b.disabled = false;
      });
    }));

    hookRun(HOOKS.panel, { asin: asin, row: r, buybox: bbx, card: inner, sec: sec, stack: stack, status: status,
      titleEl: titleEl, bbRow: bbRow, priceRow: priceRow, secQ: secQ, secHist: secHist, ui: HOOKS.ui });
  }

  /* Variantenwechsel: Amazon tauscht Titel, Breadcrumb, Preis und Buybox per
     Ajax und aendert die URL - ohne Reload. Alle 800 ms pruefen: neue ASIN
     oder unsere Titel-Chips weg (Titel neu gerendert) -> alles neu aufbauen. */
  function beobachteVarianten() {
    // Orphan-Guard: nach Extension-Reload injiziert background.js dieses Script
    // neu; der alte Kontext stellt seinen Poll ab, sobald der neue startet
    document.dispatchEvent(new Event('lc-onpage-neu'));
    var iv = setInterval(function () {
      var a = LC.amazonPro.getAsin(document, location.href);
      if (!a) return;
      /* Ohne #productTitle (Captcha-/Hund-Seite, anderes Layout) gibt es nie Titel-Chips -
         dann nur bei ASIN-Wechsel neu bauen, sonst liefe panel() alle 800 ms. */
      var chipsDa = !document.getElementById('productTitle') || !!document.querySelector('#title [data-lc], #productTitle ~ [data-lc]');
      /* Liefert LC.extract fuer diese ASIN wiederholt keinen Titel (A/B-Layout,
         kaputter Selektor), gibt der Poll nach 8 Versuchen auf - sonst liefe
         alle 800ms abraeumen() + Voll-Scrape bis zum Tab-Ende (Review 31.08.) */
      if ((panelFehler[a] || 0) >= 8) return;
      if (a !== aktuelleAsin || !chipsDa) panel();
    }, 800);
    // ...und hier hoert der ALTE Kontext zu: ohne diesen Listener liefe sein
    // Poll nach einer Nachinjektion einfach weiter (Bug-Pass 31.08.)
    document.addEventListener('lc-onpage-neu', function () { clearInterval(iv); }, { once: true });
  }

  // ------------------------------------------------------------ Suchseite

  /* Bestseller-/Neuheiten-/Aufsteiger-Listen (/gp/bestsellers/..., /zgbs/...) haben
     andere Kacheln als die Suche: #gridItemRoot > div[data-asin], Rang in .zg-bdg-text,
     kein Anzeigen-/Kaufzahl-Block (LO 30.08.: Kopfzeile + Quick View auch dort). */
  // Praefix (?:-\/[a-z]{2}\/)? = umgestellte Sprache (amazon.de/-/en/...), gilt auch fuer dp und /s unten
  var IST_BESTSELLER = /^\/(?:-\/[a-z]{2}\/)?(?:[^/]+\/)?(?:gp\/(?:bestsellers|new-releases|movers-and-shakers|most-wished-for)|zgbs)\//.test(location.pathname);

  function serp() {
    styles();
    var keyword = '';
    try { keyword = new URL(location.href).searchParams.get('k') || ''; } catch (e) { /* leer */ }
    var bsKategorie = '';
    if (!keyword && IST_BESTSELLER) {
      var h1 = clean((document.querySelector('h1') || {}).textContent || '').replace(/^Amazon\.de Bestseller:\s*/i, '');
      bsKategorie = h1.replace(/^Die beliebtesten Artikel in\s*/i, '');
      keyword = 'Bestseller: ' + (bsKategorie || location.pathname.split('/').filter(Boolean).slice(-2).join('/'));
    }
    /* Bestseller-Listen sind die dickste Gratis-Quelle fuer den Verkaufs-
       schaetzer (LO 01.09. "we just need more data"): Rang = BSR der Listen-
       Kategorie + Kaufzahl-Badge an derselben Kachel. NUR echte Bestseller
       (nicht new-releases/movers - deren Rang ist kein BSR), einmal je URL. */
    var IST_BS_LERNQUELLE = /\/(?:gp\/bestsellers|zgbs)\//.test(location.pathname);
    var bsGelernt = '';
    var head = null;

    var run = function () {
      var tiles = document.querySelectorAll(IST_BESTSELLER
        ? '#gridItemRoot div[data-asin]:not([data-asin=""]), .p13n-desktop-grid div[data-asin]:not([data-asin=""])'
        : 'div[data-component-type="s-search-result"][data-asin]:not([data-asin=""])');
      if (!tiles.length) return;
      var pos = 0, org = 0, ads = 0, eigen = 0, kaufSum = 0, kaufMax = 0, kaufN = 0, besteEigen = null;
      var preise = [], ratings = [], badgesN = 0, infos = [];
      Array.prototype.forEach.call(tiles, function (t) {
        var asin = t.getAttribute('data-asin');
        var gesponsert = !IST_BESTSELLER && (/(^|\s)AdHolder(\s|$)/.test(t.className) ||
          !!t.querySelector('[data-component-type="sp-sponsored-result"], .puis-sponsored-label-text'));
        var rang = IST_BESTSELLER ? parseInt(clean((t.querySelector('.zg-bdg-text') || {}).textContent || '').replace(/\D/g, ''), 10) : NaN;
        if (isFinite(rang) && rang > 0) { pos = rang; org = rang; } else { pos++; if (gesponsert) ads++; else org++; }
        var text = t.innerText || t.textContent || '';
        var km = text.match(KAUF_RE);
        var kauf = km ? mapZahl(km[1], km[2]) : null;
        if (kauf) { kaufSum += kauf; kaufMax = Math.max(kaufMax, kauf); kaufN++; }
        var titel = clean((t.querySelector('h2') || t.querySelector('[class*="line-clamp"]') || {}).textContent || '') ||
          clean((t.querySelector('img[alt]') || {}).alt || '');
        var istEigen = EIGEN.test(titel);
        if (istEigen) { eigen++; if (!gesponsert && besteEigen == null) besteEigen = org; }
        // Helium-Zutaten: Preisband, Bewertungsschnitt, Badge-Dichte der Seite
        var pr = LC.parseNum(clean((t.querySelector('[data-cy="price-recipe"] .a-price:not(.a-text-price) .a-offscreen') ||
          t.querySelector('.p13n-sc-price, [class*="p13n-sc-price"]') || {}).textContent || ''));
        if (pr != null) preise.push(pr);
        var rt = (clean((t.querySelector('.a-icon-alt') || {}).textContent || '').match(/^(\d[.,]\d)/) || [])[1];
        if (rt) ratings.push(parseFloat(rt.replace(',', '.')));
        if (t.querySelector('.a-badge-label, [data-a-badge-type]')) badgesN++;

        var badges = t.querySelector('.lc-badges');
        if (!badges) {
          badges = el('div', 'a-row lc-badges');
          var a = el('span', 'lc-asin', '<b>' + esc(asin) + '</b>'); a.title = 'ASIN kopieren';
          a.querySelector('b').addEventListener('click', function (ev) {
            ev.preventDefault(); ev.stopPropagation();
            navigator.clipboard.writeText(asin).then(function () { a.querySelector('b').textContent = asin + ' ✓'; setTimeout(function () { a.querySelector('b').textContent = asin; }, 1200); });
          });
          badges.appendChild(a);
          badges.appendChild(el('span', 'lc-pos lc-asin'));
          if (gesponsert) badges.appendChild(el('span', 'lc-asin', 'Anzeige'));
          if (istEigen) { badges.appendChild(chip('EIGEN', 'ok')); t.classList.add('lc-tile-eigen'); }
          if (kauf) badges.appendChild(chip(esc(km[0].replace(/\s*(Mal )?im (letzten|vergangenen) Monat gekauft/i, '')) + ' <span class="lc-k">/ Monat</span>', '', 'Kaufzahl laut Amazon'));
          var anker = t.querySelector('[data-cy="title-recipe"]');
          if (anker && anker.parentNode) anker.insertAdjacentElement('afterend', badges);
          else (t.querySelector('.zg-grid-general-faceout') || t).appendChild(badges);
        }
        badges.querySelector('.lc-pos').textContent = IST_BESTSELLER ? 'Rang ' + pos : 'Pos. ' + pos + (gesponsert ? '' : ' · org. ' + org);
        infos.push({ tile: t, asin: asin, badges: badges, gesponsert: gesponsert, pos: pos, org: gesponsert ? null : org,
          titel: titel, istEigen: istEigen, preis: pr, rating: rt ? parseFloat(rt.replace(',', '.')) : null, kauf: kauf });
      });

      // Bestseller-Lernquelle: Rang (= BSR der Listen-Kategorie) + Kaufzahl je
      // Kachel als Batch an den Verkaufsschaetzer - einmal je URL.
      if (IST_BS_LERNQUELLE && bsKategorie && bsGelernt !== location.href && LC.sales && LC.sales.merkenViele) {
        var lernPaare = infos.filter(function (i) { return i.kauf > 0 && i.pos > 0 && i.asin; })
          .map(function (i) { return { asin: i.asin, bsr: i.pos, kz: i.kauf }; });
        if (lernPaare.length) {
          bsGelernt = location.href;
          LC.sales.merkenViele(bsKategorie, lernPaare).then(function (neu) {
            if (!head || !neu) return;
            head.appendChild(chip('✓ <span class="lc-k">Schätzer: +' + neu + ' Datenpunkte „' + esc(bsKategorie.toLowerCase()) + '"</span>', '',
              'Rang und Kaufzahl der Bestseller-Kacheln als Kalibrier-Datenpunkte für den Verkaufsschätzer gespeichert – gratis, ohne Zugriffe'));
          }).catch(function () { /* Lernen darf die Liste nie stoeren */ });
        }
      }

      if (!head) {
        head = el('div', 'a-section lc-serp-head');
        var slot = document.querySelector('.s-main-slot') || document.querySelector('.p13n-desktop-grid, #gridItemRoot');
        if (slot && slot.parentNode) slot.parentNode.insertBefore(head, slot); else document.body.insertBefore(head, document.body.firstChild);
      }
      preise.sort(function (a, b) { return a - b; });
      var median = preise.length ? preise[Math.floor(preise.length / 2)] : null;
      var avgRating = ratings.length ? ratings.reduce(function (a, b) { return a + b; }, 0) / ratings.length : null;
      head.innerHTML = '';
      head.appendChild(el('span', 'a-text-bold', esc(keyword ? '„' + keyword + '"' : 'Suche')));
      head.appendChild(chip((IST_BESTSELLER ? infos.length : pos) + ' <span class="lc-k">' + (IST_BESTSELLER ? 'Plätze geladen' : 'Treffer') + '</span>', 'mut'));
      if (!IST_BESTSELLER) head.appendChild(chip(ads + ' <span class="lc-k">Anzeigen</span> ' + (pos ? Math.round(100 * ads / pos) : 0) + '%', 'mut'));
      head.appendChild(chip(eigen + ' <span class="lc-k">eigene</span>' + (besteEigen != null ? ' <span class="lc-k">· beste org. Pos.</span> ' + besteEigen : ''), eigen ? 'ok' : 'mut'));
      if (median != null) head.appendChild(chip('<span class="lc-k">Preis-Median</span> ' + esc(eur(median)) + ' <span class="lc-k">(' + esc(eur(preise[0])) + '–' + esc(eur(preise[preise.length - 1])) + ')</span>', 'mut', preise.length + ' Kachelpreise'));
      if (avgRating != null) head.appendChild(chip('<span class="lc-k">Ø</span> ' + avgRating.toFixed(2).replace('.', ',') + ' ★', 'mut', ratings.length + ' bewertete Treffer'));
      if (badgesN) head.appendChild(chip(badgesN + ' <span class="lc-k">Bestseller/Choice-Badges</span>', 'mut'));
      if (kaufN) head.appendChild(chip('≈ ' + nf(kaufSum) + '+ <span class="lc-k">Verk./Monat · Spitze</span> ' + nf(kaufMax) + '+', '', kaufN + ' Treffer mit Kaufzahl'));
      head.appendChild(el('span', 'lc-sp'));
      head.appendChild(darkToggle());
      darkAnwenden(darkAn);
      // bestsellerKat: auf /gp/bestsellers|/zgbs IST der Kachel-Rang der BSR
      // dieser Kategorie - Module brauchen ihn dort nicht erst zu holen.
      hookRun(HOOKS.serp, { keyword: keyword, tiles: infos, head: head, ui: HOOKS.ui,
        bestsellerKat: IST_BS_LERNQUELLE ? bsKategorie : '',
        stats: { treffer: pos, anzeigen: ads, organisch: org, eigene: eigen, median: median, rating: avgRating, kaufSum: kaufSum } });
    };

    run();
    var timer = null;
    /* Eigene Schreibvorgaenge (lc-pos-Text, Chips in .lc-badges, Kopfzeile) ignorieren -
       sonst loest run() sich selbst aus und laeuft alle 400 ms endlos. */
    var mo = new MutationObserver(function (recs) {
      if (recs.every(function (r) { return r.target.closest && r.target.closest('[data-lc]'); })) return;
      clearTimeout(timer); timer = setTimeout(run, 400);
    });
    mo.observe(document.querySelector('.s-main-slot') || document.body, { childList: true, subtree: true });
  }

  // ------------------------------------------------------------ Routing

  function start() {
    styles();
    var path = location.pathname;
    if (/^\/(?:-\/[a-z]{2}\/)?(?:[^/]+\/)?(?:dp|gp\/product)\//.test(path)) { panel(); beobachteVarianten(); }
    else if (/^\/(?:-\/[a-z]{2}\/)?s\/?$/.test(path) || IST_BESTSELLER) serp();
  }

  /* Unsichtbare Tabs (Preisjagd, Keyword-Messung oeffnen Amazon im Hintergrund)
     bekommen kein Panel und keinen AOD-Abruf. Wird der Tab spaeter sichtbar
     (Ctrl-Klick), startet alles dann. */
  darkInit.then(function () {
    if (document.visibilityState === 'visible') return start();
    var once = function () {
      if (document.visibilityState !== 'visible') return;
      document.removeEventListener('visibilitychange', once);
      start();
    };
    document.addEventListener('visibilitychange', once);
  });
})();
