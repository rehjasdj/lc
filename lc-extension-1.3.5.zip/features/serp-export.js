/* Export der Suchergebnisseite (nach Helium ASIN Grabber / Xray-Export):
   Kopfzeilen-Chips "ASINs kopieren", "CSV" (deutsches Excel: ; und BOM),
   "Markdown" (Tabelle fuer ChatGPT) und "eigene vs. Markt". Nimmt die
   Quick-View-Daten (data-lc-qv-data) mit, wenn sie da sind. Kein Netz. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.serp = H.serp || [];
  var ui = null, letzterCtx = null;
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  var de = function (n) { return n == null ? '' : String(n).replace('.', ','); };

  function zeilen(ctx) {
    return ctx.tiles.map(function (t) {
      var qv = {};
      try { qv = JSON.parse(t.tile.getAttribute('data-lc-qv-data') || '{}') || {}; } catch (e) { qv = {}; }
      var bewA = t.tile.querySelector('a[aria-label*="Bewertung"], span[aria-label*="Bewertung"]');
      var bew = bewA ? (clean(bewA.getAttribute('aria-label')).match(/^([\d.]+)/) || [])[1] : '';
      var badge = clean((t.tile.querySelector('.a-badge-text') || {}).textContent);
      return {
        pos: t.pos, org: t.org == null ? '' : t.org, asin: t.asin, titel: clean(t.titel), preis: t.preis, rating: t.rating,
        bewertungen: bew || '', kauf: t.kauf || '', anzeige: t.gesponsert ? 'ja' : '', badge: badge, eigen: t.istEigen ? 'ja' : '',
        bsr: qv.bsr || '', bsr_kategorie: qv.bsr_kategorie || '', verkaeufer: qv.verkaeufer || '', seit: qv.seit || '', varianten: qv.varianten > 1 ? qv.varianten : ''
      };
    });
  }
  var SPALTEN = [['pos', 'Pos'], ['org', 'org. Pos'], ['asin', 'ASIN'], ['titel', 'Titel'], ['preis', 'Preis'], ['rating', 'Bewertung'],
    ['bewertungen', 'Anzahl Bewertungen'], ['kauf', 'Kaufzahl/Monat'], ['anzeige', 'Anzeige'], ['badge', 'Badge'], ['eigen', 'EIGEN'],
    ['bsr', 'BSR'], ['bsr_kategorie', 'BSR-Kategorie'], ['verkaeufer', 'Verkäufer'], ['seit', 'seit'], ['varianten', 'Varianten']];
  var QV = { bsr: 1, bsr_kategorie: 1, verkaeufer: 1, seit: 1, varianten: 1 };

  function csv(rows) {
    var q = function (v) { v = v == null ? '' : String(v); return /[;"\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    var out = [SPALTEN.map(function (s) { return s[1]; }).join(';')];
    rows.forEach(function (r) {
      out.push(SPALTEN.map(function (s) { var v = r[s[0]]; return q(s[0] === 'preis' || s[0] === 'rating' ? de(v) : v); }).join(';'));
    });
    return '﻿' + out.join('\r\n');
  }

  function markdown(rows, keyword) {
    var mitQv = rows.some(function (r) { return r.bsr || r.verkaeufer; });
    var sp = SPALTEN.filter(function (s) { return mitQv || !QV[s[0]]; });
    var z = function (v) { return String(v == null ? '' : v).replace(/\|/g, '/'); };
    var out = ['# Amazon-Suche „' + keyword + '" – ' + rows.length + ' Treffer (' + new Date().toISOString().slice(0, 10) + ')', '',
      '| ' + sp.map(function (s) { return s[1]; }).join(' | ') + ' |', '|' + sp.map(function () { return '---'; }).join('|') + '|'];
    rows.forEach(function (r) {
      out.push('| ' + sp.map(function (s) { var v = r[s[0]]; return z(s[0] === 'preis' || s[0] === 'rating' ? de(v) : v); }).join(' | ') + ' |');
    });
    return out.join('\n');
  }

  function download(text, name, typ) {
    var blob = new Blob([text], { type: typ });
    var a = ui.el('a'); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 5000);
  }

  function kopieren(chipEl, text) {
    var alt = chipEl.innerHTML;
    navigator.clipboard.writeText(text).then(function () {
      chipEl.innerHTML = alt + ' ✓';
      setTimeout(function () { chipEl.innerHTML = alt; }, 1200);
    }).catch(function () { chipEl.innerHTML = alt + ' ✗'; });
  }

  H.serpExport = { zeilen: function () { return letzterCtx ? zeilen(letzterCtx) : []; }, csv: csv, markdown: markdown };

  H.serp.push(function (ctx) {
    ui = ctx.ui; letzterCtx = ctx;
    var anker = ctx.head.querySelector('.lc-sp');
    var add = function (c, fn) {
      c.classList.add('lc-exp', 'lc-copy');
      if (fn) c.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); fn(c); });
      ctx.head.insertBefore(c, anker || null);
      return c;
    };
    var kw = ctx.keyword || 'suche';
    add(ui.chip('ASINs kopieren', 'mut', 'alle ' + ctx.tiles.length + ' ASINs dieser Seite zeilenweise in die Zwischenablage'), function (c) {
      kopieren(c, ctx.tiles.map(function (t) { return t.asin; }).join('\n'));
    });
    add(ui.chip('CSV', 'mut', 'Trefferliste als CSV für Excel (Pos, ASIN, Titel, Preis, Bewertung, Kaufzahl, Anzeige, Badge, EIGEN, Quick-View-Daten)'), function () {
      download(csv(zeilen(ctx)), 'serp-' + kw.replace(/[^\w\-äöüß]+/gi, '_') + '-' + new Date().toISOString().slice(0, 10) + '.csv', 'text/csv;charset=utf-8');
    });
    add(ui.chip('Markdown', 'mut', 'Trefferliste als Markdown-Tabelle in die Zwischenablage – für ChatGPT'), function (c) {
      kopieren(c, markdown(zeilen(ctx), kw));
    });
    var eig = ctx.tiles.filter(function (t) { return t.istEigen && t.preis != null; });
    if (eig.length && ctx.stats.median != null) {
      var avg = eig.reduce(function (a, t) { return a + t.preis; }, 0) / eig.length;
      var diff = Math.round(100 * (avg / ctx.stats.median - 1));
      var c = ui.chip('<span class="lc-k">eigene Ø</span> ' + ui.esc(ui.eur(avg)) + ' <span class="lc-k">· Markt-Median</span> ' + ui.esc(ui.eur(ctx.stats.median)) +
        ' <span class="lc-k">(' + (diff >= 0 ? '+' : '') + diff + '%)</span>', diff > 10 ? 'bad' : (diff < -10 ? 'ok' : 'mut'), eig.length + ' eigene Kacheln mit Preis gegen den Median aller Kachelpreise');
      c.classList.add('lc-exp'); ctx.head.insertBefore(c, anker || null);
    }
  });
})();
