/* Rank-Tracking (nach Helium 10 "Keyword Tracker"), passiv und lokal: bei jedem
   Besuch einer Suchseite wird die Position der EIGENEN Kacheln je Keyword
   gemerkt - chrome.storage.local "rank:<keyword>" =
     { asins: { <ASIN>: [[iso, orgPos|null, pos], ...] }, letzte: iso }
   (max. 200 Messungen je ASIN, innerhalb von 6 h keine zweite). An der Kachel
   steht "Pos. 14 · zuletzt 18 ▲", im Kopf das beste eigene Ergebnis; Klick auf
   den Kopf-Chip kopiert alle Messungen des Keywords als Markdown-Tabelle.
   Nur Seite 1 wird gemessen: Amazon zaehlt die Kacheln auf /s?k=…&page=2 wieder
   ab 1, die Position waere also falsch. Vor jedem Schreiben wird der Schluessel
   frisch gelesen und eingemischt (zweiter Tab mit demselben Keyword).
   Auf der Produktseite: Sektion "Keyword-Ränge" mit allen gemessenen Keywords
   dieser ASIN. Kein Netz, keine Rechte. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || []; H.serp = H.serp || [];

  var CFG = H.ranktracker = { DEDUPE: 6 * 60 * 60 * 1000, MAX: 200 };
  var ui = null, key = '', daten = null, laden = null;
  var vorher = {};   // letzte gespeicherte Messung VOR diesem Besuch je ASIN (bleibt ueber alle Durchlaeufe gleich)

  // kleinere Position = besser
  var pfeil = function (neu, alt) {
    if (neu == null || alt == null) return { z: '', k: 'mut' };
    return neu < alt ? { z: '▲', k: 'ok' } : (neu > alt ? { z: '▼', k: 'bad' } : { z: '=', k: 'mut' });
  };
  var orgTxt = function (e) { return !e ? '–' : (e[1] == null ? 'Anzeige (Pos. ' + e[2] + ')' : String(e[1])); };
  var istFrisch = function (list) {
    var last = list && list[list.length - 1];
    return !!last && Date.now() - Date.parse(last[0]) < CFG.DEDUPE;
  };
  var seite = function () {
    try { return parseInt(new URL(location.href).searchParams.get('page'), 10) || 1; } catch (e) { return 1; }
  };
  // set() ohne Promise-Form: Fehler (Quota, Kontext weg) landen in lastError statt als unbehandelte Rejection
  var speichern = function (o) {
    if (ui && ui.storageSet) return ui.storageSet(o);
    try { chrome.storage.local.set(o, function () { void chrome.runtime.lastError; }); } catch (e) { /* Storage weg */ }
  };
  var kopieren = function (chipEl, text) {
    var alt = chipEl.innerHTML;
    navigator.clipboard.writeText(text).then(function () {
      chipEl.innerHTML = alt + ' ✓';
      setTimeout(function () { chipEl.innerHTML = alt; }, 1200);
    }).catch(function () { chipEl.innerHTML = alt + ' ✗'; });
  };
  var tabelle = function (kopf, zeilen) {
    return ['| ' + kopf.join(' | ') + ' |', '|' + kopf.map(function () { return '---'; }).join('|') + '|']
      .concat(zeilen.map(function (z) { return '| ' + z.map(function (v) { return String(v == null ? '' : v).replace(/\|/g, '/'); }).join(' | ') + ' |'; })).join('\n');
  };
  var kopfChip = function (ctx, c) {
    c.classList.add('lc-rank');
    var old = ctx.head.querySelector('.lc-rank'); if (old) old.remove();
    ctx.head.insertBefore(c, ctx.head.querySelector('.lc-sp') || null);
  };

  // ---- Suchseite: messen ---------------------------------------------------
  // Je ASIN eine Messung pro Besuch; erscheint sie als Anzeige UND organisch, zaehlt die organische.
  function messen(ctx) {
    var eigene = {};
    ctx.tiles.forEach(function (t) {
      if (!t.istEigen) return;
      var e = eigene[t.asin];
      if (!e || (t.org != null && (e.org == null || t.org < e.org))) eigene[t.asin] = { org: t.org, pos: t.pos };
    });
    var neu = [];
    Object.keys(eigene).forEach(function (asin) {
      var list = daten.asins[asin] || [], last = list[list.length - 1], frisch = istFrisch(list);
      // Vergleichswert: die Messung vor der frischen; gibt es keine aeltere, die frische selbst
      if (!(asin in vorher)) vorher[asin] = (frisch ? list[list.length - 2] || last : last) || null;
      if (!frisch) neu.push(asin);                          // dedupe 6 h
    });
    if (!neu.length) return Promise.resolve(eigene);
    // vor dem Schreiben frisch lesen: ein anderer Tab mit demselben Keyword darf nicht ueberschrieben werden
    return ui.storage(key).then(function (d) {
      if (d[key] && d[key].asins) daten = d[key];
      var jetzt = new Date().toISOString(), dirty = false;
      neu.forEach(function (asin) {
        var list = daten.asins[asin] = daten.asins[asin] || [];
        if (istFrisch(list)) return;                         // der andere Tab war schneller
        list.push([jetzt, eigene[asin].org, eigene[asin].pos]);
        while (list.length > CFG.MAX) list.shift();
        dirty = true;
      });
      if (!dirty) return eigene;
      daten.letzte = jetzt;
      var o = {}; o[key] = daten;
      /* Zusaetzlicher ASIN-Index verhindert auf Produktseiten get(null) ueber
         saemtliche Keyword-Verlaeufe. */
      return Promise.all(neu.map(function (asin) {
        var ik = 'rankIndex:' + asin;
        return ui.storage(ik).then(function (x) {
          var idx = x[ik] || {}; idx[key.slice(5)] = daten.asins[asin]; o[ik] = idx;
        });
      })).then(function () { return speichern(o); }).then(function () { return eigene; });
    });
  }

  function markdownKeyword(kw) {
    var zeilen = [];
    Object.keys(daten.asins).sort().forEach(function (asin) {
      daten.asins[asin].forEach(function (e) { zeilen.push([kw, asin, e[0].slice(0, 10), e[1] == null ? '–' : e[1]]); });
    });
    return '# Rank-Tracking „' + kw + '" (' + new Date().toISOString().slice(0, 10) + ')\n\n' + tabelle(['Keyword', 'ASIN', 'Datum', 'org. Pos'], zeilen);
  }

  // ---- Suchseite: zeigen ---------------------------------------------------
  function zeigen(ctx, eigene, kw) {
    ctx.tiles.forEach(function (t) {
      if (!t.istEigen || !t.badges) return;
      var alt = t.badges.querySelector('.lc-rank'); if (alt) alt.remove();
      var v = vorher[t.asin], vo = v ? v[1] : null, c;
      if (t.org == null) {
        c = ui.chip('<span class="lc-k">Anzeige · org. zuletzt</span> ' + (vo == null ? '–' : vo), 'mut',
          'Anzeigenplatz wird nicht als Rang gezaehlt' + (v ? '; letzte organische Messung ' + ui.tag(new Date(v[0])) : ''));
      } else {
        var p = pfeil(t.org, vo);
        c = ui.chip('<span class="lc-k">Pos.</span> ' + t.org + (v
          ? ' <span class="lc-k">· zuletzt</span> ' + (vo == null ? 'Anzeige' : vo) + (p.z ? ' ' + p.z : '')
          : ' <span class="lc-k">· erste Messung</span>'), p.k,
          'Organische Position für „' + kw + '"' + (v ? ', Vergleich mit der Messung vom ' + ui.tag(new Date(v[0])) : ' – noch kein Vergleichswert') + ' (lokal gespeichert)');
      }
      c.classList.add('lc-rank'); t.badges.appendChild(c);
    });

    var best = null, bestAlt = null, n = 0, mess = 0;
    Object.keys(eigene).forEach(function (asin) {
      n++; mess += (daten.asins[asin] || []).length;
      var o = eigene[asin].org, v = vorher[asin];
      if (o != null && (best == null || o < best)) best = o;
      if (v && v[1] != null && (bestAlt == null || v[1] < bestAlt)) bestAlt = v[1];
    });
    var p = pfeil(best, bestAlt);
    var c = ui.chip('<span class="lc-k">Rank-Tracking:</span> ' + n + ' <span class="lc-k">eigene</span>' +
      (best != null ? ' <span class="lc-k">· bestes org. Pos.</span> ' + best + (bestAlt != null ? ' <span class="lc-k">(' + p.z + ' von ' + bestAlt + ')</span>' : '') : ''),
      n ? p.k : 'mut', 'Position der eigenen Kacheln je Keyword, lokal gespeichert (' + n + ' ASINs, ' + mess + ' Messungen für „' + kw + '"). Klick: alle Messungen als Markdown-Tabelle kopieren');
    c.classList.add('lc-copy');
    c.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); kopieren(c, markdownKeyword(kw)); });
    kopfChip(ctx, c);
  }

  H.serp.push(function (ctx) {
    ui = ctx.ui;
    // Nur echte Suchseiten (/s?k=...) tracken. onpage.js schickt auch Bestseller-
    // Listen durch serp() und synthetisiert dort ein Keyword aus der h1 - so
    // entstand der Muell-Eintrag "bestseller: bestseller" (LO, 30.08.).
    try { if (!new URL(location.href).searchParams.get('k')) return; } catch (e) { return; }
    var kw = String(ctx.keyword || '').replace(/\s+/g, ' ').trim().toLowerCase();
    if (!kw) return;
    var s = seite();
    if (s > 1) {   // Seite 2+: org zaehlt wieder ab 1 -> nicht messen, nur Hinweis
      kopfChip(ctx, ui.chip('<span class="lc-k">Rank-Tracking:</span> Seite ' + s + ' <span class="lc-k">· nur Seite 1 wird gemessen</span>', 'mut',
        'Amazon zählt die Positionen auf jeder Seite wieder ab 1; gemessen wird deshalb nur Seite 1 der Suche „' + kw + '"'));
      return;
    }
    key = 'rank:' + kw;
    if (!laden) {
      laden = ui.storage(key).then(function (d) {
        daten = d[key] && d[key].asins ? d[key] : { asins: {}, letzte: '' };
      }).catch(function () { daten = { asins: {}, letzte: '' }; });
    }
    laden.then(function () { return messen(ctx); }).then(function (eigene) { zeigen(ctx, eigene, kw); })
      .catch(function (e) { console.warn('[LC] Rank-Tracking', e); });
  });

  // ---- Produktseite: alle Keywords dieser ASIN ------------------------------
  H.panel.push(function (ctx) {
    ui = ctx.ui;
    if (!ui || typeof ctx.sec !== 'function' || !ctx.asin) return;
    var ik = 'rankIndex:' + ctx.asin;
    ui.storage(ik).then(function (d) {
      if (ui.aktuelleAsin() !== ctx.asin) return;
      var rows = [];
      var idx = d[ik] || {};
      Object.keys(idx).forEach(function (kw) {
        var list = idx[kw];
        if (!list || !list.length) return;
        rows.push({ kw: kw, last: list[list.length - 1], prev: list.length > 1 ? list[list.length - 2] : null });
      });
      if (!rows.length) return;
      var org = function (e) { return e && e[1] != null ? e[1] : 1e9; };
      rows.sort(function (a, b) { return org(a.last) - org(b.last) || a.kw.localeCompare(b.kw); });
      var box = ctx.sec('Keyword-Ränge', 'bullets');
      box.appendChild(ui.el('div', 'lc-check', rows.map(function (r) {
        var p = pfeil(r.last[1], r.prev ? r.prev[1] : null);
        var trend = r.prev ? p.z + ' ' + orgTxt(r.prev) : 'erste Messung';
        return '<div><span class="lc-t"><a class="a-link-normal" href="/s?k=' + encodeURIComponent(r.kw) + '" title="Suche „' + ui.esc(r.kw) + '&quot; öffnen">' + ui.esc(r.kw) + '</a></span>' +
          '<span class="lc-mono" title="letzte organische Position">' + (r.last[1] != null ? 'Pos. ' + r.last[1] : ui.esc(orgTxt(r.last))) + '</span>' +
          '<span class="' + (p.k === 'ok' ? 'lc-ok' : (p.k === 'bad' ? 'lc-bad' : 'lc-k')) + '" title="Trend gegen die vorletzte Messung' + (r.prev ? ' vom ' + ui.tag(new Date(r.prev[0])) : '') + '">' + ui.esc(trend) + '</span>' +
          '<span class="lc-k" title="Datum der letzten Messung">' + ui.esc(ui.tag(new Date(r.last[0]))) + '</span></div>';
      }).join('')));
      var c = ui.chip('als Markdown kopieren', 'mut', 'Keyword, letzte org. Position, Trend und Datum als Tabelle in die Zwischenablage');
      c.classList.add('lc-rank', 'lc-copy');
      c.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        kopieren(c, '# Keyword-Ränge ' + ctx.asin + ' (' + new Date().toISOString().slice(0, 10) + ')\n\n' +
          tabelle(['Keyword', 'org. Pos', 'Trend', 'Datum'], rows.map(function (r) {
            return [r.kw, orgTxt(r.last), r.prev ? pfeil(r.last[1], r.prev[1]).z + ' ' + orgTxt(r.prev) : 'erste Messung', r.last[0].slice(0, 10)];
          })));
      });
      box.appendChild(ui.el('div', 'a-spacing-top-mini')).appendChild(c);
    }).catch(function (e) { console.warn('[LC] Rank-Tracking', e); });
  });
})();
