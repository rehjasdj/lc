/* Quick View in der Suche (nach DS Amazon Quick View / Helium Xray): BSR mit
   Kategorie (verlinkt auf Amazons Bestseller-Liste), Verkaeufer/FBA, "seit"
   und Variantenzahl an jeder Kachel - ohne Klick.

   Datenquelle: die Produktseite jeder Kachel, same-origin geholt
   (/dp/<ASIN>, mit Cookies), durch shared/extract.js gelesen. Nur sichtbare
   Kacheln (IntersectionObserver), 2 gleichzeitig, >= 400 ms Abstand, max. 60 je
   Seitenaufruf, 6 h Cache (qv:<ASIN>). Captcha -> sofort Stopp.
   Nebenbei wandert jede Messung in den lokalen Verlauf (histSample), so
   entsteht auch fuer Wettbewerber eine Preis/BSR-Kurve.
   Rechte: keine neuen (amazon.de ist freigegeben). Aus-/Einschalter im Kopf. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC || !LC.extract || !LC.amazonPro) return;
  var H = LC.onpage = LC.onpage || {};
  H.serp = H.serp || [];

  var CFG = H.quickview = { GAP: 400, PAR: 2, MAX: 60, TTL: 6 * 60 * 60 * 1000 };
  H.quickview.lesen = lesen;   // Auto-Research (dp-watchlist) parst DP-HTML mit demselben Parser
  var ui = null, queue = [], running = 0, fetched = 0, geladen = 0, gesamt = 0, fehler = 0;
  var bsKat = '';   // gesetzt auf Bestseller-Listen: dort ist der Kachel-Rang der BSR
  var stopped = false, aus = false, ausGelesen = false, lastAt = 0, io = null, headChip = null;
  var bsrs = [];
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  var zahl = function (v) { var n = parseInt(String(v == null ? '' : v).replace(/\D/g, ''), 10); return isFinite(n) && n > 0 ? n : null; };

  // ---- Produktseite lesen ------------------------------------------------
  function lesen(html, asin) {
    /* ponytail: Amazons DP-HTML (1,5-3 MB) besteht zur Haelfte aus Inline-
       Scripts/Styles. Vor dem Parsen wegschneiden (Regex, wenige ms) - der
       DOMParser und LC.extract laufen dann auf dem halben Baum, und das
       passiert 60x je Suchseite im Haupt-Thread. ld+json bleibt (extract.js). */
    var schlank = html.replace(/<script\b(?![^>]*application\/ld\+json)[^>]*>[\s\S]*?<\/script>/gi, '')
      .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '')
      .replace(/<svg\b[^>]*>[\s\S]*?<\/svg>/gi, '');    // Inline-Icons: hunderte Knoten, kein Text, nichts liest sie
    var doc = new DOMParser().parseFromString(schlank, 'text/html');
    if (!doc.getElementById('productTitle')) {
      // nur echte Blockseiten-Marker - "captcha"/"Roboter" gaben Dauer-Fehlalarme
      if (/validateCaptcha|opfcaptcha/i.test(html)) throw new Error('captcha');
      return { leer: true, ts: Date.now() };
    }
    var r = LC.extract(doc, location.origin + '/dp/' + asin) || {};
    /* BSR-Fallback direkt aus dem Seitentext: die Attribut-Tabelle von
       extract.js trifft nicht jedes DP-Layout, dann kam ueberall "BSR –"
       obwohl der Rang auf der Seite steht (LO 01.09.). Format amazon.de:
       "Nr. 1.929 in Garten (Siehe Top 100 ...)  Nr. 2 in Liegen". */
    if (r.bsr == null) {
      var quelle = doc.getElementById('detailBulletsWrapper_feature_div') ||
        doc.getElementById('productDetails_detailBullets_sections1') ||
        doc.getElementById('prodDetails') || doc.body;
      // doc.body-Fallback ist der Text der GANZEN Seite; die Produktinformation
      // steht vor den Rezensionen - 200k Zeichen reichen, der Rest ist Regex-Ballast
      var txt = clean(quelle ? quelle.textContent : '').slice(0, 200000), re = /Nr\.\s*([\d.]+)\s+in\s+([^(:;]{2,60}?)(?=\s*(?:\(|Nr\.|$))/g, m, treffer = [];
      while ((m = re.exec(txt)) && treffer.length < 2) {
        var rang = parseInt(m[1].replace(/\./g, ''), 10);
        if (isFinite(rang) && rang > 0) treffer.push({ rang: rang, kat: clean(m[2]) });
      }
      if (treffer.length) {
        r.bsr = treffer[0].rang; r.bsr_kategorie = treffer[0].kat;
        if (treffer[1]) { r.bsr_unter = treffer[1].rang; r.bsr_unter_kategorie = treffer[1].kat; }
      }
    }
    var bb = LC.amazonPro.buyboxOnPage(doc) || {};
    var kat = clean(r.bsr_kategorie).toLowerCase(), link = '';
    Array.prototype.forEach.call(doc.querySelectorAll('a[href*="/gp/bestsellers/"]'), function (a) {
      var t = clean(a.textContent).replace(/^Siehe Top \d+ in\s+/i, '').toLowerCase();
      if (!link && t && t === kat) link = a.getAttribute('href');
    });
    /* Nebenbei lernen (LO 01.09. "geht das nicht ohne neue Tabs?"): dieselbe
       DP-HTML traegt Kaufzahl-Badge UND BSR - als Kalibrier-Paar an den
       Verkaufsschaetzer, null zusaetzliche Requests. ui erst zur Laufzeit
       greifen (onpage.js laedt nach dieser Datei). */
    try {
      var uiH = LC.onpage && LC.onpage.ui;
      if (LC.sales && uiH && uiH.kaufBadge) {
        var kb = uiH.kaufBadge(doc), bsrN = zahl(r.bsr);
        if (kb && kb.zahl > 0 && bsrN > 0 && kat) LC.sales.merken(kat, asin, bsrN, kb.zahl);
      }
    } catch (eLern) { /* Lernen darf Quick View nie stoeren */ }
    var seit = '';
    Array.prototype.forEach.call(doc.querySelectorAll('th, span.a-text-bold'), function (n) {
      if (seit || !/Im Angebot .*seit|Date First Available/i.test(n.textContent)) return;
      var v = n.tagName === 'TH' ? n.nextElementSibling : n.nextElementSibling;
      var m = clean(v && v.textContent).match(/(\d{4})/);
      if (m) seit = m[1];
    });
    var vars = {};
    Array.prototype.forEach.call(doc.querySelectorAll('[data-defaultasin]'), function (li) { vars[li.getAttribute('data-defaultasin')] = 1; });
    var bbTxt = ((doc.getElementById('desktop_buybox') || doc.getElementById('buybox') || {}).textContent) || '';
    // extract.js faellt auf den Byline-Store-Link zurueck ("Besuche den Casaria-Store") - das ist kein Verkaeufer
    var vk = clean(bb.verkaeufer) || clean(r.verkaeufer);
    if (!clean(bb.verkaeufer) && /^(Besuche den |Marke: )/i.test(vk)) vk = '';
    return {
      bsr: zahl(r.bsr), bsr_kategorie: clean(r.bsr_kategorie), bsr_link: link,
      bsr_unter: zahl(r.bsr_unter), bsr_unter_kategorie: clean(r.bsr_unter_kategorie),
      verkaeufer: vk, fba: /Versand (?:durch|von) Amazon/i.test(bbTxt),
      buybox: bb.status || '', seit: seit, varianten: Object.keys(vars).length,
      preis: r.preis == null ? null : Number(r.preis), ts: Date.now()
    };
  }

  // Popup-Toggle lcNoCookies (Standard AN): DP-Abrufe anonym = ohne Login-/
  // Standort-Personalisierung. Blockt Amazon anonym, einmal mit Session nachfassen.
  var anonAn = true;
  try {
    chrome.storage.local.get('lcNoCookies', function (d) { anonAn = !d || d.lcNoCookies !== false; });
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area === 'local' && ch.lcNoCookies) anonAn = ch.lcNoCookies.newValue !== false;
    });
  } catch (e) { /* Orphan-Kontext */ }

  /* Parsen erst, wenn der Haupt-Thread Luft hat: DOMParser + LC.extract auf
     1-3 MB kosten 50-150 ms, und das lief bis zu 60x mitten ins Scrollen
     (Long Tasks). timeout 1,5 s = spaetestens dann laeuft es trotzdem, die
     Warteschlange darf nicht haengen. Fallback setTimeout ohne rIC (jsdom).
     Bewusst hier und nicht in lesen(): dp-watchlist ruft lesen(html, asin)
     synchron auf, die Signatur bleibt. */
  function wennIdle(fn) {
    return new Promise(function (res, rej) {
      var lauf = function () { try { res(fn()); } catch (e) { rej(e); } };
      if (typeof requestIdleCallback === 'function') requestIdleCallback(lauf, { timeout: 1500 });
      else setTimeout(lauf, 50);
    });
  }

  function holen(asin) {
    var mit = function (cred) {
      return fetch('/dp/' + asin, { credentials: cred })
        // Fehlerseiten nicht als {leer} 6 h cachen; 503 = Amazon bremst -> wie Captcha stoppen
        .then(function (res) { if (!res.ok) throw new Error(res.status === 503 ? 'captcha' : 'http ' + res.status); return res.text(); })
        .then(function (html) { return wennIdle(function () { return lesen(html, asin); }); });
    };
    if (!anonAn) return mit('same-origin');
    /* Die cookielose Abfrage limitiert Amazon deutlich haerter: 503 oder eine
       Zustimmungs-/Robot-Zwischenseite kamen schon beim ersten Treffer - das
       warf 'captcha', stoppte die GANZE Warteschlange und wurde 15 min
       persistiert, also passierte gar nichts mehr (LO 01.09.). Deshalb wird
       JEDER Fehlschlag der anonymen Abfrage - Fehler wie leeres Ergebnis -
       einmal mit der normalen Sitzung wiederholt. Erst wenn auch die scheitert,
       bremst Amazon wirklich. */
    return mit('omit').then(function (d) {
      return d && d.leer ? mit('same-origin') : d;
    }).catch(function () { return mit('same-origin'); });
  }

  // ---- Chips an der Kachel -----------------------------------------------
  function zeigen(item, d) {
    var t = item.tile, b = item.badges;
    if (!b || b.querySelector('.lc-qv')) return;
    var add = function (c) { c.classList.add('lc-qv'); b.appendChild(c); };
    /* Auf der Bestseller-Liste IST der Kachel-Rang der BSR dieser Kategorie -
       exakt, sofort und ohne Abruf. Die Produktseite nennt ihn dort teils gar
       nicht (LO 01.09.: "ueberall keine bsrs obwohl das die bsr seite ist"). */
    if (bsKat && item.pos > 0 && !d.bsr) {
      d = Object.assign({}, d, { bsr: item.pos, bsr_kategorie: bsKat, leer: false });
    }
    if (d.leer) { add(ui.chip('Quick View: Seite nicht lesbar', 'mut')); }
    else {
      if (d.bsr) {
        add(ui.chip('<span class="lc-k">BSR</span> ' + ui.nf(d.bsr) + (d.bsr_kategorie ? ' <span class="lc-k">· ' + ui.esc(d.bsr_kategorie) + '</span>' : ''), '',
          (d.bsr_unter ? 'Nr. ' + ui.nf(d.bsr_unter) + ' in ' + d.bsr_unter_kategorie + ' · ' : '') + (d.bsr_link ? 'Bestseller-Liste öffnen' : 'Bestseller-Rang'), d.bsr_link || undefined));
        bsrs.push(d.bsr);
      } else add(ui.chip('<span class="lc-k">BSR</span> –', 'mut', 'kein Bestseller-Rang auf der Produktseite'));
      if (d.verkaeufer) add(ui.chip('<span class="lc-k">Verk.</span> ' + ui.esc(d.verkaeufer) + (d.fba ? ' <span class="lc-k">· FBA</span>' : ''), ui.EIGEN.test(d.verkaeufer) ? 'ok' : 'mut', 'Buybox-Verkäufer' + (d.fba ? ', Versand durch Amazon' : '')));
      else if (d.buybox === 'UNTERDRUECKT') add(ui.chip('Buybox unterdrückt', 'bad'));
      if (d.seit) add(ui.chip('<span class="lc-k">seit</span> ' + ui.esc(d.seit), 'mut', 'Im Angebot seit'));
      if (d.varianten > 1) add(ui.chip(d.varianten + ' <span class="lc-k">Var.</span>', 'mut', d.varianten + ' Varianten'));
    }
    t.setAttribute('data-lc-qv-data', JSON.stringify(d));
    t.dataset.lcQv = 'done';
    geladen++;
    kopf();
  }

  function kopf() {
    if (!headChip) return;
    var txt;
    if (stopped) {
      headChip.className = 'lc-chip bad';
      txt = 'Quick View pausiert – Amazon bremst <span class="lc-k">· Klick: weiter versuchen</span>';
    } else if (aus) { headChip.className = 'lc-chip mut'; txt = 'Quick View aus <span class="lc-k">· Klick: an</span>'; }
    else {
      headChip.className = 'lc-chip ' + (geladen >= gesamt ? 'ok' : '');
      txt = '<span class="lc-k">Quick View</span> ' + geladen + '/' + gesamt;
      if (fehler) txt += ' <span class="lc-k">· ' + fehler + ' Fehler</span>';
      if (fetched >= CFG.MAX && geladen < gesamt) txt += ' <span class="lc-k">· Limit ' + CFG.MAX + ' je Seite erreicht</span>';
      if (bsrs.length >= 3) {
        var s = bsrs.slice().sort(function (a, b) { return a - b; });
        txt += ' <span class="lc-k">· Ø BSR</span> ' + ui.nf(s[Math.floor(s.length / 2)]);
      }
    }
    headChip.innerHTML = txt;
  }

  // ---- Warteschlange -----------------------------------------------------
  function pump() {
    if (stopped || aus) return;
    while (running < CFG.PAR && queue.length) {
      if (fetched >= CFG.MAX) { queue.forEach(function (q) { q.tile.dataset.lcQv = 'skip'; }); queue = []; kopf(); break; }   // nicht mehr 'pending': Aus/An stellt sie sonst wieder an
      var item = queue.shift();
      if (item.tile.dataset.lcQv !== 'pending') continue;
      var wait = Math.max(0, lastAt + CFG.GAP - Date.now());
      lastAt = Date.now() + wait;
      running++; fetched++;
      (function (it, w) {
        setTimeout(function () {
          holen(it.asin).then(function (d) {
            var o = {}; o['qv:' + it.asin] = d;
            chrome.storage.local.set(o, function () { void chrome.runtime.lastError; });
            zeigen(it, d);
            if (!d.leer && (d.preis != null || d.bsr)) ui.send({ type: 'histSample', asin: it.asin, sample: { preis: d.preis, bsr: d.bsr, buybox: null, anbieter: null, angebot_min: null } });
          }).catch(function (e) {
            it.tile.dataset.lcQv = 'err';
            fehler++; kopf();
            console.warn('[LC] Quick View', it.asin, (e && e.message) || e);
            if (e && e.message === 'captcha') {
              stopped = true; queue = []; kopf();
              // Persistiert: der Stopp galt nur fuers aktuelle Dokument - auf
              // Seite 2 liefen sonst 60 weitere Requests in dieselbe Captcha-
              // Sperre und verlaengerten sie (Review 31.08.)
              chrome.storage.local.set({ qvStoppedUntil: Date.now() + 15 * 60 * 1000 }, function () { void chrome.runtime.lastError; });
            }
          }).then(function () { running--; pump(); });
        }, w);
      })(item, wait);
    }
  }

  function anstellen(item) {
    if (item.tile.dataset.lcQv !== 'pending' || queue.indexOf(item) >= 0) return;
    queue.push(item);
    queue.sort(function (a, b) { return a.pos - b.pos; });
    pump();
  }

  function beobachten(item) {
    if (typeof IntersectionObserver !== 'function') return anstellen(item);   // jsdom/alt: sofort
    if (!io) {
      io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (!en.isIntersecting) return;
          io.unobserve(en.target);
          var it = en.target.__lcQv;
          if (it) anstellen(it);
        });
      }, { rootMargin: '300px' });
    }
    item.tile.__lcQv = item;
    io.observe(item.tile);
  }

  // ---- Hook ---------------------------------------------------------------
  H.serp.push(function (ctx) {
    if (document.visibilityState !== 'visible') return;
    ui = ctx.ui;
    bsKat = ctx.bestsellerKat || '';
    var anker = ctx.head.querySelector('.lc-sp');
    headChip = ui.chip('<span class="lc-k">Quick View</span> …', 'mut', 'BSR, Verkäufer und Varianten je Treffer (von der Produktseite gelesen). Klick: aus/an');
    headChip.classList.add('lc-copy');
    headChip.addEventListener('click', function (ev) {
      ev.preventDefault(); ev.stopPropagation();
      /* Steckt eine Amazon-Bremse (stopped), soll der Klick sie LOESEN und
         nicht den Quick View abschalten - sonst kommt man aus dem pausierten
         Zustand nur durchs Warten heraus (LO 01.09.). */
      if (stopped) {
        stopped = false; fehler = 0;
        chrome.storage.local.remove('qvStoppedUntil', function () { void chrome.runtime.lastError; });
      } else {
        aus = !aus;
        chrome.storage.local.set({ qvOff: aus }, function () { void chrome.runtime.lastError; });
      }
      if (!aus) {
        ctx.tiles.forEach(function (t) {
          if (t.tile.dataset.lcQv === 'pending' || t.tile.dataset.lcQv === 'err') {
            t.tile.dataset.lcQv = 'pending'; anstellen(t);
          }
        });
      }
      kopf();
    });
    ctx.head.insertBefore(headChip, anker || null);

    var neu = ctx.tiles.filter(function (t) { return !t.tile.dataset.lcQv; });
    gesamt = ctx.tiles.length;
    neu.forEach(function (t) { t.tile.dataset.lcQv = 'pending'; });
    var start = function () {
      if (!neu.length) return kopf();
      var keys = neu.map(function (t) { return 'qv:' + t.asin; });
      ui.storage(keys).then(function (d) {
        neu.forEach(function (t) {
          var c = d['qv:' + t.asin];
          // Leere Treffer nur 10 min glauben statt 6 h: sonst haelt ein einziger
          // schlechter Lauf (Zwischenseite, Netzhaenger) die ganze Liste tot.
          if (c && Date.now() - c.ts < (c.leer ? 10 * 60 * 1000 : CFG.TTL)) zeigen(t, c);
          else if (!aus) beobachten(t);
        });
        kopf();
      }).catch(function () { /* Storage weg - dann eben ohne Cache */ neu.forEach(beobachten); });
    };
    if (ausGelesen) start();
    else ui.storage(['qvOff', 'qvStoppedUntil']).then(function (d) {
      aus = !!d.qvOff; ausGelesen = true;
      if (d.qvStoppedUntil && d.qvStoppedUntil > Date.now()) stopped = true;   // Captcha-Sperre gilt dokumentuebergreifend
      start();
    }).catch(start);
  });
})();
