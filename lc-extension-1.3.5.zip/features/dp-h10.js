/* Helium10-Zusatzdaten fuer die Produktseite - optionaler Andockpunkt.

   Standardmaessig AUS. Erst wenn im Popup die Checkbox "Helium 10 Zusatzdaten"
   an ist, spricht dieses Feature members.helium10.com an. Ohne Toggle bleibt
   die Extension zu 100 % lokal - die Non-Online-Variante ist der Default.

   Auth: Wir nutzen die Session-Cookies des laufenden H10-Logins in Chrome.
   Kein API-Key, kein Datenverkehr wenn der Nutzer nicht selbst H10-Kunde ist.

   Rechte: members.helium10.com + research-tools.helium10.com muessen in
   host_permissions stehen. Ist das nicht der Fall, meldet fetch einen
   Netzwerkfehler und wir zeigen einen Hinweis - kein Crash.

   Setzt shared/h10.js voraus (LC.h10). Hakt sich in LC.onpage.panel ein. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC || !LC.h10) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];

  var HOST_ALIAS = 'amazon.de';  // Content-Script laeuft nur auf amazon.de
  var CACHE_MIN = 15;             // pro ASIN + Feld einmal alle 15 min

  /* Login-Check: LC.h10.ready() (memoisiert, ein check-login je Seitenaufbau) -
     dp-chart/dp-keywords/dp-reviews nutzen denselben; kein zweiter Request von hier. */

  /* Kleiner Datei-lokaler Cache. Die Antworten landen NICHT in chrome.storage,
     damit sie nach dem Tab-Schliessen weg sind - das war eine Bewusstseinsfrage:
     Fremdanbieter-Antworten sollen sich nicht in unserem Speicher sammeln. */
  var mem = Object.create(null);
  function cached(key, fn) {
    var e = mem[key];
    if (e && Date.now() - e.at < CACHE_MIN * 60 * 1000) return Promise.resolve(e.value);
    return fn().then(function (v) { mem[key] = { at: Date.now(), value: v }; return v; });
  }

  function pill(ui, label, wert, titel) {
    var chip = ui.chip(ui.esc(label) + ' <b>' + ui.esc(wert) + '</b>', 'mut', titel);
    return chip;
  }

  H.panel.push(function (ctx) {
    var ui = ctx.ui, asin = ctx.asin;
    if (!ui || !asin) return;
    if (document.querySelector('.lc-h10-chip')) return;                        // schon verteilt

    ui.storage('lcH10Enabled').then(function (d) {
      if (!d.lcH10Enabled) return;                                              // Toggle aus - kein Netz
      LC.h10.ready().then(function (login) {
        if (!login || ui.aktuelleAsin() !== ctx.asin) return;                  // ohne Login still, andere Sektionen zeigen ohnehin nichts H10
        var HOST = 'amazon.de';

        // -- Variante-Anteil: kleiner Chip in der Listing-Chip-Reihe (secQ) - neben "5 Bullets"
        // Kostet Kontingent (100/Monat Free), und der mem-Cache oben lebt nur bis
        // zum naechsten Reload/Variantenwechsel - jeder Twister-Klick war ein
        // neuer Request. Deshalb wie h10sales: nur Anteil + Parent 7 Tage in
        // chrome.storage, je Konto (andere Konten, andere Daten) und ASIN.
        if (ctx.secQ) {
          var CHILD_TTL = 7 * 24 * 3600 * 1000, childKey = 'h10child:' + login.accountId + ':' + asin;
          ui.storage(childKey).then(function (dc) {
            var c = dc && dc[childKey];
            if (c && c.p != null && Date.now() - c.ts < CHILD_TTL) return c;
            return cached('child:' + asin, function () { return LC.h10.childSalesPerformance(asin, HOST); }).then(function (res) {
              var data = res && res.ok && res.data && res.data.results && res.data.results.data;
              var e = data && data[asin];
              if (!e || e.performance == null) return null;
              var oc = {}; oc[childKey] = { p: Number(e.performance), parent: e.parentAsin || '', ts: Date.now() };
              ui.storageSet(oc).catch(function () { /* Cache ist optional */ });
              return oc[childKey];
            });
          }).then(function (c) {
            if (!c || ui.aktuelleAsin() !== ctx.asin) return;
            var chip = ui.chip('<span class="lc-k">Variante</span> ' + Math.round(c.p * 100) + ' %',
              'mut', 'H10-Schätzung: Anteil dieser ASIN an den Verkäufen des Parent ' + (c.parent || asin));
            chip.classList.add('lc-h10-chip');
            ctx.secQ.appendChild(chip);
          }).catch(function () { /* Chip ist Beiwerk */ });
        }

        // -- Sales-Estimator als Klick-Chip in der Buybox-Zeile - neben "500+ / Monat"
        // Abrufe kosten Kontingent (10/Monat Free) -> Ergebnis PERSISTENT in
        // chrome.storage (h10:sales:<asin>, 7 Tage; nur die nackte Zahl, keine
        // Fremd-Antwort), sonst ist jeder Run nach einem Reload verloren (LO 01.09.).
        if (ctx.bbRow) {
          // Prefix bewusst OHNE 'h10:' - der ist vom Backup ausgeschlossen
          // (Login-Session-Daten); die nackte Sales-Zahl SOLL mit ins Backup.
          var SALES_TTL = 7 * 24 * 3600 * 1000, salesKey = 'h10sales:' + asin;
          var chip = ui.chip('<span class="lc-k">H10 Sales/30 T</span> abrufen ⟳', '', 'Klick: Verkaufsschätzung aus Helium 10 - kostet einen von 10 Free-Abrufen im Monat');
          chip.classList.add('lc-h10-chip', 'lc-copy');
          ui.storage(salesKey).then(function (dc) {
            var c = dc && dc[salesKey];
            if (!c || !(c.val > 0) || Date.now() - c.ts > SALES_TTL) return;
            chip.className = 'lc-chip ok lc-h10-chip lc-copy';
            chip.innerHTML = '<span class="lc-k">H10 Sales/30 T</span> ' + ui.nf(c.val) + ' <span class="lc-k">· ' + ui.tag(new Date(c.ts)) + '</span>';
            chip.title = 'Helium-10-Verkaufsschätzung aus dem Speicher (abgerufen am ' + ui.tag(new Date(c.ts)) + ', kostet nichts). Klick: neu abrufen - kostet einen Free-Abruf';
          });
          chip.addEventListener('click', function (ev) {
            ev.preventDefault(); ev.stopPropagation();
            if (chip.dataset.laeuft) return; chip.dataset.laeuft = '1';
            chip.innerHTML = '<span class="lc-k">H10 Sales/30 T</span> lädt …';
            cached('sales:' + asin, function () { return LC.h10.salesEstimator(asin, HOST); }).then(function (res) {
              /* Die haeufigste Fehlantwort ist KEIN Bug, sondern das leere
                 Monatskontingent: HTTP 400 { message: "Limit exceeded" } (Free
                 hat 10 Abrufe/Monat). Der Chip sagte dazu nur "Fehler: HTTP
                 400" - LO 01.09. Klartext statt Statuscode, und der Zaehler
                 daneben, der nichts kostet. */
              if (!res || !res.ok) {
                var msg = (res && res.data && (res.data.message || res.data.error)) || '';
                if (res && res.status === 400 && /limit|uses|exceed/i.test(msg)) {
                  throw new Error('Monatskontingent aufgebraucht');
                }
                if (res && res.status === 402) throw new Error('Kontingent leer (402)');
                if (res && res.status === 403) throw new Error('Plan erlaubt das nicht (403)');
                throw new Error('HTTP ' + (res && res.status) + (msg ? ' – ' + msg : ''));
              }
              var d = res.data || {};
              var val = d.last30DaysSales != null ? d.last30DaysSales : (d.results && d.results.last30DaysSales);
              var left = d.userData && d.userData.usesLeft;
              chip.className = 'lc-chip ok lc-h10-chip';
              chip.innerHTML = '<span class="lc-k">H10 Sales/30 T</span> ' + ui.nf(val || 0) + (left != null ? ' <span class="lc-k">· noch ' + left + '/Monat</span>' : '');
              if (val > 0) { var oc = {}; oc[salesKey] = { val: Number(val), ts: Date.now() }; ui.storageSet(oc).catch(function () { /* Cache ist optional */ }); }
              /* H10s Punktschaetzung ist genauer als Amazons "200+"-Eimer
                 (LO 01.09.) - als Kalibrier-Paar Quelle 'h' (Gewicht 2) an
                 den Verkaufsschaetzer. */
              try {
                var r = ctx.row || {};
                var bsrH = parseInt(String(r.bsr == null ? '' : r.bsr).replace(/\D/g, ''), 10);
                var katH = String(r.bsr_kategorie || String(r.kategorie || '').split(/[>›»]/)[0] || '').toLowerCase().trim();
                if (LC.sales && val > 0 && bsrH > 0 && katH) LC.sales.merken(katH, asin, bsrH, val, 'h');
              } catch (eH) { /* Lernen darf den Chip nie stoeren */ }
            }).catch(function (e) {
              chip.className = 'lc-chip bad lc-h10-chip';
              chip.innerHTML = '<span class="lc-k">H10 Sales</span> ' + ui.esc(e.message || 'kein Netz');
              delete chip.dataset.laeuft;
              /* Restzaehler nachreichen: eigener Endpunkt, kostet keine Abfrage.
                 Zeigt, ob das Kontingent wirklich leer ist oder woanders klemmt. */
              if (LC.h10.salesEstimatorUses) {
                LC.h10.salesEstimatorUses().then(function (u) {
                  var ud = u && u.data && u.data.userData;
                  if (ud && ud.usesLeft != null) {
                    chip.innerHTML += ' <span class="lc-k">· noch ' + ud.usesLeft + '/Monat</span>';
                  }
                }).catch(function () { /* Zaehler ist Beiwerk */ });
              }
            });
          });
          ctx.bbRow.appendChild(chip);
        }

        // -- Konto/Plan als kleine Fussnote am Ende der Karte
        if (ctx.card) {
          var fuss = ui.el('div', 'a-size-mini a-color-secondary a-spacing-top-mini lc-h10-chip',
            'H10 · Konto ' + ui.esc(String(login.accountId)) + ' · Plan ' + ui.esc(login.planLabel || login.plan));
          ctx.card.appendChild(fuss);
        }
      });
    }).catch(function (e) { console.warn('[LC] dp-h10', e); });
  });
})();
