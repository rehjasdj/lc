/* Popup-Steuerung: erfassen, analysieren (A+/Buybox), suchen, Preisvergleich,
   exportieren. Extraktion: shared/extract.js (injiziert). Alles Schreibende und
   Langlaufende macht der Service Worker - das Popup darf jederzeit zugehen. */
'use strict';

/* Dasselbe explizite Theme wie auf amazon.de verwenden. prefers-color-scheme
   bleibt nur der Fallback, solange noch keine LC-Einstellung gespeichert ist. */
try {
  chrome.storage.local.get('lcDark', function (d) {
    var gesetzt = d && typeof d.lcDark === 'boolean';
    document.documentElement.classList.toggle('lc-dark', gesetzt && d.lcDark);
    document.documentElement.classList.toggle('lc-light', gesetzt && !d.lcDark);
  });
  chrome.storage.onChanged.addListener(function (ch, area) {
    if (area !== 'local' || !ch.lcDark) return;
    document.documentElement.classList.toggle('lc-dark', !!ch.lcDark.newValue);
    document.documentElement.classList.toggle('lc-light', !ch.lcDark.newValue);
  });
} catch (e) { /* prefers-color-scheme bleibt aktiv */ }

var $ = function (id) { return document.getElementById(id); };
var view = 'rows'; // 'rows' | 'matches' | 'keywords' | 'pro'

function setStatus(msg, cls) {
  var el = $('status');
  el.textContent = msg || '';
  el.className = cls || '';
}

function load() {
  return storeGet([
      'rows', 'matches', 'keywords', 'keywordEvidence', 'keywordRuns',
      'keywordSerpMeasurements', 'keywordApiEvidence', 'pro', 'searchStatus', 'eanMap', 'autoCompare',
      'lcH10Enabled', 'lcH10Platinum', 'lcH10AccountId', 'lcNoCookies', 'lcAutoLearn', 'lcAutoResearch'
    ]).then(function (d) {
      return {
        rows: d.rows || [], matches: d.matches || [],
        keywords: d.keywords || [], pro: d.pro || [],
        keywordEvidence: d.keywordEvidence || [], keywordRuns: d.keywordRuns || [],
        keywordSerpMeasurements: d.keywordSerpMeasurements || [],
        keywordApiEvidence: d.keywordApiEvidence || [],
        searchStatus: d.searchStatus || {}, eanMap: d.eanMap || {},
        autoCompare: !!d.autoCompare,
        lcH10Enabled: !!d.lcH10Enabled,
        lcH10Platinum: !!d.lcH10Platinum,
        lcH10AccountId: d.lcH10AccountId || '',
        lcNoCookies: d.lcNoCookies !== false,   // Standard AN (organisch messen)
        lcAutoLearn: d.lcAutoLearn !== false,   // Standard AN (Schaetzer sammelt nebenbei)
        lcAutoResearch: d.lcAutoResearch !== false   // Standard AN (LO erwartet Auto-Messung)
      };
    });
}

/* Mehrere Keys in EINEM set(): Promise.all einzelner set()-Aufrufe ist keine
   Transaktion - schliesst das Popup dazwischen, laufen Keywords und Belege
   auseinander. lastError wird gemeldet statt verschluckt (Review 31.08.). */
function saveViele(obj) {
  return storeSet(obj).then(function (r) { if (!r || !r.ok) throw new Error((r && r.error) || 'Speichern fehlgeschlagen'); });
}
function storeGet(keys) {
  return new Promise(function (res) {
    try { chrome.runtime.sendMessage({ type: 'lcStoreGet', keys: keys == null ? null : keys }, function (r) {
      var e = chrome.runtime.lastError;
      if (!e && r && r.ok) return res(r.data || {});
      chrome.storage.local.get(keys, function (d) { res(d || {}); });
    }); } catch (e) { chrome.storage.local.get(keys, function (d) { res(d || {}); }); }
  });
}
/* Nur Keys mit Praefix (plus extraKeys) lesen: storeGet(null) zog bei jedem
   Popup-Start, jeder cal:*-Aenderung und beim CSV-Export den GANZEN Speicher
   (11 MB) durch die Message-Pipe. Der Worker filtert selbst (storage.local UND
   Disk-Ordner); antwortet er nicht (aelterer Worker), wird lokal komplett
   gelesen und hier gefiltert - wie frueher, nur noch als Fallback. */
function storeGetPrefix(prefix, extraKeys) {
  var extra = extraKeys || [];
  var filtern = function (d) {
    var out = {};
    Object.keys(d || {}).forEach(function (k) {
      if (k.indexOf(prefix) === 0 || extra.indexOf(k) > -1) out[k] = d[k];
    });
    return out;
  };
  return new Promise(function (res) {
    var lokal = function () { chrome.storage.local.get(null, function (d) { res(filtern(d)); }); };
    try { chrome.runtime.sendMessage({ type: 'lcStoreGet', prefix: prefix, keys: extra }, function (r) {
      if (!chrome.runtime.lastError && r && r.ok) return res(r.data || {});
      lokal();
    }); } catch (e) { lokal(); }
  });
}
function storeSet(obj) {
  return new Promise(function (res) {
    try { chrome.runtime.sendMessage({ type: 'lcStoreSet', data: obj || {} }, function (r) {
      var e = chrome.runtime.lastError; res(!e && r ? r : { ok: false, error: e && e.message });
    }); } catch (e) { res({ ok: false, error: e.message }); }
  });
}
function save(key, val) {
  return saveViele(Object.fromEntries([[key, val]]));
}
/* Aggregierte Keyword-Zeilen tragen den Seed kleingeschrieben (cleanKeyword in
   api.js), die Rohbelege den Originaltext. Jeder Seed-Vergleich muss beide
   Seiten normalisieren - sonst loescht/exportiert ein Seed mit Grossbuchstaben
   NICHTS und meldet trotzdem Erfolg (Review 31.08.). */
function seedNorm(s) { return String(s == null ? '' : s).replace(/\s+/g, ' ').trim().toLowerCase(); }

/* Antwort durchreichen, Fehler als null: bisher wurde lastError verschluckt
   und das Popup meldete "Suche laeuft...", obwohl der Worker den Auftrag nie
   bekommen hatte (Review 02.09.). */
function sendMsg(msg) {
  return new Promise(function (res) {
    try { chrome.runtime.sendMessage(msg, function (resp) {
      if (chrome.runtime.lastError || resp == null) return res(null);
      res(resp);
    }); } catch (e) { res(null); }
  });
}

/* Hintergrund-Auftrag (batchSearch, keywords, proCheck, checkVariants): der
   Worker quittiert sofort mit {started:true} und arbeitet weiter. Bleibt die
   Quittung aus, ist er tot oder die Extension halb neu geladen - dann ehrlich
   melden statt "laeuft..." zu behaupten. */
function auftrag(msg, laeuftText) {
  return sendMsg(msg).then(function (resp) {
    if (!resp) return setStatus('Hintergrunddienst antwortet nicht – Extension neu laden', 'err');
    setStatus(laeuftText);
  });
}

/* Zwei-Klick-Bestaetigung statt confirm(): im Extension-Popup liefert der
   Dialog sofort false (Firefox blockt ihn ganz) - der Handler bricht ab und
   der Knopf tut scheinbar nichts (LO 01.09.). Erster Klick schaerft den Knopf
   fuer 4 s (Text + Status 'warn'), der zweite im Fenster fuehrt fn aus. Der
   Zustand haengt am Knopf selbst, damit sich mehrere Knoepfe nicht gegenseitig
   scharfschalten. Ohne fn (zweiter Aufruf aus einem anderen Handler, s.
   Backup-Import) laeuft das beim Schaerfen gemerkte fn. */
function bestaetigen(button, statusText, fn) {
  var s = button._scharf;
  var zurueck = function () {
    clearTimeout(s.timer);
    button._scharf = null;
    button.textContent = s.text;
    button.classList.remove('scharf');
  };
  if (s) { zurueck(); return s.fn(); }
  s = button._scharf = { text: button.textContent, fn: fn };
  // ponytail: Ein-Zeichen-Knoepfe (×, ✕) werden zum "?", Textknoepfe sagen es aus
  button.textContent = s.text.length <= 2 ? '?' : 'Nochmal klicken zum Bestätigen';
  button.classList.add('scharf');
  var meldung = statusText + ' – nochmal klicken zum Bestätigen.';
  setStatus(meldung, 'warn');
  s.timer = setTimeout(function () {
    zurueck();
    if ($('status').textContent === meldung) setStatus('');   // nur die eigene Meldung wegraeumen
  }, 4000);
}

/* SheetJS (950 KB) erst laden, wenn Import/Export ihn wirklich braucht: als
   <script> in popup.html kostete er bei JEDEM Oeffnen Parse-Zeit, gebraucht
   wird er nur fuer .xlsx. Die Manifest-CSP (script-src 'self') erlaubt das
   Nachladen aus dem eigenen Paket; einmal geladen bleibt er global (XLSX). */
var xlsxPromise = null;
function ladeXlsx() {
  if (globalThis.XLSX) return Promise.resolve(globalThis.XLSX);
  if (!xlsxPromise) xlsxPromise = new Promise(function (res, rej) {
    var s = document.createElement('script');
    s.src = 'vendor/xlsx.full.min.js';
    s.onload = function () { res(globalThis.XLSX); };
    s.onerror = function () { xlsxPromise = null; rej(new Error('vendor/xlsx.full.min.js konnte nicht geladen werden')); };
    document.head.appendChild(s);
  });
  return xlsxPromise;
}

// ------------------------------------------------------------------ Plattform-Checkboxen

(function buildPlats() {
  var wrap = $('plats');
  var groups = [
    { label: 'Unsere Plattformen', vergleich: false, checked: true },
    { label: 'Preisvergleich (verkaufen wir nicht)', vergleich: true, checked: false }
  ];
  groups.forEach(function (g) {
    var head = document.createElement('span');
    head.className = 'grp';
    head.textContent = g.label;
    wrap.appendChild(head);
    LC.PLATFORMS.filter(function (p) { return !!p.vergleich === g.vergleich; }).forEach(function (p) {
      var label = document.createElement('label');
      var cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.value = p.id;
      cb.checked = g.checked;
      label.appendChild(cb);
      label.appendChild(document.createTextNode(p.label));
      wrap.appendChild(label);
    });
  });
})();

function checkedPlats() {
  return Array.prototype.slice.call($('plats').querySelectorAll('input:checked'))
    .map(function (cb) { return cb.value; });
}

// ------------------------------------------------------------------ Query-Hinweis

var TYPE_LABEL = { ean: 'EAN', asin: 'ASIN', sku: 'SKU / Freitext' };

function updateHint() {
  var q = $('query').value.trim();
  var hint = $('qhint');
  if (!q) { hint.textContent = ''; return; }
  var t = LC.search.detectQueryType(q);
  hint.innerHTML = '';
  var b = document.createElement('b');
  b.textContent = TYPE_LABEL[t];
  hint.appendChild(document.createTextNode('erkannt: '));
  hint.appendChild(b);
  if (t === 'ean') hint.appendChild(document.createTextNode(' — Amazon-Treffer liefert die ASIN'));
  if (t === 'asin') hint.appendChild(document.createTextNode(' — Amazon wird direkt als Listing erfasst'));
}

$('query').addEventListener('input', updateHint);
$('query').addEventListener('keydown', function (e) {
  if (e.key === 'Enter') $('search').click();
});

// ------------------------------------------------------------------ Analyse-Panel (Produktbetreuer)

/* Alle Plattformen ausser der, auf der das Listing selbst steht. Bewusst NICHT
   nur comparePlatforms() (= Temu): die eigenen Kaufland-/eBay-Angebote sind
   fuer die Buybox-Sanierung gerade der wahrscheinliche Preisanker. */
function comparePlatsFor(row) {
  var ownId = (LC.PLATFORMS.find(function (p) { return p.label === row.plattform; }) || {}).id;
  return LC.PLATFORMS.map(function (p) { return p.id; })
    .filter(function (id) { return id !== ownId; });
}

/* Preisvergleich starten: EAN direkt aus der Zeile, sonst aus dem gelernten
   ASIN->EAN-Mapping. Ohne EAN laufen Otto/Temu sowieso ueber Marke+Titel. */
function startCompare(row, eanMap) {
  var ean = row.ean || eanMap[row.produkt_id] || eanMap[row.sku] || '';
  var plats = comparePlatsFor(row);
  if (!plats.length) return setStatus('Keine Vergleichsplattformen definiert.', 'err');
  auftrag({
    type: 'batchSearch', perPlatform: true,
    ean: ean, titel: row.titel, marke: row.marke,
    mpn: row.mpn, sku: row.sku, produktId: row.produkt_id,
    platforms: plats,
    sourcePreis: row.preis, sourceLabel: row.plattform,
    qtype: 'ean', query: ean
  }, 'Preisvergleich laeuft auf: ' + plats.join(', ') + '...');
  switchView('matches');
}

function renderAnalyse(row, eanMap) {
  var box = $('analyse');
  box.innerHTML = '';
  if (!row) { box.hidden = true; return; }

  var isAmazon = row.plattform === 'Amazon';
  var head = document.createElement('div');
  head.className = 'h';
  head.textContent = 'Analyse — ' + (row.produkt_id || row.sku || '') + ' · ' + row.plattform;
  box.appendChild(head);

  var line = function (label, value, cls) {
    var el = document.createElement('div');
    el.className = 'line';
    var l = document.createElement('span');
    l.textContent = label;
    var v = document.createElement('span');
    v.className = cls || '';
    v.textContent = value;
    el.appendChild(l);
    el.appendChild(v);
    box.appendChild(el);
  };

  if (isAmazon) {
    line('A+:', row.aplus || '?', row.aplus === 'KEIN A+' ? 'bad' : 'good');
    var bbCls = row.buybox === 'ja' ? 'good' : (row.buybox === 'UNTERDRUECKT' ? 'bad' : 'warn');
    line('Buybox:', row.buybox || '?', bbCls);
    if (row.buybox === 'UNTERDRUECKT') {
      line('', 'irgendwo ist der Artikel guenstiger → Preisvergleich!', 'bad');
    }
    if (row.andere_angebote) line('Angebote:', row.andere_angebote, 'warn');
  }
  var ean = row.ean || eanMap[row.produkt_id] || eanMap[row.sku] || '';
  line('EAN:', ean || 'unbekannt (Preisvergleich laeuft dann ueber Marke+Titel)', ean ? '' : 'warn');
  if (row.preis != null) {
    line('Preis:', row.preis.toFixed(2).replace('.', ',') + ' ' + (row.waehrung || 'EUR'));
  }

  var btnRow = document.createElement('div');
  btnRow.className = 'row';

  var cmp = document.createElement('button');
  cmp.className = row.buybox === 'UNTERDRUECKT' ? 'primary' : '';
  cmp.textContent = 'Preisvergleich (' + comparePlatsFor(row).map(function (id) {
    return LC.PLATFORMS.find(function (p) { return p.id === id; }).label;
  }).join(', ') + ')';
  cmp.addEventListener('click', function () { startCompare(row, eanMap); });
  btnRow.appendChild(cmp);

  if (isAmazon && row.varianten_asins && row.varianten_asins.length) {
    var vc = document.createElement('button');
    vc.textContent = 'Varianten pruefen (' + row.varianten_asins.length + ')';
    vc.title = 'Alle Geschwister-ASINs laden: A+ da? Buybox da?';
    vc.addEventListener('click', function () {
      vc.disabled = true;
      auftrag({ type: 'checkVariants', asins: row.varianten_asins },
              'Varianten-Check laeuft (' + row.varianten_asins.length + ' ASINs)...');
    });
    btnRow.appendChild(vc);
  }

  box.appendChild(btnRow);
  box.hidden = false;
}

// ------------------------------------------------------------------ Rendern

/* Der eigene Webshop ist Referenz, nicht Wettbewerber - er wird deshalb
   zurueckgenommen dargestellt und nie als guenstigster Preis markiert.
   Dieselbe Pruefung wie im Urteil (shared/match.js), damit Anzeige und
   Bewertung nicht auseinanderlaufen koennen. */
function istShop(r) {
  return !!(LC.match && LC.match.istEigenerShop && LC.match.istEigenerShop(r));
}

var VIEW_TABS = { rows: 'viewRows', matches: 'viewMatches', keywords: 'viewKeywords', pro: 'viewPro' };

function switchView(v) {
  view = v;
  Object.keys(VIEW_TABS).forEach(function (k) {
    $(VIEW_TABS[k]).className = v === k ? 'active' : '';
  });
  load().then(render);
}

Object.keys(VIEW_TABS).forEach(function (k) {
  $(VIEW_TABS[k]).addEventListener('click', function () { switchView(k); });
});

function fmtPreis(p, w) {
  if (p == null) return '';
  return p.toFixed(2).replace('.', ',') + ' ' + (w || 'EUR');
}

/* Buybox-Zeilen haben eine andere Form als Listings/Treffer - eigener,
   schlanker Renderer. (Der fruehere keywords-Zweig hier war UNERREICHBAR -
   render() leitet 'keywords' immer an renderKeywordHistory - und enthielt
   eine abweichende Kopie des Loeschpfads; entfernt im Review 31.08.) */
function renderSimple(list, items, kind) {
  if (!items.length) {
    var e = document.createElement('div');
    e.className = 'empty';
    e.textContent = 'Noch keine ASIN geprueft.';
    list.appendChild(e);
    return;
  }

  items.forEach(function (r, i) {
    var item = document.createElement('div');
    item.className = 'item';
    var body = document.createElement('div');
    body.className = 'body';

    var tag = document.createElement('span');
    tag.className = 'tag';
    tag.textContent = r.asin || '?';
    body.appendChild(tag);

    var t = document.createElement('span');
    t.className = 't';
    // Bei Buybox-Zeilen steht das URTEIL oben - nicht der Status, den er selbst sieht.
    t.textContent = r.urteil || ('Buybox: ' + (r.buybox || '?'));
    body.appendChild(t);

    var m = document.createElement('span');
    m.className = /UNTERBOTEN/.test(r.urteil || '') ? 'w' : 'meta';
    m.textContent = [
      r.guenstigster_beleg ? 'Nachweis: ' + r.guenstigster_beleg : '',
      (r.bestaetigte != null ? r.bestaetigte + ' von ' + r.kandidaten + ' Treffern belegt' : ''),
      'Buybox ' + (r.buybox || '?'),
      r.angebot_min != null ? 'Amazon ab ' + fmtPreis(r.angebot_min, 'EUR') : '',
      r.fehler ? '! ' + r.fehler : ''
    ].filter(Boolean).join(' · ');
    body.appendChild(m);

    /* Das ganze Wettbewerbsfeld aufklappbar: nicht nur wer unterbietet, sondern
       WER ALLES den Artikel fuehrt und zu welchem Gesamtpreis - die teuren
       Anbieter belegen, wo der Markt liegt. */
    if (kind === 'pro' && r.wettbewerb) {
      var det = document.createElement('details');
      det.className = 'feld';
      var sum = document.createElement('summary');
      sum.textContent = (r.anbieter_extern || 0) + ' Anbieter im Markt' +
        (r.luecke != null
          ? (r.luecke < 0
              ? ' · guenstigster liegt ' + fmtPreis(Math.abs(r.luecke), 'EUR') + ' darunter'
              : ' · niemand unterbietet')
          : '');
      det.appendChild(sum);
      var pre = document.createElement('pre');
      pre.className = 'feldtext';
      pre.textContent = r.wettbewerb;
      det.appendChild(pre);
      body.appendChild(det);
    }

    if (kind === 'pro' && r.verworfen) {
      var v = document.createElement('span');
      v.className = 'meta';
      v.textContent = 'verworfen: ' + r.verworfen;
      v.title = r.verworfen;
      body.appendChild(v);
    }

    item.appendChild(body);

    var del = document.createElement('button');
    del.className = 'ghost';
    del.textContent = '✕';
    del.title = 'Eintrag entfernen';
    del.setAttribute('aria-label', 'Eintrag entfernen');
    del.addEventListener('click', function () {
      load().then(function (d) {
        var arr = d[kind];
        /* Per IDENTITAET loeschen, nicht ueber den Render-Index: ein parallel
           laufender proCheck haengt neu gepruefte ASINs ans Ende - der Index
           der gerenderten Zeile zeigt dann auf einen anderen Eintrag
           (Review 31.08., analog zum istGleich-Muster der Trefferliste). */
        var ix = arr.findIndex(function (x) { return x.asin === r.asin && x.geprueft_am === r.geprueft_am; });
        if (ix < 0) ix = arr.findIndex(function (x) { return x.asin === r.asin; });
        if (ix > -1) arr.splice(ix, 1);
        return save(kind, arr).then(function () { load().then(render); });
      });
    });
    item.appendChild(del);

    list.appendChild(item);
  });
}

/* ---------------------------------------------------------- Keyword-Historie

   Alle abgefragten Keywords bleiben als Historie erhalten (Import fuellt sie
   mit). Gruppiert nach Seed = die Liste der Abfragen; aufklappen liest die
   Treffer. ALLES ist modular - pro Seed UND pro einzelnem Keyword: neu ernten
   (tief/schnell), exportieren, loeschen. Import laeuft ueber die vorhandenen
   Import-Knoepfe (eine einzelne exportierte Keyword-Datei fuegt sich zusammen).
   Rerun MERGT (runKeywords haengt an und aggregiert neu) - aktualisiert also
   das Keyword, ohne die uebrige Historie zu zerstoeren. */
function mkBtn(txt, title, cls, fn) {
  var b = document.createElement('button');
  b.className = 'ghost ' + (cls || '');
  b.textContent = txt; b.title = title; b.setAttribute('aria-label', title);
  b.addEventListener('click', fn);
  return b;
}
function stopToggle(ev) { ev.preventDefault(); ev.stopPropagation(); }

function keywordCapablePlatforms() {
  var kann = function (p) { return p === 'kaufland' || LC.api.hasSuggest(p); };
  var plats = checkedPlats().filter(kann);
  if (!plats.length) {
    plats = LC.PLATFORMS.filter(function (p) { return kann(p.id); }).map(function (p) { return p.id; });
  }
  return plats;
}

// Rerun/Aktualisieren: den Begriff (Seed ODER einzelnes Keyword) neu ernten.
function rerunHarvest(begriff, tief) {
  if (!begriff) return;
  var plats = keywordCapablePlatforms();
  auftrag({ type: 'keywords', seeds: [begriff], platforms: plats, tief: !!tief },
          'Rerun "' + begriff + '" (' + (tief ? 'tief' : 'schnell') + ') auf ' + plats.join(', ') + '...');
  switchView('keywords');
}

function keywordMeta(r) {
  return [
    'beste Pos. ' + (r.beste_position || r.position || '?'),
    r.demand_graph_index_0_100 != null ? 'Demand ' + r.demand_graph_index_0_100 + '/100' : '',
    r.confidence_0_100 != null ? 'Confidence ' + r.confidence_0_100 + '/100' : '',
    r.marktplatz_konsens ? 'Konsens ' + r.marktplatz_konsens : '',
    r.trend ? 'Trend ' + r.trend : '',
    (r.serp_gekauft_max != null && r.serp_gekauft_max !== '') ? r.serp_gekauft_max + ' Verk./Mon.' : '',
    (r.serp_preis_median != null && r.serp_preis_median !== '') ? 'Median ' + fmtPreis(Number(r.serp_preis_median), 'EUR') : '',
    r.datenquelle || ''
  ].filter(Boolean).join(' · ');
}

// Ein einzelnes Keyword (Plattform+Seed+Keyword) samt Belegen entfernen.
function keywordEintragLoeschen(r) {
  load().then(function (d) {
    var pid = r.plattform_id || String(r.plattform || '').toLowerCase();
    d.keywordEvidence = (d.keywordEvidence || []).filter(function (row) {
      var rp = row.plattform_id || String(row.plattform || '').toLowerCase();
      return !(rp === pid && seedNorm(row.seed) === seedNorm(r.seed) && row.keyword === r.keyword);
    });
    var usedApi = Object.create(null);
    d.keywordEvidence.forEach(function (row) { if (row.api_abruf_id) usedApi[row.api_abruf_id] = 1; });
    d.keywordApiEvidence = (d.keywordApiEvidence || []).filter(function (row) { return !row.abruf_id || !!usedApi[row.abruf_id]; });
    d.keywordSerpMeasurements = (d.keywordSerpMeasurements || []).filter(function (row) {
      var rp = row.plattform_id || String(row.plattform || '').toLowerCase();
      return !(rp === pid && row.keyword === r.keyword);
    });
    d.keywords = LC.api.aggregateEvidence(d.keywordEvidence, d.keywordRuns, d.keywordSerpMeasurements);
    saveViele({
      keywordEvidence: d.keywordEvidence,
      keywordSerpMeasurements: d.keywordSerpMeasurements,
      keywordApiEvidence: d.keywordApiEvidence,
      keywords: d.keywords
    }).then(function () { load().then(render); })
      .catch(function (e) { setStatus('Speichern fehlgeschlagen: ' + e.message, 'err'); });
  });
}

// Ganzen Seed (alle seine Keywords + Belege) entfernen. Rueckfrage macht der
// Knopf selbst (bestaetigen, Zwei-Klick) - confirm() geht im Popup nicht.
function deleteSeed(seed) {
  load().then(function (d) {
    var ziel = seedNorm(seed);
    var weg = function (arr) { return (arr || []).filter(function (r) { return seedNorm(r.seed) !== ziel; }); };
    d.keywordEvidence = weg(d.keywordEvidence);
    d.keywordRuns = weg(d.keywordRuns);
    d.keywordSerpMeasurements = weg(d.keywordSerpMeasurements);
    d.keywordApiEvidence = weg(d.keywordApiEvidence);
    d.keywords = LC.api.aggregateEvidence(d.keywordEvidence, d.keywordRuns, d.keywordSerpMeasurements);
    saveViele({
      keywordEvidence: d.keywordEvidence, keywordRuns: d.keywordRuns,
      keywordSerpMeasurements: d.keywordSerpMeasurements, keywordApiEvidence: d.keywordApiEvidence,
      keywords: d.keywords
    }).then(function () { load().then(render); setStatus('Seed "' + seed + '" geloescht.', 'ok'); })
      .catch(function (e) { setStatus('Loeschen fehlgeschlagen: ' + e.message, 'err'); });
  });
}

// Gefilterten Keyword-Ausschnitt als eigene .xlsx (Seed- ODER Einzel-Keyword).
function exportKeywordFilter(filterFn, suffix, statusText) {
  load().then(function (d) {
    var kw = (d.keywords || []).filter(filterFn);
    if (!kw.length) return setStatus('Nichts zu exportieren.', 'err');
    var safe = String(suffix).replace(/[^a-z0-9]+/gi, '-').slice(0, 40).replace(/^-|-$/g, '');
    var name = LC.defaultFilename().replace(/\.xlsx$/i, '') + '-keyword-' + (safe || 'export') + '.xlsx';
    xlsxExport(name, function (XLSX) {
      return LC.buildWorkbook(XLSX, [], [], {
        keywords: kw,
        keywordEvidence: (d.keywordEvidence || []).filter(filterFn),
        keywordRuns: (d.keywordRuns || []).filter(filterFn),
        keywordSerpMeasurements: (d.keywordSerpMeasurements || []).filter(filterFn),
        keywordApiEvidence: (d.keywordApiEvidence || []).filter(filterFn),
        pro: []
      });
    }, function () { setStatus(statusText, 'ok'); });
  });
}

// Eine Keyword-Zeile mit den modularen Aktionen (rerun tief/schnell, export, loeschen).
function keywordRow(r) {
  var item = document.createElement('div'); item.className = 'item kwrow';
  var body = document.createElement('div'); body.className = 'body';
  var tag = document.createElement('span'); tag.className = 'tag'; tag.textContent = r.plattform || '?'; body.appendChild(tag);
  var t = document.createElement('span'); t.className = 't'; t.textContent = r.keyword || ''; t.title = r.keyword || ''; body.appendChild(t);
  var m = document.createElement('span'); m.className = 'meta'; m.textContent = keywordMeta(r); body.appendChild(m);
  item.appendChild(body);

  var akt = document.createElement('span'); akt.className = 'kwakt';
  akt.appendChild(mkBtn('↻ᵗ', 'Dieses Keyword neu ernten - tief (mit SERP)', 'mini', function () { rerunHarvest(r.keyword, true); }));
  akt.appendChild(mkBtn('↻ˢ', 'Dieses Keyword neu ernten / aktualisieren - schnell', 'mini', function () { rerunHarvest(r.keyword, false); }));
  akt.appendChild(mkBtn('⇩', 'Nur dieses Keyword als .xlsx', 'mini', function () {
    exportKeywordFilter(function (x) {
      return seedNorm(x.seed) === seedNorm(r.seed) && (x.keyword == null || x.keyword === r.keyword);
    }, r.keyword, '"' + r.keyword + '" exportiert.');
  }));
  akt.appendChild(mkBtn('✕', 'Dieses Keyword entfernen', 'mini danger', function () { keywordEintragLoeschen(r); }));
  item.appendChild(akt);
  return item;
}

function renderKeywordHistory(list, keywords) {
  if (!keywords.length) {
    var e = document.createElement('div'); e.className = 'empty';
    e.textContent = 'Noch keine Keywords geerntet. (Import laedt eine fruehere .xlsx zurueck.)';
    list.appendChild(e); return;
  }
  var bySeed = {};
  // Gruppenschluessel ist der NORMALISIERTE Seed ('' = ohne Seed, Anzeige unten)
  keywords.forEach(function (r) { var s = seedNorm(r.seed); (bySeed[s] = bySeed[s] || []).push(r); });
  var seeds = Object.keys(bySeed).sort(function (a, b) { return bySeed[b].length - bySeed[a].length; });

  seeds.forEach(function (seed) {
    var gruppe = bySeed[seed];
    var plats = {}; gruppe.forEach(function (r) { if (r.plattform) plats[r.plattform] = 1; });
    var det = document.createElement('details'); det.className = 'seed';
    var sum = document.createElement('summary');
    var nm = document.createElement('span'); nm.className = 'seedname'; nm.textContent = seed || '(ohne Seed)'; sum.appendChild(nm);
    var inf = document.createElement('span'); inf.className = 'seedinfo';
    inf.textContent = gruppe.length + ' KW · ' + Object.keys(plats).length + ' MP'; sum.appendChild(inf);
    var sa = document.createElement('span'); sa.className = 'seedakt';
    sa.appendChild(mkBtn('↻ᵗ', 'Ganzen Seed neu ernten - tief', 'mini', function (ev) { stopToggle(ev); rerunHarvest(seed, true); }));
    sa.appendChild(mkBtn('↻ˢ', 'Ganzen Seed neu ernten - schnell', 'mini', function (ev) { stopToggle(ev); rerunHarvest(seed, false); }));
    sa.appendChild(mkBtn('⇩', 'Ganzen Seed als .xlsx', 'mini', function (ev) {
      stopToggle(ev);
      exportKeywordFilter(function (x) { return seedNorm(x.seed) === seed; }, seed, 'Seed "' + (seed || '(ohne Seed)') + '" exportiert.');
    }));
    sa.appendChild(mkBtn('✕', 'Ganzen Seed loeschen', 'mini danger', function (ev) {
      stopToggle(ev);
      bestaetigen(ev.currentTarget, 'Seed "' + (seed || '(ohne Seed)') + '" mit allen Keywords und Belegen loeschen',
                  function () { deleteSeed(seed); });
    }));
    sum.appendChild(sa);
    det.appendChild(sum);
    gruppe.forEach(function (r) { det.appendChild(keywordRow(r)); });
    list.appendChild(det);
  });
}

function render(data) {
  var rows = data.rows, matches = data.matches;
  var keywords = data.keywords || [], pro = data.pro || [];

  $('viewRows').textContent = 'Listings (' + rows.length + ')';
  $('viewMatches').textContent = 'Treffer (' + matches.length + ')';
  $('viewKeywords').textContent = 'Keywords (' + keywords.length + ')';
  $('viewPro').textContent = 'Buybox (' + pro.length + ')';

  var gesamt = rows.length + matches.length + keywords.length + pro.length;
  $('export').disabled = !gesamt;
  $('export').textContent = 'Export .xlsx' + (gesamt ? ' (' + gesamt + ')' : '');
  $('exportMd').disabled = !gesamt;
  $('clear').disabled = !gesamt;

  // Die Reiter-Aktionen beziehen sich auf den sichtbaren Reiter - ist der
  // leer, sind sie aus. Sonst klickt man ins Nichts und bekommt eine Fehlermeldung.
  var imReiter = ({ rows: rows, matches: matches, keywords: keywords, pro: pro }[view] || []).length;
  $('viewExport').disabled = !imReiter;
  $('viewClear').disabled = !imReiter;

  $('autoCompare').checked = data.autoCompare;
  if ($('h10Enabled')) $('h10Enabled').checked = data.lcH10Enabled;
  if ($('h10Platinum')) $('h10Platinum').checked = data.lcH10Platinum;
  // Nur den Wert setzen - die Kontoliste (Netz-Request an Helium) holt der
  // Start einmal und der H10-Schalter beim Einschalten, nicht jeder Reiterwechsel.
  if ($('h10AccountId')) $('h10AccountId').value = data.lcH10AccountId || '';
  $('noCookies').checked = data.lcNoCookies;
  $('autoLearn').checked = data.lcAutoLearn;
  $('autoResearch').checked = data.lcAutoResearch;

  var list = $('list');
  list.textContent = '';

  if (view === 'keywords') return renderKeywordHistory(list, keywords);
  if (view === 'pro') return renderSimple(list, pro, 'pro');

  var items = view === 'rows' ? rows : matches;

  /* Nachweislich fremde Treffer ("EAN weicht ab", "Fremdmarke ... im Titel")
     standen bisher gleichwertig neben den echten und haben die Liste
     unbrauchbar gemacht. Sie bleiben nachvollziehbar - im Excel-Export und
     als Zeile am Ende -, aber sie stehen nicht mehr dazwischen. */
  var verworfen = [];
  if (view === 'matches') {
    verworfen = items.filter(function (r) { return r.match_stufe === 'FREMD'; });
    if (verworfen.length) {
      items = items.filter(function (r) { return r.match_stufe !== 'FREMD'; });
    }
  }

  if (!items.length && verworfen.length) {
    var nurFremd = document.createElement('div');
    nurFremd.className = 'empty';
    nurFremd.textContent = 'Kein passender Treffer - ' + verworfen.length +
      ' Kandidat(en) waren nachweislich andere Artikel.';
    list.appendChild(nurFremd);
    return;
  }

  if (!items.length) {
    var e = document.createElement('div');
    e.className = 'empty';
    e.textContent = view === 'rows' ? 'Noch nichts erfasst.' : 'Noch keine Suche gelaufen.';
    list.appendChild(e);
    return;
  }

  /* Spaltenkopf: erst er macht aus untereinanderstehenden Zeilen eine
     Tabelle, die man von oben nach unten lesen kann. */
  var kopf = document.createElement('div');
  kopf.className = 'grid thead';
  ['Plattform', 'Titel', 'Preis', view === 'rows' ? 'Status' : 'Beleg', ''].forEach(function (h, n) {
    var c = document.createElement('span');
    if (n === 2) c.className = 'num';
    c.textContent = h;
    kopf.appendChild(c);
  });
  list.appendChild(kopf);

  /* Der guenstigste BELEGTE Fremdpreis wird hervorgehoben - das ist die eine
     Zahl, wegen der das Werkzeug geoeffnet wird. Der eigene Shop bleibt
     aussen vor: er kann die Buybox nicht kosten. */
  var bestPreis = null;
  if (view === 'matches') {
    items.forEach(function (r) {
      if (r.match_bestaetigt === 'ja' && r.preis != null && !istShop(r) &&
          (bestPreis == null || r.preis < bestPreis)) bestPreis = r.preis;
    });
  }

  /* Eintrag identifizieren statt ueber den Listenindex: seit echte und
     unbelegte Treffer in getrennten Gruppen gerendert werden, stimmt der
     Schleifenindex nicht mehr mit der Position in d.matches ueberein. */
  function istGleich(a, b) {
    if (a.url && b.url) return a.url === b.url;
    return (a.plattform || '') === (b.plattform || '') &&
           (a.titel || '') === (b.titel || '') &&
           String(a.preis) === String(b.preis) &&
           (a.produkt_id || '') === (b.produkt_id || '');
  }

  function baueZeile(r) {
    var item = document.createElement('div');
    item.className = 'grid item' + (istShop(r) ? ' ref' : '');

    var tag = document.createElement('span');
    tag.className = 'tag';
    tag.textContent = r.plattform || '?';
    tag.title = r.plattform || '';
    item.appendChild(tag);

    // Produkt-ID steht im Tooltip statt in einer eigenen Spalte - sie kostete
    // Breite, die der Titel braucht, und wird beim Lesen praktisch nie gebraucht.
    var idHint = r.produkt_id ? r.produkt_id + '\n' : '';
    if (r.url) {
      var a = document.createElement('a');
      a.className = 't';
      a.href = r.url;
      a.textContent = r.titel || '(ohne Titel)';
      a.title = idHint + (r.titel || '') + '\n' + r.url;
      a.addEventListener('click', function (ev) {
        ev.preventDefault();
        chrome.tabs.create({ url: r.url, active: false });
      });
      item.appendChild(a);
    } else {
      var t = document.createElement('span');
      t.className = 't';
      t.textContent = r.titel || '(ohne Titel)';
      t.title = idHint + (r.titel || '');
      item.appendChild(t);
    }

    var p = document.createElement('span');
    p.className = 'preis' + (r.preis == null ? ' leer' : '') +
                  (bestPreis != null && r.preis === bestPreis && !istShop(r) ? ' best' : '');
    p.textContent = r.preis == null ? '–' : fmtPreis(r.preis, r.waehrung);
    item.appendChild(p);

    if (view === 'rows') {
      var w = document.createElement('span');
      if (r.warnungen) {
        w.className = 'w';
        w.textContent = r.warnungen;
        w.title = r.warnungen;
      } else {
        w.className = 'ok';
        w.textContent = 'ok';
      }
      item.appendChild(w);
    } else {
      var m = document.createElement('span');
      m.className = 'meta';
      // Belegt-Status zuerst: ein Preis ohne Identitaetsnachweis ist wertlos.
      if (istShop(r)) {
        m.textContent = 'Referenz – zählt nicht';
      } else if (r.match_bestaetigt) {
        m.className = r.match_bestaetigt === 'ja' ? 'ok' : 'w';
        m.textContent = (r.match_bestaetigt === 'ja' ? '✓ ' : '✗ ') + (r.match_grund || '');
      } else {
        m.textContent = 'Pos. ' + (r.position || '?') + (r.gesponsert ? ' · Anzeige' : '');
      }
      m.title = [r.match_grund, r.gesponsert ? 'gesponsert' : '',
                 'Position ' + (r.position || '?')].filter(Boolean).join('\n');
      item.appendChild(m);
    }

    var akt = document.createElement('span');
    akt.className = 'akt';
    item.appendChild(akt);

    if (view === 'rows') {
      // Analyse-Panel fuer einen aelteren Eintrag wieder oeffnen
      var re = document.createElement('button');
      re.className = 'ghost';
      re.textContent = '⌕';
      re.title = 'Analyse anzeigen';
      re.setAttribute('aria-label', 'Analyse anzeigen');
      re.addEventListener('click', function () {
        load().then(function (d) { renderAnalyse(r, d.eanMap); });
      });
      akt.appendChild(re);
    }

    if (view === 'matches' && r.url) {
      var grab = document.createElement('button');
      grab.className = 'ghost';
      grab.textContent = '↓';
      grab.title = 'Volles Listing erfassen';
      grab.setAttribute('aria-label', 'Volles Listing erfassen');
      grab.addEventListener('click', function () {
        grab.disabled = true;
        setStatus('Erfasse Listing...');
        sendMsg({ type: 'deepGrab', url: r.url }).then(function (resp) {
          grab.disabled = false;
          if (resp && resp.ok) setStatus('Erfasst: ' + resp.titel.slice(0, 45), 'ok');
          else setStatus('Fehler: ' + ((resp && resp.error) || 'unbekannt'), 'err');
          load().then(render);
        });
      });
      akt.appendChild(grab);
    }

    var del = document.createElement('button');
    del.className = 'ghost';
    del.textContent = '✕';
    del.title = 'Eintrag entfernen';
    del.setAttribute('aria-label', 'Eintrag entfernen');
    del.addEventListener('click', function () {
      load().then(function (d) {
        var arr = view === 'rows' ? d.rows : d.matches;
        var idx = arr.findIndex(function (x) { return istGleich(x, r); });
        if (idx > -1) arr.splice(idx, 1);
        return save(view, arr).then(function () { load().then(render); });
      });
    });
    akt.appendChild(del);

    list.appendChild(item);
  }

  /* Echte von falschen trennen - der Kern des Ganzen: bestaetigte Treffer (der
     nachgewiesene Artikel) stehen oben, darunter mit klarer Trennlinie die
     unbelegten Kandidaten. Fremdartikel (FREMD) sind schon in 'verworfen'
     ausgelagert und erscheinen nur als Schlusszeile. */
  function sektion(text) {
    var s = document.createElement('div');
    s.className = 'empty tail sektion';
    s.textContent = text;
    return s;
  }

  if (view === 'rows') {
    items.forEach(baueZeile);
  } else {
    var refRows  = items.filter(istShop);
    var echte    = items.filter(function (r) { return !istShop(r) && r.match_bestaetigt === 'ja'; });
    var unsicher = items.filter(function (r) { return !istShop(r) && r.match_bestaetigt !== 'ja'; });
    refRows.forEach(baueZeile);
    echte.forEach(baueZeile);
    if (unsicher.length) {
      list.appendChild(sektion(echte.length || refRows.length
        ? '— Unbestaetigt · Identitaet nicht belegt (' + unsicher.length + ') —'
        : 'Kein bestaetigter Treffer · ' + unsicher.length + ' unbelegte(r) Kandidat(en):'));
      unsicher.forEach(baueZeile);
    }
  }

  // Abschlusszeile: was aussortiert wurde, bleibt sichtbar - nur nicht dazwischen.
  if (verworfen.length) {
    var hinweis = document.createElement('div');
    hinweis.className = 'empty tail';
    hinweis.textContent = '+ ' + verworfen.length + ' verworfen (' +
      verworfen.slice(0, 3).map(function (v) {
        return (v.plattform || '?') + ': ' + (v.match_grund || 'anderer Artikel');
      }).join(' | ') + (verworfen.length > 3 ? ' ...' : '') + ') - vollstaendig im Excel-Export';
    list.appendChild(hinweis);
  }
}

// ------------------------------------------------------------------ Erfassen

function grabTab(tabId) {
  return chrome.scripting.executeScript({
    target: { tabId: tabId },
    files: ['shared/extract.js', 'collect.js']
  }).then(function (res) {
    return res && res[0] ? res[0].result : null;
  });
}

function addRows(newRows) {
  return sendMsg({ type: 'saveRows', rows: newRows }).then(function (resp) {
    // Ohne diese Pruefung meldet das Popup "Erfasst" in Gruen, obwohl der
    // Worker nie geantwortet oder {ok:false} gemeldet hat (Review 31.08.)
    if (!resp || !resp.ok) throw new Error((resp && resp.error) || 'Service Worker nicht erreichbar');
    return load().then(function (d) { render(d); return d; });
  });
}

/* Aktiver Shop-Tab - auch wenn das Popup als eigenes Fenster laeuft (?win=1):
   dann ist currentWindow das Popup selbst, also stattdessen den aktiven Tab
   des zuletzt benutzten normalen Fensters nehmen (lastAccessed, Fallback #1). */
var IST_FENSTER = new URLSearchParams(location.search).has('win');
function aktivTab(cb) {
  if (!IST_FENSTER) return chrome.tabs.query({ active: true, currentWindow: true }, cb);
  chrome.tabs.query({ active: true, windowType: 'normal' }, function (tabs) {
    tabs = (tabs || []).slice().sort(function (a, b) { return (b.lastAccessed || 0) - (a.lastAccessed || 0); });
    cb(tabs);
  });
}
if (IST_FENSTER) {
  document.body.classList.add('win');
  $('alsFenster').hidden = true;
} else {
  $('alsFenster').addEventListener('click', function () {
    // windows.create braucht keine zusaetzliche Permission (nur tabs-DETAILS taeten das)
    chrome.windows.create({ url: chrome.runtime.getURL('popup.html?win=1'), type: 'popup', width: 830, height: 720 });
    window.close();
  });
}

$('grab').addEventListener('click', function () {
  setStatus('Erfasse...');
  aktivTab(function (tabs) {
    var tab = tabs[0];
    if (!tab) return setStatus('Kein aktiver Tab.', 'err');
    grabTab(tab.id).then(function (row) {
      if (!row || !row.titel) return setStatus('Nichts gefunden - ist das eine Produktseite?', 'err');
      return addRows([row]).then(function (d) {
        switchView('rows');
        renderAnalyse(row, d.eanMap);
        setStatus('Erfasst: ' + row.titel.slice(0, 45), 'ok');
        // Auto-Preisvergleich auf den Fremdplattformen
        if (d.autoCompare && row.preis != null) startCompare(row, d.eanMap);
      });
    }).catch(function (e) {
      setStatus('Fehler: ' + e.message, 'err');
    });
  });
});

$('grabAll').addEventListener('click', function () {
  setStatus('Durchsuche Tabs...');
  chrome.tabs.query({}, function (tabs) {
    var targets = tabs.filter(function (t) {
      if (!t.url || !/^https?:/.test(t.url)) return false;
      try {
        return LC.detectPlatform(new URL(t.url).hostname).id !== 'generic';
      } catch (e) { return false; }
    });

    if (!targets.length) return setStatus('Keine passenden Tabs offen.', 'err');

    var done = 0, failed = 0, collected = [];
    var next = function (i) {
      if (i >= targets.length) {
        return addRows(collected).then(function () {
          switchView('rows');
          setStatus(done + ' erfasst' + (failed ? ', ' + failed + ' ohne Treffer' : ''),
                    done ? 'ok' : 'err');
        });
      }
      setStatus('Erfasse ' + (i + 1) + '/' + targets.length + '...');
      return grabTab(targets[i].id).then(function (row) {
        if (row && row.titel) { collected.push(row); done++; } else failed++;
      }).catch(function () { failed++; })
        .then(function () { return next(i + 1); });
    };
    next(0);
  });
});

// ------------------------------------------------------------------ Suche

$('search').addEventListener('click', function () {
  var q = $('query').value.trim();
  if (!q) return setStatus('Suchbegriff eingeben.', 'err');
  var plats = checkedPlats();
  if (!plats.length) return setStatus('Mindestens eine Plattform waehlen.', 'err');

  var qtype = LC.search.detectQueryType(q);
  auftrag({ type: 'batchSearch', query: q, qtype: qtype, platforms: plats },
          'Suche laeuft... (Popup darf zugehen, Ergebnisse werden gesammelt)');
  switchView('matches');
});

$('openTabs').addEventListener('click', function () {
  var q = $('query').value.trim();
  if (!q) return setStatus('Suchbegriff eingeben.', 'err');
  var qtype = LC.search.detectQueryType(q);
  checkedPlats().forEach(function (pid) {
    var url = LC.search.searchUrl(pid, q, qtype);
    if (url) chrome.tabs.create({ url: url, active: false });
  });
  setStatus('Such-Tabs geoeffnet.', 'ok');
});

$('autoCompare').addEventListener('change', function () {
  save('autoCompare', $('autoCompare').checked);
});

if ($('h10Enabled')) $('h10Enabled').addEventListener('change', function () {
  save('lcH10Enabled', $('h10Enabled').checked);
  // Kontoliste nur beim Einschalten neu holen (evtl. inzwischen eingeloggt) -
  // abgeschaltet braucht sie niemand, und jeder Abruf ist ein Netz-Request.
  if ($('h10Enabled').checked) h10KontenFuellen($('h10AccountId').value);
});
if ($('h10Platinum')) $('h10Platinum').addEventListener('change', function () {
  save('lcH10Platinum', $('h10Platinum').checked);
});

/* Kontoauswahl aus Helium selbst: /api/v1/customers/accounts ist der einzige
   Endpunkt, der die Konten AUFLISTET - check-login kennt nur das aktive und
   meldet immer das Standard-Konto. Erspart das Abtippen einer Nummer (LO
   01.09.). Ein gespeichertes Konto bleibt waehlbar, auch wenn der Abruf
   scheitert - sonst wuerde ein Netzfehler die Einstellung verlieren. */
function h10KontenFuellen(gewaehlt) {
  var sel = $('h10AccountId');
  if (!sel) return;
  var setzen = function (liste, hinweis) {
    sel.textContent = '';
    var o = document.createElement('option');
    o.value = ''; o.textContent = hinweis || 'Standard-Konto von Helium';
    sel.appendChild(o);
    liste.forEach(function (k) {
      var e = document.createElement('option');
      e.value = k.id;
      e.textContent = k.name + ' (' + k.id + ')' + (k.standard ? ' · Standard' : '');
      sel.appendChild(e);
    });
    if (gewaehlt && !liste.some(function (k) { return k.id === gewaehlt; })) {
      var g = document.createElement('option');
      g.value = gewaehlt; g.textContent = 'Konto ' + gewaehlt;
      sel.appendChild(g);
    }
    sel.value = gewaehlt || '';
  };
  setzen([], 'Standard-Konto von Helium');
  if (!LC.h10 || !LC.h10.kontoListe) return;
  LC.h10.kontoListe()
    .then(function (liste) { setzen(liste); })
    .catch(function () { setzen([], 'Standard-Konto (Konten nicht abrufbar)'); });
}

/* Mehrfach-Konten bei Helium 10: check-login meldet das serverseitig aktive
   Konto. Wird im H10-Web auf ein Premium-Konto umgeschaltet, zieht die
   Session in unseren Aufrufen nicht immer mit. Das hier gewaehlte Konto
   erzwingt es fuer alle Aufrufe ausser /black-box/. */
if ($('h10AccountId')) $('h10AccountId').addEventListener('change', function () {
  var v = $('h10AccountId').value.trim();
  save('lcH10AccountId', v).then(function () {
    // Gemerkte Session + Token verwerfen, sonst gilt das alte Konto weiter.
    if (LC.h10 && LC.h10.vergissSession) LC.h10.vergissSession();
    setStatus(v ? 'Helium-10-Konto ' + v + ' erzwungen. Amazon-Tabs neu laden.'
                : 'Helium-10-Konto wieder automatisch. Amazon-Tabs neu laden.', 'ok');
  });
});

/* Zeigt roh, welches Konto und welcher Plan wirklich ankommen - damit sich
   ein Multi-Konto-Problem am Arbeitsplatz in fuenf Sekunden einordnen laesst,
   statt es zu raten. Kostet keine Kontingente: check-login, subscription und
   der Token-Abruf sind zaehlerfrei. */
if ($('h10Diag')) $('h10Diag').addEventListener('click', function () {
  var out = $('h10DiagOut');
  out.style.display = 'block';
  out.textContent = 'frage Helium 10 …';
  if (!LC.h10) { out.textContent = 'shared/h10.js nicht geladen.'; return; }

  var wunsch = $('h10AccountId').value.trim();
  LC.h10.checkLogin().then(function (r) {
    var c = (r && r.data) || {};
    var zeilen = [
      'check-login          HTTP ' + (r && r.status),
      '  eingeloggt         ' + (c.logged === undefined ? '(kein Feld)' : c.logged),
      '  gemeldetes Konto   ' + (c.accountId == null ? '(keins)' : c.accountId),
      '  Plan               ' + (c.plan || '(keiner)') + (c.planLabel ? ' / ' + c.planLabel : ''),
      '  Module             ' + (c.modules ? Object.keys(c.modules).join(', ') : '(keine)')
    ];
    /* Alles, was nach weiteren Konten aussieht, ungefiltert mit ausgeben - der
       Feldname dafuer ist nicht dokumentiert und darf nicht geraten werden. */
    Object.keys(c).forEach(function (k) {
      if (/account|member|team|sub|switch/i.test(k) && k !== 'accountId') {
        zeilen.push('  ' + k.padEnd(19) + JSON.stringify(c[k]).slice(0, 200));
      }
    });
    var konto = wunsch || c.accountId;
    zeilen.push('', 'benutzt wird         ' + (konto == null ? '(keins)' : konto) +
                (wunsch ? '   <- von Hand erzwungen' : ''));
    out.textContent = zeilen.join('\n');

    return LC.h10.subscription().then(function (s) {
      var plan = s && s.data && s.data.data && s.data.data.subscription && s.data.data.subscription.plan;
      zeilen.push('', 'subscription         HTTP ' + (s && s.status),
                      '  Plan laut Konto    ' + (plan ? (plan.title || plan.key) : '(keiner)'));
      out.textContent = zeilen.join('\n');
      if (konto == null) return null;
      return LC.h10.siteToken(konto);
    }).then(function (t) {
      if (!t) return null;
      var d = t.data && t.data.data;
      zeilen.push('', 'site/token           HTTP ' + t.status,
                      '  Token erhalten     ' + (d && d.token ? 'ja' : 'NEIN'),
                      '  Konto laut Token   ' + (d && d.account ? JSON.stringify(d.account).slice(0, 200) : '(kein Feld)'),
                      '  Besitzer           ' + (d ? d.isAccountOwner : '?'));
      out.textContent = zeilen.join('\n');
      /* Berechtigungsliste (Pacvue): pro Feature hasAccess / usesLeft. Das ist
         die Liste, nach der die echte H10-Erweiterung Widgets zeigt oder
         versteckt - damit ist morgen in fuenf Sekunden klar, ob ein Fehler
         am Konto-Recht liegt oder am Code (LO 02.09.). */
      var kontoFuerFeatures = konto;
      var featuresP = (LC.h10.features && kontoFuerFeatures != null)
        ? LC.h10.features(kontoFuerFeatures).then(function (f) {
            zeilen.push('', 'Berechtigungen (Pacvue)  HTTP ' + f.status + (f.plan ? '   Plan ' + (f.plan.title || f.plan.key) : ''));
            var namen = Object.keys(f.features || {}).sort();
            if (!namen.length) zeilen.push('  (keine Liste erhalten)');
            namen.forEach(function (n) {
              var x = f.features[n] || {};
              var kont = x.usesLimit == null ? 'unbegrenzt' : (x.usesLeft + '/' + x.usesLimit);
              zeilen.push('  ' + (x.hasAccess ? '✓' : '✗') + ' ' + n.padEnd(30) + kont + (x.hasFullAccess ? '  (voll)' : ''));
            });
            out.textContent = zeilen.join('\n');
          }).catch(function (e) {
            zeilen.push('', 'Berechtigungen (Pacvue): Fehler ' + ((e && e.message) || e));
            out.textContent = zeilen.join('\n');
          })
        : Promise.resolve();

      if (!wunsch) {
        return featuresP.then(function () {
          zeilen.push('', 'Fuer den Kontowechsel-Test eine Konto-Nummer ins Feld eintragen.');
          out.textContent = zeilen.join('\n');
          return null;
        });
      }
      /* Kontowechsel-Test: nimmt der Server die Nummer als Parameter an? Die
         echte H10-Erweiterung sieht den Wechsel, wir nicht - also fragt sie
         nicht "wer bin ich", sondern schickt das Konto mit. Beide Endpunkte,
         die im Code nachweislich eine Nummer entgegennehmen, hier gegen die
         gewuenschte Nummer geprueft (kostet keine Kontingente). */
      zeilen.push('', '--- Kontowechsel-Test auf ' + wunsch + ' ---');
      out.textContent = zeilen.join('\n');
      return LC.h10.fetchJson(LC.h10.MEMBERS + '/extension/check-login' +
                              LC.h10.qs({ accountId: wunsch })).then(function (r2) {
        var c2 = (r2 && r2.data) || {};
        zeilen.push('check-login?accountId  HTTP ' + (r2 && r2.status),
                    '  meldet jetzt Konto   ' + (c2.accountId == null ? '(keins)' : c2.accountId) +
                      (String(c2.accountId) === String(wunsch) ? '   <<< GREIFT' : '   (unveraendert)'),
                    '  Plan                 ' + (c2.plan || '(keiner)'),
                    '  Module               ' + (c2.modules ? Object.keys(c2.modules).join(', ') : '(keine)'));
        out.textContent = zeilen.join('\n');
        return LC.h10.bsrWidget('B00UZA3HEG', 'amazon.de', wunsch);
      }).then(function (b) {
        var bd = b && b.data;
        zeilen.push('', 'bsr-widget (accountId im Rumpf)  HTTP ' + (b && b.status),
                    '  Antwort              ' + (bd ? JSON.stringify(bd).slice(0, 160) : '(leer)'));
        out.textContent = zeilen.join('\n');
        /* Premium-Routen, die auf Free 403/402 geben - fuer den Check am
           Premium-Konto (LO 03.09.): sales-chart (Sales-Widget der echten
           Erweiterung) und cpc-history. Kostet auf Free nichts, weil abgelehnt. */
        return LC.h10.salesChart ? LC.h10.salesChart('B00UZA3HEG', 'amazon.de', 30, wunsch) : null;
      }).then(function (sc) {
        if (sc) {
          var sd = sc.data;
          zeilen.push('', 'sales-chart (Sales-Widget-Route)  HTTP ' + sc.status,
                      '  Antwort              ' + (sd ? JSON.stringify(sd).slice(0, 220) : '(leer)'));
          out.textContent = zeilen.join('\n');
        }
        /* cpc-history in ZWEI Parameter-Varianten (LO 02.09.: "cpc war
           irgendwas mit id, ein falscher Call"): unsere bisherige mit
           marketplaceId=<kleine H10-Nummer> und die Schreibweise des Helium-
           Moduls mit marketplace=<Amazon-ID>. Welche 200 gibt, entscheidet. */
        if (!LC.h10.bearerFor || !LC.h10.fetchJson) return null;
        return LC.h10.bearerFor(wunsch).then(function (tok) {
          var kopf = { auth: 'bearer', headers: { 'Authorization': 'Bearer ' + tok } };
          var basis = LC.h10.RESEARCH + '/api/v1/amazon/cpc-history';
          return Promise.all([
            LC.h10.fetchJson(basis + LC.h10.qs({ keyword: 'gartenliege', marketplaceId: 4 }), kopf),
            LC.h10.fetchJson(basis + LC.h10.qs({ keyword: 'gartenliege', marketplace: 'A1PA6795UKMFR9' }), kopf),
            LC.h10.fetchJson(basis + LC.h10.qs({ keywords: ['gartenliege'], marketplace: 'A1PA6795UKMFR9' }), kopf)
          ]);
        }).catch(function (e) { return [{ status: 0, data: String(e && e.message || e) }]; });
      }).then(function (cps) {
        if (cps) {
          var namen = ['keyword + marketplaceId=4 (bisher)', 'keyword + marketplace=A1PA…', 'keywords[] + marketplace'];
          zeilen.push('', 'cpc-history (research-tools) – 3 Varianten:');
          cps.forEach(function (cp, i) {
            zeilen.push('  ' + namen[i] + '  HTTP ' + cp.status,
                        '     ' + (cp.data ? JSON.stringify(cp.data).slice(0, 160) : '(leer)'));
          });
          out.textContent = zeilen.join('\n');
        }
        return LC.h10.keywordPhrasesData ? LC.h10.keywordPhrasesData(wunsch, ['gartenliege', 'liegestuhl klappbar'], 'amazon.de') : null;
      }).then(function (kp) {
        if (kp) {
          var kd = kp.data;
          zeilen.push('', 'keywords/phrases/data (Batch SV+CPC)  HTTP ' + kp.status,
                      '  Antwort              ' + (kd ? JSON.stringify(kd).slice(0, 400) : '(leer)'));
          out.textContent = zeilen.join('\n');
        }
      });
    });
  }).catch(function (e) {
    out.textContent = 'Fehler: ' + ((e && e.message) || e) +
      '\n\nIst helium10.com in diesem Browser eingeloggt?';
  });
});
$('noCookies').addEventListener('change', function () {
  save('lcNoCookies', $('noCookies').checked);
});
$('autoLearn').addEventListener('change', function () {
  save('lcAutoLearn', $('autoLearn').checked);
});
/* Auto-Research haengt an der Ordner-Sicherung (LO 01.09.): ohne Ordner landen
   die stuendlich gesammelten Reihen nur im Browserprofil und sind beim
   naechsten Rechner weg - dafuer lohnen 40 Abrufe pro Stunde nicht. Der
   Schalter bleibt sichtbar, aber gesperrt, damit klar ist WARUM. */
function autoResearchKopplung() {
  chrome.storage.local.get('lcAutoBackup', function (d) {
    var an = !!(d && d.lcAutoBackup);
    var chk = $('autoResearch'), hint = $('autoResearchHinweis');
    if (!chk) return;
    chk.disabled = !an;
    if (hint) hint.hidden = an;
    if (!an && chk.checked) chk.checked = false;   // Anzeige ehrlich halten
  });
}
autoResearchKopplung();
chrome.storage.onChanged.addListener(function (ch, area) {
  if (area === 'local' && ch.lcAutoBackup) autoResearchKopplung();
});

$('autoResearch').addEventListener('change', function () {
  save('lcAutoResearch', $('autoResearch').checked);
});

// ------------------------------------------------------------------ Dark-Mode-Regler
/* Nur Anzeige und Speichern. Die Werte liegen in chrome.storage.local; dark.js
   auf amazon.de hoert darauf und rechnet die Palette live um - deshalb sieht
   man die Aenderung sofort im offenen Tab, ohne Reload. */
(function darkRegler() {
  var DK_STD = { lcDunkel: 50, lcSpreiz: 50, lcKontrast: 50, lcBild: 100, lcBildK: 100, lcBildS: 100,
    lcFreist: true, lcFsStaerke: 228, lcFsKante: 38, lcFont: '' };
  var DK_SLD = { dkDunkel: 'lcDunkel', dkSpreiz: 'lcSpreiz', dkKontrast: 'lcKontrast', dkBild: 'lcBild',
    dkBildK: 'lcBildK', dkBildS: 'lcBildS', dkFsStaerke: 'lcFsStaerke', dkFsKante: 'lcFsKante' };
  // Flood-Fill-Schwellen sind Helligkeitswerte (0-255), keine Prozente
  var DK_ROH = { dkFsStaerke: 1, dkFsKante: 1 };

  var zeigen = function (id) { $(id + 'V').textContent = $(id).value + (DK_ROH[id] ? '' : '%'); };
  var fuellen = function (d) {
    Object.keys(DK_SLD).forEach(function (id) {
      var k = DK_SLD[id];
      $(id).value = d[k] != null ? d[k] : DK_STD[k];
      zeigen(id);
    });
    $('dkFreist').checked = d.lcFreist !== false;
    $('dkFont').value = d.lcFont || '';
  };

  chrome.storage.local.get(Object.keys(DK_STD), fuellen);

  Object.keys(DK_SLD).forEach(function (id) {
    $(id).addEventListener('input', function () { zeigen(id); save(DK_SLD[id], +$(id).value); });
  });
  $('dkFreist').addEventListener('change', function () { save('lcFreist', $('dkFreist').checked); });
  $('dkFont').addEventListener('input', function () { save('lcFont', $('dkFont').value.trim()); });
  $('dkReset').addEventListener('click', function () {
    chrome.storage.local.set(DK_STD, function () { fuellen(DK_STD); });
  });
})();

// ------------------------------------------------------------------ Keywords / Buybox

$('kwRun').addEventListener('click', function () {
  var seed = $('kwSeed').value.trim() || $('query').value.trim();
  if (!seed) return setStatus('Seed eingeben (oder oben einen Suchbegriff).', 'err');

  /* Kaufland laeuft ueber seine echte Suchbox; die API blockiert direkte
     fetch()-Aufrufe. bol bleibt ohne belastbare Quelle aus der Keyword-Ernte. */
  var kannKeywords = function (p) { return p === 'kaufland' || LC.api.hasSuggest(p); };
  var plats = checkedPlats().filter(kannKeywords);
  if (!plats.length) {
    plats = LC.PLATFORMS.filter(function (p) { return kannKeywords(p.id); })
                        .map(function (p) { return p.id; });
  }

  auftrag({ type: 'keywords', seeds: [seed], platforms: plats, tief: $('kwDeep').checked },
          'Keyword-Ernte laeuft (' + plats.join(', ') + ')... Popup darf zugehen.');
  switchView('keywords');
});

/* Der Knopf "Guenstigere Preise finden" ist aus der Keyword-Sektion entfernt
   (LO 01.09.: "buybox aus keyword dropdown raus, ancient remnant"). Der
   Handler bleibt geguarded stehen - die Buybox-Sammelpruefung selbst laeuft
   weiter ueber den Reiter Buybox. */
if ($('proRun')) $('proRun').addEventListener('click', function () {
  /* Ein Klick vom Listing aus: ASIN kommt aus dem aktiven Tab, damit man nicht
     erst irgendwo eine ASIN abtippen muss. Fallbacks: Suchfeld, dann alle
     bereits erfassten Amazon-Listings. */
  aktivTab(function (tabs) {
    var tab = tabs[0], asins = [];
    var m = tab && tab.url && tab.url.match(/amazon\.[a-z.]+\/(?:.*\/)?(?:dp|gp\/product)\/([A-Z0-9]{10})/i);
    if (m) asins.push(m[1].toUpperCase());

    var q = $('query').value.trim().toUpperCase();
    if (!asins.length && /^B0[A-Z0-9]{8}$/.test(q)) asins.push(q);

    load().then(function (d) {
      /* Kein Sammel-Fallback ueber rows mehr: der zog JEDES jemals erfasste
         Amazon-Listing wieder in die Pruefung - so wurde die laengst
         aussortierte Gartenliege bei jedem Klick auf "Buybox" erneut
         durchsucht. Ohne aktives Amazon-Tab und ohne ASIN im Feld ist eine
         ehrliche Absage richtig. */
      if (!asins.length) {
        return setStatus('Keine ASIN - oeffne ein Amazon-Listing oder gib oben eine ASIN ein.', 'err');
      }
      // Nur die angehakten Plattformen (Temu ist standardmaessig aus - Captcha-Wand).
      var vplats = checkedPlats().filter(function (p) { return p !== 'amazon' && p !== 'deubaxxl'; });
      /* Leere Liste hiesse im Worker "alle Plattformen" - dann laufen eBay/
         Kaufland/Otto ueberraschend los. Ehrliche Absage stattdessen. */
      if (!vplats.length) return setStatus('Mindestens eine Vergleichsplattform (eBay, Kaufland, Otto ...) anhaken.', 'err');
      auftrag({ type: 'proCheck', asins: asins, platforms: vplats },
              'Suche guenstigere Angebote fuer ' + asins.join(', ') + '... Popup darf zugehen.');
      switchView('pro');
    });
  });
});

/* Fortschritt der Hintergrund-Jobs live anzeigen. */
chrome.storage.onChanged.addListener(function (changes, area) {
  if (area !== 'local') return;
  if (changes.searchStatus) {
    var s = changes.searchStatus.newValue || {};
    if (s.running) {
      setStatus(((s.done || 0) + 1) + '/' + (s.total || '?') + ': ' + (s.current || '...'));
    } else if (s.result) {
      setStatus(s.result, s.ok ? 'ok' : 'err');
    }
  }
if (changes.rows || changes.matches || changes.keywords || changes.keywordEvidence ||
      changes.keywordRuns || changes.keywordSerpMeasurements || changes.keywordApiEvidence || changes.pro) load().then(render);
  if (changes.log) renderLog(changes.log.newValue || []);
});
chrome.runtime.onMessage.addListener(function (msg) {
  if (!msg || msg.type !== 'lcDiskChanged') return;
  var ks = msg.keys || [];
  if (ks.some(function (k) { return /^keyword(Evidence|Runs|SerpMeasurements|ApiEvidence)$/.test(k); })) load().then(render);
});

// ------------------------------------------------------------------ Protokoll

/* Zeigt, WOMIT gesucht wurde und woran eine Stufe gescheitert ist. Ohne das
   bleibt bei "keine Treffer" nur Raten - genau der Zustand, aus dem heraus
   nicht erkennbar war, dass auf Kaufland ueberhaupt nur die EAN probiert wird. */
function renderLog(zeilen) {
  var pre = $('log');
  if (!pre) return;
  pre.textContent = '';
  zeilen.forEach(function (z) {
    var span = document.createElement('span');
    // Nur die entscheidenden Zeilen bekommen Farbe: Abbruch und Abschnittsstart.
    if (/AUFGEGEBEN|ABBRUCH|verworfen/.test(z)) span.className = 'stop';
    else if (/^\S+\s+===/.test(z)) span.className = 'head';
    span.textContent = z + '\n';
    pre.appendChild(span);
  });
  $('logCount').textContent = zeilen.length ? 'Protokoll (' + zeilen.length + ')' : 'Protokoll';
  // Ans Ende scrollen - der letzte Schritt ist der interessante.
  if ($('logbox').open) pre.scrollTop = pre.scrollHeight;
}

$('logCopy').addEventListener('click', function (ev) {
  // Nicht das <details> mit auf-/zuklappen.
  ev.preventDefault();
  ev.stopPropagation();
  navigator.clipboard.writeText($('log').textContent || '').then(function () {
    setStatus('Protokoll kopiert.', 'ok');
  });
});

chrome.storage.local.get('log', function (d) { renderLog(d.log || []); });

// ------------------------------------------------------------------ Export / Leeren

/* Ohne "downloads"-Berechtigung (IT-Vorgabe: so wenig Rechte wie moeglich):
   ein <a download> im Popup reicht, Chrome wie Firefox legen die Datei in den
   Standard-Download-Ordner. */
function dateiSpeichern(blob, name) {
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url; a.download = name; a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  setTimeout(function () { a.remove(); URL.revokeObjectURL(url); }, 60000);
}

$('export').addEventListener('click', function () {
  load().then(function (d) {
    if (!d.rows.length && !d.matches.length && !d.keywords.length && !d.pro.length) return;

    /* Kompakt: OHNE die Rohbeleg-Blaetter (Keyword-Belege, API-Belege mit
       Rohantworten, Laeufe, Marktdaten) - die machten die Datei um ein
       Vielfaches groesser als noetig. Wer die Belege braucht: Reiter
       "Keywords" -> "exportieren" liefert sie weiterhin komplett. */
    xlsxExport(LC.defaultFilename(), function (XLSX) {
      return LC.buildWorkbook(XLSX, d.rows, d.matches, {
        keywords: d.keywords, keywordEvidence: [], keywordRuns: [],
        keywordSerpMeasurements: [], keywordApiEvidence: [], pro: d.pro
      });
    }, function () {
      setStatus([
        d.rows.length + ' Listings',
        d.matches.length + ' Treffer',
        d.keywords.length ? d.keywords.length + ' Keywords' : '',
        d.pro.length ? d.pro.length + ' Buybox' : ''
      ].filter(Boolean).join(' + ') + ' exportiert (kompakt, ohne Rohbelege).', 'ok');
    });
  });
});

/* Der eigentliche Arbeitsablauf: Keywords + eigenes Listing + Competitor-Listing
   als EINE lesbare Datei an ChatGPT geben. Unrelevantes vorher im Popup
   loeschen - exportiert wird, was gerade in den Reitern steht. */
$('exportMd').addEventListener('click', function () {
  load().then(function (d) {
    if (!d.rows.length && !d.matches.length && !d.keywords.length && !d.pro.length) {
      return setStatus('Nichts zu exportieren.', 'err');
    }
    var md = LC.buildMarkdown(d);
    dateiSpeichern(new Blob([md], { type: 'text/markdown;charset=utf-8' }),
      LC.defaultFilename().replace(/\.xlsx$/i, '.md'));
    setStatus('Markdown fuer ChatGPT gespeichert (' + Math.round(md.length / 1000) + ' k Zeichen).', 'ok');
  });
});

/* Firefox behandelt host_permissions in MV3 als optional - ohne Freigabe kann
   kein Shop-Tab gelesen werden. Chrome erteilt sie bei der Installation; dort
   bleibt der Knopf unsichtbar. */
(function pruefeHostRechte() {
  var origins = (chrome.runtime.getManifest().host_permissions || []);
  var btn = $('permBtn');
  if (!chrome.permissions || !origins.length || !btn) return;
  chrome.permissions.contains({ origins: origins }, function (ok) {
    void chrome.runtime.lastError;
    btn.hidden = !!ok;
  });
  btn.addEventListener('click', function () {
    chrome.permissions.request({ origins: origins }, function (granted) {
      void chrome.runtime.lastError;
      btn.hidden = !!granted;
      setStatus(granted ? 'Zugriff auf die Shop-Seiten erteilt.'
        : 'Zugriff nicht erteilt - Erfassen und Suchen funktionieren dann nicht.', granted ? 'ok' : 'err');
    });
  });
})();

/* ------------------------------------------------------------ Import

   Einen frueheren Export zurueckladen. LC.parseWorkbook dreht die Feld-Labels
   wieder zu keys zurueck; danach wird ZUSAMMENGEFUEHRT statt ersetzt: ein
   alter Export + neue Laeufe = kombinierte Historie. Genau das macht die .xlsx
   zum dauerhaften Speicher, der ein Storage-Clearing ueberlebt. Keywords werden
   aus den zusammengefuehrten Belegen NEU aggregiert (sonst zaehlt man doppelt).
   Welche Reiter ein Import beruehrt, sagt entweder der globale Knopf (alle) oder
   der Reiter-Knopf (nur dieser). Den Rest erkennt der Import an den Blaettern
   in der Datei - der Dateiname-Suffix (-keywords, -rows, ...) fuehrt einen also
   von selbst zum richtigen Datentopf. */
var IMPORT_ZIELE = {
  rows:     ['rows'],
  matches:  ['matches'],
  keywords: ['keywords', 'keywordEvidence', 'keywordRuns', 'keywordSerpMeasurements', 'keywordApiEvidence'],
  pro:      ['pro']
};

function importSchluessel(o, ziel) {
  if (ziel === 'rows')    return o.produkt_id || o.url || ((o.plattform || '') + '|' + (o.titel || ''));
  if (ziel === 'matches') return o.url || ((o.plattform || '') + '|' + (o.titel || '') + '|' + o.preis);
  if (ziel === 'pro')     return (o.asin || '') + '|' + (o.geprueft_am || '');
  return JSON.stringify(o); // Belege/Laeufe/Keywords: exakte Zeile deduplizieren
}

function importMische(alt, neu, ziel) {
  var seen = Object.create(null), out = [];
  // Neue zuerst -> bei Dubletten gewinnt der frischere Wert.
  (neu || []).concat(alt || []).forEach(function (o) {
    var k = importSchluessel(o, ziel);
    if (seen[k]) return;
    seen[k] = 1; out.push(o);
  });
  return out;
}

function importieren(nurZiele) {
  var input = $('importFile');
  input.value = '';
  input.onchange = function () {
    var file = input.files && input.files[0];
    if (!file) return;
    setStatus('Lese ' + file.name + ' ...');
    file.arrayBuffer().then(function (buf) {
      return ladeXlsx().then(function (XLSX) {
        var wb = XLSX.read(new Uint8Array(buf), { type: 'array', cellDates: true });
        return LC.parseWorkbook(XLSX, wb);
      });
    }).then(function (parsed) {
      return load().then(function (d) {
        var erlaubt = nurZiele ||
          ['rows', 'matches', 'pro', 'keywords', 'keywordEvidence', 'keywordRuns', 'keywordSerpMeasurements', 'keywordApiEvidence'];
        var geaendert = {};
        ['rows', 'matches', 'pro', 'keywordEvidence', 'keywordRuns', 'keywordSerpMeasurements', 'keywordApiEvidence'].forEach(function (k) {
          if (erlaubt.indexOf(k) === -1 || !parsed[k]) return;
          d[k] = importMische(d[k], parsed[k], k);
          geaendert[k] = d[k].length;
        });
        var belegeDa = geaendert.keywordEvidence || geaendert.keywordRuns || geaendert.keywordSerpMeasurements;
        if (erlaubt.indexOf('keywords') > -1) {
          if (belegeDa) {
            d.keywords = LC.api.aggregateEvidence(d.keywordEvidence || [], d.keywordRuns || [], d.keywordSerpMeasurements || []);
            geaendert.keywords = d.keywords.length;
          } else if (parsed.keywords) {
            d.keywords = importMische(d.keywords, parsed.keywords, 'keywords');
            geaendert.keywords = d.keywords.length;
          }
        }
        var keys = Object.keys(geaendert);
        if (!keys.length) { setStatus('Nichts Passendes in "' + file.name + '" gefunden.', 'err'); return; }
        // EIN set() fuer alle Reiter: Promise.all einzelner save() war keine
        // Transaktion - Popup zu dazwischen = Keywords ohne ihre Belege.
        var patch = {};
        keys.forEach(function (k) { patch[k] = d[k]; });
        return saveViele(patch).then(function () {
          load().then(render);
          setStatus('Importiert aus ' + file.name + ': ' +
            keys.map(function (k) { return d[k].length + ' ' + k; }).join(', '), 'ok');
        });
      });
    }).catch(function (e) {
      setStatus('Import-Fehler: ' + ((e && e.message) || e), 'err');
    });
  };
  input.click();
}

$('import').addEventListener('click', function () { importieren(null); });
$('viewImport').addEventListener('click', function () { importieren(IMPORT_ZIELE[view] || null); });

/* ---------------------------------------------------------- Reiter einzeln

   Alles-oder-nichts war zu grob: wer die Keyword-Ernte behalten, aber die
   Treffer eines missglueckten Laufs loswerden will, musste bisher alles
   wegwerfen und neu erfassen. Diese beiden Knoepfe wirken deshalb nur auf den
   gerade sichtbaren Reiter - die Fusszeile bleibt fuer alles zusammen. */
var VIEW_INFO = {
  rows:     { key: 'rows',     label: 'Listings' },
  matches:  { key: 'matches',  label: 'Suchtreffer' },
  keywords: { key: 'keywords', label: 'Keywords' },
  pro:      { key: 'pro',      label: 'Buybox' }
};

/* Zerfall auf der SEITE auslösen, nicht im Popup: ein Popup ist ein eigenes
   kleines Fenster, jede Animation darin endet an dessen Kante. Über
   chrome.scripting laeuft sie als Overlay im aktiven Tab und kann sich ueber
   die ganze Seite verwehen.
   Schlaegt es fehl (interne Seite wie chrome://, kein Tab, keine Freigabe),
   wird trotzdem geleert - die Animation ist Beiwerk, nicht Bedingung. */
/* Die sichtbaren Zeilen im Popup mitzerfallen lassen - gestaffelt von oben
   nach unten, damit es eine Welle wird und kein gemeinsames Blinken. */
function zeilenZerfallen() {
  var zeilen = $('list').querySelectorAll('.item');
  for (var i = 0; i < zeilen.length; i++) {
    zeilen[i].style.setProperty('--i', i);
    zeilen[i].classList.add('dust');
  }
}

function zerfallAufSeite() {
  /* Die ECHTEN Zeilentexte mitgeben, nicht nur eine Anzahl: der Zerfall
     zerlegt den Inhalt selbst in Pixel, deshalb behält die Wolke am Anfang
     die Form der Liste. Mit Platzhaltern sähe es aus wie Konfetti. */
  var texte = [];
  var zeilen = $('list').querySelectorAll('.item');
  for (var i = 0; i < zeilen.length && texte.length < 26; i++) {
    var t = (zeilen[i].textContent || '').replace(/\s+/g, ' ').trim();
    if (t) texte.push(t);
  }
  if (!texte.length) texte = ['keine Eintraege'];

  return new Promise(function (fertig) {
    aktivTab(function (tabs) {
      var tab = tabs && tabs[0];
      if (!tab || !tab.id || /^(chrome|edge|about|devtools|view-source):/i.test(tab.url || '')) {
        return fertig();
      }
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['dust.js']
      }, function () {
        if (chrome.runtime.lastError) return fertig();
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: function (zz, uu) { deubaDustEffect(zz, uu); },
          // Startfeld dort, wo das Popup sitzt - oben rechts unter der Leiste.
          args: [texte, { x: 0.66, y: 0.09 }]
        }, function () { void chrome.runtime.lastError; fertig(); });
      });
    });
  });
}

/* Excel bauen und speichern - EIN Pfad fuer alle Export-Knoepfe. Die Arbeit
   startet per setTimeout(0) im NAECHSTEN Task: erst so wird "Baue Excel-
   Datei..." ueberhaupt gemalt, ein .then() liefe als Microtask noch vor dem
   Paint und die Meldung erschien nie. bauen(XLSX) liefert das Workbook. */
function xlsxExport(name, bauen, fertig) {
  setStatus('Baue Excel-Datei...');
  setTimeout(function () {
    ladeXlsx().then(function (XLSX) {
      var buf = XLSX.write(bauen(XLSX), { bookType: 'xlsx', type: 'array', cellDates: true });
      dateiSpeichern(new Blob([buf], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      }), name);
      fertig();
    }).catch(function (e) { setStatus('Export fehlgeschlagen: ' + ((e && e.message) || e), 'err'); });
  }, 0);
}

$('viewExport').addEventListener('click', function () {
  var info = VIEW_INFO[view];
  load().then(function (d) {
    var daten = d[info.key] || [];
    if (!daten.length) return setStatus('Nichts zu exportieren in "' + info.label + '".', 'err');

    var name = LC.defaultFilename().replace(/\.xlsx$/i, '') + '-' + info.key + '.xlsx';
    // Nur den sichtbaren Reiter befuellen, die anderen bleiben leer -
    // buildWorkbook laesst leere Blaetter weg.
    xlsxExport(name, function (XLSX) {
      return LC.buildWorkbook(XLSX,
        view === 'rows' ? daten : [],
        view === 'matches' ? daten : [],
        {
          keywords: view === 'keywords' ? daten : [],
          keywordEvidence: view === 'keywords' ? d.keywordEvidence : [],
          keywordRuns: view === 'keywords' ? d.keywordRuns : [],
          keywordSerpMeasurements: view === 'keywords' ? d.keywordSerpMeasurements : [],
          keywordApiEvidence: view === 'keywords' ? d.keywordApiEvidence : [],
          pro: view === 'pro' ? daten : []
        });
    }, function () {
      setStatus(daten.length + ' ' + info.label + ' exportiert.', 'ok');
    });
  });
});

$('viewClear').addEventListener('click', function () {
  var info = VIEW_INFO[view];
  load().then(function (d) {
    var n = (d[info.key] || []).length;
    if (!n) return setStatus('"' + info.label + '" ist bereits leer.');

    zerfallAufSeite();
    // Im Popup zerfallen die Zeilen mit - dort endet es an der Fensterkante,
    // auf der Seite laeuft es weiter. Geloescht wird erst danach, sonst
    // reisst das Neuzeichnen die Animation weg.
    zeilenZerfallen();
    return new Promise(function (weiter) { setTimeout(weiter, 620); })
      .then(function () {
        // Alle Schluessel des Reiters in EINEM set() (dieselbe Liste wie beim
        // Reiter-Import) - fuenf einzelne save() waren keine Transaktion.
        var patch = {};
        IMPORT_ZIELE[view].forEach(function (k) { patch[k] = []; });
        return saveViele(patch);
      })
      .then(function () {
        if (view === 'rows') $('analyse').hidden = true;
        load().then(render);
        setStatus(n + ' Eintrag/Eintraege aus "' + info.label + '" geleert.', 'ok');
      })
      .catch(function (e) { setStatus('Leeren fehlgeschlagen: ' + e.message, 'err'); });
  });
});

$('clear').addEventListener('click', function () {
  /* Harte Rueckfrage: dieser Knopf loescht ALLES (Listings, Treffer, Keywords,
     Buybox) auf einmal. Weil die Daten nur lokal liegen und rumgereicht werden,
     ist ein versehentlicher Klick teuer - also Zwei-Klick-Bestaetigung
     (confirm() geht im Popup nicht) und an den Export erinnern. */
  bestaetigen($('clear'), 'ALLES loeschen: Listings, Treffer, Keywords, Buybox – nur per vorherigem Export zurueckholbar', function () {
    /* Auch den Statustext zuruecksetzen: der stand in chrome.storage und
       tauchte beim naechsten Oeffnen wieder auf - so las man das Ergebnis eines
       laengst vergessenen Laufs als aktuellen Stand. Das EAN-Mapping bleibt
       bewusst erhalten, es ist muehsam erarbeitetes Wissen und wird nie falsch. */
    setStatus('Loesche alles...');
    zerfallAufSeite();
    zeilenZerfallen();
    new Promise(function (weiter) { setTimeout(weiter, 620); }).then(function () {
      // Neun Keys in EINEM set() - einzelne save() waren keine Transaktion.
      return saveViele({
        rows: [], matches: [], keywords: [], keywordEvidence: [], keywordRuns: [],
        keywordSerpMeasurements: [], keywordApiEvidence: [], pro: [], searchStatus: null
      });
    }).then(function () {
      $('analyse').hidden = true;
      load().then(render);
      setStatus('Alles geleert. (EAN-Mapping bleibt erhalten)');
    }).catch(function (e) { setStatus('Loeschen fehlgeschlagen: ' + e.message, 'err'); });
  });
});

// ------------------------------------------------------------------ Datensicherung
//
// LC.backup (features/popup-backup.js) macht die eigentliche Arbeit; hier nur
// UI-Klebstoff. Alle drei Knoepfe sind bewusst unter der Tools-Klappleiste -
// wer eine .xlsx exportieren will, findet das oben; wer Storage-Backups pflegt,
// weiss wonach er sucht.
(function () {
  if (!globalThis.LC || !LC.backup) return;

  function nf(n) {
    if (!isFinite(n) || n < 0) return '0';
    if (n >= 1e6) return (n / 1e6).toFixed(1) + ' MB';
    if (n >= 1e3) return (n / 1e3).toFixed(1) + ' kB';
    return n + ' B';
  }

  function info(text, cls) {
    var el = $('backupInfo'); if (!el) return;
    el.textContent = text || '';
    el.style.color = cls === 'err' ? 'var(--bad)' : cls === 'ok' ? 'var(--ok)' : '';
  }

  var expBtn = $('backupExport');
  if (expBtn) expBtn.addEventListener('click', function () {
    LC.backup.exportObject().then(function (obj) {
      var keys = Object.keys(obj);
      if (!keys.length) return info('Nichts zu sichern.', 'err');
      var json = JSON.stringify(obj, null, 2);
      var blob = new Blob([json], { type: 'application/json;charset=utf-8' });
      dateiSpeichern(blob, LC.backup.defaultFilename());
      info(keys.length + ' Schluessel gesichert (' + nf(json.length) + ').', 'ok');
    }).catch(function (e) { info('Fehler: ' + ((e && e.message) || e), 'err'); });
  });

  var impBtn = $('backupImport');
  if (impBtn) impBtn.addEventListener('click', function () {
    // Zweiter Klick nach der Diff-Vorschau: den vorbereiteten Import schreiben.
    if (impBtn._scharf) return bestaetigen(impBtn);
    var input = $('backupFile'); if (!input) return;
    input.value = '';
    input.onchange = function () {
      var file = input.files && input.files[0];
      if (!file) return;
      info('Lese ' + file.name + ' ...');
      file.text().then(function (txt) {
        var obj;
        try { obj = JSON.parse(txt); }
        catch (e) { throw new Error('Kein gueltiges JSON: ' + e.message); }
        var fehler = LC.backup.validate(obj);
        if (fehler) throw new Error(fehler);
        var keys = Object.keys(obj);
        // Diff ohne zu schreiben, damit die Bestaetigung ehrlich ist - nur die
        // betroffenen Keys lesen, nicht den ganzen Speicher.
        return storeGet(keys).then(function (alt) {
          var neu = 0, ueber = 0;
          keys.forEach(function (k) { if (k in (alt || {})) ueber++; else neu++; });
          // >5 MB nur warnen, nicht abbrechen - Notfall-Restore bleibt moeglich.
          var gross = file.size > 5 * 1024 * 1024 ? nf(file.size) + ' gross, kann dauern. ' : '';
          info('Import von ' + file.name + ': ' + gross + neu + ' neu, ' + ueber + ' werden ueberschrieben.');
          // Bestaetigung per Zwei-Klick auf "Importieren" (confirm() geht im Popup nicht).
          bestaetigen(impBtn, 'Import von ' + file.name + ' (' + keys.length + ' Schluessel) schreiben', function () {
            info('Schreibe ' + file.name + ' ...');
            LC.backup.importObject(obj).then(function (d) {
              info('Import fertig: ' + d.neu + ' neu, ' + d.ueberschrieben + ' ueberschrieben.', 'ok');
              // Sichtbaren Reiter neu zeichnen, damit importierte Listings sofort auftauchen.
              load().then(render);
            }).catch(function (e) { info('Fehler: ' + ((e && e.message) || e), 'err'); });
          });
        });
      }).catch(function (e) { info('Fehler: ' + ((e && e.message) || e), 'err'); });
    };
    input.click();
  });

  var statBtn = $('backupStats');
  if (statBtn) statBtn.addEventListener('click', function () {
    LC.backup.stats().then(function (by) {
      var einteile = Object.keys(by).sort(function (a, b) { return by[b] - by[a]; });
      if (!einteile.length) return info('Storage ist leer.');
      backupModalZeigen(einteile.map(function (k) { return { name: k, bytes: by[k] }; }));
    }).catch(function (e) { info('Fehler: ' + ((e && e.message) || e), 'err'); });
  });

  /* Kleines Modal ueber dem Popup - Klick auf den Hintergrund oder Esc schliesst.
     Kein a-popover-inline; das ist eine Amazon-Klasse, im Popup nicht definiert. */
  function backupModalZeigen(zeilen) {
    var alt = document.getElementById('lc-backup-modal');
    if (alt) alt.remove();

    var back = document.createElement('div');
    back.id = 'lc-backup-modal';
    back.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:9999;display:flex;align-items:center;justify-content:center;padding:24px';

    var box = document.createElement('div');
    box.style.cssText = 'background:var(--bg);color:var(--text);border:1px solid var(--line-strong);' +
      'max-width:100%;max-height:100%;overflow:auto;padding:14px 16px;min-width:280px;' +
      'font:12px/1.5 "Segoe UI",system-ui,sans-serif';

    var h = document.createElement('div');
    h.style.cssText = 'font-size:11px;color:var(--muted);margin-bottom:8px';
    h.textContent = 'Storage-Statistik';
    box.appendChild(h);

    var summe = 0;
    zeilen.forEach(function (z) {
      summe += z.bytes;
      var row = document.createElement('div');
      row.style.cssText = 'display:flex;justify-content:space-between;gap:12px;padding:2px 0;font-family:var(--mono);font-variant-numeric:tabular-nums';
      var n = document.createElement('span'); n.textContent = z.name;
      var v = document.createElement('span'); v.textContent = nf(z.bytes);
      row.appendChild(n); row.appendChild(v);
      box.appendChild(row);
    });
    var foot = document.createElement('div');
    foot.style.cssText = 'margin-top:10px;padding-top:8px;border-top:1px solid var(--line);display:flex;justify-content:space-between;font-family:var(--mono)';
    var lbl = document.createElement('span'); lbl.textContent = 'Gesamt';
    var wert = document.createElement('span'); wert.textContent = nf(summe);
    foot.appendChild(lbl); foot.appendChild(wert);
    box.appendChild(foot);

    // EIN Schliesspfad fuer Knopf, Hintergrund-Klick und Esc: bisher blieb der
    // keydown-Listener stehen, wenn nicht per Esc geschlossen wurde (kumulierte).
    var esc = function (e) { if (e.key === 'Escape') schliessen(); };
    var schliessen = function () { back.remove(); document.removeEventListener('keydown', esc); };

    var zu = document.createElement('button');
    zu.textContent = 'Schliessen';
    zu.style.cssText = 'margin-top:10px;float:right';
    zu.addEventListener('click', schliessen);
    box.appendChild(zu);

    back.appendChild(box);
    back.addEventListener('click', function (e) { if (e.target === back) schliessen(); });
    document.body.appendChild(back);
    document.addEventListener('keydown', esc);
  }
})();

// ------------------------------------------------------------------ Automatische Sicherung
//
// File System Access API (nur Chrome/Edge, keine neue Extension-Permission).
// Das DirectoryHandle kann chrome.storage nicht speichern - dafuer IndexedDB
// ('lc-backup'/'handles'), dieselbe DB liest auch der opportunistische
// Trigger im Service Worker (background.js) mit. JSON-Erzeugung kommt von
// LC.backup.exportObject() - dieselbe Quelle wie beim manuellen Export oben,
// nicht dupliziert.
(function () {
  if (!globalThis.LC || !LC.backup) return;
  if (!$('autoBackupOrdner')) return;

  var DB_NAME = 'lc-backup', STORE = 'handles';
  var AUFBEWAHREN = 30;
  var MUSTER = /^listing-checker-backup-\d{4}-\d{2}-\d{2}(-\d{4})?\.json$/;

  function idbOpen() {
    return new Promise(function (res, rej) {
      var req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = function () { req.result.createObjectStore(STORE); };
      req.onsuccess = function () { res(req.result); };
      req.onerror = function () { rej(req.error); };
    });
  }
  function idbGet(key) {
    return idbOpen().then(function (db) {
      return new Promise(function (res, rej) {
        var r = db.transaction(STORE, 'readonly').objectStore(STORE).get(key);
        r.onsuccess = function () { res(r.result || null); };
        r.onerror = function () { rej(r.error); };
      });
    });
  }
  function idbSet(key, val) {
    return idbOpen().then(function (db) {
      return new Promise(function (res, rej) {
        var tx = db.transaction(STORE, 'readwrite');
        tx.objectStore(STORE).put(val, key);
        tx.oncomplete = function () { res(); };
        tx.onerror = function () { rej(tx.error); };
      });
    });
  }

  var infoEl = $('autoBackupInfo');
  function autoInfo(text, cls) {
    if (!infoEl) return;
    infoEl.textContent = text || '';
    infoEl.style.color = cls === 'err' ? 'var(--bad)' : cls === 'ok' ? 'var(--ok)' : '';
  }

  function dateiname(d) {
    var mm = String(d.getMonth() + 1).padStart(2, '0');
    var tt = String(d.getDate()).padStart(2, '0');
    var hh = String(d.getHours()).padStart(2, '0');
    var mi = String(d.getMinutes()).padStart(2, '0');
    return 'listing-checker-backup-' + d.getFullYear() + '-' + mm + '-' + tt + '-' + hh + mi + '.json';
  }

  // Verzeichnisinhalt einsammeln, ohne for-await-of (Rest der Datei ist reines
  // Promise-Chaining, keine async/await-Syntax - hier bleiben wir konsistent).
  function alleDateien(handle) {
    return new Promise(function (res, rej) {
      var namen = [];
      var it = handle.entries();
      function schritt() {
        it.next().then(function (r) {
          if (r.done) return res(namen);
          if (r.value[1].kind === 'file') namen.push(r.value[0]);
          schritt();
        }).catch(rej);
      }
      schritt();
    });
  }

  // Aufbewahrung: nur eigene Dateien anfassen, die letzten 30 behalten.
  function aufraeumen(handle) {
    return alleDateien(handle).then(function (namen) {
      var treffer = namen.filter(function (n) { return MUSTER.test(n); }).sort();
      var zuViel = treffer.length - AUFBEWAHREN;
      if (zuViel <= 0) return;
      var loeschen = treffer.slice(0, zuViel);
      return loeschen.reduce(function (kette, name) {
        return kette.then(function () { return handle.removeEntry(name).catch(function () {}); });
      }, Promise.resolve());
    });
  }

  function pruefePermission(handle) {
    return handle.queryPermission({ mode: 'readwrite' }).then(function (p) {
      if (p === 'granted') return true;
      if (p === 'denied') return false;
      // 'prompt': braucht echte User-Geste - ohne Klick schlaegt das leise fehl.
      return handle.requestPermission({ mode: 'readwrite' }).then(function (p2) {
        return p2 === 'granted';
      }).catch(function () { return false; });
    });
  }

  function jetztSichern(handle) {
    var jetztBtn = $('autoBackupJetzt');
    var alterZeitstempel = 0;
    return new Promise(function (res) {
      chrome.storage.local.get('lcAutoBackupLast', function (d) { res(d.lcAutoBackupLast || 0); });
    }).then(function (alt) {
      alterZeitstempel = alt;
      // Zeitstempel VOR dem Schreiben setzen - sonst kann der Service-Worker-
      // Trigger in background.js (gleiche IndexedDB) parallel doppelt sichern.
      return saveViele({ lcAutoBackupLast: Date.now() });
    }).then(function () {
      return LC.backup.exportObject();
    }).then(function (obj) {
      var json = JSON.stringify(obj, null, 2);
      return handle.getFileHandle(dateiname(new Date()), { create: true }).then(function (fh) {
        return fh.createWritable().then(function (w) {
          return w.write(json).then(function () { return w.close(); });
        });
      });
    }).then(function () {
      return aufraeumen(handle);
    }).then(function () {
      if (jetztBtn) jetztBtn.hidden = true;
      autoInfo('Gesichert nach ' + handle.name + ' (' + new Date().toLocaleString('de-DE') + ')', 'ok');
    }).catch(function (e) {
      saveViele({ lcAutoBackupLast: alterZeitstempel }); // Fehlschlag zaehlt nicht als erledigt
      if (e && (e.name === 'NotFoundError' || e.name === 'NotAllowedError')) {
        autoInfo('Ordner nicht mehr erreichbar - neu waehlen.', 'err');
      } else {
        autoInfo('Fehler bei Auto-Sicherung: ' + ((e && e.message) || e), 'err');
      }
    });
  }

  function statusText(handle, letzte) {
    var ort = handle ? handle.name : 'kein Ordner gewaehlt';
    if (!letzte) return ort + ' - noch nicht gesichert.';
    return ort + ' - zuletzt gesichert ' + new Date(letzte).toLocaleString('de-DE') + '.';
  }

  var chk = $('autoBackupAn'), ordnerBtn = $('autoBackupOrdner'), jetztBtn = $('autoBackupJetzt');

  if (!window.showDirectoryPicker) {
    // Feature-Detection statt UA-Sniffing: in Firefox gibt es die API schlicht nicht.
    ordnerBtn.disabled = true;
    ordnerBtn.title = 'nur Chrome/Edge - in Firefox bitte den manuellen Export nutzen';
    autoInfo('nur Chrome/Edge - in Firefox bitte den manuellen Export oben nutzen.');
  } else {
    ordnerBtn.addEventListener('click', function () {
      window.showDirectoryPicker({ mode: 'readwrite' }).then(function (handle) {
        return idbSet('dir', handle).then(function () {
          /* Ein gewaehlter Ordner ist kein optionales Backup-Ziel mehr, sondern
             der fuehrende Datenspeicher. Aktivieren + vorhandene wachsende
             Browserdaten einmalig in Einzeldateien migrieren. */
          return saveViele({ lcAutoBackup: true }).then(function () {
            chk.checked = true;
            return new Promise(function (res, rej) {
              chrome.runtime.sendMessage({ type: 'lcDiskMigrieren' }, function (r) {
                var e = chrome.runtime.lastError;
                if (e || !r || !r.ok) return rej(new Error((e && e.message) || (r && r.error) || 'Migration fehlgeschlagen'));
                res(r.migrated || 0);
              });
            });
          }).then(function (n) {
          jetztBtn.hidden = true;
            autoInfo(handle.name + ' ist Datenspeicher · ' + n + ' vorhandene Datenreihen auf Disk verschoben.', 'ok');
          });
        });
      }).catch(function (e) {
        if (e && e.name === 'AbortError') return; // Nutzer hat den Dialog abgebrochen
        autoInfo('Fehler: ' + ((e && e.message) || e), 'err');
      });
    });

    chk.addEventListener('change', function () {
      if (!chk.checked) {
        chk.checked = true;
        autoInfo('Der eingerichtete Ordner ist der führende Datenspeicher. Zum Abschalten zuerst Daten exportieren.', 'err');
        return;
      }
      saveViele({ lcAutoBackup: true });
    });

    jetztBtn.addEventListener('click', function () {
      idbGet('dir').then(function (handle) {
        if (!handle) return autoInfo('kein Ordner gewaehlt.', 'err');
        return jetztSichern(handle);
      });
    });

    // Beim Popup-Start: Status anzeigen und, falls faellig, Auto-Sicherung versuchen.
    chrome.storage.local.get(['lcAutoBackup', 'lcAutoBackupLast'], function (d) {
      chk.checked = !!d.lcAutoBackup;
      idbGet('dir').then(function (handle) {
        autoInfo(statusText(handle, d.lcAutoBackupLast));
        if (!d.lcAutoBackup || !handle) return;
        return pruefePermission(handle).then(function (ok) {
          if (!ok) {
            jetztBtn.hidden = false;
            autoInfo('Auto-Sicherung wartet auf Klick - ' + statusText(handle, d.lcAutoBackupLast));
            return;
          }
          autoInfo(handle.name + ' ist der führende Datenspeicher.', 'ok');
        });
      }).catch(function () { /* Handle unlesbar - Statuszeile zeigt bereits den Fallback */ });
    });
  }
})();

// ------------------------------------------------------------------ Start

load().then(function (d) {
  render(d);
  // Kontoliste EINMAL beim Start holen (Netz-Request an Helium) - render()
  // setzt nur noch den Wert; frueher lief der Abruf bei jedem Reiterwechsel.
  h10KontenFuellen(d.lcH10AccountId || '');
  var s = d.searchStatus;
  if (s && s.running) {
    setStatus('Suche laeuft: ' + (s.current || '...'));
    switchView('matches');
  } else if (s && s.result) {
    setStatus(s.result, s.ok ? 'ok' : 'err');
  }
});

/* ------------------------------------------------------------ Brand Analytics
   Amazon Brand Analytics gibt den Search Frequency Rank (SFR) je Suchbegriff
   aus. Wer Zugriff hat, exportiert die Tabelle als CSV; die Datei landet hier.
   Kleinste Zahl = meiste Suchen. In der Keyword-Abdeckung (features/dp-sfr.js)
   wird der Wert je Keyword eingeblendet. */
(function () {
  var MAX = 20000;
  var LC_ = globalThis.LC = globalThis.LC || {};

  // Trenner-Erkennung: Tab > Semikolon > Komma - wer die meisten Spalten liefert.
  function trenner(zeile) {
    return ['\t', ';', ','].reduce(function (best, s) {
      return zeile.split(s).length > zeile.split(best).length ? s : best;
    }, ',');
  }
  function zelle(s) {
    return String(s == null ? '' : s).trim().replace(/^"(.*)"$/, '$1').trim();
  }
  function parseCsv(text) {
    var lines = String(text || '').split(/\r?\n/).filter(function (l) { return l.trim(); });
    if (!lines.length) return { rows: [] };
    var sep = trenner(lines[0]);
    var split = function (l) { return l.split(sep).map(zelle); };
    var head = split(lines[0]).map(function (h) { return h.toLowerCase(); });
    var kwIdx = head.findIndex(function (h) { return /search\s*term|suchbegriff/.test(h); });
    var rkIdx = head.findIndex(function (h) { return /search\s*frequency\s*rank|^rang$/.test(h); });
    var start = 1;
    if (kwIdx < 0 || rkIdx < 0) {
      // Keine Header -> annehmen: Spalte 0 = Keyword, Spalte 1 = Rang
      kwIdx = 0; rkIdx = 1; start = 0;
    }
    var rows = [];
    for (var i = start; i < lines.length; i++) {
      var c = split(lines[i]);
      var kw = (c[kwIdx] || '').toLowerCase().trim();
      // Zahl kann "1.234" oder "1,234" oder "1234" sein - Trennerklopfer weg.
      var rk = parseInt(String(c[rkIdx] || '').replace(/[\s.,]/g, ''), 10);
      if (kw && isFinite(rk)) rows.push([kw, rk]);
    }
    return { rows: rows };
  }

  function ddmmyy(iso) {
    var t = iso ? new Date(iso) : new Date();
    if (isNaN(t.getTime())) t = new Date();
    return ('0' + t.getDate()).slice(-2) + '.' +
           ('0' + (t.getMonth() + 1)).slice(-2) + '.' +
           String(t.getFullYear()).slice(-2);
  }
  function anwenden(sfr) {
    var stat = document.getElementById('brandCsvStatus');
    var chip = document.getElementById('brandCsvChip');
    var keys = sfr ? Object.keys(sfr).filter(function (k) { return k !== 'updated'; }) : [];
    if (stat) stat.textContent = keys.length
      ? keys.length + ' Suchbegriffe geladen, aktualisiert ' + ddmmyy(sfr && sfr.updated)
      : '';
    if (chip) chip.hidden = !keys.length;
  }

  function importText(text) {
    var parsed = parseCsv(text);
    var out = { updated: new Date().toISOString() };
    var rows = parsed.rows.slice(0, MAX);
    // ponytail: bei Dubletten gewinnt der letzte Eintrag im CSV
    rows.forEach(function (r) { out[r[0]] = r[1]; });
    return storeSet({ sfr: out }).then(function () {
      anwenden(out);
      return { count: rows.length, sfr: out };
    });
  }
  function clearSfr() {
    return sendMsg({ type: 'lcStoreRemove', keys: 'sfr' }).then(function (r) {
      if (!r || !r.ok) throw new Error((r && r.error) || 'Speichern fehlgeschlagen');
      anwenden(null);
    });
  }
  LC_.brandCsv = { importText: importText, clear: clearSfr, parse: parseCsv, apply: anwenden };

  // UI verdrahten - nur wenn die Elemente da sind (auch nutzbar ohne DOM, s. Test).
  var imp = document.getElementById('brandCsvImport');
  if (imp) imp.addEventListener('click', function () {
    var file = document.getElementById('brandCsvFile');
    var txt = document.getElementById('brandCsvText');
    var f = file && file.files && file.files[0];
    var kette = f ? f.text() : Promise.resolve((txt && txt.value) || '');
    kette.then(function (t) {
      if (!t.trim()) { setStatus('Keine CSV-Daten - Datei wählen oder einfügen.', 'err'); return; }
      return importText(t).then(function (r) {
        setStatus(r.count + ' Suchbegriffe (SFR) importiert.', 'ok');
        if (txt) txt.value = '';
        if (file) file.value = '';
      });
    }).catch(function (e) { setStatus('CSV-Fehler: ' + ((e && e.message) || e), 'err'); });
  });
  var clr = document.getElementById('brandCsvClear');
  if (clr) clr.addEventListener('click', function () {
    clearSfr().then(function () { setStatus('SFR-Daten gelöscht.', 'ok'); });
  });

  // Zustand initial anzeigen (nach Popup-Aufruf: was liegt schon im Storage?)
  storeGet('sfr').then(function (d) { anwenden(d && d.sfr); }).catch(function () {});
})();

/* ------------------------------------------------------------ Verkaufsschaetzer kalibrieren
   Tabelle je Hauptkategorie (Paare/Fit-Exponent/Faktor), CSV-Export aller
   cal:<kategorie>-Paare und Freitext-Import echter Seller-Central-Zahlen als
   manuelle Paare. Die Schaetz-Mathematik selbst liegt in shared/sales.js
   (LC.sales) - hier nur die Kalibrier-Ansicht. */
(function () {
  if (!globalThis.LC || !LC.sales) return;
  var tableEl = $('salesCalTable');
  if (!tableEl) return;

  // cal:<kategorie>-Keys aus einem kompletten storage-Snapshot herausziehen.
  function kategorien(d) {
    var out = {};
    Object.keys(d || {}).forEach(function (k) {
      if (k.indexOf('cal:') !== 0) return;
      var tab = d[k] || {};
      out[k.slice(4)] = Object.keys(tab).map(function (a) { return tab[a]; })
        .filter(function (p) { return Array.isArray(p) && p[0] > 0 && p[1] > 0; });
    });
    return out;
  }

  function faktorZeile(kat, paare, faktorWert, istFallback) {
    var manuell = paare.filter(function (p) { return p[3] === 'm'; }).length;
    var h10n = paare.filter(function (p) { return p[3] === 'h'; }).length;   // H10-Sales-Klicks (seit 01.09.)
    // Niveau statt Fit-Exponent: die Kurvenform ist fest (oeffentliche Tabelle),
    // aus den eigenen Punkten kommt nur noch die Hoehe (Umbau 01.09.).
    var niv = LC.sales.niveauAus(paare, kat);
    var row = document.createElement('div');
    row.className = 'lc-calrow';

    var nm = document.createElement('span');
    nm.textContent = istFallback ? '(Standard – ohne eigenen Faktor)' : (kat || '(ohne Kategorie)');
    nm.title = istFallback ? 'Gilt fuer jede Kategorie, die keinen eigenen Faktor hat' : kat;
    row.appendChild(nm);

    var n = document.createElement('span');
    n.textContent = istFallback ? '' : (paare.length + ' (' + manuell + ' man.' + (h10n ? ', ' + h10n + ' H10' : '') + ')');
    row.appendChild(n);

    var b = document.createElement('span');
    b.textContent = niv ? '×' + niv.wert.toFixed(2) : '–';
    b.title = niv
      ? 'Niveaufaktor: so weit liegt diese Kategorie über (>1) oder unter (<1) der öffentlichen Standardkurve'
      : 'noch kein eigener Datenpunkt – es gilt die Standardkurve';
    row.appendChild(b);

    var inp = document.createElement('input');
    inp.type = 'number'; inp.step = '0.05'; inp.placeholder = '1';
    inp.value = faktorWert == null ? '' : faktorWert;
    inp.title = 'Korrekturfaktor - multipliziert die gesamte Schätzung dieser Kategorie (leer = 1)';
    inp.addEventListener('change', function () {
      var roh = inp.value.trim();
      var f = roh === '' ? null : Number(roh.replace(',', '.'));
      if (roh !== '' && (!isFinite(f) || f <= 0)) {
        setStatus('Faktor muss eine Zahl größer 0 sein.', 'err');
        inp.value = faktorWert == null ? '' : faktorWert;
        return;
      }
      // Frisch lesen, nur den eigenen Kategorie-Schluessel setzen - calFaktor ist geteilt.
      chrome.storage.local.get('calFaktor', function (d) {
        var cf = (d && d.calFaktor) || {};
        var schluessel = istFallback ? '*' : kat;
        if (f == null) delete cf[schluessel]; else cf[schluessel] = f;
        saveViele({ calFaktor: cf }).then(function () {
          setStatus('Faktor für "' + schluessel + '" gespeichert.', 'ok');
        }).catch(function (e) { setStatus('Speichern fehlgeschlagen: ' + e.message, 'err'); });
      });
    });
    row.appendChild(inp);

    /* Reset je Kategorie: gesammelte SERP-/Badge-Paare koennen auf der falschen
       Rang-Skala liegen (Unterkategorie-Rang unter der Hauptkategorie abgelegt).
       niveauAus siebt sie zwar aus der Rechnung, aber wer neu anfangen will,
       braucht den Knopf. Der Fallback-Zeile fehlen Punkte - dort kein Knopf. */
    if (!istFallback) {
      // Zwei-Klick statt confirm() (s. bestaetigen): erster Klick macht "?",
      // zweiter loescht, nach 4 s zurueck auf "×".
      var del = document.createElement('button');
      del.type = 'button';
      del.className = 'lc-calreset';
      del.textContent = '×';
      del.title = 'Alle ' + paare.length + ' gesammelten Punkte der Kategorie "' + kat + '" löschen';
      del.addEventListener('click', function () {
        bestaetigen(del, paare.length + ' Punkte für "' + kat + '" löschen', function () {
          chrome.runtime.sendMessage({ type: 'lcStoreRemove', keys: 'cal:' + kat }, function () {
            void chrome.runtime.lastError;
            setStatus('Kalibrier-Punkte für "' + kat + '" gelöscht.', 'ok');
            renderCalTable();
          });
        });
      });
      row.appendChild(del);
    }
    return row;
  }

  function renderCalTable() {
    // Nur cal:* + calFaktor - nicht den ganzen Speicher (s. storeGetPrefix).
    storeGetPrefix('cal:', ['calFaktor']).then(function (d) {
      tableEl.textContent = '';
      var kopf = document.createElement('div');
      kopf.className = 'lc-calrow head';
      ['Kategorie', 'Punkte', 'Niveau', 'Faktor', ''].forEach(function (h) {
        var s = document.createElement('span'); s.textContent = h; kopf.appendChild(s);
      });
      tableEl.appendChild(kopf);

      var cf = (d && d.calFaktor) || {};
      tableEl.appendChild(faktorZeile('*', [], cf['*'], true));

      var kats = kategorien(d);
      var namen = Object.keys(kats).sort(function (a, b) { return kats[b].length - kats[a].length; });
      namen.forEach(function (kat) { tableEl.appendChild(faktorZeile(kat, kats[kat], cf[kat], false)); });

      if (!namen.length) {
        var e = document.createElement('div');
        e.className = 'hint';
        e.textContent = 'Noch keine Kalibrier-Paare gesammelt - dp-sales.js sammelt sie automatisch auf Produktseiten mit Amazons Kaufzahl-Badge.';
        tableEl.appendChild(e);
      }
    });
  }

  renderCalTable();
  chrome.storage.onChanged.addListener(function (ch, area) {
    if (area !== 'local') return;
    var betroffen = Object.keys(ch).some(function (k) { return k.indexOf('cal:') === 0 || k === 'calFaktor'; });
    if (betroffen) renderCalTable();
  });
  chrome.runtime.onMessage.addListener(function (msg) {
    if (msg && msg.type === 'lcDiskChanged' && (msg.keys || []).some(function (k) { return k.indexOf('cal:') === 0; })) renderCalTable();
  });

  // ---- CSV-Export (Semikolon + BOM, deutsches Excel) ---------------------
  var expBtn = $('salesCalExport');
  if (expBtn) expBtn.addEventListener('click', function () {
    storeGetPrefix('cal:').then(function (d) {
      var kats = kategorien(d);
      var zeilen = ['Kategorie;ASIN;BSR;Kaufzahl;Quelle;Datum'];
      Object.keys(kats).forEach(function (kat) {
        var tab = (d && d['cal:' + kat]) || {};
        Object.keys(tab).forEach(function (asin) {
          var p = tab[asin];
          if (!Array.isArray(p) || !(p[0] > 0) || !(p[1] > 0)) return;
          var datum = p[2] ? new Date(p[2]).toISOString().slice(0, 10) : '';
          zeilen.push([kat, asin, p[0], p[1], p[3] === 'm' ? 'manuell' : p[3] === 'h' ? 'H10' : 'automatisch', datum].join(';'));
        });
      });
      if (zeilen.length === 1) return setStatus('Keine Kalibrier-Paare zum Exportieren.', 'err');
      navigator.clipboard.writeText('﻿' + zeilen.join('\r\n')).then(function () {
        setStatus((zeilen.length - 1) + ' Paare als CSV in die Zwischenablage kopiert.', 'ok');
      }).catch(function (e) { setStatus('Kopieren fehlgeschlagen: ' + ((e && e.message) || e), 'err'); });
    });
  });

  // ---- Import: "kategorie;bsr;menge" je Zeile, als manuelle Paare mischen ----
  var impBtn = $('salesCalImportBtn');
  if (impBtn) impBtn.addEventListener('click', function () {
    var ta = $('salesCalImport');
    var text = ((ta && ta.value) || '').trim();
    if (!text) return setStatus('Keine Zeilen zum Importieren.', 'err');

    /* ZWEI Formate, weil der Export-Knopf daneben ein anderes schreibt als das
       hier gelesene (LO 01.09.: die eigene Export-CSV liess sich nicht
       zurueckladen - teile[1] ist dort die ASIN, nicht der BSR):
         kurz : kategorie;bsr;menge                        -> immer manuell ('m')
         Export: Kategorie;ASIN;BSR;Kaufzahl;Quelle;Datum  -> Quelle + ASIN bleiben
       Unterschieden wird an der 2. Spalte: eine reine Zahl ist ein BSR, alles
       andere eine ASIN. Kopfzeile wird uebersprungen. */
    var byKat = {};   // kategorie -> [{ asin, bsr, menge, quelle }, ...]
    var fehler = 0;
    text.split(/\r?\n/).map(function (z) { return z.trim(); }).filter(Boolean).forEach(function (z) {
      var teile = z.split(';');
      var kat = teile.length > 0 ? teile[0].trim().toLowerCase() : '';
      if (!kat || kat === 'kategorie') return;                     // Kopfzeile
      var langformat = teile.length >= 4 && !/^\d+$/.test(String(teile[1] || '').trim());
      var asin = langformat ? String(teile[1] || '').trim() : '';
      var bsr = parseInt(String(teile[langformat ? 2 : 1] || '').replace(/\D/g, ''), 10);
      var menge = parseInt(String(teile[langformat ? 3 : 2] || '').replace(/\D/g, ''), 10);
      if (!isFinite(bsr) || bsr <= 0 || !isFinite(menge) || menge <= 0) { fehler++; return; }
      var qRoh = langformat ? String(teile[4] || '').trim().toLowerCase() : 'manuell';
      var quelle = qRoh === 'h10' || qRoh === 'h' ? 'h' : qRoh === 'automatisch' ? null : 'm';
      (byKat[kat] = byKat[kat] || []).push({ asin: asin, bsr: bsr, menge: menge, quelle: quelle });
    });
    var katListe = Object.keys(byKat);
    if (!katListe.length) return setStatus('Keine gültige Zeile gefunden (kategorie;bsr;menge oder die Export-CSV).', 'err');

    storeGet(katListe.map(function (k) { return 'cal:' + k; })).then(function (d) {
      var patch = {}, n = 0;
      katListe.forEach(function (kat) {
        var key = 'cal:' + kat;
        var tab = (d && d[key]) || {};
        byKat[kat].forEach(function (p) {
          var ts = Date.now() + n;   // eindeutig je Paar, auch bei gleichem BSR im selben Import
          // Echte ASIN als Schluessel: ein Reimport aktualisiert den Punkt,
          // statt ihn ein zweites Mal danebenzulegen.
          var schluessel = p.asin || ('m:' + p.bsr + ':' + ts);
          tab[schluessel] = p.quelle ? [p.bsr, p.menge, ts, p.quelle] : [p.bsr, p.menge, ts];
          n++;
        });
        patch[key] = tab;
      });
      saveViele(patch).then(function () {
        if (ta) ta.value = '';
        setStatus(n + ' manuelle Paare importiert' + (fehler ? ' (' + fehler + ' Zeile(n) übersprungen)' : '') + '.', 'ok');
      }).catch(function (e) { setStatus('Import fehlgeschlagen: ' + e.message, 'err'); });
    });
  });
})();
