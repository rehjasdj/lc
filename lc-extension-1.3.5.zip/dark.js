/* Dark Mode - Schalter. Laeuft bei document_start (vor dem ersten Paint), damit
   die Seite nach Reload/Navigation nicht erst hell aufblitzt und der Modus
   nicht "raus" ist. Gemerkt in chrome.storage.local (lcDark); ein localStorage-
   Spiegel liefert den Wert synchron, bevor der Storage-Callback kommt.
   Das Theme selbst steht in dark.css (echtes Farbschema, kein Invert-Filter).
   Bilder bleiben unangetastet (LO, 28.08.2026).

   Fremde Add-ons (Helium 10, Keepa, Jungle Scout ...) zeichnen ihre Fenster
   in Shadow-Roots - dort gilt Seiten-CSS nicht. Fuer jeden OFFENEN Shadow-Root
   wird darum ein kleines Theme-Blatt eingehaengt. Geschlossene sind unerreichbar. */
(function () {
  if (window.top !== window) return;
  var root = document.documentElement;
  var an = function () { return root.classList.contains('lc-dark'); };

  var SHADOW_CSS = [
    ':host{color-scheme:dark;color:var(--lc-fg)}',
    /* :not([data-lc]) MUSS drinbleiben: eigenes UI (Chips lc-ok/lc-bad, Panel)
       faerbt sich selbst - ohne die Ausnahme schlaegt diese Regel per
       Spezifitaet jede .lc-ok-Farbregel trotz !important (LO 01.09.: "keinerlei
       Farben mehr im custom UI"). */
    '*:not(img):not(svg):not(svg *):not(video):not(canvas):not(iframe):not(input):not(select):not(textarea):not([style*="background-image"]):not([data-lc-surface]):not([data-lc]):not([data-lc] *):not([data-lc-keep]):not([data-lc-keep] *){background-color:transparent!important;background-image:none!important;border-color:var(--lc-line)!important;color:inherit!important;text-shadow:none!important}',
    '[data-lc-surface]{background-color:var(--lc-card)!important;background-image:none!important;border-color:var(--lc-line)!important;color:var(--lc-fg)!important}',
    'a{color:var(--lc-link)!important}',
    'button,input,select,textarea,[role="button"]{background:var(--lc-raised)!important;color:var(--lc-fg)!important;border-color:var(--lc-line2)!important}',
    '.highcharts-background,.highcharts-plot-background{fill:var(--lc-card)!important}',
    '.highcharts-grid-line,.highcharts-axis-line,.highcharts-tick{stroke:var(--lc-line2)!important}',
    '.highcharts-root text{fill:var(--lc-fg2)!important}',
    '.highcharts-tooltip-box,.highcharts-label-box{fill:var(--lc-raised)!important;stroke:var(--lc-line2)!important}',
    '.highcharts-tooltip text{fill:var(--lc-fg)!important}',
    '.apexcharts-tooltip,.apexcharts-tooltip *{background:var(--lc-raised)!important;color:var(--lc-fg)!important}'
  ].join('\n');

  /* ---- Regler: Dunkelstufe, Kontrast, Bild-Helligkeit, Schriftart ----------
     Alles laeuft ueber die CSS-Variablen aus dark.css. Bewusst KEIN
     filter:brightness/contrast auf der Seite - das wuerde Amazons Textfarben,
     Sterne, Badges und Produktfotos gleich mit verrechnen. Stattdessen wird
     die Palette hier neu ausgerechnet und die Regeln in dark.css bleiben
     genau so gezielt wie vorher.

     DUNKELSTUFE = Grundhelligkeit der Flaechen (multiplikativ, Farbton bleibt).

     KONTRAST (lcSpreiz) = Spreizung des GANZEN Themes um mittleres Grau, wie
     bei Dark Reader. Hoch gedreht laeuft der Grund gegen Sattschwarz und der
     Text gegen Weiss; runter gedreht ruecken alle Werte zur Mitte zusammen -
     flau/ausgewaschen. Regler auf 50 = exakt die Originalpalette.

     TEXTKONTRAST (lcKontrast) = zusaetzlich nur die Textfarben Richtung
     Weiss (mehr) bzw. Richtung Grund (weniger) mischen. Beide Regler wirken
     nacheinander: erst Spreizung, dann Text-Mischung.

     Die Ebenen (Karte, erhoeht, Raender) werden bei der Spreizung NICHT
     einzeln gespreizt, sondern behalten ihren Abstand zum Grund (skaliert mit
     demselben Faktor). Sonst kollabiert bei hartem Kontrast alles auf Schwarz
     und Karten waeren nicht mehr vom Hintergrund zu unterscheiden.

     Zum Schluss laeuft jede Textfarbe durch anheben(): gegen die hellste
     Flaeche geprueft und noetigenfalls Richtung Weiss gezogen, bis MIN
     erreicht ist. MIN ist bewusst 3.0 und nicht 4.5 - "ausgewaschen" soll
     moeglich sein (LO, 30.08.), unlesbar nicht.

     Amazons Marken-Gelb/-Orange, Sterne und Farbmuster haengen nicht an den
     Variablen und bleiben unberuehrt. */
  /* Islands (Karten, Buybox, Popups) bewusst BLAEULICHER und heller als der
     neutrale Seitengrund, damit sie sich als eigene Flaechen absetzen statt im
     Schwarz zu verschwimmen (LO, 30.08.: "islands andere farbe waere peak"). */
  var BASIS = {
    bg: '#141a1f', card: '#1e2b38', raised: '#283848',
    line: '#37485c', line2: '#43566b',
    fg: '#e6e9eb', fg2: '#a3adb5', fg3: '#8b969f',
    link: '#7cc7e8', price: '#ffb04d'
  };
  var STD = { lcDunkel: 50, lcSpreiz: 50, lcKontrast: 50, lcBild: 100, lcBildK: 100, lcBildS: 100,
    lcFreist: true, lcFsStaerke: 228, lcFsKante: 38, lcFont: '' };
  var stand = STD;

  var kanaele = function (h) { var n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
  var hex = function (a) {
    return '#' + a.map(function (v) {
      v = Math.max(0, Math.min(255, Math.round(v)));
      return (v < 16 ? '0' : '') + v.toString(16);
    }).join('');
  };
  var skal = function (h, f) { return hex(kanaele(h).map(function (v) { return v * f; })); };
  var misch = function (h, ziel, t) {
    var a = kanaele(h), b = kanaele(ziel);
    return hex(a.map(function (v, i) { return v + (b[i] - v) * t; }));
  };
  var zahl = function (v, std) { v = parseFloat(v); return isFinite(v) ? v : std; };

  var MIN = 3.0;   // WCAG AA fuer grossen Text; 4.5 wuerde "ausgewaschen" verhindern
  var lum = function (h) {
    var a = kanaele(h).map(function (v) {
      v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2];
  };
  var quote = function (a, b) {
    var x = lum(a), y = lum(b);
    return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
  };
  /* Sicherheitsklammer: zieht die Farbe so weit Richtung Weiss, bis sie auf
     der Flaeche MIN erreicht. Reicht selbst Weiss nicht, kommt Weiss zurueck -
     schlechter als vorher wird es dadurch nie. */
  var anheben = function (h, flaeche) {
    if (quote(h, flaeche) >= MIN) return h;
    var lo = 0, hi = 1, m;
    for (var i = 0; i < 14; i++) {
      m = (lo + hi) / 2;
      if (quote(misch(h, '#ffffff', m), flaeche) >= MIN) hi = m; else lo = m;
    }
    return misch(h, '#ffffff', hi);
  };

  var theme = function (o) {
    stand = o = Object.assign({}, STD, o || {});
    var st = root.style;
    var d = 1 + (50 - zahl(o.lcDunkel, 50)) / 50 * 0.9;   // 0.1 (fast schwarz) .. 1.9
    var f = 1 + (zahl(o.lcSpreiz, 50) - 50) / 50 * 0.9;   // 0.1 (ausgewaschen) .. 1.9 (satt)
    var k = (zahl(o.lcKontrast, 50) - 50) / 50;           // -1 (flau) .. +1 (hart)

    // Theme-Spreizung um Mittelgrau (Dark-Reader-Prinzip)
    var spreiz = function (h) {
      return hex(kanaele(h).map(function (v) { return 128 + (v - 128) * f; }));
    };
    var bgD = kanaele(skal(BASIS.bg, d));
    var bg = spreiz(skal(BASIS.bg, d));
    var bgS = kanaele(bg);
    // Flaechen behalten ihren Abstand zum gespreizten Grund (Abstand skaliert
    // mit f) - einzeln gespreizt wuerden bei hartem Kontrast alle auf Schwarz
    // kollabieren und Karten waeren unsichtbar
    var flaeche = function (h) {
      var a = kanaele(skal(h, d));
      return hex(a.map(function (v, i) { return bgS[i] + (v - bgD[i]) * f; }));
    };
    var raised = flaeche(BASIS.raised);   // hellste Flaeche = strengster Fall
    // staerke = wie weit diese Farbe dem Textkontrast-Regler folgen darf
    var txt = function (h, staerke) {
      h = spreiz(h);
      return anheben(k >= 0 ? misch(h, '#ffffff', k * staerke) : misch(h, bg, -k * staerke), raised);
    };
    // Raender sind kein Text - sie duerfen dezent bleiben, also ohne Klammer
    var rand = function (h, staerke) {
      var b = flaeche(h);
      return k >= 0 ? misch(b, '#ffffff', k * staerke) : misch(b, bg, -k * staerke);
    };
    st.setProperty('--lc-bg', bg);
    st.setProperty('--lc-card', flaeche(BASIS.card));
    st.setProperty('--lc-raised', raised);
    st.setProperty('--lc-line', rand(BASIS.line, 0.30));
    st.setProperty('--lc-line2', rand(BASIS.line2, 0.30));
    st.setProperty('--lc-fg', txt(BASIS.fg, 0.35));
    st.setProperty('--lc-fg2', txt(BASIS.fg2, 0.40));
    st.setProperty('--lc-fg3', txt(BASIS.fg3, 0.45));
    st.setProperty('--lc-link', anheben(spreiz(BASIS.link), raised));
    st.setProperty('--lc-price', anheben(spreiz(BASIS.price), raised));
    st.setProperty('--lc-bild', (zahl(o.lcBild, 100) / 100).toFixed(2));
    st.setProperty('--lc-bild-k', (zahl(o.lcBildK, 100) / 100).toFixed(2));
    st.setProperty('--lc-bild-s', (zahl(o.lcBildS, 100) / 100).toFixed(2));
    st.setProperty('--lc-font', o.lcFont || 'inherit');
    root.classList.toggle('lc-font', !!o.lcFont);
    try { localStorage.setItem('lcTheme', JSON.stringify(o)); } catch (e) { /* egal */ }
  };

  var hell = function (c) {
    var m = String(c || '').match(/rgba?\((\d+)[, ]+(\d+)[, ]+(\d+)(?:[, /]+([\d.]+))?\)/);
    return !!(m && +m[1] >= 235 && +m[2] >= 235 && +m[3] >= 235 && (m[4] == null || +m[4] > 0.5));
  };
  /* Alle Flaechen-Finder (flaechenMarkieren, lightSurface, overlayInnen) LESEN
     nur noch und sammeln Treffer in `treffer`; geschrieben (setAttribute) wird
     spaeter am Stueck in lauf(). Grund (Messung 02.09., SERP mit 60 Kacheln,
     2,3 s RecalcStyle): jedes setAttribute zwischen zwei getComputedStyle/
     getBoundingClientRect macht den Style-Baum dirty, und der naechste Read
     zwingt den Browser zu einem frischen Recalc - Layout-Thrash pro Element.
     Ergebnis ist dasselbe: data-lc-surface wirkt nur auf das Element selbst
     (dark.css:69, SHADOW_CSS), kein Read haengt vom Write eines anderen ab. */
  var flaechenMarkieren = function (sr, treffer) {
    var ebene = Array.prototype.slice.call(sr.children);
    ebene = ebene.concat.apply(ebene, ebene.map(function (e) { return Array.prototype.slice.call(e.children); }));
    ebene.forEach(function (e) {
      if (e.tagName === 'STYLE' || e.tagName === 'SCRIPT' || e.tagName === 'IMG') return;
      var r = e.getBoundingClientRect();
      if (r.width >= 60 && r.height >= 20 && hell(getComputedStyle(e).backgroundColor)) treffer.push(e);
    });
  };
  /* Lese-Haelfte: Shadow-Roots unter host (rekursiv), die ein Theme-Blatt
     brauchen (on) bzw. loswerden sollen (off), in `roots` sammeln. Die hellen
     Flaechen MUESSEN jetzt gelesen werden, vor dem Einhaengen - danach macht
     SHADOW_CSS jeden Grund transparent und flaechenMarkieren faende nichts. */
  var shadowLesen = function (host, on, treffer, roots) {
    var sr = host.shadowRoot;
    if (!sr) return;
    var st = sr.querySelector('style[data-lc-dark]');
    if (on ? !st : !!st) {
      roots.push(sr);
      if (on) { try { flaechenMarkieren(sr, treffer); } catch (e) { /* egal */ } }
    }
    Array.prototype.forEach.call(sr.querySelectorAll('*'), function (e) { if (e.shadowRoot) shadowLesen(e, on, treffer, roots); });
  };
  // Schreib-Haelfte: Blatt ein- bzw. aushaengen (Flaechen-Attribute setzt lauf())
  var shadowSchreiben = function (sr, on) {
    if (on) {
      var st = document.createElement('style'); st.setAttribute('data-lc-dark', '1'); st.textContent = SHADOW_CSS;
      sr.appendChild(st);
    } else {
      var alt = sr.querySelector('style[data-lc-dark]');
      if (alt) alt.remove();
      Array.prototype.forEach.call(sr.querySelectorAll('[data-lc-surface]'), function (e) { e.removeAttribute('data-lc-surface'); });
    }
  };

  /* Schwebende Schichten im NORMALEN DOM erkennen (Gegenstueck zu
     flaechenMarkieren fuer Shadow-Roots): fixed - oder absolute mit hohem
     z-index -, grossflaechig, und ohne eigenen deckenden Grund (transparent
     oder helles Weiss). Solche Schichten bekommen data-lc-surface und damit
     per dark.css die erhoehte Flaeche. Ein halbtransparenter dunkler Backdrop
     (rgba(0,0,0,.5)) wird bewusst NICHT uebermalt. */
  var lightSurface = function (n) {
    if (!an()) return;
    if (n.nodeType === 9) n = n.body;
    if (!n || n.nodeType !== 1) return;
    var kand = [n];
    Array.prototype.forEach.call(n.children, function (c) {
      kand.push(c);
      Array.prototype.forEach.call(c.children, function (c2) { kand.push(c2); });
    });
    var ohneGrund = function (cs) {
      var m = String(cs.backgroundColor).match(/rgba?\((\d+)[, ]+(\d+)[, ]+(\d+)(?:[, /]+([\d.]+))?\)/);
      return !m || (m[4] != null && +m[4] < 0.3) || hell(cs.backgroundColor);
    };
    /* Innenflaechen eines erkannten Overlays: die Immersive View legt Titel/
       Details/Thumb-Spalte in NORMALE (statische) divs im fixed-Wrapper - das
       Positions-Kriterium unten erwischt sie nie, sie blieben durchsichtig
       (LO-Screenshot 01.09.). Also im Overlay selbst alle grossen Bloecke ohne
       deckenden Grund markieren, Position egal. Deckel 600 Elemente, Elemente
       mit background-image auslassen (die [data-lc-surface]-Regel wuerde es
       loeschen und z.B. Thumbnails killen). */
    var overlayInnen = function (root) {
      var alle = root.querySelectorAll('*'), n = Math.min(alle.length, 600);
      for (var i = 0; i < n; i++) {
        var e = alle[i];
        if (e.hasAttribute('data-lc-surface') || e.hasAttribute('data-lc')) continue;
        var cs;
        try { cs = getComputedStyle(e); } catch (err) { continue; }
        if (cs.backgroundImage && cs.backgroundImage !== 'none') continue;
        var r = e.getBoundingClientRect();
        if (r.width < 200 || r.height < 100) continue;
        if (ohneGrund(cs)) e.setAttribute('data-lc-surface', '1');
      }
    };
    kand.forEach(function (e) {
      if (e.hasAttribute('data-lc')) return;
      var cs;
      try { cs = getComputedStyle(e); } catch (err) { return; }
      if (cs.position !== 'fixed' && !(cs.position === 'absolute' && +cs.zIndex >= 50)) return;
      var r = e.getBoundingClientRect();
      if (r.width < 200 || r.height < 100) return;
      if (!e.hasAttribute('data-lc-surface') && ohneGrund(cs)) e.setAttribute('data-lc-surface', '1');
      // grosses Overlay (mind. halber Viewport): auch die statischen
      // Innenflaechen brauchen einen Grund - dunkler Backdrop bleibt dunkel,
      // aber seine hellen/transparenten Inhalte werden zur Flaeche.
      if (r.width >= innerWidth / 2 && r.height >= innerHeight / 2) overlayInnen(e);
    });
  };

  /* Zwei Dringlichkeiten: 'offen' = neue Teilbaeume (voller Scan inkl.
     Shadow-Roots und Bilder), 'flach' = Attribut-Wechsel an EINEM Element
     (nur lightSurface bzw. Bild-Maske). Attribut-Mutationen sind auf Amazon
     Dauerfeuer (Lazyload, Carousel, Hover) - ein voller querySelectorAll('*')-
     Scan pro Ereignis wuerde beim Scrollen sicht- und spuerbar ruckeln. */
  var timer = 0, offen = [], flach = [];
  var spaeter = function (node, nurFlach) {
    if (node) {
      var ziel = nurFlach ? flach : offen;
      if (ziel.indexOf(node) < 0) ziel.push(node);
    }
    clearTimeout(timer);
    timer = setTimeout(function () {
      var liste = offen, leicht = flach; offen = []; flach = [];
      if (!liste.length && !leicht.length) liste = [document];
      var on = an();
      liste.forEach(function (n) {
        try {
          if (n.nodeType !== 1 && n.nodeType !== 9) return;
          if (n.shadowRoot) shadowTheme(n, on);
          Array.prototype.forEach.call(n.querySelectorAll('*'), function (e) { if (e.shadowRoot) shadowTheme(e, on); });
          if (on) { bilder(n); lightSurface(n); }
        } catch (e) { /* egal */ }
      });
      if (on) leicht.forEach(function (n) {
        try {
          if (n.nodeType !== 1) return;
          if (n.tagName === 'IMG') { if (n.complete) freistellen(n); return; }
          lightSurface(n);
        } catch (e) { /* egal */ }
      });
    }, 120);
  };

  /* ---- Produktbilder freistellen (Flood-Fill vom Bildrand) -----------------
     Amazons Produktfotos sind JPEGs mit eingebranntem Weiss - kein URL-Trick
     liefert Transparenz. Ein SVG-Filter wuerde weisse PRODUKTE gleich mit
     wegstanzen (und "wandregal weiss" steht in den Keywords ganz oben).
     Darum Flood-Fill: nur Weiss, das vom Bildrand aus zusammenhaengend
     erreichbar ist, wird transparent. Weisse Flaechen IM Produkt bleiben,
     Lifestyle-Fotos (Ecken nicht weiss) werden gar nicht angefasst.
     Moeglich, weil m.media-amazon.com CORS * sendet (live geprueft 30.08.).

     Die Maske kommt als PNG-data-URL in CSS mask-image auf das Original -
     src/srcset bleiben unveraendert, Zoom und Galerie laufen weiter.
     Gleiches Verfahren wie am 28.08. (alphaMaske), Schwellen unveraendert. */
  /* Schwellen sind seit 30.08. per Popup-Regler einstellbar (lcFsStaerke/
     lcFsKante) - freistellen() reicht sie als Parameter durch; ohne Parameter
     gelten die bewaehrten Standardwerte (so testet tools/flood-fill-test.js). */
  var HELLW = 228, DUNKELW = 190;   // >= HELLW weg, <= DUNKELW bleibt, dazwischen weich
  var maskCache = {};               // src -> dataURL | '' (kein Freisteller)

  var alphaMaske = function (px, w, h, hw, dw) {
    hw = hw || HELLW; dw = dw || DUNKELW;
    var ecken = [0, (w - 1) * 4, (h - 1) * w * 4, ((h - 1) * w + w - 1) * 4];
    for (var i = 0; i < 4; i++) {
      var o = ecken[i];
      if (px[o] < 235 || px[o + 1] < 235 || px[o + 2] < 235) return null;   // Lifestyle
    }
    var a = new Uint8ClampedArray(w * h).fill(255);
    var gesehen = new Uint8Array(w * h);
    var stapel = [];
    for (var x = 0; x < w; x++) { stapel.push(x, (h - 1) * w + x); }
    for (var y = 0; y < h; y++) { stapel.push(y * w, y * w + w - 1); }
    while (stapel.length) {
      var p = stapel.pop();
      if (gesehen[p]) continue;
      gesehen[p] = 1;
      var q = p * 4, hl = Math.min(px[q], px[q + 1], px[q + 2]);
      if (hl < dw) continue;                            // Produktkante - Fill endet
      a[p] = hl >= hw ? 0 : Math.round(255 * (hw - hl) / Math.max(1, hw - dw));
      var px_ = p % w, py = (p - px_) / w;
      if (px_ > 0) stapel.push(p - 1);
      if (px_ < w - 1) stapel.push(p + 1);
      if (py > 0) stapel.push(p - w);
      if (py < h - 1) stapel.push(p + w);
    }
    /* Zweiter Pass: EINGESCHLOSSENE Weiss-Inseln (LO-Bild 30.08., Bambus-
       Lattenregal - Latten-Schlitze UND die grossen Faecher-Oeffnungen
       erreicht der Rand-Fill nie). Durchbruch vs. weisse Produktflaeche:
       (a) kleine Inseln (< 2% der Bildflaeche) sind immer Durchbrueche;
       (b) grosse Inseln sind Durchbrueche, wenn sie fast komplett REINWEISS
           sind (>= 90% der Pixel >= Schwelle) - Studio-Hintergrund ist
           gleichmaessig weiss, eine weisse Produktflaeche hat Schattierung
           und Verlaeufe und bleibt darum stehen. */
    var INSEL_MAX = Math.floor(w * h * 0.02);
    for (var s0 = 0; s0 < w * h; s0++) {
      if (gesehen[s0]) continue;
      var q0 = s0 * 4;
      if (Math.min(px[q0], px[q0 + 1], px[q0 + 2]) < hw) continue;   // Saat nur bei echtem Weiss
      var region = [s0], st2 = [s0], rein = 1;
      gesehen[s0] = 1;
      while (st2.length) {
        var p2 = st2.pop(), x2 = p2 % w, y2 = (p2 - x2) / w;
        [x2 > 0 ? p2 - 1 : -1, x2 < w - 1 ? p2 + 1 : -1, y2 > 0 ? p2 - w : -1, y2 < h - 1 ? p2 + w : -1].forEach(function (n2) {
          if (n2 < 0 || gesehen[n2]) return;
          var qn = n2 * 4, hn = Math.min(px[qn], px[qn + 1], px[qn + 2]);
          if (hn < dw) return;                                        // Produktkante
          gesehen[n2] = 1; region.push(n2); st2.push(n2);
          if (hn >= hw) rein++;
        });
      }
      if (region.length > INSEL_MAX && rein < region.length * 0.9) continue;  // schattierte Flaeche -> Produkt
      region.forEach(function (p3) {
        var q3 = p3 * 4, h3 = Math.min(px[q3], px[q3 + 1], px[q3 + 2]);
        a[p3] = h3 >= hw ? 0 : Math.round(255 * (hw - h3) / Math.max(1, hw - dw));
      });
    }
    // Notbremse: ist fast das GANZE Bild transparent geworden, hat der Fill ein
    // weisses Produkt gefressen (weiss auf weiss, keine Kante - LO-Screenshot
    // 30.08., "Regal weiss 2"). Dann lieber gar nicht maskieren. Ein normaler
    // Freisteller hat 50-88% Hintergrund, ein gefressenes Produkt ueber 93%.
    var weg = 0;
    for (var j = 0; j < a.length; j++) { if (!a[j]) weg++; }
    if (weg > a.length * 0.93) return null;
    return a;
  };

  var maskeSetzen = function (img, url) {
    if (url) {
      img.style.setProperty('mask-image', 'url("' + url + '")', 'important');
      img.style.setProperty('-webkit-mask-image', 'url("' + url + '")', 'important');
      img.style.setProperty('mask-size', '100% 100%', 'important');
      img.style.setProperty('-webkit-mask-size', '100% 100%', 'important');
    }
  };

  var freistellen = function (img) {
    if (!an() || stand.lcFreist === false) return;   // Popup-Schalter "freistellen"
    var src = img.currentSrc || img.src || '';
    if (src.indexOf('media-amazon.com/images/I/') < 0) return;   // nur Produktfotos
    if ((img.naturalWidth || 0) < 60 || (img.naturalHeight || 0) < 60) return; // Icons
    if (img.dataset.lcMasked === src) return;
    img.dataset.lcMasked = src;
    if (maskCache[src] !== undefined) { maskeSetzen(img, maskCache[src]); return; }
    maskCache[src] = '';   // Platzhalter gegen Doppelarbeit waehrend des Ladens
    var b = new Image();
    b.crossOrigin = 'anonymous';
    b.onload = function () {
      var url = '';
      try {
        // ponytail: Maske auf max 400px rechnen - CSS skaliert sie aufs Original,
        // der Kantenverlust ist unsichtbar, der Fill 10x billiger
        var s = Math.min(1, 400 / Math.max(b.naturalWidth, b.naturalHeight));
        var mw = Math.max(1, Math.round(b.naturalWidth * s));
        var mh = Math.max(1, Math.round(b.naturalHeight * s));
        var c = document.createElement('canvas');
        c.width = mw; c.height = mh;
        var x = c.getContext('2d', { willReadFrequently: true });
        x.drawImage(b, 0, 0, mw, mh);
        var d = x.getImageData(0, 0, mw, mh);
        // Regler-Schwellen: Staerke = ab welcher Helligkeit "Hintergrund",
        // Kante = wie weich Schatten auslaufen (Staerke minus Kante = Stopp)
        var hw = Math.max(200, Math.min(252, zahl(stand.lcFsStaerke, HELLW)));
        var dw = Math.max(100, hw - Math.max(0, Math.min(80, zahl(stand.lcFsKante, HELLW - DUNKELW))));
        var m = alphaMaske(d.data, mw, mh, hw, dw);
        if (m) {
          for (var i = 0; i < m.length; i++) {
            var o = i * 4;
            d.data[o] = d.data[o + 1] = d.data[o + 2] = 255;
            d.data[o + 3] = m[i];   // CSS-mask nutzt den Alphakanal
          }
          x.putImageData(d, 0, 0);
          url = c.toDataURL('image/png');
        }
      } catch (e) { /* CORS/Canvas verweigert - Bild bleibt wie es ist */ }
      maskCache[src] = url;
      // src kann sich inzwischen geaendert haben (Variantenwechsel)
      if ((img.currentSrc || img.src) === src) maskeSetzen(img, url);
    };
    b.onerror = function () { maskCache[src] = ''; };
    b.src = src;
  };

  var bilder = function (wurzel) {
    if (!an()) return;
    var liste = (wurzel && wurzel.querySelectorAll) ? wurzel.querySelectorAll('img') : [];
    Array.prototype.forEach.call(liste, function (im) { if (im.complete) freistellen(im); });
  };
  var maskenWeg = function () {
    Array.prototype.forEach.call(document.querySelectorAll('img[data-lc-masked]'), function (im) {
      im.style.removeProperty('mask-image'); im.style.removeProperty('-webkit-mask-image');
      im.style.removeProperty('mask-size'); im.style.removeProperty('-webkit-mask-size');
      delete im.dataset.lcMasked;
    });
  };
  // Nachladende/gewechselte Bilder (Galerie, Varianten-Ajax, SERP-Scroll)
  document.addEventListener('load', function (e) {
    if (e.target && e.target.tagName === 'IMG') freistellen(e.target);
  }, true);

  var set = function (on) {
    root.classList.toggle('lc-dark', !!on);
    try { localStorage.setItem('lcDark', on ? '1' : '0'); } catch (e) { /* egal */ }
    if (on) { bilder(document); }
    else {
      maskenWeg();
      Array.prototype.forEach.call(document.querySelectorAll('[data-lc-surface]'), function (e) { e.removeAttribute('data-lc-surface'); });
    }
    spaeter(null);
  };
  var KEYS = Object.keys(STD);   // alle Regler-Keys aus STD
  try { if (localStorage.getItem('lcDark') === '1') root.classList.add('lc-dark'); } catch (e) { /* egal */ }
  // Spiegel zuerst: die Reglerwerte stehen damit vor dem ersten Paint, sonst
  // blitzt die Standard-Palette kurz auf, bevor der Storage-Callback kommt.
  try { theme(JSON.parse(localStorage.getItem('lcTheme') || 'null')); } catch (e) { theme(null); }
  try {
    chrome.storage.local.get(['lcDark'].concat(KEYS), function (d) { set(d && d.lcDark); theme(d); });
    chrome.storage.onChanged.addListener(function (ch, area) {
      if (area !== 'local') return;
      if (ch.lcDark) set(ch.lcDark.newValue);
      if (KEYS.some(function (k) { return ch[k]; })) {
        var o = {};
        KEYS.forEach(function (k) { o[k] = ch[k] ? ch[k].newValue : stand[k]; });
        theme(o);
        // Freistellen-Schalter wirkt sofort, nicht erst beim naechsten Bild-Load.
        // Bewusst HIER statt in theme(): der Palette-Test extrahiert theme() ohne
        // die Bild-Funktionen - ein Aufruf dort wuerde ihn brechen.
        if (ch.lcFreist) { if (ch.lcFreist.newValue === false) maskenWeg(); else if (an()) bilder(document); }
        // Schwellen-Regler: alte Masken sind mit den alten Schwellen gerechnet -
        // Cache leeren und sichtbare Bilder neu maskieren
        if (ch.lcFsStaerke || ch.lcFsKante) {
          maskCache = {};
          Array.prototype.forEach.call(document.querySelectorAll('img[data-lc-masked]'), function (im) { delete im.dataset.lcMasked; });
          if (an() && stand.lcFreist !== false) bilder(document);
        }
      }
    });
  } catch (e) { /* kein Storage - hell lassen */ }

  // Orphan-Guard: wird dark.js nach einem Extension-Reload nachinjiziert, laeuft
  // der ALTE Kontext (samt Observer) sonst weiter. Der Neue feuert das Event,
  // der Alte hoert es und stellt seinen Observer ab.
  document.dispatchEvent(new Event('lc-dark-neu'));
  var beobachter = new MutationObserver(function (muts) {
    if (!an()) return;
    muts.forEach(function (m) {
      // Auch Style-/Klassen-Wechsel beobachten: die Immersive View liegt von
      // Anfang an im DOM und wird nur per display:none->block eingeblendet -
      // ohne das hier wuerde lightSurface sie nie zu sehen bekommen.
      if (m.type === 'attributes') {
        var t = m.target;
        // root-Style schreiben WIR (theme() bei jedem Slider-Tick) und data-lc
        // ist unser eigenes UI - beides loest bewusst keinen Scan aus
        if (t !== root && t.nodeType === 1 && !t.hasAttribute('data-lc')) spaeter(t, true);
        return;
      }
      Array.prototype.forEach.call(m.addedNodes, function (n) { if (n.nodeType === 1) spaeter(n); });
    });
  });
  beobachter.observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['style', 'class', 'hidden'] });
  document.addEventListener('lc-dark-neu', function () { beobachter.disconnect(); }, { once: true });
  document.addEventListener('DOMContentLoaded', function () { spaeter(null); });
})();
