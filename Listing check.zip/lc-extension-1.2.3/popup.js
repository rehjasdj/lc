/* Popup-Steuerung: erfassen, analysieren (A+/Buybox), suchen, Preisvergleich,
   exportieren. Extraktion: shared/extract.js (injiziert). Alles Schreibende und
   Langlaufende macht der Service Worker - das Popup darf jederzeit zugehen. */
'use strict';

var $ = function (id) { return document.getElementById(id); };
var view = 'rows'; // 'rows' | 'matches' | 'keywords' | 'pro'

function setStatus(msg, cls) {
  var el = $('status');
  el.textContent = msg || '';
  el.className = cls || '';
}

function load() {
  return new Promise(function (res) {
    chrome.storage.local.get([
      'rows', 'matches', 'keywords', 'keywordEvidence', 'keywordRuns',
      'keywordSerpMeasurements', 'keywordApiEvidence', 'pro', 'searchStatus', 'eanMap', 'autoCompare'
    ], function (d) {
      res({
        rows: d.rows || [], matches: d.matches || [],
        keywords: d.keywords || [], pro: d.pro || [],
        keywordEvidence: d.keywordEvidence || [], keywordRuns: d.keywordRuns || [],
        keywordSerpMeasurements: d.keywordSerpMeasurements || [],
        keywordApiEvidence: d.keywordApiEvidence || [],
        searchStatus: d.searchStatus || {}, eanMap: d.eanMap || {},
        autoCompare: !!d.autoCompare
      });
    });
  });
}

function save(key, val) {
  return new Promise(function (res) {
    chrome.storage.local.set(Object.fromEntries([[key, val]]), res);
  });
}

function sendMsg(msg) {
  return new Promise(function (res) {
    chrome.runtime.sendMessage(msg, function (resp) {
      void chrome.runtime.lastError;
      res(resp);
    });
  });
}

// ------------------------------------------------------------------ Plattform-Checkboxen

(function buildPlats() {
  var wrap = $('plats');
  var groups = [
    { label: 'Unsere Plattformen', vergleich: false, checked: true },
    { label: 'Preisvergleich (verkaufen wir nicht)', vergleich: true, checked: false }
  ];
  groups.forEach(function (g) {
    var head = document.createElement('span');
    head.className = 'grp';
    head.textContent = g.label;
    wrap.appendChild(head);
    LC.PLATFORMS.filter(function (p) { return !!p.vergleich === g.vergleich; }).forEach(function (p) {
      var label = document.createElement('label');
      var cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.value = p.id;
      cb.checked = g.checked;
      label.appendChild(cb);
      label.appendChild(document.createTextNode(p.label));
      wrap.appendChild(label);
    });
  });
})();

function checkedPlats() {
  return Array.prototype.slice.call($('plats').querySelectorAll('input:checked'))
    .map(function (cb) { return cb.value; });
}

// ------------------------------------------------------------------ Query-Hinweis

var TYPE_LABEL = { ean: 'EAN', asin: 'ASIN', sku: 'SKU / Freitext' };

function updateHint() {
  var q = $('query').value.trim();
  var hint = $('qhint');
  if (!q) { hint.textContent = ''; return; }
  var t = LC.search.detectQueryType(q);
  hint.innerHTML = '';
  var b = document.createElement('b');
  b.textContent = TYPE_LABEL[t];
  hint.appendChild(document.createTextNode('erkannt: '));
  hint.appendChild(b);
  if (t === 'ean') hint.appendChild(document.createTextNode(' — Amazon-Treffer liefert die ASIN'));
  if (t === 'asin') hint.appendChild(document.createTextNode(' — Amazon wird direkt als Listing erfasst'));
}

$('query').addEventListener('input', updateHint);
$('query').addEventListener('keydown', function (e) {
  if (e.key === 'Enter') $('search').click();
});

// ------------------------------------------------------------------ Analyse-Panel (Produktbetreuer)

/* Alle Plattformen ausser der, auf der das Listing selbst steht. Bewusst NICHT
   nur comparePlatforms() (= Temu): die eigenen Kaufland-/eBay-Angebote sind
   fuer die Buybox-Sanierung gerade der wahrscheinliche Preisanker. */
function comparePlatsFor(row) {
  var ownId = (LC.PLATFORMS.find(function (p) { return p.label === row.plattform; }) || {}).id;
  return LC.PLATFORMS.map(function (p) { return p.id; })
    .filter(function (id) { return id !== ownId; });
}

/* Preisvergleich starten: EAN direkt aus der Zeile, sonst aus dem gelernten
   ASIN->EAN-Mapping. Ohne EAN laufen Otto/Temu sowieso ueber Marke+Titel. */
function startCompare(row, eanMap) {
  var ean = row.ean || eanMap[row.produkt_id] || eanMap[row.sku] || '';
  var plats = comparePlatsFor(row);
  if (!plats.length) return setStatus('Keine Vergleichsplattformen definiert.', 'err');
  sendMsg({
    type: 'batchSearch', perPlatform: true,
    ean: ean, titel: row.titel, marke: row.marke,
    mpn: row.mpn, sku: row.sku, produktId: row.produkt_id,
    platforms: plats,
    sourcePreis: row.preis, sourceLabel: row.plattform,
    qtype: 'ean', query: ean
  });
  setStatus('Preisvergleich laeuft auf: ' + plats.join(', ') + '...');
  switchView('matches');
}

function renderAnalyse(row, eanMap) {
  var box = $('analyse');
  box.innerHTML = '';
  if (!row) { box.hidden = true; return; }

  var isAmazon = row.plattform === 'Amazon';
  var head = document.createElement('div');
  head.className = 'h';
  head.textContent = 'Analyse — ' + (row.produkt_id || row.sku || '') + ' · ' + row.plattform;
  box.appendChild(head);

  var line = function (label, value, cls) {
    var el = document.createElement('div');
    el.className = 'line';
    var l = document.createElement('span');
    l.textContent = label;
    var v = document.createElement('span');
    v.className = cls || '';
    v.textContent = value;
    el.appendChild(l);
    el.appendChild(v);
    box.appendChild(el);
  };

  if (isAmazon) {
    line('A+:', row.aplus || '?', row.aplus === 'KEIN A+' ? 'bad' : 'good');
    var bbCls = row.buybox === 'ja' ? 'good' : (row.buybox === 'UNTERDRUECKT' ? 'bad' : 'warn');
    line('Buybox:', row.buybox || '?', bbCls);
    if (row.buybox === 'UNTERDRUECKT') {
      line('', 'irgendwo ist der Artikel guenstiger → Preisvergleich!', 'bad');
    }
    if (row.andere_angebote) line('Angebote:', row.andere_angebote, 'warn');
  }
  var ean = row.ean || eanMap[row.produkt_id] || eanMap[row.sku] || '';
  line('EAN:', ean || 'unbekannt (Preisvergleich laeuft dann ueber Marke+Titel)', ean ? '' : 'warn');
  if (row.preis != null) {
    line('Preis:', row.preis.toFixed(2).replace('.', ',') + ' ' + (row.waehrung || 'EUR'));
  }

  var btnRow = document.createElement('div');
  btnRow.className = 'row';

  var cmp = document.createElement('button');
  cmp.className = row.buybox === 'UNTERDRUECKT' ? 'primary' : '';
  cmp.textContent = 'Preisvergleich (' + comparePlatsFor(row).map(function (id) {
    return LC.PLATFORMS.find(function (p) { return p.id === id; }).label;
  }).join(', ') + ')';
  cmp.addEventListener('click', function () { startCompare(row, eanMap); });
  btnRow.appendChild(cmp);

  if (isAmazon && row.varianten_asins && row.varianten_asins.length) {
    var vc = document.createElement('button');
    vc.textContent = 'Varianten pruefen (' + row.varianten_asins.length + ')';
    vc.title = 'Alle Geschwister-ASINs laden: A+ da? Buybox da?';
    vc.addEventListener('click', function () {
      vc.disabled = true;
      sendMsg({ type: 'checkVariants', asins: row.varianten_asins });
      setStatus('Varianten-Check laeuft (' + row.varianten_asins.length + ' ASINs)...');
    });
    btnRow.appendChild(vc);
  }

  box.appendChild(btnRow);
  box.hidden = false;
}

// ------------------------------------------------------------------ Rendern

/* Der eigene Webshop ist Referenz, nicht Wettbewerber - er wird deshalb
   zurueckgenommen dargestellt und nie als guenstigster Preis markiert.
   Dieselbe Pruefung wie im Urteil (shared/match.js), damit Anzeige und
   Bewertung nicht auseinanderlaufen koennen. */
function istShop(r) {
  return !!(LC.match && LC.match.istEigenerShop && LC.match.istEigenerShop(r));
}

var VIEW_TABS = { rows: 'viewRows', matches: 'viewMatches', keywords: 'viewKeywords', pro: 'viewPro' };

function switchView(v) {
  view = v;
  Object.keys(VIEW_TABS).forEach(function (k) {
    $(VIEW_TABS[k]).className = v === k ? 'active' : '';
  });
  load().then(render);
}

Object.keys(VIEW_TABS).forEach(function (k) {
  $(VIEW_TABS[k]).addEventListener('click', function () { switchView(k); });
});

function fmtPreis(p, w) {
  if (p == null) return '';
  return p.toFixed(2).replace('.', ',') + ' ' + (w || 'EUR');
}

/* Keywords und Buybox-Zeilen haben eine andere Form als Listings/Treffer -
   eigener, schlanker Renderer statt Sonderfaelle in den grossen zu flicken. */
function renderSimple(list, items, kind) {
  if (!items.length) {
    var e = document.createElement('div');
    e.className = 'empty';
    e.textContent = kind === 'keywords'
      ? 'Noch keine Keywords geerntet.'
      : 'Noch keine ASIN geprueft.';
    list.appendChild(e);
    return;
  }

  items.forEach(function (r, i) {
    var item = document.createElement('div');
    item.className = 'item';
    var body = document.createElement('div');
    body.className = 'body';

    var tag = document.createElement('span');
    tag.className = 'tag';
    tag.textContent = kind === 'keywords' ? (r.plattform || '?') : (r.asin || '?');
    body.appendChild(tag);

    var t = document.createElement('span');
    t.className = 't';
    // Bei Buybox-Zeilen steht das URTEIL oben - nicht der Status, den er selbst sieht.
    t.textContent = kind === 'keywords'
      ? (r.keyword || '')
      : (r.urteil || ('Buybox: ' + (r.buybox || '?')));
    body.appendChild(t);

    var m = document.createElement('span');
    m.className = (kind === 'pro' && /UNTERBOTEN/.test(r.urteil || '')) ? 'w' : 'meta';
    m.textContent = kind === 'keywords'
      ? [
          'Seed: ' + (r.seed || '-'),
          'beste Pos. ' + (r.beste_position || r.position || '?'),
          r.demand_graph_index_0_100 != null ? 'Demand Graph ' + r.demand_graph_index_0_100 + '/100' : '',
          r.confidence_0_100 != null ? 'Confidence ' + r.confidence_0_100 + '/100' : '',
          r.marktplatz_konsens ? 'Konsens ' + r.marktplatz_konsens : '',
          r.trend ? 'Trend ' + r.trend : '',
          r.serp_sichtbare_treffer !== '' && r.serp_sichtbare_treffer != null
            ? r.serp_sichtbare_treffer + ' sichtbare Treffer' : '',
          r.serp_anzeigenquote_prozent !== '' && r.serp_anzeigenquote_prozent != null
            ? r.serp_anzeigenquote_prozent + '% Anzeigen' : '',
          r.serp_preis_median !== '' && r.serp_preis_median != null
            ? 'Median ' + fmtPreis(Number(r.serp_preis_median), 'EUR') : '',
          r.search_volume !== '' && r.search_volume != null
            ? 'Suchvolumen: ' + r.search_volume + (r.zeitraum ? ' (' + r.zeitraum + ')' : '')
            : 'kein absolutes Suchvolumen',
          r.datenquelle || ''
        ].filter(Boolean).join(' · ')
      : [
          r.guenstigster_beleg ? 'Nachweis: ' + r.guenstigster_beleg : '',
          (r.bestaetigte != null ? r.bestaetigte + ' von ' + r.kandidaten + ' Treffern belegt' : ''),
          'Buybox ' + (r.buybox || '?'),
          r.angebot_min != null ? 'Amazon ab ' + fmtPreis(r.angebot_min, 'EUR') : '',
          r.fehler ? '! ' + r.fehler : ''
        ].filter(Boolean).join(' · ');
    body.appendChild(m);

    /* Das ganze Wettbewerbsfeld aufklappbar: nicht nur wer unterbietet, sondern
       WER ALLES den Artikel fuehrt und zu welchem Gesamtpreis - die teuren
       Anbieter belegen, wo der Markt liegt. */
    if (kind === 'pro' && r.wettbewerb) {
      var det = document.createElement('details');
      det.className = 'feld';
      var sum = document.createElement('summary');
      sum.textContent = (r.anbieter_extern || 0) + ' Anbieter im Markt' +
        (r.luecke != null
          ? (r.luecke < 0
              ? ' · guenstigster liegt ' + fmtPreis(Math.abs(r.luecke), 'EUR') + ' darunter'
              : ' · niemand unterbietet')
          : '');
      det.appendChild(sum);
      var pre = document.createElement('pre');
      pre.className = 'feldtext';
      pre.textContent = r.wettbewerb;
      det.appendChild(pre);
      body.appendChild(det);
    }

    if (kind === 'pro' && r.verworfen) {
      var v = document.createElement('span');
      v.className = 'meta';
      v.textContent = 'verworfen: ' + r.verworfen;
      v.title = r.verworfen;
      body.appendChild(v);
    }

    item.appendChild(body);

    var del = document.createElement('button');
    del.className = 'ghost';
    del.textContent = '✕';
    del.title = 'Eintrag entfernen';
    del.setAttribute('aria-label', 'Eintrag entfernen');
    del.addEventListener('click', function () {
      load().then(function (d) {
        if (kind === 'keywords') {
          var pid = r.plattform_id || String(r.plattform || '').toLowerCase();
          d.keywordEvidence = d.keywordEvidence.filter(function (row) {
            var rowPid = row.plattform_id || String(row.plattform || '').toLowerCase();
            return !(rowPid === pid && row.seed === r.seed && row.keyword === r.keyword);
          });
          var usedApiIds = Object.create(null);
          d.keywordEvidence.forEach(function (row) {
            if (row.api_abruf_id) usedApiIds[row.api_abruf_id] = 1;
          });
          d.keywordApiEvidence = d.keywordApiEvidence.filter(function (row) {
            return !row.abruf_id || !!usedApiIds[row.abruf_id];
          });
          d.keywordSerpMeasurements = d.keywordSerpMeasurements.filter(function (row) {
            var rowPid = row.plattform_id || String(row.plattform || '').toLowerCase();
            return !(rowPid === pid && row.keyword === r.keyword);
          });
          d.keywords = LC.api.aggregateEvidence(
            d.keywordEvidence, d.keywordRuns, d.keywordSerpMeasurements
          );
          return Promise.all([
            save('keywordEvidence', d.keywordEvidence),
            save('keywordSerpMeasurements', d.keywordSerpMeasurements),
            save('keywordApiEvidence', d.keywordApiEvidence),
            save('keywords', d.keywords)
          ]).then(function () { load().then(render); });
        }
        var arr = d[kind];
        arr.splice(i, 1);
        return save(kind, arr).then(function () { load().then(render); });
      });
    });
    item.appendChild(del);

    list.appendChild(item);
  });
}

function render(data) {
  var rows = data.rows, matches = data.matches;
  var keywords = data.keywords || [], pro = data.pro || [];

  $('viewRows').textContent = 'Listings (' + rows.length + ')';
  $('viewMatches').textContent = 'Treffer (' + matches.length + ')';
  $('viewKeywords').textContent = 'Keywords (' + keywords.length + ')';
  $('viewPro').textContent = 'Buybox (' + pro.length + ')';

  var gesamt = rows.length + matches.length + keywords.length + pro.length;
  $('export').disabled = !gesamt;
  $('export').textContent = 'Export .xlsx' + (gesamt ? ' (' + gesamt + ')' : '');
  $('clear').disabled = !gesamt;

  // Die Reiter-Aktionen beziehen sich auf den sichtbaren Reiter - ist der
  // leer, sind sie aus. Sonst klickt man ins Nichts und bekommt eine Fehlermeldung.
  var imReiter = ({ rows: rows, matches: matches, keywords: keywords, pro: pro }[view] || []).length;
  $('viewExport').disabled = !imReiter;
  $('viewClear').disabled = !imReiter;

  $('autoCompare').checked = data.autoCompare;

  var list = $('list');
  list.textContent = '';

  if (view === 'keywords' || view === 'pro') {
    return renderSimple(list, view === 'keywords' ? keywords : pro, view);
  }

  var items = view === 'rows' ? rows : matches;

  /* Nachweislich fremde Treffer ("EAN weicht ab", "Fremdmarke ... im Titel")
     standen bisher gleichwertig neben den echten und haben die Liste
     unbrauchbar gemacht. Sie bleiben nachvollziehbar - im Excel-Export und
     als Zeile am Ende -, aber sie stehen nicht mehr dazwischen. */
  var verworfen = [];
  if (view === 'matches') {
    verworfen = items.filter(function (r) { return r.match_stufe === 'FREMD'; });
    if (verworfen.length) {
      items = items.filter(function (r) { return r.match_stufe !== 'FREMD'; });
    }
  }

  if (!items.length && verworfen.length) {
    var nurFremd = document.createElement('div');
    nurFremd.className = 'empty';
    nurFremd.textContent = 'Kein passender Treffer - ' + verworfen.length +
      ' Kandidat(en) waren nachweislich andere Artikel.';
    list.appendChild(nurFremd);
    return;
  }

  if (!items.length) {
    var e = document.createElement('div');
    e.className = 'empty';
    e.textContent = view === 'rows' ? 'Noch nichts erfasst.' : 'Noch keine Suche gelaufen.';
    list.appendChild(e);
    return;
  }

  /* Spaltenkopf: erst er macht aus untereinanderstehenden Zeilen eine
     Tabelle, die man von oben nach unten lesen kann. */
  var kopf = document.createElement('div');
  kopf.className = 'grid thead';
  ['Plattform', 'Titel', 'Preis', view === 'rows' ? 'Status' : 'Beleg', ''].forEach(function (h, n) {
    var c = document.createElement('span');
    if (n === 2) c.className = 'num';
    c.textContent = h;
    kopf.appendChild(c);
  });
  list.appendChild(kopf);

  /* Der guenstigste BELEGTE Fremdpreis wird hervorgehoben - das ist die eine
     Zahl, wegen der das Werkzeug geoeffnet wird. Der eigene Shop bleibt
     aussen vor: er kann die Buybox nicht kosten. */
  var bestPreis = null;
  if (view === 'matches') {
    items.forEach(function (r) {
      if (r.match_bestaetigt === 'ja' && r.preis != null && !istShop(r) &&
          (bestPreis == null || r.preis < bestPreis)) bestPreis = r.preis;
    });
  }

  /* Eintrag identifizieren statt ueber den Listenindex: seit echte und
     unbelegte Treffer in getrennten Gruppen gerendert werden, stimmt der
     Schleifenindex nicht mehr mit der Position in d.matches ueberein. */
  function istGleich(a, b) {
    if (a.url && b.url) return a.url === b.url;
    return (a.plattform || '') === (b.plattform || '') &&
           (a.titel || '') === (b.titel || '') &&
           String(a.preis) === String(b.preis) &&
           (a.produkt_id || '') === (b.produkt_id || '');
  }

  function baueZeile(r) {
    var item = document.createElement('div');
    item.className = 'grid item' + (istShop(r) ? ' ref' : '');

    var tag = document.createElement('span');
    tag.className = 'tag';
    tag.textContent = r.plattform || '?';
    tag.title = r.plattform || '';
    item.appendChild(tag);

    // Produkt-ID steht im Tooltip statt in einer eigenen Spalte - sie kostete
    // Breite, die der Titel braucht, und wird beim Lesen praktisch nie gebraucht.
    var idHint = r.produkt_id ? r.produkt_id + '\n' : '';
    if (r.url) {
      var a = document.createElement('a');
      a.className = 't';
      a.href = r.url;
      a.textContent = r.titel || '(ohne Titel)';
      a.title = idHint + (r.titel || '') + '\n' + r.url;
      a.addEventListener('click', function (ev) {
        ev.preventDefault();
        chrome.tabs.create({ url: r.url, active: false });
      });
      item.appendChild(a);
    } else {
      var t = document.createElement('span');
      t.className = 't';
      t.textContent = r.titel || '(ohne Titel)';
      t.title = idHint + (r.titel || '');
      item.appendChild(t);
    }

    var p = document.createElement('span');
    p.className = 'preis' + (r.preis == null ? ' leer' : '') +
                  (bestPreis != null && r.preis === bestPreis && !istShop(r) ? ' best' : '');
    p.textContent = r.preis == null ? '–' : fmtPreis(r.preis, r.waehrung);
    item.appendChild(p);

    if (view === 'rows') {
      var w = document.createElement('span');
      if (r.warnungen) {
        w.className = 'w';
        w.textContent = r.warnungen;
        w.title = r.warnungen;
      } else {
        w.className = 'ok';
        w.textContent = 'ok';
      }
      item.appendChild(w);
    } else {
      var m = document.createElement('span');
      m.className = 'meta';
      // Belegt-Status zuerst: ein Preis ohne Identitaetsnachweis ist wertlos.
      if (istShop(r)) {
        m.textContent = 'Referenz – zählt nicht';
      } else if (r.match_bestaetigt) {
        m.className = r.match_bestaetigt === 'ja' ? 'ok' : 'w';
        m.textContent = (r.match_bestaetigt === 'ja' ? '✓ ' : '✗ ') + (r.match_grund || '');
      } else {
        m.textContent = 'Pos. ' + (r.position || '?') + (r.gesponsert ? ' · Anzeige' : '');
      }
      m.title = [r.match_grund, r.gesponsert ? 'gesponsert' : '',
                 'Position ' + (r.position || '?')].filter(Boolean).join('\n');
      item.appendChild(m);
    }

    var akt = document.createElement('span');
    akt.className = 'akt';
    item.appendChild(akt);

    if (view === 'rows') {
      // Analyse-Panel fuer einen aelteren Eintrag wieder oeffnen
      var re = document.createElement('button');
      re.className = 'ghost';
      re.textContent = '⌕';
      re.title = 'Analyse anzeigen';
      re.setAttribute('aria-label', 'Analyse anzeigen');
      re.addEventListener('click', function () {
        load().then(function (d) { renderAnalyse(r, d.eanMap); });
      });
      akt.appendChild(re);
    }

    if (view === 'matches' && r.url) {
      var grab = document.createElement('button');
      grab.className = 'ghost';
      grab.textContent = '↓';
      grab.title = 'Volles Listing erfassen';
      grab.setAttribute('aria-label', 'Volles Listing erfassen');
      grab.addEventListener('click', function () {
        grab.disabled = true;
        setStatus('Erfasse Listing...');
        sendMsg({ type: 'deepGrab', url: r.url }).then(function (resp) {
          grab.disabled = false;
          if (resp && resp.ok) setStatus('Erfasst: ' + resp.titel.slice(0, 45), 'ok');
          else setStatus('Fehler: ' + ((resp && resp.error) || 'unbekannt'), 'err');
          load().then(render);
        });
      });
      akt.appendChild(grab);
    }

    var del = document.createElement('button');
    del.className = 'ghost';
    del.textContent = '✕';
    del.title = 'Eintrag entfernen';
    del.setAttribute('aria-label', 'Eintrag entfernen');
    del.addEventListener('click', function () {
      load().then(function (d) {
        var arr = view === 'rows' ? d.rows : d.matches;
        var idx = arr.findIndex(function (x) { return istGleich(x, r); });
        if (idx > -1) arr.splice(idx, 1);
        return save(view, arr).then(function () { load().then(render); });
      });
    });
    akt.appendChild(del);

    list.appendChild(item);
  }

  /* Echte von falschen trennen - der Kern des Ganzen: bestaetigte Treffer (der
     nachgewiesene Artikel) stehen oben, darunter mit klarer Trennlinie die
     unbelegten Kandidaten. Fremdartikel (FREMD) sind schon in 'verworfen'
     ausgelagert und erscheinen nur als Schlusszeile. */
  function sektion(text) {
    var s = document.createElement('div');
    s.className = 'empty tail sektion';
    s.textContent = text;
    return s;
  }

  if (view === 'rows') {
    items.forEach(baueZeile);
  } else {
    var refRows  = items.filter(istShop);
    var echte    = items.filter(function (r) { return !istShop(r) && r.match_bestaetigt === 'ja'; });
    var unsicher = items.filter(function (r) { return !istShop(r) && r.match_bestaetigt !== 'ja'; });
    refRows.forEach(baueZeile);
    echte.forEach(baueZeile);
    if (unsicher.length) {
      list.appendChild(sektion(echte.length || refRows.length
        ? '— Unbestaetigt · Identitaet nicht belegt (' + unsicher.length + ') —'
        : 'Kein bestaetigter Treffer · ' + unsicher.length + ' unbelegte(r) Kandidat(en):'));
      unsicher.forEach(baueZeile);
    }
  }

  // Abschlusszeile: was aussortiert wurde, bleibt sichtbar - nur nicht dazwischen.
  if (verworfen.length) {
    var hinweis = document.createElement('div');
    hinweis.className = 'empty tail';
    hinweis.textContent = '+ ' + verworfen.length + ' verworfen (' +
      verworfen.slice(0, 3).map(function (v) {
        return (v.plattform || '?') + ': ' + (v.match_grund || 'anderer Artikel');
      }).join(' | ') + (verworfen.length > 3 ? ' ...' : '') + ') - vollstaendig im Excel-Export';
    list.appendChild(hinweis);
  }
}

// ------------------------------------------------------------------ Erfassen

function grabTab(tabId) {
  return chrome.scripting.executeScript({
    target: { tabId: tabId },
    files: ['shared/extract.js', 'collect.js']
  }).then(function (res) {
    return res && res[0] ? res[0].result : null;
  });
}

function addRows(newRows) {
  return sendMsg({ type: 'saveRows', rows: newRows }).then(function () {
    return load().then(function (d) { render(d); return d; });
  });
}

$('grab').addEventListener('click', function () {
  setStatus('Erfasse...');
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var tab = tabs[0];
    if (!tab) return setStatus('Kein aktiver Tab.', 'err');
    grabTab(tab.id).then(function (row) {
      if (!row || !row.titel) return setStatus('Nichts gefunden - ist das eine Produktseite?', 'err');
      return addRows([row]).then(function (d) {
        switchView('rows');
        renderAnalyse(row, d.eanMap);
        setStatus('Erfasst: ' + row.titel.slice(0, 45), 'ok');
        // Auto-Preisvergleich auf den Fremdplattformen
        if (d.autoCompare && row.preis != null) startCompare(row, d.eanMap);
      });
    }).catch(function (e) {
      setStatus('Fehler: ' + e.message, 'err');
    });
  });
});

$('grabAll').addEventListener('click', function () {
  setStatus('Durchsuche Tabs...');
  chrome.tabs.query({}, function (tabs) {
    var targets = tabs.filter(function (t) {
      if (!t.url || !/^https?:/.test(t.url)) return false;
      try {
        return LC.detectPlatform(new URL(t.url).hostname).id !== 'generic';
      } catch (e) { return false; }
    });

    if (!targets.length) return setStatus('Keine passenden Tabs offen.', 'err');

    var done = 0, failed = 0, collected = [];
    var next = function (i) {
      if (i >= targets.length) {
        return addRows(collected).then(function () {
          switchView('rows');
          setStatus(done + ' erfasst' + (failed ? ', ' + failed + ' ohne Treffer' : ''),
                    done ? 'ok' : 'err');
        });
      }
      setStatus('Erfasse ' + (i + 1) + '/' + targets.length + '...');
      return grabTab(targets[i].id).then(function (row) {
        if (row && row.titel) { collected.push(row); done++; } else failed++;
      }).catch(function () { failed++; })
        .then(function () { return next(i + 1); });
    };
    next(0);
  });
});

// ------------------------------------------------------------------ Suche

$('search').addEventListener('click', function () {
  var q = $('query').value.trim();
  if (!q) return setStatus('Suchbegriff eingeben.', 'err');
  var plats = checkedPlats();
  if (!plats.length) return setStatus('Mindestens eine Plattform waehlen.', 'err');

  var qtype = LC.search.detectQueryType(q);
  sendMsg({ type: 'batchSearch', query: q, qtype: qtype, platforms: plats });
  setStatus('Suche laeuft... (Popup darf zugehen, Ergebnisse werden gesammelt)');
  switchView('matches');
});

$('openTabs').addEventListener('click', function () {
  var q = $('query').value.trim();
  if (!q) return setStatus('Suchbegriff eingeben.', 'err');
  var qtype = LC.search.detectQueryType(q);
  checkedPlats().forEach(function (pid) {
    var url = LC.search.searchUrl(pid, q, qtype);
    if (url) chrome.tabs.create({ url: url, active: false });
  });
  setStatus('Such-Tabs geoeffnet.', 'ok');
});

$('autoCompare').addEventListener('change', function () {
  save('autoCompare', $('autoCompare').checked);
});

// ------------------------------------------------------------------ Keywords / Buybox

$('kwRun').addEventListener('click', function () {
  var seed = $('kwSeed').value.trim() || $('query').value.trim();
  if (!seed) return setStatus('Seed eingeben (oder oben einen Suchbegriff).', 'err');

  /* Kaufland laeuft ueber seine echte Suchbox; die API blockiert direkte
     fetch()-Aufrufe. bol bleibt ohne belastbare Quelle aus der Keyword-Ernte. */
  var kannKeywords = function (p) { return p === 'kaufland' || LC.api.hasSuggest(p); };
  var plats = checkedPlats().filter(kannKeywords);
  if (!plats.length) {
    plats = LC.PLATFORMS.filter(function (p) { return kannKeywords(p.id); })
                        .map(function (p) { return p.id; });
  }

  sendMsg({ type: 'keywords', seeds: [seed], platforms: plats, tief: $('kwDeep').checked });
  setStatus('Keyword-Ernte laeuft (' + plats.join(', ') + ')... Popup darf zugehen.');
  switchView('keywords');
});

$('proRun').addEventListener('click', function () {
  /* Ein Klick vom Listing aus: ASIN kommt aus dem aktiven Tab, damit man nicht
     erst irgendwo eine ASIN abtippen muss. Fallbacks: Suchfeld, dann alle
     bereits erfassten Amazon-Listings. */
  chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
    var tab = tabs[0], asins = [];
    var m = tab && tab.url && tab.url.match(/amazon\.[a-z.]+\/(?:.*\/)?(?:dp|gp\/product)\/([A-Z0-9]{10})/i);
    if (m) asins.push(m[1].toUpperCase());

    var q = $('query').value.trim().toUpperCase();
    if (!asins.length && /^B0[A-Z0-9]{8}$/.test(q)) asins.push(q);

    load().then(function (d) {
      /* Kein Sammel-Fallback ueber rows mehr: der zog JEDES jemals erfasste
         Amazon-Listing wieder in die Pruefung - so wurde die laengst
         aussortierte Gartenliege bei jedem Klick auf "Buybox" erneut
         durchsucht. Ohne aktives Amazon-Tab und ohne ASIN im Feld ist eine
         ehrliche Absage richtig. */
      if (!asins.length) {
        return setStatus('Keine ASIN - oeffne ein Amazon-Listing oder gib oben eine ASIN ein.', 'err');
      }
      sendMsg({ type: 'proCheck', asins: asins });
      setStatus('Suche guenstigere Angebote fuer ' + asins.join(', ') + '... Popup darf zugehen.');
      switchView('pro');
    });
  });
});

/* Fortschritt der Hintergrund-Jobs live anzeigen. */
chrome.storage.onChanged.addListener(function (changes, area) {
  if (area !== 'local') return;
  if (changes.searchStatus) {
    var s = changes.searchStatus.newValue || {};
    if (s.running) {
      setStatus(((s.done || 0) + 1) + '/' + (s.total || '?') + ': ' + (s.current || '...'));
    } else if (s.result) {
      setStatus(s.result, s.ok ? 'ok' : 'err');
    }
  }
if (changes.rows || changes.matches || changes.keywords || changes.keywordEvidence ||
      changes.keywordRuns || changes.keywordSerpMeasurements || changes.keywordApiEvidence || changes.pro) load().then(render);
  if (changes.log) renderLog(changes.log.newValue || []);
});

// ------------------------------------------------------------------ Protokoll

/* Zeigt, WOMIT gesucht wurde und woran eine Stufe gescheitert ist. Ohne das
   bleibt bei "keine Treffer" nur Raten - genau der Zustand, aus dem heraus
   nicht erkennbar war, dass auf Kaufland ueberhaupt nur die EAN probiert wird. */
function renderLog(zeilen) {
  var pre = $('log');
  if (!pre) return;
  pre.textContent = '';
  zeilen.forEach(function (z) {
    var span = document.createElement('span');
    // Nur die entscheidenden Zeilen bekommen Farbe: Abbruch und Abschnittsstart.
    if (/AUFGEGEBEN|ABBRUCH|verworfen/.test(z)) span.className = 'stop';
    else if (/^\S+\s+===/.test(z)) span.className = 'head';
    span.textContent = z + '\n';
    pre.appendChild(span);
  });
  $('logCount').textContent = zeilen.length ? 'Protokoll (' + zeilen.length + ')' : 'Protokoll';
  // Ans Ende scrollen - der letzte Schritt ist der interessante.
  if ($('logbox').open) pre.scrollTop = pre.scrollHeight;
}

$('logCopy').addEventListener('click', function (ev) {
  // Nicht das <details> mit auf-/zuklappen.
  ev.preventDefault();
  ev.stopPropagation();
  navigator.clipboard.writeText($('log').textContent || '').then(function () {
    setStatus('Protokoll kopiert.', 'ok');
  });
});

chrome.storage.local.get('log', function (d) { renderLog(d.log || []); });

// ------------------------------------------------------------------ Export / Leeren

$('export').addEventListener('click', function () {
  load().then(function (d) {
    if (!d.rows.length && !d.matches.length && !d.keywords.length && !d.pro.length) return;
    setStatus('Baue Excel-Datei...');

    var wb = LC.buildWorkbook(XLSX, d.rows, d.matches, {
      keywords: d.keywords, keywordEvidence: d.keywordEvidence,
      keywordRuns: d.keywordRuns, keywordSerpMeasurements: d.keywordSerpMeasurements,
      keywordApiEvidence: d.keywordApiEvidence,
      pro: d.pro
    });
    var buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array', cellDates: true });
    var blob = new Blob([buf], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    });
    var url = URL.createObjectURL(blob);

    chrome.downloads.download({
      url: url,
      filename: LC.defaultFilename(),
      saveAs: true
    }, function () {
      setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
      setStatus([
        d.rows.length + ' Listings',
        d.matches.length + ' Treffer',
        d.keywords.length ? d.keywords.length + ' Keywords' : '',
        d.keywordEvidence.length ? d.keywordEvidence.length + ' Keyword-Belege' : '',
        d.keywordSerpMeasurements.length ? d.keywordSerpMeasurements.length + ' Marktmessungen' : '',
        d.keywordApiEvidence.length ? d.keywordApiEvidence.length + ' API-Belege' : '',
        d.pro.length ? d.pro.length + ' Buybox' : ''
      ].filter(Boolean).join(' + ') + ' exportiert.', 'ok');
    });
  });
});

/* ---------------------------------------------------------- Reiter einzeln

   Alles-oder-nichts war zu grob: wer die Keyword-Ernte behalten, aber die
   Treffer eines missglueckten Laufs loswerden will, musste bisher alles
   wegwerfen und neu erfassen. Diese beiden Knoepfe wirken deshalb nur auf den
   gerade sichtbaren Reiter - die Fusszeile bleibt fuer alles zusammen. */
var VIEW_INFO = {
  rows:     { key: 'rows',     label: 'Listings' },
  matches:  { key: 'matches',  label: 'Suchtreffer' },
  keywords: { key: 'keywords', label: 'Keywords' },
  pro:      { key: 'pro',      label: 'Buybox' }
};

/* Zerfall auf der SEITE auslösen, nicht im Popup: ein Popup ist ein eigenes
   kleines Fenster, jede Animation darin endet an dessen Kante. Über
   chrome.scripting laeuft sie als Overlay im aktiven Tab und kann sich ueber
   die ganze Seite verwehen.
   Schlaegt es fehl (interne Seite wie chrome://, kein Tab, keine Freigabe),
   wird trotzdem geleert - die Animation ist Beiwerk, nicht Bedingung. */
/* Die sichtbaren Zeilen im Popup mitzerfallen lassen - gestaffelt von oben
   nach unten, damit es eine Welle wird und kein gemeinsames Blinken. */
function zeilenZerfallen() {
  var zeilen = $('list').querySelectorAll('.item');
  for (var i = 0; i < zeilen.length; i++) {
    zeilen[i].style.setProperty('--i', i);
    zeilen[i].classList.add('dust');
  }
}

function zerfallAufSeite() {
  /* Die ECHTEN Zeilentexte mitgeben, nicht nur eine Anzahl: der Zerfall
     zerlegt den Inhalt selbst in Pixel, deshalb behält die Wolke am Anfang
     die Form der Liste. Mit Platzhaltern sähe es aus wie Konfetti. */
  var texte = [];
  var zeilen = $('list').querySelectorAll('.item');
  for (var i = 0; i < zeilen.length && texte.length < 26; i++) {
    var t = (zeilen[i].textContent || '').replace(/\s+/g, ' ').trim();
    if (t) texte.push(t);
  }
  if (!texte.length) texte = ['keine Eintraege'];

  return new Promise(function (fertig) {
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var tab = tabs && tabs[0];
      if (!tab || !tab.id || /^(chrome|edge|about|devtools|view-source):/i.test(tab.url || '')) {
        return fertig();
      }
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ['dust.js']
      }, function () {
        if (chrome.runtime.lastError) return fertig();
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: function (zz, uu) { deubaDustEffect(zz, uu); },
          // Startfeld dort, wo das Popup sitzt - oben rechts unter der Leiste.
          args: [texte, { x: 0.66, y: 0.09 }]
        }, function () { void chrome.runtime.lastError; fertig(); });
      });
    });
  });
}

function xlsxLaden(wb, name, fertig) {
  var buf = XLSX.write(wb, { bookType: 'xlsx', type: 'array', cellDates: true });
  var blob = new Blob([buf], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
  });
  var url = URL.createObjectURL(blob);
  chrome.downloads.download({ url: url, filename: name, saveAs: true }, function () {
    setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
    fertig();
  });
}

$('viewExport').addEventListener('click', function () {
  var info = VIEW_INFO[view];
  load().then(function (d) {
    var daten = d[info.key] || [];
    if (!daten.length) return setStatus('Nichts zu exportieren in "' + info.label + '".', 'err');
    setStatus('Baue Excel-Datei...');

    // Nur den sichtbaren Reiter befuellen, die anderen bleiben leer -
    // buildWorkbook laesst leere Blaetter weg.
    var wb = LC.buildWorkbook(XLSX,
      view === 'rows' ? daten : [],
      view === 'matches' ? daten : [],
      {
        keywords: view === 'keywords' ? daten : [],
        keywordEvidence: view === 'keywords' ? d.keywordEvidence : [],
        keywordRuns: view === 'keywords' ? d.keywordRuns : [],
        keywordSerpMeasurements: view === 'keywords' ? d.keywordSerpMeasurements : [],
        keywordApiEvidence: view === 'keywords' ? d.keywordApiEvidence : [],
        pro: view === 'pro' ? daten : []
      });

    var name = LC.defaultFilename().replace(/\.xlsx$/i, '') + '-' + info.key + '.xlsx';
    xlsxLaden(wb, name, function () {
      setStatus(daten.length + ' ' + info.label + ' exportiert.', 'ok');
    });
  });
});

$('viewClear').addEventListener('click', function () {
  var info = VIEW_INFO[view];
  load().then(function (d) {
    var n = (d[info.key] || []).length;
    if (!n) return setStatus('"' + info.label + '" ist bereits leer.');

    zerfallAufSeite();
    // Im Popup zerfallen die Zeilen mit - dort endet es an der Fensterkante,
    // auf der Seite laeuft es weiter. Geloescht wird erst danach, sonst
    // reisst das Neuzeichnen die Animation weg.
    zeilenZerfallen();
    return new Promise(function (weiter) { setTimeout(weiter, 620); })
      .then(function () {
        if (view !== 'keywords') return save(info.key, []);
        return Promise.all([
          save('keywords', []), save('keywordEvidence', []), save('keywordRuns', []),
          save('keywordSerpMeasurements', []), save('keywordApiEvidence', [])
        ]);
      })
      .then(function () {
        if (view === 'rows') $('analyse').hidden = true;
        load().then(render);
        setStatus(n + ' Eintrag/Eintraege aus "' + info.label + '" geleert.', 'ok');
      });
  });
});

$('clear').addEventListener('click', function () {
  /* Auch den Statustext zuruecksetzen: der stand in chrome.storage und
     tauchte beim naechsten Oeffnen wieder auf - so las man das Ergebnis eines
     laengst vergessenen Laufs als aktuellen Stand. Das EAN-Mapping bleibt
     bewusst erhalten, es ist muehsam erarbeitetes Wissen und wird nie falsch. */
  load().then(function (d) {
    var gesamt = d.rows.length + d.matches.length + d.keywords.length + d.pro.length;
    zerfallAufSeite();
    zeilenZerfallen();
    return new Promise(function (weiter) { setTimeout(weiter, 620); });
  }).then(function () {
    return Promise.all([save('rows', []), save('matches', []), save('keywords', []),
                        save('keywordEvidence', []), save('keywordRuns', []),
                        save('keywordSerpMeasurements', []), save('keywordApiEvidence', []), save('pro', []),
                        save('searchStatus', null)]);
  }).then(function () {
    $('analyse').hidden = true;
    load().then(render);
    setStatus('Alles geleert. (EAN-Mapping bleibt erhalten)');
  });
});

// ------------------------------------------------------------------ Start

load().then(function (d) {
  render(d);
  var s = d.searchStatus;
  if (s && s.running) {
    setStatus('Suche laeuft: ' + (s.current || '...'));
    switchView('matches');
  } else if (s && s.result) {
    setStatus(s.result, s.ok ? 'ok' : 'err');
  }
});
