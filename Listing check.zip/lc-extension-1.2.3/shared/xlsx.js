/* Listing Checker - geteilter Excel-Export.
   Erwartet, dass shared/extract.js vorher geladen wurde (globalThis.LC).

   Warum .xlsx und nicht CSV: Zahlen werden als echte Zahlen gespeichert, nicht als Text.
   Excel rendert sie dann automatisch in der Systemsprache - auf deutschem Windows also
   mit Komma als Dezimaltrenner und Punkt als Tausendertrenner. Kein Suchen/Ersetzen,
   kein Import-Assistent, keine kaputten "1.299" die zu 1,299 werden.
   Umgekehrt bleiben EAN/ASIN/SKU explizit Text - sonst frisst Excel fuehrende Nullen
   und macht aus 4260xxxxxxxx eine 4,26E+12. */
(function () {
  'use strict';

  var LC = globalThis.LC || (typeof window !== 'undefined' ? window.LC : null);
  if (!LC) throw new Error('shared/extract.js muss vor shared/xlsx.js geladen werden');

  var SHEET = 'Listings';
  var SHEET_MATCHES = 'Suchtreffer';
  var SHEET_KEYWORDS = 'Keywords';
  var SHEET_MATRIX = 'Keyword-Matrix';
  var SHEET_KEYWORD_EVIDENCE = 'Keyword-Belege';
  var SHEET_KEYWORD_RUNS = 'Keyword-Laeufe';
  var SHEET_KEYWORD_SERP = 'Keyword-Marktdaten';
  var SHEET_KEYWORD_API = 'Keyword-API-Belege';
  var SHEET_KEYWORD_METHOD = 'Keyword-Methodik';
  var SHEET_PRO = 'Buybox & Angebote';

  var KEYWORD_FIELDS = [
    { key: 'gefunden_am', label: 'Gefunden am', type: 'datetime' },
    { key: 'plattform',   label: 'Plattform',   type: 'text' },
    { key: 'seed',        label: 'Seed',        type: 'text' },
    { key: 'keyword',     label: 'Keyword',     type: 'text' },
    { key: 'beste_position', label: 'Beste Pos.', type: 'int' },
    { key: 'mittlere_position', label: 'Mittlere Pos.', type: 'num' },
    { key: 'beobachtungen', label: 'Beobachtungen', type: 'int' },
    { key: 'praefixe', label: 'Praefixe', type: 'int' },
    { key: 'praefix_abdeckung_prozent', label: 'Praefixbreite %', type: 'num' },
    { key: 'laeufe', label: 'Laeufe', type: 'int' },
    { key: 'lauf_ids', label: 'Zugehoerige Lauf-IDs', type: 'text' },
    { key: 'api_abruf_ids', label: 'Zugehoerige API-Abruf-IDs', type: 'text' },
    { key: 'prefix_rang_belege', label: 'Praefix -> Rang -> Lauf-ID', type: 'text' },
    { key: 'autocomplete_beleg_urls', label: 'Autocomplete-Beleg-URLs', type: 'text' },
    { key: 'lauf_persistenz_prozent', label: 'Persistenz %', type: 'num' },
    { key: 'marktplatz_konsens', label: 'Marktplatz-Konsens', type: 'text' },
    { key: 'konsens_plattformen', label: 'Konsens-Plattformen', type: 'text' },
    { key: 'rangstaerke_0_100', label: 'Rangstaerke 0-100', type: 'num' },
    { key: 'demand_signal_0_100', label: 'Demand-Signal 0-100', type: 'int' },
    { key: 'demand_graph_index_0_100', label: 'Demand Graph 0-100', type: 'int' },
    { key: 'confidence_0_100', label: 'Confidence 0-100', type: 'int' },
    { key: 'trend', label: 'Trend', type: 'text' },
    { key: 'trend_delta', label: 'Trend-Delta', type: 'num' },
    { key: 'verwandte_keywords', label: 'Graph-Nachbarn', type: 'text' },
    { key: 'serp_gemessen_am', label: 'SERP gemessen am', type: 'datetime' },
    { key: 'serp_lauf_id', label: 'SERP Lauf-ID', type: 'text' },
    { key: 'serp_sichtbare_treffer', label: 'Sichtbare Treffer', type: 'int' },
    { key: 'serp_gesamt_ergebnis', label: 'Ergebniszahl (Seite)', type: 'int' },
    { key: 'serp_gesamt_text', label: 'Ergebnistext (roh)', type: 'text' },
    { key: 'serp_anzeigen', label: 'Anzeigen Stichprobe', type: 'int' },
    { key: 'serp_anzeigenquote_prozent', label: 'Anzeigenquote %', type: 'num' },
    { key: 'serp_preis_min', label: 'Preis min', type: 'money' },
    { key: 'serp_preis_median', label: 'Preis Median', type: 'money' },
    { key: 'serp_preis_max', label: 'Preis max', type: 'money' },
    { key: 'serp_gekauft_summe', label: 'Verkaeufe/Monat (Seite)', type: 'int' },
    { key: 'serp_gekauft_max', label: 'Verkaeufe/Monat (Spitze)', type: 'int' },
    { key: 'serp_url', label: 'SERP-Beleg-URL', type: 'text' },
    { key: 'datenquelle', label: 'Datenquelle', type: 'text' },
    { key: 'belegart',    label: 'Belegart',    type: 'text' },
    { key: 'search_volume', label: 'Suchvolumen', type: 'int' },
    { key: 'zeitraum',    label: 'Zeitraum',    type: 'text' },
    { key: 'score_methode', label: 'Score-Methode', type: 'text' }
  ];

  var KEYWORD_EVIDENCE_FIELDS = [
    { key: 'beobachtet_am', label: 'Beobachtet am', type: 'datetime' },
    { key: 'batch_id', label: 'Batch-ID', type: 'text' },
    { key: 'lauf_id', label: 'Lauf-ID', type: 'text' },
    { key: 'api_abruf_id', label: 'API-Abruf-ID', type: 'text' },
    { key: 'plattform', label: 'Plattform', type: 'text' },
    { key: 'plattform_id', label: 'Plattform-ID', type: 'text' },
    { key: 'seed', label: 'Seed', type: 'text' },
    { key: 'such_prefix', label: 'Exaktes Suchpraefix', type: 'text' },
    { key: 'keyword', label: 'Antwort-Keyword', type: 'text' },
    { key: 'position', label: 'Echter Antwortrang', type: 'int' },
    { key: 'antwort_anzahl', label: 'Antwortgroesse', type: 'int' },
    { key: 'datenquelle', label: 'Datenquelle', type: 'text' },
    { key: 'abrufart', label: 'Abrufart', type: 'text' },
    { key: 'beleg_url', label: 'First-Party-Beleg-URL', type: 'text' }
  ];

  var KEYWORD_RUN_FIELDS = [
    { key: 'gestartet_am', label: 'Gestartet am', type: 'datetime' },
    { key: 'beendet_am', label: 'Beendet am', type: 'datetime' },
    { key: 'batch_id', label: 'Batch-ID', type: 'text' },
    { key: 'lauf_id', label: 'Lauf-ID', type: 'text' },
    { key: 'plattform', label: 'Plattform', type: 'text' },
    { key: 'seed', label: 'Seed', type: 'text' },
    { key: 'modus', label: 'Modus', type: 'text' },
    { key: 'prefixe_gesamt', label: 'Praefixe geplant', type: 'int' },
    { key: 'prefixe_mit_treffern', label: 'Praefixe mit Treffern', type: 'int' },
    { key: 'beobachtungen', label: 'Beobachtungen', type: 'int' },
    { key: 'status', label: 'Status', type: 'text' },
    { key: 'fehler', label: 'Fehler', type: 'text' }
  ];

  var KEYWORD_SERP_FIELDS = [
    { key: 'gemessen_am', label: 'Gemessen am', type: 'datetime' },
    { key: 'batch_id', label: 'Batch-ID', type: 'text' },
    { key: 'lauf_id', label: 'Lauf-ID', type: 'text' },
    { key: 'plattform', label: 'Plattform', type: 'text' },
    { key: 'seed', label: 'Seed', type: 'text' },
    { key: 'keyword', label: 'Keyword', type: 'text' },
    { key: 'sichtbare_treffer', label: 'Sichtbare Treffer', type: 'int' },
    { key: 'gesamt_ergebnis', label: 'Ergebniszahl (Seite)', type: 'int' },
    { key: 'gesamt_text', label: 'Ergebnistext (roh)', type: 'text' },
    { key: 'anzeigen', label: 'Anzeigen Stichprobe', type: 'int' },
    { key: 'anzeigenquote_prozent', label: 'Anzeigenquote %', type: 'num' },
    { key: 'preis_stichprobe', label: 'Preise Stichprobe', type: 'int' },
    { key: 'preis_min', label: 'Preis min', type: 'money' },
    { key: 'preis_median', label: 'Preis Median', type: 'money' },
    { key: 'preis_max', label: 'Preis max', type: 'money' },
    // Echte Monatsverkaeufe, die Amazon selbst je Treffer nennt ("X mal im
    // letzten Monat gekauft"). Steht nicht bei jedem Treffer - gekauft_treffer
    // sagt bei wie vielen, damit die Summe nie als vollstaendig gelesen wird.
    { key: 'gekauft_summe', label: 'Verkaeufe/Monat (Summe Seite)', type: 'int' },
    { key: 'gekauft_max', label: 'Verkaeufe/Monat (Spitzenreiter)', type: 'int' },
    { key: 'gekauft_treffer', label: 'Treffer mit Kaufzahl', type: 'int' },
    { key: 'blockiert', label: 'Blockiert', type: 'text' },
    { key: 'datenquelle', label: 'Datenquelle', type: 'text' },
    { key: 'beleg_url', label: 'Beleg-URL', type: 'text' }
  ];

  var KEYWORD_API_FIELDS = [
    { key: 'abgerufen_am', label: 'Abgerufen am', type: 'datetime' },
    { key: 'batch_id', label: 'Batch-ID', type: 'text' },
    { key: 'lauf_id', label: 'Lauf-ID', type: 'text' },
    { key: 'abruf_id', label: 'API-Abruf-ID', type: 'text' },
    { key: 'plattform', label: 'Plattform / Quelle', type: 'text' },
    { key: 'plattform_id', label: 'Plattform-ID', type: 'text' },
    { key: 'seed', label: 'Seed', type: 'text' },
    { key: 'such_prefix', label: 'Exakte Eingabe', type: 'text' },
    { key: 'messwert_typ', label: 'Messwert-Typ', type: 'text' },
    { key: 'messwert_wert', label: 'Messwert', type: 'num' },
    { key: 'einheit', label: 'Einheit', type: 'text' },
    { key: 'zeitraum', label: 'Zeitraum', type: 'text' },
    { key: 'methode', label: 'HTTP-Methode', type: 'text' },
    { key: 'request_url', label: 'Request-URL / Endpoint + Parameter', type: 'text' },
    { key: 'http_status', label: 'HTTP-Status', type: 'int' },
    { key: 'content_type', label: 'Content-Type', type: 'text' },
    { key: 'antwort_hash_sha256', label: 'Antwort SHA-256', type: 'text' },
    { key: 'antwort_auszug', label: 'Rohantwort-Auszug', type: 'text' },
    { key: 'antwort_gekuerzt', label: 'Antwort gekuerzt?', type: 'text' },
    { key: 'abrufart', label: 'Abrufart', type: 'text' },
    { key: 'zugaenglichkeit', label: 'Zugaenglichkeit', type: 'text' }
  ];

  var KEYWORD_METHOD_FIELDS = [
    { key: 'bereich', label: 'Bereich', type: 'text' },
    { key: 'kennzahl', label: 'Kennzahl / Feld', type: 'text' },
    { key: 'bedeutung', label: 'Bedeutung', type: 'text' },
    { key: 'berechnung', label: 'Berechnung', type: 'text' },
    { key: 'nachweis', label: 'Wo nachpruefbar?', type: 'text' },
    { key: 'einschraenkung', label: 'Einschraenkung', type: 'text' }
  ];

  function keywordMethodRows() {
    return [
      {
        bereich: 'Rueckverfolgung', kennzahl: 'Lauf-ID',
        bedeutung: 'Verbindet die Auswertung im Blatt Keywords mit den unveraenderten Rohdaten.',
        berechnung: 'Eine eindeutige ID je Seed, Plattform und Messlauf.',
        nachweis: 'Keywords -> Zugehoerige Lauf-IDs und API-Abruf-IDs; danach Keyword-Belege, Keyword-API-Belege, Keyword-Laeufe und Keyword-Marktdaten filtern.',
        einschraenkung: 'Beim manuellen Loeschen eines Keywords werden seine Rohbelege ebenfalls entfernt.'
      },
      {
        bereich: 'API-Rueckverfolgung', kennzahl: 'API-Abruf-ID / SHA-256',
        bedeutung: 'Verbindet jeden aus einer API-Antwort abgeleiteten Keyword-Wert mit dem konkreten Abruf und dessen unveraenderlichem Antwort-Fingerabdruck.',
        berechnung: 'Eine ID je Request; SHA-256 ueber die empfangene Rohantwort vor der Auswertung.',
        nachweis: 'Keyword-API-Belege: Request-URL inklusive Parameter, Zeitpunkt, HTTP-Status, Einheit, Zeitraum, SHA-256 und Rohantwort-Auszug.',
        einschraenkung: 'Bei UI-geschuetzten Endpunkten ist der Abruf nur im echten First-Party-Seitenfluss reproduzierbar.'
      },
      {
        bereich: 'Autocomplete', kennzahl: 'Echter Antwortrang',
        bedeutung: 'Position des Keywords in der originalen First-Party-Antwort fuer ein exaktes Praefix.',
        berechnung: '1-basierter Array-Index der Antwort; keine Position nach nachtraeglicher Deduplizierung.',
        nachweis: 'Keyword-Belege: Exaktes Suchpraefix, Antwort-Keyword, Echter Antwortrang, Antwortgroesse und Beleg-URL.',
        einschraenkung: 'Autocomplete-Rang ist ein Nachfragesignal, aber kein absolutes Suchvolumen.'
      },
      {
        bereich: 'Autocomplete', kennzahl: 'Rangstaerke 0-100',
        bedeutung: 'Normalisiert unterschiedliche Antwortgroessen; Rang 1 ist 100.',
        berechnung: '100 x (Antwortgroesse - Rang) / (Antwortgroesse - 1); bei nur einer Antwort = 100.',
        nachweis: 'Keywords sowie die zugrunde liegenden Raenge im Blatt Keyword-Belege.',
        einschraenkung: 'Plattformen koennen ihre Sortierlogik jederzeit aendern.'
      },
      {
        bereich: 'Demand Graph', kennzahl: 'Praefixbreite %',
        bedeutung: 'Wie viele unterschiedliche abgefragte Praefixe dasselbe Keyword hervorbrachten.',
        berechnung: 'Eindeutige Treffer-Praefixe / maximal geplante Praefixe des Laufs x 100.',
        nachweis: 'Keywords -> Praefix-Rang-Belege; Laufumfang in Keyword-Laeufe.',
        einschraenkung: 'Schnellmodus hat nur ein Praefix und ist deshalb weniger aussagekraeftig.'
      },
      {
        bereich: 'Demand Graph', kennzahl: 'Persistenz %',
        bedeutung: 'Anteil der vergleichbaren Laeufe, in denen das Keyword erneut auftauchte.',
        berechnung: 'Laeufe mit Keyword / alle Laeufe fuer dieselbe Plattform und denselben Seed x 100.',
        nachweis: 'Keyword-Laeufe und Keyword-Belege ueber die Lauf-ID verbinden.',
        einschraenkung: 'Ein einziger Lauf ergibt rechnerisch 100% Persistenz, aber nur geringe Confidence.'
      },
      {
        bereich: 'Demand Graph', kennzahl: 'Marktplatz-Konsens',
        bedeutung: 'Auf wie vielen abgefragten Marktplaetzen exakt dieselbe Phrase fuer denselben Seed vorkam.',
        berechnung: 'Marktplaetze mit Phrase / fuer den Seed abgefragte Marktplaetze.',
        nachweis: 'Keywords -> Konsens-Plattformen; einzelne Belege in Keyword-Belege.',
        einschraenkung: 'Nur exakte normalisierte Phrasen zaehlen; Synonyme werden nicht kuenstlich gleichgesetzt.'
      },
      {
        bereich: 'Demand Graph', kennzahl: 'Demand-Signal 0-100',
        bedeutung: 'Ungewichtete Staerke der beobachteten Autocomplete-Signale.',
        berechnung: '45% Rangstaerke + 20% Praefixbreite + 20% Persistenz + 15% Marktplatz-Konsens.',
        nachweis: 'Alle Einzelkomponenten stehen in derselben Keywords-Zeile.',
        einschraenkung: 'Signalstaerke allein sagt noch nichts ueber die Breite des Belegs.'
      },
      {
        bereich: 'Demand Graph', kennzahl: 'Confidence 0-100',
        bedeutung: 'Breite und Wiederholbarkeit des vorhandenen Belegs.',
        berechnung: '45% min(1, Laeufe/3) + 30% min(1, Marktplaetze/3) + 25% min(1, Beobachtungen/6).',
        nachweis: 'Laeufe und Beobachtungen in Keywords; Rohdaten in den drei Nachweisblaettern.',
        einschraenkung: 'Confidence bewertet Belegdichte, nicht die Nachfrage selbst.'
      },
      {
        bereich: 'Demand Graph', kennzahl: 'Demand Graph 0-100',
        bedeutung: 'Confidence-gewichtetes Gesamtsignal; ein Einzellauf kann deshalb nicht als sichere 100 erscheinen.',
        berechnung: 'Demand-Signal x Confidence / 100.',
        nachweis: 'Keywords: Demand-Signal, Confidence, Demand Graph und Score-Methode.',
        einschraenkung: 'Eigener transparenter Index, kein vom Marktplatz veroeffentlichtes Suchvolumen.'
      },
      {
        bereich: 'Trend', kennzahl: 'Trend / Trend-Delta',
        bedeutung: 'Aenderung der normalisierten Rangstaerke zwischen den letzten beiden Laeufen.',
        berechnung: 'Letzter Lauf minus vorheriger Lauf; ab +8 steigend, bis -8 fallend, sonst stabil.',
        nachweis: 'Keywords sowie zeitlich sortierte Keyword-Belege und Keyword-Laeufe.',
        einschraenkung: 'Mit weniger als zwei Laeufen lautet der Trend neu.'
      },
      {
        bereich: 'Direkte Marktdaten', kennzahl: 'Sichtbare Treffer / Ergebniszahl',
        bedeutung: 'Produktkacheln der geladenen SERP und, sofern sichtbar, die vom Marktplatz eingeblendete Gesamtzahl.',
        berechnung: 'DOM-Kacheln zaehlen; Gesamtzahl aus dem unveraendert gespeicherten Ergebnistext lesen.',
        nachweis: 'Keyword-Marktdaten: Sichtbare Treffer, Ergebnistext roh und Beleg-URL.',
        einschraenkung: 'Lazy Loading, Personalisierung und A/B-Tests koennen die sichtbare Zahl veraendern.'
      },
      {
        bereich: 'Direkte Marktdaten', kennzahl: 'Anzeigenquote %',
        bedeutung: 'Werbedruck in der auf der ersten Suchseite ausgelesenen Stichprobe.',
        berechnung: 'Als gesponsert markierte Kacheln / ausgelesene Produktkacheln x 100.',
        nachweis: 'Keyword-Marktdaten: Anzeigen Stichprobe, Anzeigenquote und SERP-Beleg-URL.',
        einschraenkung: 'Keine Hochrechnung auf alle Ergebnisse oder alle Nutzer.'
      },
      {
        bereich: 'Direkte Marktdaten', kennzahl: 'Preis min / Median / max',
        bedeutung: 'Direktes Preisband der auslesbaren Produktkacheln auf der geladenen SERP.',
        berechnung: 'Minimum, Median und Maximum aller erfolgreich gelesenen Kachelpreise.',
        nachweis: 'Keyword-Marktdaten: Preise Stichprobe, Preiswerte und Beleg-URL.',
        einschraenkung: 'Produktvarianten, Versand und personalisierte Preise koennen abweichen.'
      },
      {
        bereich: 'Suchvolumen', kennzahl: 'Search Volume',
        bedeutung: 'Absolutes Suchvolumen nur aus einer explizit benannten offiziellen oder lizenzierten Quelle.',
        berechnung: 'Ohne angeschlossenen Provider bleibt das Feld leer.',
        nachweis: 'Keywords: Suchvolumen, Zeitraum und Datenquelle.',
        einschraenkung: 'Autocomplete- oder SERP-Werte werden niemals in ein erfundenes Volumen umgerechnet.'
      }
    ];
  }

  var PRO_FIELDS = [
    { key: 'geprueft_am',          label: 'Geprueft am',            type: 'datetime' },
    { key: 'asin',                 label: 'ASIN',                   type: 'text' },
    // Das Urteil zuerst - es ist der Grund, warum man die Zeile aufmacht.
    { key: 'urteil',               label: 'Urteil',                 type: 'text' },
    { key: 'guenstigster_preis',   label: 'Guenstigster (belegt)',  type: 'money' },
    { key: 'guenstigster_gesamt',  label: 'davon Gesamt inkl. Versand', type: 'money' },
    { key: 'guenstigste_plattform', label: 'wo',                    type: 'text' },
    /* Kernzahl: negativ = jemand unterbietet wirklich; null/positiv = niemand,
       ein niedrigerer Referenzwert von Amazon ist dann kein Regalpreis. */
    { key: 'luecke',               label: 'Abstand zum eigenen Preis', type: 'money' },
    { key: 'anbieter_extern',      label: 'externe Anbieter',       type: 'int' },
    { key: 'wettbewerb',           label: 'Wettbewerbsfeld',        type: 'text' },
    { key: 'guenstigster_beleg',   label: 'Identitaetsnachweis',    type: 'text' },
    { key: 'guenstigster_url',     label: 'Beleg-URL',              type: 'text' },
    { key: 'bestaetigte',          label: 'belegte Treffer',        type: 'int' },
    { key: 'kandidaten',           label: 'Kandidaten gesamt',      type: 'int' },
    { key: 'verworfen',            label: 'verworfen (Grund)',      type: 'text' },
    { key: 'stammsatz',            label: 'Stammsatz',              type: 'text' },
    { key: 'buybox',               label: 'Buybox',                 type: 'text' },
    { key: 'buybox_verkaeufer',    label: 'Buybox-Verkaeufer',      type: 'text' },
    { key: 'beleg',                label: 'Beleg (Seitenmerkmale)', type: 'text' },
    { key: 'aplus',                label: 'A+ Content',             type: 'text' },
    { key: 'angebote_anzahl',      label: 'Angebote',               type: 'int' },
    { key: 'angebot_min',          label: 'Angebot min',            type: 'money' },
    { key: 'angebot_max',          label: 'Angebot max',            type: 'money' },
    { key: 'anbieter',             label: 'Anbieter',               type: 'text' },
    { key: 'varianten',            label: 'Varianten',              type: 'text' },
    { key: 'varianten_ohne_aplus', label: 'Varianten ohne A+',      type: 'text' },
    { key: 'fehler',               label: 'Fehler',                 type: 'text' },
    { key: 'url',                  label: 'URL',                    type: 'text' }
  ];

  // Excel-Zahlenformate. Die Codes sind immer englisch notiert; Excel zeigt sie
  // anschliessend lokalisiert an (0.00 -> 0,00 auf deutschem System).
  var FMT = {
    money: '#,##0.00 "' + '€' + '"',
    num: '0.0',
    int: '#,##0',
    datetime: 'dd.mm.yyyy hh:mm'
  };

  // Spaltenbreiten in Zeichen. Lange Textfelder werden gedeckelt,
  // sonst ist die Tabelle nicht mehr bedienbar.
  var WIDTH = {
    erfasst_am: 16, plattform: 11, produkt_id: 15, ean: 15, sku: 14, mpn: 14,
    marke: 16, titel: 60, titel_laenge: 8,
    item_highlights: 55, item_highlights_laenge: 10,
    preis: 11, waehrung: 8, uvp: 12,
    rabatt_prozent: 8, preis_text: 14, versand: 20, verfuegbarkeit: 18,
    lieferzeit: 20, verkaeufer: 20, bewertung: 9, anzahl_bewertungen: 10,
    bullets_anzahl: 8, bullets_weitere: 40, beschreibung_laenge: 10,
    beschreibung: 60, bilder_anzahl: 8, bilder_urls: 40, eigenschaften_anzahl: 8,
    eigenschaften: 60, eig_material: 18, eig_farbe: 12, eig_masse: 20, eig_gewicht: 12,
    attribute: 50, top_keywords: 45, kategorie: 30, varianten: 20,
    warnungen: 45, url: 45,
    // Produktbetreuer-Spalten
    aplus: 16, buybox: 14, andere_angebote: 28,
    // Blatt "Suchtreffer"
    gesucht_am: 16, suchbegriff: 16, suchtyp: 7, position: 6,
    gesponsert: 10, treffer_gesamt: 9,
    // Blaetter "Keywords" / "Keyword-Matrix"
    gefunden_am: 16, seed: 20, keyword: 34, treffer_listings: 12, fehlt_bei: 34,
    beobachtet_am: 16, gemessen_am: 16, gestartet_am: 16, beendet_am: 16,
    batch_id: 27, lauf_id: 34, abruf_id: 38, api_abruf_id: 38, api_abruf_ids: 70,
    plattform_id: 13, such_prefix: 30,
    antwort_anzahl: 13, beleg_url: 52, abrufart: 25, datenquelle: 28,
    beste_position: 10, mittlere_position: 12, beobachtungen: 13, praefixe: 9,
    praefix_abdeckung_prozent: 15, laeufe: 8, lauf_persistenz_prozent: 13,
    marktplatz_konsens: 15, konsens_plattformen: 24, rangstaerke_0_100: 14,
    demand_signal_0_100: 15, demand_graph_index_0_100: 15, confidence_0_100: 13, trend: 10,
    lauf_ids: 42, prefix_rang_belege: 70, autocomplete_beleg_urls: 70,
    serp_lauf_id: 42,
    trend_delta: 11, verwandte_keywords: 55, serp_gemessen_am: 16,
    serp_sichtbare_treffer: 13, serp_gesamt_ergebnis: 16, serp_gesamt_text: 34,
    serp_anzeigen: 13, serp_anzeigenquote_prozent: 14, serp_preis_min: 12,
    serp_preis_median: 12, serp_preis_max: 12, serp_url: 52,
    score_methode: 70, prefixe_gesamt: 14, prefixe_mit_treffern: 16,
    gesamt_ergebnis: 16, gesamt_text: 34, anzeigen: 12,
    anzeigenquote_prozent: 14, preis_stichprobe: 13, preis_min: 12,
    preis_median: 12, preis_max: 12, status: 10,
    bereich: 19, kennzahl: 27, bedeutung: 62, berechnung: 70,
    nachweis: 70, einschraenkung: 62,
    abgerufen_am: 16, messwert_typ: 24, messwert_wert: 12, einheit: 28,
    methode: 12, request_url: 70, http_status: 12, content_type: 24,
    antwort_hash_sha256: 66, antwort_auszug: 80, antwort_gekuerzt: 16,
    zugaenglichkeit: 34,
    // Blatt "Buybox & Angebote"
    geprueft_am: 16, asin: 13, buybox_verkaeufer: 20, beleg: 46,
    urteil: 52, guenstigster_preis: 15, guenstigster_gesamt: 16,
    guenstigste_plattform: 12, luecke: 14, anbieter_extern: 9, wettbewerb: 70,
    guenstigster_beleg: 44, guenstigster_url: 40, bestaetigte: 10,
    kandidaten: 10, verworfen: 52, stammsatz: 34,
    match_stufe: 13, match_bestaetigt: 10, match_grund: 46,
    angebote_anzahl: 9, angebot_min: 12, angebot_max: 12, anbieter: 60,
    varianten_ohne_aplus: 26, fehler: 26
  };

  var isEmpty = function (v) {
    return v == null || v === '' || (typeof v === 'number' && !isFinite(v));
  };

  // Text-Zelle. Fuehrendes = / + / - wuerde Excel als Formel deuten,
  // deshalb bei solchen Werten ein Apostroph-freies Vorzeichen erzwingen.
  var textCell = function (v) {
    var s = String(v);
    if (/^[=+\-@]/.test(s)) s = "'" + s;
    return { t: 's', v: s };
  };

  function makeCell(value, type) {
    if (isEmpty(value)) return null;

    if (type === 'datetime') {
      var d = value instanceof Date ? value : new Date(value);
      if (isNaN(d.getTime())) return textCell(value);
      return { t: 'd', v: d, z: FMT.datetime };
    }

    if (type === 'money' || type === 'num' || type === 'int') {
      var n = typeof value === 'number' ? value : LC.parseNum(value);
      if (n == null || !isFinite(n)) return isEmpty(value) ? null : textCell(value);
      return { t: 'n', v: n, z: FMT[type] };
    }

    return textCell(value);
  }

  function makeSheet(XLSX, fields, rows) {
    var ws = {};

    // Kopfzeile
    for (var c = 0; c < fields.length; c++) {
      ws[XLSX.utils.encode_cell({ c: c, r: 0 })] = { t: 's', v: fields[c].label };
    }

    // Datenzeilen
    for (var r = 0; r < rows.length; r++) {
      for (var c2 = 0; c2 < fields.length; c2++) {
        var f = fields[c2];
        var cell = makeCell(rows[r][f.key], f.type);
        if (cell) ws[XLSX.utils.encode_cell({ c: c2, r: r + 1 })] = cell;
      }
    }

    ws['!ref'] = XLSX.utils.encode_range({
      s: { c: 0, r: 0 }, e: { c: fields.length - 1, r: rows.length }
    });
    ws['!cols'] = fields.map(function (f) { return { wch: WIDTH[f.key] || 16 }; });
    ws['!rows'] = [{ hpt: 22 }];
    ws['!freeze'] = { xSplit: 0, ySplit: 1 };
    ws['!autofilter'] = { ref: ws['!ref'] };
    return ws;
  }

  // Nicht ueberlappende Vorkommen einer Wortfolge zaehlen.
  function countOcc(hay, needle) {
    if (!needle) return 0;
    var n = 0, i = 0;
    while ((i = hay.indexOf(needle, i)) !== -1) { n++; i += needle.length; }
    return n;
  }

  // Der durchsuchbare Text eines Listings: alles, was Amazon indexiert.
  function listingText(r) {
    var parts = [r.titel, r.beschreibung, r.eigenschaften || r.attribute, r.bullets_weitere, r.kategorie];
    for (var i = 1; i <= 8; i++) parts.push(r['bullet_' + i]);
    return ' ' + parts.filter(Boolean).join(' ').toLowerCase().replace(/\s+/g, ' ') + ' ';
  }

  /* Keyword x Listing. Spalte je Listing, Wert = Anzahl der Vorkommen,
     dazu "fehlt bei" - das ist die eigentliche Arbeitsspalte. */
  function buildMatrix(rows, keywords) {
    var listings = (rows || []).filter(function (r) { return r && String(r.titel || '').trim(); });
    var uniq = [], seen = Object.create(null);
    (keywords || []).forEach(function (k) {
      var v = String(k.keyword || '').trim().toLowerCase();
      if (v && !seen[v]) { seen[v] = 1; uniq.push(v); }
    });
    if (!listings.length || !uniq.length) return null;

    var texts = listings.map(listingText);
    var cols = listings.map(function (r, i) {
      return {
        key: 'l' + i,
        label: r.produkt_id || r.sku || r.ean || (r.plattform + ' ' + (i + 1)),
        type: 'int'
      };
    });
    var fields = [{ key: 'keyword', label: 'Keyword', type: 'text' }]
      .concat(cols)
      .concat([
        { key: 'treffer_listings', label: 'in Listings', type: 'int' },
        { key: 'fehlt_bei',        label: 'fehlt bei',   type: 'text' }
      ]);

    var out = uniq.map(function (kw) {
      var row = { keyword: kw }, fehlt = [], n = 0;
      texts.forEach(function (t, i) {
        var c = countOcc(t, kw);
        row['l' + i] = c;
        if (c) n++; else fehlt.push(cols[i].label);
      });
      row.treffer_listings = n;
      row.fehlt_bei = fehlt.join(', ');
      return row;
    });

    // Luecken zuerst: was nirgends vorkommt, ist die interessanteste Zeile.
    out.sort(function (a, b) {
      return a.treffer_listings - b.treffer_listings ||
             (a.keyword < b.keyword ? -1 : a.keyword > b.keyword ? 1 : 0);
    });
    return { fields: fields, rows: out };
  }

  /* Baut die Arbeitsmappe.
     rows    = Listings aus LC.extract()            -> Blatt "Listings"
     matches = Suchtreffer aus LC.search (optional) -> Blatt "Suchtreffer"
     extra   = { keywords, keywordEvidence, keywordRuns, keywordSerpMeasurements, keywordApiEvidence,
                 pro } (optional)                    -> Analyse- und Rohdatenblaetter */
  function buildWorkbook(XLSX, rows, matches, extra) {
    extra = extra || {};
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, makeSheet(XLSX, LC.FIELDS, rows || []), SHEET);

    if (matches && matches.length && LC.search) {
      XLSX.utils.book_append_sheet(wb, makeSheet(XLSX, LC.search.MATCH_FIELDS, matches), SHEET_MATCHES);
    }

    if (extra.keywords && extra.keywords.length) {
      XLSX.utils.book_append_sheet(wb, makeSheet(XLSX, KEYWORD_FIELDS, extra.keywords), SHEET_KEYWORDS);
      var m = buildMatrix(rows, extra.keywords);
      if (m) XLSX.utils.book_append_sheet(wb, makeSheet(XLSX, m.fields, m.rows), SHEET_MATRIX);
    }

    if ((extra.keywords && extra.keywords.length) ||
        (extra.keywordEvidence && extra.keywordEvidence.length) ||
        (extra.keywordRuns && extra.keywordRuns.length) ||
        (extra.keywordSerpMeasurements && extra.keywordSerpMeasurements.length) ||
        (extra.keywordApiEvidence && extra.keywordApiEvidence.length)) {
      XLSX.utils.book_append_sheet(wb,
        makeSheet(XLSX, KEYWORD_METHOD_FIELDS, keywordMethodRows()), SHEET_KEYWORD_METHOD);
    }

    if (extra.keywordEvidence && extra.keywordEvidence.length) {
      XLSX.utils.book_append_sheet(wb,
        makeSheet(XLSX, KEYWORD_EVIDENCE_FIELDS, extra.keywordEvidence), SHEET_KEYWORD_EVIDENCE);
    }
    if (extra.keywordRuns && extra.keywordRuns.length) {
      XLSX.utils.book_append_sheet(wb,
        makeSheet(XLSX, KEYWORD_RUN_FIELDS, extra.keywordRuns), SHEET_KEYWORD_RUNS);
    }
    if (extra.keywordSerpMeasurements && extra.keywordSerpMeasurements.length) {
      XLSX.utils.book_append_sheet(wb,
        makeSheet(XLSX, KEYWORD_SERP_FIELDS, extra.keywordSerpMeasurements), SHEET_KEYWORD_SERP);
    }
    if (extra.keywordApiEvidence && extra.keywordApiEvidence.length) {
      XLSX.utils.book_append_sheet(wb,
        makeSheet(XLSX, KEYWORD_API_FIELDS, extra.keywordApiEvidence), SHEET_KEYWORD_API);
    }

    if (extra.pro && extra.pro.length) {
      XLSX.utils.book_append_sheet(wb, makeSheet(XLSX, PRO_FIELDS, extra.pro), SHEET_PRO);
    }

    // Fenster fixieren, damit die Kopfzeile beim Scrollen stehen bleibt.
    wb.Workbook = wb.Workbook || {};
    wb.Workbook.Views = [{ RTL: false }];

    return wb;
  }

  // listings_2026-07-30_2015.xlsx
  function defaultFilename(now) {
    var d = now || new Date();
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return 'listings_' + d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) +
           '_' + p(d.getHours()) + p(d.getMinutes()) + '.xlsx';
  }

  LC.buildWorkbook = buildWorkbook;
  LC.buildMatrix = buildMatrix;
  LC.defaultFilename = defaultFilename;
  LC.SHEET = SHEET;
  LC.SHEET_MATCHES = SHEET_MATCHES;
  LC.KEYWORD_FIELDS = KEYWORD_FIELDS;
  LC.KEYWORD_EVIDENCE_FIELDS = KEYWORD_EVIDENCE_FIELDS;
  LC.KEYWORD_RUN_FIELDS = KEYWORD_RUN_FIELDS;
  LC.KEYWORD_SERP_FIELDS = KEYWORD_SERP_FIELDS;
  LC.KEYWORD_API_FIELDS = KEYWORD_API_FIELDS;
  LC.KEYWORD_METHOD_FIELDS = KEYWORD_METHOD_FIELDS;
  LC.keywordMethodRows = keywordMethodRows;
  LC.PRO_FIELDS = PRO_FIELDS;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { buildWorkbook: buildWorkbook, defaultFilename: defaultFilename };
  }
})();
