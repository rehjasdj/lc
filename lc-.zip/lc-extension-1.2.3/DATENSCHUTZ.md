# Datenschutz- und Verarbeitungsdokumentation — Listing Checker

Diese Erweiterung verarbeitet **keine personenbezogenen Daten gezielt**. Sie wertet
öffentlich zugängliche Produkt- und Marktdaten aus. Da die erzeugten Excel-Dateien
an Kolleg:innen weitergegeben, gezeigt und gemeinsam bearbeitet werden, ist die
Verarbeitung hier nachvollziehbar dokumentiert. Dieselbe Dokumentation liegt als
Blatt **„Datenschutz"** in jedem Export bei.

## Zweck
Analyse eigener Marktplatz-Listings, Wettbewerbspreise (Buybox) und
Keyword-/Nachfrage-Recherche zur Sortiments- und Preispflege.

## Verantwortlicher
*[vom Unternehmen einzutragen]* — der einsetzende Betrieb.

## Verarbeitete Datenkategorien
- **Produkt-/Angebotsdaten**: Titel, Marke, EAN/Artikelnummer, Preis, Maße.
- **Marktdaten**: Autocomplete-Ränge, Nachfrage-Signale, Kaufzahlen, Anzeigenquote, Preisbänder.
- **Technische Belege**: URLs, Zeitstempel, HTTP-Status, SHA-256-Hashes der Rohantworten.

## Personenbezug
Es werden **keine** personenbezogenen Daten gezielt erhoben, angereichert oder
profiliert. Öffentlich sichtbare Verkäufer-/Anbieternamen können nur im optionalen
Buybox-Modul erscheinen; sie werden nicht ausgewertet und nur lokal gehalten.

## Herkunft
Öffentlich zugängliche Marktplatzseiten und deren First-Party-Autocomplete-APIs,
abgerufen im eingeloggten Browser des Nutzers (keine fremden Konten).

## Speicherung, Aufbewahrung, Volatilität
- Ausschließlich **lokal** im Browserprofil dieses Geräts (`chrome.storage.local`).
  Keine Cloud, keine Datenbank, kein Server.
- Übersteht Browser-Neustarts, **geht aber verloren** bei Deinstallation,
  Profil-Reset oder Klick auf „Leeren".
- **Dauerhaftes Archiv ist ausschließlich die exportierte `.xlsx`-Datei** unter
  Kontrolle des Nutzers. Es gibt kein automatisches Server-Backup. Wer Läufe über
  längere Zeit sammeln will, sichert sie über den Export und lädt sie bei Bedarf
  per **Import .xlsx** wieder ein — die Daten werden dabei zusammengeführt, sodass
  die Datei ein Storage-Clearing übersteht und Historie erhalten bleibt.

## Übermittlung an Dritte
**Keine.** Keine externen Dienste, kein Tracking, keine Analytics. Ein
Test-Report-Pfad existiert nur im `[TEST]`-Build und sendet ausschließlich an
`localhost` (127.0.0.1).

## Weitergabe der Export-Datei
Die `.xlsx` wird lokal erzeugt. Jede Weitergabe (an Kolleg:innen etc.) erfolgt
allein durch den Nutzer und liegt in dessen Verantwortung. Empfehlung: vor dem
Teilen prüfen, ob das optionale Buybox-Blatt mit Verkäufernamen enthalten ist.

## Rechtsgrundlage
Soweit überhaupt personenbezogene Daten berührt werden: **Art. 6 Abs. 1 lit. f
DSGVO** (berechtigtes Interesse an der Analyse eigener Angebote und des Wettbewerbs).

## Berechtigungen (Datensparsamkeit)
Zugriff nur auf die konfigurierten Marktplatz-Domains (Amazon, eBay, Kaufland,
Otto, bol, Temu, deubaxxl). Keine unbeteiligten Websites, keine Standort-,
Kontakt- oder Kamerarechte.

## Betroffenenrechte
Da lokal und ohne gezielten Personenbezug primär durch „Leeren"/Deinstallation und
Löschen der Export-Datei erfüllbar.
