/* Listing Checker - Identitaetspruefung fuer plattformuebergreifende Treffer.

   Warum es das gibt: Ein Preis ohne Identitaetsnachweis ist nicht nur wertlos,
   er ist gefaehrlich. Die Suche liefert auf Otto und Temu regelmaessig einen
   AEHNLICHEN Artikel - manchmal kompletten Unsinn. Wird so ein Preis als
   "guenstiger" gemeldet, fuehrt das zu einer falschen Preisentscheidung oder
   zu einem Support-Case, der beim ersten Nachsehen auseinanderfaellt.

   Deshalb bekommt JEDER Treffer eine Stufe und eine Begruendung. Nur BESTAETIGT
   zaehlt in ein Urteil. Alles andere wird gezeigt, aber nicht gewertet.

   Stammsatz ist der eigene Shop (deubaxxl): dort stehen Artikelnummer, EAN und
   der kanonische Titel, mit dem dieselben Artikel auch auf den Marktplaetzen
   eingestellt sind.

   Setzt shared/extract.js voraus (globalThis.LC). */
(function () {
  'use strict';

  var LC = globalThis.LC || (typeof window !== 'undefined' ? window.LC : null);
  if (!LC) throw new Error('shared/extract.js muss vor shared/match.js geladen werden');

  /* Stufen, absteigend nach Beweiskraft. bestaetigt=true heisst: als derselbe
     Artikel belegt, nicht nur plausibel. */
  var STUFEN = {
    EAN:          { rang: 1, bestaetigt: true,  label: 'EAN identisch' },
    MPN:          { rang: 2, bestaetigt: true,  label: 'Artikelnummer identisch' },
    SHOPTITEL:    { rang: 3, bestaetigt: true,  label: 'Titel wie im Shop' },
    FINGERABDRUCK:{ rang: 4, bestaetigt: true,  label: 'Produktfingerabdruck stimmt' },
    MARKE_MASSE:  { rang: 5, bestaetigt: false, label: 'Marke + Masse stimmen' },
    SCHWACH:      { rang: 6, bestaetigt: false, label: 'nur Titelaehnlichkeit' },
    FREMD:        { rang: 7, bestaetigt: false, label: 'anderer Artikel' }
  };

  var norm = function (s) {
    return String(s == null ? '' : s)
      .toLowerCase()
      .replace(/[®™©]/g, ' ')
      .replace(/[×]/g, 'x')
      .replace(/[^a-z0-9äöüß.,x-]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  };

  var ziffern = function (s) { return String(s == null ? '' : s).replace(/\D/g, ''); };

  /* Masse und Mengen sind bei Moebeln der schaerfste Unterscheider: "70x70",
     "58x26x66cm", "30 kg", "3 Ablagen". Zwei Regale derselben Marke
     unterscheiden sich fast immer genau hier. */
  var masse = function (s) {
    var t = norm(s), out = [];
    /* Einheit muss Teil des Musters sein: ohne sie scheitert "70x70x73cm" an
       der Wortgrenze zwischen "73" und "cm" und wird gar nicht erkannt.
       Die Einheit wird anschliessend abgeschnitten, damit "70x70x73cm",
       "70x70x73 cm" und "70x70x73" denselben Schluessel ergeben. */
    /* Amazon schreibt die Kette in der Attributtabelle als "70T x 70B x 73H cm"
       bzw. "89L x 89B x 54H cm" - die Achsenbuchstaben kleben an der Zahl. Ohne
       das optionale [tbhlwd] blieb die einzige Massquelle, die Amazon
       zuverlaessig fuehrt (13/13 Seiten live 06.08.2026), komplett unlesbar. */
    var DIM = /\b\d{1,3}(?:[.,]\d)?\s?[tbhlwd]?\s?x\s?\d{1,3}(?:[.,]\d)?\s?[tbhlwd]?(?:\s?x\s?\d{1,3}(?:[.,]\d)?\s?[tbhlwd]?)?\s?(?:cm|mm|m)?\b/g;
    var dim = t.match(DIM) || [];
    dim.forEach(function (d) {
      out.push(d.replace(/\s+/g, '').replace(/[tbhlwd](?=x|$)/g, '').replace(/(cm|mm|m)$/, '')
                .replace(/[tbhlwd]$/, ''));
    });
    /* Massketten aus dem Text schneiden, BEVOR nach Einzelwerten gesucht wird:
       sonst wird die letzte Zahl von "70 x 70 x 73 cm" ein zweites Mal als
       "73cm" erfasst, und derselbe Artikel bekaeme je nach Schreibweise einen
       anderen Schluessel - der Vergleich wuerde dann grundlos scheitern. */
    var rest = t.replace(DIM, ' ');
    var einheit = rest.match(/\b\d{1,4}(?:[.,]\d+)?\s?(?:cm|mm|kg|g|ml|watt|w)\b/g) || [];
    einheit.forEach(function (e) { out.push(e.replace(/\s+/g, '')); });
    return out.filter(function (v, i, a) { return a.indexOf(v) === i; });
  };

  /* Zwei Massketten desselben Artikels muessen nicht gleich lang sein: der
     Shop schreibt "70x70x73", die Marktplatzkachel nur die Grundflaeche
     "70x70". Live 06.08.2026 hat genau das Otto UND Amazon als "andere Masse"
     verworfen - beides derselbe Tisch.
     Deshalb Teilmengenvergleich statt Gleichheit: passt jede Zahl der
     KUERZEREN Kette in die laengere, ist das kein Widerspruch. Die Reihenfolge
     bleibt bewusst unbeachtet, weil "70x73x70" (BxHxT) und "70x70x73" (LxBxH)
     denselben Koerper meinen. Jede Zahl wird nur einmal verbraucht - sonst
     wuerde "70x70" auch zu "70x45x30" passen. */
  function kettenPassen(a, b) {
    var A = String(a).split('x'), B = String(b).split('x');
    var kurz = A.length <= B.length ? A.slice() : B.slice();
    var lang = A.length <= B.length ? B.slice() : A.slice();
    for (var i = 0; i < kurz.length; i++) {
      var soll = parseFloat(String(kurz[i]).replace(',', '.'));
      var pos = -1;
      for (var j = 0; j < lang.length; j++) {
        var ist = parseFloat(String(lang[j]).replace(',', '.'));
        /* Marktplatztitel runden 195,5x59,5 regelmaessig auf 195x60. Ein
           Zentimeter Toleranz deckt das ab, trennt aber Modellgroessen weiter. */
        if (isFinite(soll) && isFinite(ist) && Math.abs(soll - ist) <= Math.max(1, soll * 0.02)) {
          pos = j; break;
        }
      }
      if (pos === -1) return false;
      lang.splice(pos, 1);
    }
    return true;
  }

  var tokens = function (s) {
    return norm(s).split(' ').filter(function (w) { return w.length > 2; });
  };

  /* Dice-Koeffizient ueber Token-Mengen: 0..1, symmetrisch, ohne Abhaengigkeit.
     Bewusst kein Levenshtein - bei Marktplatztiteln zaehlt Wortueberlappung,
     nicht Zeichenabstand. */
  function aehnlichkeit(a, b) {
    var A = tokens(a), B = tokens(b);
    if (!A.length || !B.length) return 0;
    var setB = Object.create(null);
    B.forEach(function (w) { setB[w] = (setB[w] || 0) + 1; });
    var treffer = 0;
    A.forEach(function (w) { if (setB[w]) { treffer++; setB[w]--; } });
    return (2 * treffer) / (A.length + B.length);
  }

  /* ---------------------------------------------------------- Fingerabdruck

     Warum nicht der Titel: Seit dem Amazon-Titelupdate (27.07.2026, 75 Zeichen)
     ist der Titel dort bewusst generisch - "Casaria Garten Beistelltisch
     FSC-Zertifiziert Wetterfest". Keine Masse, keine Nummer, kein Material.
     Der deubaxxl-Titel derselben Ware heisst "Beistelltisch Akazienholz
     70x70x73cm". Gemeinsam: EIN Wort. Wer ueber Titelaehnlichkeit sucht,
     findet den eigenen Artikel nicht - er findet, was zufaellig auch
     "Garten" und "FSC" im Titel hat (live 05.08.2026: Hochbeete, Gartenduschen).

     Identisch sind auf BEIDEN Seiten dagegen: EAN, Artikelnummer, Masse und
     Produkttyp. Masse stehen bei Amazon in den Bullets, der Produkttyp in der
     Breadcrumb. Beides erfassen wir laengst - benutzt hat es bisher niemand. */

  /* Felder, die Identitaet tragen koennen. Beschreibung bewusst NICHT: dort
     stehen Fremdmasse ("passend fuer Toepfe bis 30 cm"), die den Massfilter
     verwaessern - und der Massfilter ist das schaerfste Werkzeug, das wir haben. */
  function volltext(row) {
    var teile = [row.titel, row.item_highlights];
    for (var i = 1; i <= 8; i++) teile.push(row['bullet_' + i]);
    teile.push(row.bullets_weitere, row.eigenschaften || row.attribute,
      row.eig_masse, row.eig_gewicht, row.eig_belastbarkeit,
      row.eig_material, row.eig_lieferumfang,
      row.plattform === 'deubaxxl' || row.plattform === 'DeubaXXL' ? row.beschreibung : '');
    return teile.filter(Boolean).join(' \n ');
  }

  function materialien(text) {
    var t = norm(text);
    var gruppen = [
      ['akazie', 'akazienholz'], ['bambus'], ['aluminium', 'alu'], ['stahl'],
      ['polyester'], ['polyrattan', 'rattan'], ['kunststoff'], ['massivholz']
    ];
    return gruppen.filter(function (g) {
      return g.some(function (w) { return t.indexOf(w) > -1; });
    }).map(function (g) { return g[0]; });
  }

  /* 0 = Variantenfamilie/unklar. Gerade Temu buendelt Einzel- und 2er-Set
     unter einer URL; ohne ausgewaehlte Menge darf kein Variantenpreis zaehlen. */
  function setMenge(text) {
    var t = norm(text);
    if (/\beinzeln\b/.test(t) && /\b(?:2er|2 x|2x)\b/.test(t)) return 0;
    var m = t.match(/(?:^|\s)(\d{1,2})\s*x\s+[a-z]/) ||
            t.match(/\b(\d{1,2})er\s*[- ]?(?:set|pack)\b/) ||
            t.match(/\bset\s+(?:mit|aus)\s+(\d{1,2})\b/);
    return m ? Number(m[1]) : 1;
  }

  /* GTIN-8/12/13/14-Pruefziffer (Modulo 10, Gewichte 3-1 von rechts).
     Ohne sie waere das Lesen einer EAN aus Freitext Raterei - mit ihr ist es
     ein Beweis: eine zufaellige 13-stellige Zahl besteht sie mit 1:10, eine
     echte EAN immer. */
  function gtinGueltig(d) {
    if (!/^\d+$/.test(d) || [8, 12, 13, 14].indexOf(d.length) === -1) return false;
    var summe = 0;
    for (var i = d.length - 2; i >= 0; i--) {
      summe += Number(d[i]) * ((d.length - i) % 2 === 0 ? 3 : 1);
    }
    return (10 - (summe % 10)) % 10 === Number(d[d.length - 1]);
  }

  /* Amazon fuehrt die EAN oft nicht als Attribut, aber Deuba schreibt sie in
     die Bullets ("EAN: 4251776601793"). Ein gueltiger GTIN aus dem Fliesstext
     ist die staerkste Bruecke, die es gibt - und dank Pruefziffer sicher. */
  function findeEan(text) {
    var t = String(text || '');
    var pruefe = function (roh) {
      var d = roh.replace(/\D/g, '');
      // 14-stellige GTIN auf EAN-13 normalisieren (fuehrende 0).
      if (/^0\d{13}$/.test(d)) d = d.slice(1);
      return (d.length >= 12 && gtinGueltig(d)) ? d : '';
    };

    /* Erst beschriftete Zahlen: "EAN: 4251776601793" ist ein Beleg, eine
       beliebige Zahl im Text nur ein Kandidat. Kein \s im Zahlenmuster -
       ueber einen Zeilenumbruch wuerden sonst zwei getrennte Zahlen zu einer
       falschen 13-stelligen verschmelzen. */
    var mitLabel = t.match(/(?:ean|gtin|barcode)[^\d]{0,12}[\d -]{8,20}/gi) || [];
    for (var i = 0; i < mitLabel.length; i++) {
      var tref = pruefe(mitLabel[i].replace(/^[^\d]+/, ''));
      if (tref) return tref;
    }

    var frei = t.match(/\d[\d -]{6,16}\d/g) || [];
    for (var j = 0; j < frei.length; j++) {
      var f = pruefe(frei[j]);
      if (f) return f;
    }
    return '';
  }

  /* Wortstamm fuer Komposita- und Pluralvergleich: "Beistelltische" ~
     "Beistelltisch", "Schubkarren" ~ "Bauschubkarre". Deutsche Produktnamen
     lassen sich exakt nicht vergleichen, ueber den Stamm sehr wohl. */
  function stamm(w) { return w.slice(0, Math.max(4, w.length - 2)); }
  function verwandt(a, b) {
    if (!a || !b) return false;
    return a.indexOf(stamm(b)) > -1 || b.indexOf(stamm(a)) > -1;
  }

  /* Eigenschafts- und Marketingwoerter stehen nie fuer einen Produkttyp.
     Nur Fallback - die Hauptarbeit macht der Kategorieabgleich. */
  var KEIN_TYP = /^(garten|neu|neue[rsn]?|gross|klein|hochwertig|premium|robust|stabil|wetterfest|witterungsbestaendig|zertifiziert|fsc|xxl|xl|inkl|mit|ohne|fuer|und|aus|set|stueck|farbe|schwarz|weiss|grau|braun|natur|anthrazit)$/;

  /* Marken, die sich am TITEL erkennen lassen - noetig, weil Amazon und eBay in
     ihren Trefferkacheln gar kein Markenfeld fuehren und der vorhandene
     Markenwiderspruch dort deshalb nie greift. So ueberlebte ein
     "COSTWAY Beistelltisch 70x70x73cm" mit passenden Massen als Kandidat.
     EIGENE: alles unter dem Deuba-Dach - eine ANDERE eigene Marke im Titel
     heisst ebenfalls "anderer Artikel" (Monzana-Treffer auf einen
     Casaria-Stammsatz ist ein Geschwistermodell, kein Fund).
     ponytail: Liste statt Klassifizierer - ergaenzen kostet ein Wort. */
  var EIGENE_MARKEN = ['casaria', 'monzana', 'gardebruk', 'deuba'];
  var FREMD_MARKEN = ['costway', 'hometown', 'homcom', 'songmics', 'vasagle', 'relaxdays',
    'tectake', 'outsunny', 'jago', 'vidaxl', 'blumfeldt', 'kesser', 'wiltec', 'arebos',
    'hengda', 'juskys', 'homecall', 'ecd germany', 'onbest', 'tresko', 'sekey', 'randaco'];

  /* Nennt der Treffertitel eine erkennbare ANDERE Marke, ist es ein anderer
     Artikel - unabhaengig davon, wie gut Titel und Masse passen. */
  function fremdeMarkeImTitel(keyMarke, hitTitel) {
    if (!keyMarke) return '';
    var t = ' ' + norm(hitTitel) + ' ';
    var alle = FREMD_MARKEN.concat(EIGENE_MARKEN);
    for (var i = 0; i < alle.length; i++) {
      if (alle[i] === keyMarke) continue;
      if (t.indexOf(' ' + alle[i] + ' ') > -1 || t.indexOf(' ' + alle[i] + '®') > -1) return alle[i];
    }
    return '';
  }

  /* Der Produkttyp ist das einzige Titelwort, das der eigene Shop garantiert
     auch fuehrt. Er steckt in der Schnittmenge aus Titel und Kategoriepfad:
     "Casaria Garten Beistelltisch FSC-Zertifiziert" x "Garten > Gartenmoebel >
     Beistelltische" -> "Beistelltisch". Ohne Kategorie: das laengste Wort, das
     kein Eigenschaftswort ist. */
  /* Deutsche Eigenschaftswoerter an der Endung erkennen. "ergonomisch",
     "klappbar", "witterungsbestaendig" sind nie ein Produkttyp - live
     06.08.2026 hat genau "ergonomisch" als vermeintlicher Typ echte Treffer
     auf Temu und Kaufland verworfen, weil es dort nicht im Titel stand. */
  /* "isch" ist die haeufigste Adjektivendung ("ergonomisch", "elektrisch") -
     und zugleich das Ende von TISCH. Ohne die Ausnahme fliegen Beistelltisch,
     Gartentisch und Klapptisch als vermeintliche Adjektive raus, und der
     Schluessel verliert seinen Produkttyp.
     "ig" und "end" bleiben ganz draussen: Kaefig, Honig, Wand - zu viele
     Substantive, zu wenig Gewinn. Ein zu breiter Filter ist schlimmer als
     gar keiner. */
  function istAdjektiv(w) {
    if (/tisch$/.test(w)) return false;
    return /(isch|lich|bar|sam|los|voll|frei|iert)$/.test(w);
  }

  function produkttyp(titel, kategorie, marke) {
    return typBestimmen(titel, kategorie, marke).typ;
  }

  /* Liefert zusaetzlich, WOHER der Typ stammt. Das entscheidet, ob er als
     Ausschlusskriterium taugen darf: aus dem Kategoriepfad bestaetigt = ja,
     bloss das laengste Titelwort geraten = nein. */
  function typBestimmen(titel, kategorie, marke) {
    var mk = norm(marke);
    var worte = norm(titel).split(' ').filter(function (w) {
      return w.length >= 4 && !KEIN_TYP.test(w) && !istAdjektiv(w) &&
             (!mk || w.indexOf(mk) === -1);
    });
    if (!worte.length) return { typ: '', belegt: false };

    var kat = norm(kategorie).split(' ').filter(function (w) { return w.length >= 4; });
    for (var i = 0; i < worte.length; i++) {
      for (var j = 0; j < kat.length; j++) {
        if (verwandt(worte[i], kat[j])) return { typ: worte[i], belegt: true };
      }
    }
    /* Marktplaetze ohne Breadcrumb (Temu) liefern lange SEO-Titel. Dort war
       das laengste Wort regelmaessig eine Eigenschaft wie "Belastbarkeit".
       Produktnomen an stabilen Komposit-Endungen schlagen diesen Fallback. */
    var endungen = /(liege|tisch|stuhl|regal|schrank|box|bank|bett|zelt|pavillon|wagen|karre|bogen|zaun|tonne|grill|schuppen|sessel)$/;
    var nomen = worte.filter(function (w) { return endungen.test(w); });
    if (nomen.length) return { typ: nomen[0], belegt: false };
    return {
      typ: worte.slice().sort(function (a, b) { return b.length - a.length; })[0],
      belegt: false
    };
  }

  /* Stammsatz aus einer erfassten Zeile. Am besten aus dem eigenen Shop -
     dort sind Artikelnummer, EAN und der kanonische Titel beisammen. */
  function produktSchluessel(row) {
    row = row || {};
    var voll = volltext(row);
    var typInfo = typBestimmen(row.titel, row.kategorie, row.marke);
    return {
      // EAN aus dem Feld, sonst aus dem Fliesstext (pruefziffervalidiert).
      ean: ziffern(row.ean) || findeEan(voll),
      mpn: norm(row.mpn || row.sku || ''),
      marke: norm(row.marke),
      titel: row.titel || '',
      // Masse aus Titel UND Bullets - bei Amazon stehen sie nur dort.
      masse: masse(voll),
      typ: typInfo.typ,
      /* Nur ein aus dem Kategoriepfad BESTAETIGTER Typ darf Treffer
         ausschliessen. Ein geratener (laengstes Titelwort) taugt zum Suchen,
         aber nicht zum Verwerfen - sonst kostet ein Wort wie "ergonomisch"
         echte Treffer. */
      typ_belegt: typInfo.belegt,
      materialien: materialien(voll),
      set_menge: setMenge([row.titel, row.eig_lieferumfang, row.varianten].filter(Boolean).join(' ')),
      produkt_id: String(row.produkt_id || ''),
      quelle: row.plattform || ''
    };
  }

  /* Einen Treffer gegen den Stammsatz pruefen.
     hit: { titel, preis, produkt_id, url, ean?, mpn? } - ean/mpn liegen nur vor,
     wenn die Trefferseite selbst geoeffnet wurde (Suchergebnisse zeigen sie selten). */
  function bewerte(key, hit) {
    key = key || {}; hit = hit || {};
    var hitEan = ziffern(hit.ean);
    var hitTitel = hit.titel || '';

    if (key.ean && hitEan && key.ean.length >= 8) {
      if (hitEan === key.ean) return ergebnis('EAN', 1, 'EAN ' + key.ean + ' identisch');
      return ergebnis('FREMD', 0, 'EAN weicht ab (' + hitEan + ' statt ' + key.ean + ')');
    }

    var hitMpn = norm(hit.mpn || '');
    if (key.mpn && key.mpn.length >= 4 && hitMpn && hitMpn.indexOf(key.mpn) > -1) {
      return ergebnis('MPN', 0.95, 'Artikelnummer ' + key.mpn + ' identisch');
    }

    /* Deuba haengt die eigene Artikelnummer an Marktplatztitel:
       "CASARIA Gartentisch ... Gartenmoebel 105897". Das ist ein HARTER Beleg -
       staerker als jedes Mass, weil eine Artikelnummer nur einen Artikel meint.
       Live 06.08.2026 stand sie im eBay-Titel und wurde ignoriert; der Treffer
       fiel stattdessen auf "Titel nur 15%" durch.
       Mindestens fuenf Ziffern und beidseitige Ziffernbegrenzung, damit
       "105897" nicht in "1058970" oder in einer Massangabe zufaellig trifft. */
    if (key.mpn && /^\d{5,9}$/.test(key.mpn) &&
        new RegExp('(^|[^0-9])' + key.mpn + '([^0-9]|$)').test(norm(hitTitel))) {
      return ergebnis('MPN', 0.95, 'Artikelnummer ' + key.mpn + ' steht im Treffertitel');
    }

    var sim = aehnlichkeit(key.titel, hitTitel);

    /* Masse NUR aus dem Kacheltitel zu lesen war der Fehler hinter "er sagt
       keine Masse, aber die sind literally da": seit dem 75-Zeichen-Update
       nennt Amazon sie im Titel nicht mehr - wohl aber im URL-Slug
       (.../Campingtisch-70x70x73cm/dp/B078Y6TKG4) und in den Attributen der
       geoeffneten Produktseite (hit.masse_text). Beide werden mitgelesen.
       Der URL-Pfad bewusst OHNE Host: eine Domain wie "24x7.de" wuerde sonst
       als Mass durchgehen. */
    var hitMassText = hitTitel + ' ' + [hit.masse_text, hit.eigenschaften || hit.attribute,
                      hit.eig_masse, hit.eig_belastbarkeit, hit.beschreibung]
                      .filter(Boolean).join(' ') + ' ' +
                      String(hit.url || '').replace(/^https?:\/\/[^/]+/, '').replace(/[/_-]/g, ' ');
    var hitMasse = masse(hitMassText);
    var ketten = function (a) { return a.filter(function (m) { return m.indexOf('x') > -1; }); };
    var keyK = ketten(key.masse), hitK = ketten(hitMasse);
    var hitVolltext = [hitTitel, hit.beschreibung, hit.material_text, hit.eig_material,
      hit.eig_lieferumfang, hit.varianten, hit.eigenschaften || hit.attribute, hit.masse_text, hit.url]
      .filter(Boolean).join(' ');

    /* Marke dreistufig (live belegt 05.08.2026, Otto):
       - NACHGEWIESEN: steht im Titel ODER im separaten Markenfeld der Kachel.
         Otto fuehrt sie nur im Feld - wer allein den Titel prueft, verwirft
         dort die eigenen Listings.
       - WIDERSPRUCH: das Markenfeld nennt eine ANDERE Marke -> anderer Artikel.
       - FEHLT: kein Gegenbeweis, aber auch kein Beleg -> bestaetigen kann so
         ein Treffer nur noch ueber EAN/Artikelnummer. */
    var markeDa = !key.marke ||
      norm(hitTitel).indexOf(key.marke) > -1 ||
      (hit.marke && norm(hit.marke).indexOf(key.marke) > -1);
    if (key.marke && hit.marke && norm(hit.marke).indexOf(key.marke) === -1) {
      return ergebnis('FREMD', sim, 'andere Marke: "' + hit.marke + '" statt "' + key.marke + '"');
    }
    /* Zweite Bremse fuer Amazon und eBay: deren Kacheln fuehren gar kein
       Markenfeld, dort greift die Pruefung darueber nie - und ein "COSTWAY
       Beistelltisch 70x70x73cm" mit passenden Massen kam als Kandidat durch. */
    var fremdeMarke = fremdeMarkeImTitel(key.marke, hitTitel);
    if (fremdeMarke) {
      return ergebnis('FREMD', sim,
        'Fremdmarke "' + fremdeMarke + '" im Treffertitel statt "' + key.marke + '"');
    }

    /* Temu fuehrt keine EAN und blendet die Marke oft aus. Ein Treffer darf
       trotzdem als identisch gelten, aber nur mit einem mehrteiligen, harten
       Fingerabdruck: stabile Goods-ID, exakte Set-Menge, Produkttyp-Familie,
       Material, lange Hauptabmessung UND gleiche Traglast pro Einzelteil.
       Die Pro-Stueck-Normalisierung ist fuer 2er-Sets wichtig: Deuba nennt
       dort 320 kg gesamt, Temu 160 kg je Liege. */
    var temuId = /^temu$/i.test(String(hit.plattform || ''))
      ? String(hit.produkt_id || '')
      : (/^temu$/i.test(String(key.quelle || '')) ? String(key.produkt_id || '') : '');
    if (temuId) {
      var hitSetFrueh = setMenge(hitVolltext);
      var hitMatFrueh = materialien(hitVolltext);
      var matOkFrueh = (key.materialien || []).some(function (x) {
        return hitMatFrueh.indexOf(x) > -1;
      });
      var typOkFrueh = norm(hitVolltext).split(' ').some(function (w) {
        return verwandt(w, key.typ) || (/liege$/.test(w) && /liege$/.test(key.typ || ''));
      });
      var setOkFrueh = key.set_menge > 0 && hitSetFrueh > 0 && key.set_menge === hitSetFrueh;
      var keyCm = (key.masse || []).filter(function (x) { return /cm$/.test(x); })
        .map(function (x) { return parseFloat(x.replace(',', '.')); });
      keyK.forEach(function (k) {
        String(k).split('x').forEach(function (x) { keyCm.push(parseFloat(x.replace(',', '.'))); });
      });
      var hitDimZahlen = hitMasse.filter(function (x) { return /cm$/.test(x); })
        .map(function (x) { return parseFloat(x.replace(',', '.')); });
      hitK.forEach(function (k) {
        String(k).split('x').forEach(function (x) { hitDimZahlen.push(parseFloat(x.replace(',', '.'))); });
      });
      var langeOk = keyCm.some(function (a) {
        return a >= 100 && hitDimZahlen.some(function (b) {
          return Math.abs(a - b) <= Math.max(1, a * 0.02);
        });
      });
      var keyKg = (key.masse || []).filter(function (x) { return /kg$/.test(x); })
        .map(function (x) { return parseFloat(x.replace(',', '.')); });
      var hitKg = hitMasse.filter(function (x) { return /kg$/.test(x); })
        .map(function (x) { return parseFloat(x.replace(',', '.')); });
      var lastOkFrueh = keyKg.some(function (a) {
        return hitKg.some(function (b) {
          return Math.abs(a - b) < 0.01 ||
            Math.abs(a / key.set_menge - b) < 0.01 ||
            Math.abs(a - b / hitSetFrueh) < 0.01;
        });
      });
      if (setOkFrueh && typOkFrueh && matOkFrueh && langeOk && lastOkFrueh) {
        return ergebnis('FINGERABDRUCK', 0.9,
          'Temu Goods-ID ' + temuId + ': Set ' + hitSetFrueh +
          ', Typ, Material, Hauptmass und Traglast je Stueck stimmen');
      }
    }

    /* Auf der Deuba-SUCHKACHEL fehlen Masse und Traglast; sie stehen erst auf
       der Produktseite. Typ-Familie + Set-Menge + Material reichen nur zum
       OEFFNEN des Kandidaten, niemals zum Bestaetigen. */
    if (/^temu$/i.test(String(key.quelle || '')) && key.produkt_id &&
        (hit.produkt_id || /deubaxxl\.de/i.test(String(hit.url || '')))) {
      var kSet = setMenge(hitVolltext);
      var kMat = materialien(hitVolltext);
      var kTyp = norm(hitVolltext).split(' ').some(function (w) {
        return verwandt(w, key.typ) || (/liege$/.test(w) && /liege$/.test(key.typ || ''));
      });
      if (key.set_menge > 0 && kSet === key.set_menge && kTyp &&
          (key.materialien || []).some(function (x) { return kMat.indexOf(x) > -1; })) {
        return ergebnis('SCHWACH', 0.7,
          'Temu→Shop-Kandidat: Set, Produkttyp und Material stimmen; Produktseite muss Masse/Traglast belegen');
      }
    }

    /* Masse ZUERST pruefen, vor jeder Titelaehnlichkeit. Geschwistermodelle
       derselben Marke haben fast identische Titel und unterscheiden sich nur
       in den Massen - ohne diese Reihenfolge wird das 46x46-Modell als der
       70x70-Artikel bestaetigt und liefert ein falsches "UNTERBOTEN".
       Wichtig: WIDERSPRUCH disqualifiziert, FEHLEN nicht. Nennt der Treffer
       gar keine Masse, ist das kein Gegenbeweis - dann bleibt es unbestaetigt. */
    /* Zwei Klassen von Massen: Dimensionsketten ("70x70x73") sind der
       eigentliche Fingerabdruck, Einzelwerte ("250kg") nur Beiwerk - zwei
       verschiedene Schubkarren tragen beide 250 kg, aber keine zwei Modelle
       dieselbe Kette. Nennen BEIDE Seiten eine Kette, muss sie stimmen. */
    if (keyK.length && hitK.length &&
        !keyK.some(function (a) {
          return hitK.some(function (b) { return kettenPassen(a, b); });
        })) {
      return ergebnis('FREMD', sim,
        'andere Masse: Treffer hat ' + hitK.join(', ') + ', erwartet ' + keyK.join(', '));
    }

    // Auch hier Teilketten zulassen - sonst faengt dieser zweite Widerspruch
    // genau die Treffer wieder ein, die der Kettenvergleich oben durchgelassen hat.
    var gemeinsam = key.masse.filter(function (m) {
      return hitMasse.some(function (h) {
        if (m === h) return true;
        return m.indexOf('x') > -1 && h.indexOf('x') > -1 && kettenPassen(m, h);
      });
    });
    var widerspruch = key.masse.length > 0 && hitMasse.length > 0 && gemeinsam.length === 0;
    if (widerspruch) {
      return ergebnis('FREMD', sim,
        'andere Masse: Treffer hat ' + hitMasse.join(', ') + ', erwartet ' + key.masse.join(', '));
    }
    /* EIN gemeinsames Mass genuegt: der Schluessel kennt seit dem Bullet-Lesen
       mehr Masse als jeder Marktplatztitel je nennt - "alle muessen vorkommen"
       waere nie mehr erfuellt und wuerde jeden echten Treffer verwerfen. */
    var masseOk = gemeinsam.length > 0;

    /* Eigene Listings tragen den Shop-Titel praktisch unveraendert. Hohe
       Wortueberlappung PLUS NACHGEWIESENE Marke PLUS widerspruchsfreie Masse
       ist damit ein echter Identitaetsnachweis. Ohne Markennachweis bestaetigt
       ein Titel NIE - und nennt der Treffer Masse, die der Stammsatz nicht
       kennt, ist die Identitaet unpruefbar statt belegt (beides waren die
       "nimmt manchmal falsche"-Faelle vom 05.08.2026). */
    if (key.marke && markeDa && sim >= 0.8 && masseOk) {
      return ergebnis('SHOPTITEL', sim, 'Titel zu ' + pct(sim) + ' wie im Shop, Marke und Masse (' + key.masse.join(', ') + ') stimmen');
    }
    if (key.marke && markeDa && sim >= 0.8 && !key.masse.length && !hitMasse.length) {
      return ergebnis('SHOPTITEL', sim, 'Titel zu ' + pct(sim) + ' wie im Shop, Marke vorhanden (beide ohne Massangabe)');
    }
    /* Stimmt die Dimensionskette ueberein, traegt das MASS den Beleg - nicht
       der Titel. Sonst scheitert jeder von Amazon kommende Treffer an der
       Titelschwelle: "Casaria Garten Beistelltisch FSC-Zertifiziert" und
       "Beistelltisch Akazienholz 70x70x73cm" sind sich zu 20% aehnlich und
       trotzdem derselbe Tisch. Zwei verschiedene Artikel teilen praktisch nie
       eine 3D-Kette. Ein Beweis ist es aber nicht - ein 2er-Set hat dieselben
       Masse -, deshalb bleibt es bei "plausibel": der Kandidat ueberlebt, und
       die geoeffnete Produktseite entscheidet ueber die EAN. */
    /* Massbeleg = uebereinstimmende Dimensionskette ODER mindestens zwei
       gleiche Einzelwerte. Zwei sind noetig, weil ein einzelnes "250 kg" bei
       Schubkarren ein Standardwert ist - "250 kg UND Ø40 cm" dagegen nicht.
       Live 05.08.2026: der echte Shop-Artikel "Schubkarre verzinkt 250kg
       Tragkraft 100L Luftreifen Ø40cm" hat gar keine Kette und wurde deshalb
       verworfen, obwohl beide Einzelmasse stimmten. */
    var massBeleg = (keyK.length > 0 && hitK.length > 0) || gemeinsam.length >= 2;
    if (masseOk && markeDa && (sim >= 0.4 || massBeleg)) {
      return ergebnis('MARKE_MASSE', sim, 'Marke + Masse (' + gemeinsam.join(', ') + ') stimmen, Titel zu ' + pct(sim));
    }
    if (masseOk && !markeDa && (sim >= 0.4 || massBeleg)) {
      return ergebnis('SCHWACH', sim, 'Masse (' + gemeinsam.join(', ') + ') stimmen, aber Marke nicht nachweisbar (Titel ' + pct(sim) + ')');
    }

    /* Produkttyp-Gegenprobe, letzte Bremse vor den schwachen Stufen: nennt der
       Treffer den Produkttyp nicht einmal sinngemaess ("Hochbeet" statt
       "Schubkarre"), ist die Titelaehnlichkeit blosses Rauschen aus geteilten
       Marketingwoertern ("Garten", "wetterfest", "FSC") - genau so kamen
       Hochbeete in die Beistelltisch-Liste. Greift bewusst NUR, wenn auch kein
       Mass fuer den Treffer spricht: Synonyme wie Beistelltisch/Gartentisch
       wuerden hier sonst echte Treffer kosten. */
    if (key.typ && key.typ_belegt && !massBeleg &&
        !norm(hitTitel).split(' ').some(function (w) { return verwandt(w, key.typ); })) {
      return ergebnis('FREMD', sim, 'anderer Produkttyp: "' + key.typ + '" kommt im Treffer nicht vor');
    }
    /* Nur mit Mindest-Titelaehnlichkeit: "nennt keine Masse" bei 0% Titel ist
       kein schwacher Kandidat, sondern ein fremder (live 05.08.2026: die
       Kaufland-Fehlerseite bekam so ein SCHWACH mit "Titel 0%"). */
    if (key.masse.length && !hitMasse.length && sim >= 0.3) {
      return ergebnis('SCHWACH', sim, 'Treffer nennt keine Masse - Identitaet nicht belegbar (Titel ' + pct(sim) + ')');
    }
    if (sim >= 0.3) return ergebnis('SCHWACH', sim, 'nur Titelaehnlichkeit ' + pct(sim) + ', kein Identifier');
    /* Traegt der Treffer UNSERE Marke, ist er nie einfach "fremd" - Temu klebt
       UI-Text an die Kacheltitel ("LokalCASARIA®...In neuer Registerkarte
       oeffnen"), was die Titelaehnlichkeit auf 7-13% drueckt. Ein
       CASARIA-Listing dort ist geschaeftlich relevant, auch unbestaetigt. */
    if (key.marke && markeDa) {
      return ergebnis('SCHWACH', sim, 'traegt Marke "' + key.marke + '", Titel aber nur ' + pct(sim) + ' - von Hand pruefen');
    }
    return ergebnis('FREMD', sim, 'Titel zu ' + pct(sim) + ' - zu wenig Gemeinsames');
  }

  function pct(x) { return Math.round(x * 100) + '%'; }

  function ergebnis(stufe, punkte, grund) {
    var s = STUFEN[stufe];
    return {
      stufe: stufe,
      bestaetigt: s.bestaetigt,
      rang: s.rang,
      label: s.label,
      punkte: Math.round(punkte * 100) / 100,
      grund: grund
    };
  }

  /* Treffer bewerten und sortieren: bestaetigte zuerst, darin der guenstigste.
     Gibt zusaetzlich das Urteil zurueck - und zwar NUR auf Basis bestaetigter
     Treffer. Unbestaetigte bleiben sichtbar, zaehlen aber nicht. */
  /* Der eigene Webshop: Stammsatz und Preisbezug, aber niemals Wettbewerber
     und niemals Ursache eines Buybox-Verlusts. Absichtlich ueber URL UND
     Plattformlabel, weil der Shop-Treffer aus zwei Quellen kommen kann
     (shopHitAus() setzt 'deubaxxl', extractSearchResults das Plattform-Label). */
  function istEigenerShop(h) {
    if (!h) return false;
    return /deubaxxl/i.test(String(h.plattform || '')) ||
           /(^|\.)deubaxxl\./i.test(String(h.url || ''));
  }

  // Der Preis, den Amazon vergleicht: Ware plus Versand, wo bekannt.
  function gesamtpreis(h) {
    if (!h) return Infinity;
    if (h.gesamt != null) return h.gesamt;
    if (h.preis != null && h.versand_betrag != null) return h.preis + h.versand_betrag;
    return h.preis != null ? h.preis : Infinity;
  }

  /* Das vollstaendige Wettbewerbsfeld als eine lesbare Zeile je Anbieter.
     Fuer die Frage "gibt es diesen Preis ueberhaupt irgendwo" sind gerade die
     TEUREREN Anbieter der Beleg - sie zeigen, wo der Markt wirklich liegt. Ein
     leeres Feld ist hier ein Ergebnis, kein Fehler. */
  function wettbewerbsfeld(bewertet) {
    return (bewertet || []).slice()
      /* Bewiesen ANDERE Artikel (FREMD: widersprechende EAN/Masse/Marke/Typ)
         sind kein Wettbewerb fuer DIESES Produkt - Kaufland lieferte auf eine
         Titelsuche 5 fremde casaria-Artikel. Sie bleiben in "verworfen"
         sichtbar, floodet aber nicht das Feld. */
      .filter(function (h) { return h.match_stufe !== 'FREMD'; })
      .sort(function (a, b) { return gesamtpreis(a) - gesamtpreis(b); })
      .map(function (h) {
        var teile = [h.plattform || h.verkaeufer || '?'];
        if (h.preis != null) teile.push(eur(h.preis));
        if (h.versand_betrag != null) {
          teile.push(h.versand_betrag === 0 ? 'frei Haus' : '+' + eur(h.versand_betrag) + ' Versand');
        } else if (h.versand) {
          teile.push('Versand unbekannt');
        }
        if (h.gesamt != null && h.gesamt !== h.preis) teile.push('= ' + eur(h.gesamt));
        if (istEigenerShop(h)) teile.push('[eigener Shop, keine Referenz]');
        else if (h.match_bestaetigt === 'ja') teile.push('[belegt: ' + h.match_stufe + ']');
        else teile.push('[unbelegt: ' + h.match_grund + ']');
        return teile.join(' ');
      }).join('\n');
  }

  function bewerteAlle(key, hits, eigenerPreis) {
    var bewertet = (hits || []).map(function (h) {
      var b = bewerte(key, h);
      return Object.assign({}, h, {
        match_stufe: b.stufe, match_bestaetigt: b.bestaetigt ? 'ja' : 'nein',
        match_grund: b.grund, match_punkte: b.punkte, _rang: b.rang
      });
    });

    bewertet.sort(function (a, b) {
      if (a._rang !== b._rang) return a._rang - b._rang;
      if (a.preis == null) return 1;
      if (b.preis == null) return -1;
      return a.preis - b.preis;
    });

    /* Nur EUR vergleichen: die 20-USD-Karte von eBay darf kein "UNTERBOTEN"
       gegen einen 62,95-EUR-Preis erzeugen (live passiert am 05.08.2026).

       Und: der EIGENE Webshop scheidet als Ursache aus. Amazon zaehlt den
       eigenen Shop des Sellers nicht gegen ihn - Deuba darf dort guenstiger
       sein, ohne die Buybox zu verlieren (Amazon selbst bestaetigt das; seit
       der Verfuegung des Bundeskartellamts vom 05.02.2026 sind solche
       Preiskontrollen ohnehin untersagt). Bisher gewann deubaxxl praktisch
       jeden Vergleich - identische EAN, meist niedrigster Preis - und das
       Werkzeug meldete dann den eigenen Shop als Grund fuer die verlorene
       Buybox. Das ist fachlich falsch und fuehrt zu genau der falschen
       Reaktion: den Shoppreis anheben, ohne dass sich an der Buybox etwas
       aendert.

       WICHTIG - nur der Webshop ist ausgenommen, nicht die eigenen
       MARKTPLATZ-Angebote: Deubas Kaufland- oder eBay-Angebot ist fuer Amazon
       sehr wohl ein externer Wettbewerbspreis (am 05.08.2026 an B078Y6TKG4
       belegt: eigenes Kaufland-Angebot 62,95 EUR als wahrscheinlicher Anker).
       Der Shop-Treffer bleibt in "treffer" sichtbar - er ist der Stammsatz und
       der Preisbezug -, er wird nur nicht mehr zur Ursache erklaert. */
    var belegt = bewertet.filter(function (h) {
      return h.match_bestaetigt === 'ja' && h.preis != null &&
             (!h.waehrung || h.waehrung === 'EUR') &&
             !istEigenerShop(h);
    });
    /* Nach GESAMTPREIS vergleichen, nicht nach Warenpreis: Amazon rechnet den
       eigenen Preis inklusive Versand ("your total price (price + shipping)"),
       und ein Tisch fuer 59 EUR mit 25 EUR Spedition ist teurer als einer fuer
       75 EUR frei Haus. Wo kein Versand bekannt ist, bleibt es beim Warenpreis. */
    var guenstigster = belegt.length ? belegt.reduce(function (m, h) {
      return gesamtpreis(h) < gesamtpreis(m) ? h : m;
    }) : null;

    var shopTreffer = bewertet.filter(istEigenerShop)[0] || null;
    var shopHinweis = (shopTreffer && shopTreffer.preis != null)
      ? ' [eigener Shop ' + eur(shopTreffer.preis) + ' - zaehlt nicht als Ursache]' : '';

    var urteil;
    if (!bewertet.length) urteil = 'keine Treffer';
    else if (!guenstigster) {
      /* Fuer die Buybox-Frage ist das ein ERGEBNIS, keine Fehlermeldung:
         unterbietet kein externer Haendler, liegt die Ursache des
         Buybox-Verlusts nachweislich NICHT bei einem gefundenen
         Marktplatzpreis - dann lohnt die Suche woanders (Kontoleistung,
         Lieferzeit, Amazons interner Referenzpreis). */
      var fremde = bewertet.filter(function (h) { return !istEigenerShop(h); });
      urteil = fremde.length
        ? 'KEIN bestaetigter Fremdtreffer (' + fremde.length + ' Kandidat(en) ohne Identitaetsnachweis)' + shopHinweis
        : 'kein externer Wettbewerber gefunden' + shopHinweis;
    } else if (eigenerPreis != null) {
      // Gesamtpreis (inkl. Versand) gegen den eigenen - so vergleicht Amazon.
      var gp = gesamtpreis(guenstigster);
      var d = Math.round((gp / eigenerPreis - 1) * 100);
      var vk = gp !== guenstigster.preis ? ' inkl. Versand' : '';
      urteil = guenstigster.plattform + ' ' + eur(gp) + vk +
        ' vs. eigener Preis ' + eur(eigenerPreis) + ' (' + (d > 0 ? '+' : '') + d + '%)' +
        (d < 0 ? ' - UNTERBOTEN' : '');
    } else {
      urteil = 'guenstigster bestaetigter: ' + guenstigster.plattform + ' ' + eur(gesamtpreis(guenstigster));
    }

    /* Die Kernzahl fuer den Buybox-Fall: wie weit liegt der guenstigste BELEGTE
       externe Gesamtpreis unter dem eigenen. Null oder positiv = niemand
       unterbietet, ein von Amazon genannter niedrigerer Referenzwert ist dann
       nachweislich kein Regalpreis - genau die Aussage, die man belegen will. */
    var luecke = null;
    if (guenstigster && eigenerPreis != null) {
      luecke = Math.round((gesamtpreis(guenstigster) - eigenerPreis) * 100) / 100;
    }

    return {
      treffer: bewertet,
      guenstigster: guenstigster,
      urteil: urteil,
      luecke: luecke,
      feld: wettbewerbsfeld(bewertet),
      // Nur echte Wettbewerber zaehlen - bewiesen fremde Artikel (FREMD) nicht.
      anbieter_gesamt: bewertet.filter(function (h) {
        return !istEigenerShop(h) && h.match_stufe !== 'FREMD';
      }).length
    };
  }

  function eur(p) { return p.toFixed(2).replace('.', ',') + ' €'; }

  LC.match = {
    produktSchluessel: produktSchluessel,
    bewerte: bewerte,
    bewerteAlle: bewerteAlle,
    aehnlichkeit: aehnlichkeit,
    masse: masse,
    istEigenerShop: istEigenerShop,
    findeEan: findeEan,
    gtinGueltig: gtinGueltig,
    produkttyp: produkttyp,
    typBestimmen: typBestimmen,
    volltext: volltext,
    STUFEN: STUFEN
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = LC.match;
})();
