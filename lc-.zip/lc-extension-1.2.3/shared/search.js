/* Listing Checker - geteilte Such-Logik (EAN / SKU / ASIN / Freitext).
   Kernstueck des Workflows: deubaxxl liefert SKU+EAN, die EAN-Suche auf Amazon
   liefert die ASIN (data-asin des Treffers). Laeuft wie extract.js unveraendert
   im Addon (chrome.scripting) und im Node-Script (Playwright).
   Setzt voraus, dass shared/extract.js vorher geladen wurde (globalThis.LC). */
(function () {
  'use strict';

  var LC = globalThis.LC || (typeof window !== 'undefined' ? window.LC : null);
  if (!LC) throw new Error('shared/extract.js muss vor shared/search.js geladen werden');

  var clean = function (s) {
    return s == null ? '' : String(s).replace(/\s+/g, ' ').trim();
  };

  // ------------------------------------------------------------ Query-Typ

  /* EAN-8, UPC-12, EAN-13, GTIN-14 = nur Ziffern.
     ASIN = 10 Zeichen, modern immer B0xxxxxxxx.
     Alles andere behandeln wir als SKU/Freitext - fuer die Such-URL ist das egal. */
  function detectQueryType(q) {
    q = clean(q);
    if (/^\d{8}$/.test(q) || /^\d{12,14}$/.test(q)) return 'ean';
    if (/^B0[A-Z0-9]{8}$/i.test(q)) return 'asin';
    return 'sku';
  }

  // ------------------------------------------------------------ Such-URLs

  var SEARCH_URLS = {
    amazon:   'https://www.amazon.de/s?k={q}',
    ebay:     'https://www.ebay.de/sch/i.html?_nkw={q}',
    kaufland: 'https://www.kaufland.de/s/?search_value={q}',
    otto:     'https://www.otto.de/suche/{q}/',
    bol:      'https://www.bol.com/nl/nl/s/?searchtext={q}',
    deubaxxl: 'https://www.deubaxxl.de/search?search={q}',
    temu:     'https://www.temu.com/de/search_result.html?search_key={q}'
  };

  // Fremdplattformen, auf denen wir nicht verkaufen - nur fuer den Preisvergleich.
  function comparePlatforms() {
    return LC.PLATFORMS.filter(function (p) { return p.vergleich; }).map(function (p) { return p.id; });
  }
  function sellingPlatforms() {
    return LC.PLATFORMS.filter(function (p) { return !p.vergleich; }).map(function (p) { return p.id; });
  }

  /* Live geprueft: Otto faellt bei EAN-Suchen auf unscharfe Volltextsuche zurueck,
     Kaufland findet die EAN nicht verlaesslich und Temu kennt EANs gar nicht
     (eigener Katalog). Dort direkt Marke+Titel nehmen, statt einen nutzlosen
     ersten Lauf vor den belastbareren Fallbacks zu setzen. */
  var NO_EAN_SEARCH = { kaufland: true, otto: true, bol: true, temu: true };

  function queryFor(pid, ean, titel, marke) {
    if (ean && !NO_EAN_SEARCH[pid]) return { q: ean, type: 'ean' };
    /* Marke nicht doppeln: Shop- und Marktplatztitel beginnen fast immer selbst
       mit der Marke. Sonst frisst sie eines der sechs Suchwoerter - und genau
       diese fehlenden Woerter (Masse, Set-Groesse) holen den falschen Artikel. */
    var m = clean(marke), t = clean(titel);
    if (m && t.toLowerCase().indexOf(m.toLowerCase()) === 0) m = '';
    var words = clean([m, t].filter(Boolean).join(' '))
      .replace(/[|,;()®™©]/g, ' ')
      .split(/\s+/).filter(Boolean).slice(0, 6).join(' ');
    return words ? { q: words, type: 'sku' } : (ean ? { q: ean, type: 'ean' } : null);
  }

  /* Direkte Suchleiter fuer einen Zielmarktplatz. Auf EAN-blinden Katalogen
     ist der deutsche Produkttyp oft unbrauchbar (besonders bol/Temu). Der
     sprachunabhaengige Fingerabdruck aus Marke + voller Dimensionskette ist
     deshalb ein eigener Fallback. Maximal drei Queries und Abbruch beim
     ersten belegten Preis halten den Netzverkehr eng begrenzt. */
  function targetQueries(pid, key) {
    key = key || {};
    var out = [];
    var add = function (q) {
      if (!q || !q.q) return;
      q.q = clean(q.q).replace(/[|,;()®™©]/g, ' ').replace(/\s+/g, ' ').trim();
      if (q.q && out.every(function (x) { return x.q !== q.q; })) out.push(q);
    };

    add(queryFor(pid, key.ean, key.titel, key.marke));
    if (NO_EAN_SEARCH[pid]) {
      var ketten = (key.masse || []).filter(function (m) {
        return (String(m).match(/x/g) || []).length >= 2;
      }).sort(function (a, b) {
        return b.split('x').length - a.split('x').length || b.length - a.length;
      });
      if (key.marke && ketten[0]) add({ q: key.marke + ' ' + ketten[0], type: 'sku' });
      if (key.marke && key.mpn) add({ q: key.marke + ' ' + key.mpn, type: 'sku' });
      if (ketten[0]) add({ q: ketten[0], type: 'sku' });
    } else if (key.ean) {
      add(queryFor(pid, '', key.titel, key.marke));
    }
    return out.slice(0, 3);
  }

  /* Suchanfragen fuer die SHOP-Suche (deubaxxl), absteigend nach Beweiskraft.
     Nimmt den Fingerabdruck aus LC.match.produktSchluessel, NICHT den Titel.

     Warum: Live belegt (05.08.2026) liefert der volle Amazon-Titel in der
     Shopware-Volltextsuche Hochbeete und Gartenduschen - "FSC-zertifiziert"
     und "Garten" wiegen dort schwerer als "Beistelltisch". Der Amazon-Titel
     ist seit dem 75-Zeichen-Update auch gar nicht mehr dafuer gemacht: er
     nennt weder Mass noch Nummer.

     Die Leiter sucht deshalb mit dem, was BEIDE Seiten fuehren:
     1. EAN            - exakt, Shopware leitet direkt auf die Produktseite um
     2. Artikelnummer  - dito
     3. Typ + Marke    - hoher Recall, Marke grenzt die Kategorie ein
     4. Typ allein     - maximaler Recall; die Masse filtern anschliessend hart
     5. Typ + Mass     - falls der Shop dieselbe Schreibweise fuehrt
     Praezision entsteht bewusst NICHT ueber die Query (Shopware tokenisiert
     "70x70x73cm" anders als "70x70x73"), sondern ueber den Massfilter danach. */
  function shopQueries(key) {
    key = key || {};
    var out = [];
    var add = function (q, type) {
      q = clean(q);
      if (q && out.every(function (o) { return o.q !== q; })) out.push({ q: q, type: type || 'sku' });
    };

    add(key.ean, 'ean');
    add(key.mpn);
    if (/^temu$/i.test(String(key.quelle || '')) && key.typ) {
      var temuTypen = [key.typ];
      if (/sonnenliege$/.test(key.typ)) temuTypen.unshift(key.typ.replace(/sonnenliege$/, 'gartenliege'));
      else if (/gartenliege$/.test(key.typ)) temuTypen.push(key.typ.replace(/gartenliege$/, 'sonnenliege'));
      var temuMaterial = (key.materialien || [])[0] || '';
      if (temuMaterial === 'akazie') temuMaterial = 'akazienholz';
      temuTypen.forEach(function (typ) {
        if (key.set_menge > 1) add(typ + ' ' + key.set_menge + 'er set ' + temuMaterial);
        else add(typ + ' ' + temuMaterial);
      });
    }
    if (key.typ) {
      /* Nicht blind das erste Mass nehmen. Amazon liefert oft erst die
         Grundflaeche (70x70), danach die eindeutige 3D-Kette (70x70x73) und
         spaeter Belastbarkeit/Gewicht. Die breitere Grundflaeche brachte den
         Zielartikel im Deuba-Shop nicht unter die ersten zehn Treffer. */
      var ketten = (key.masse || []).filter(function (m) { return (m.match(/x/g) || []).length >= 2; })
        .sort(function (a, b) { return b.split('x').length - a.split('x').length || b.length - a.length; });
      var gewichte = (key.masse || []).filter(function (m) { return /kg$/.test(m); })
        .sort(function (a, b) { return parseFloat(b.replace(',', '.')) - parseFloat(a.replace(',', '.')); });
      var starkesMass = ketten[0] || (key.masse || [])[0] || '';
      var belastbarkeit = gewichte[0] || '';

      if (starkesMass) {
        add(key.typ + (key.marke ? ' ' + key.marke : '') + ' ' + starkesMass);
        add(key.typ + ' ' + starkesMass);
      }
      if (belastbarkeit && belastbarkeit !== starkesMass) {
        add(key.typ + (key.marke ? ' ' + key.marke : '') + ' ' + belastbarkeit);
        add(key.typ + ' ' + belastbarkeit);
      }
      add(key.typ + (key.marke ? ' ' + key.marke : ''));
      add(key.typ);
    }
    /* Notnagel, wenn kein Produkttyp erkennbar war: die laengsten Titelwoerter.
       Schlechter als alles darueber, aber besser als gar keine Suche. */
    if (!out.length && key.titel) {
      var worte = clean(key.titel).replace(/[|,;()®™©]/g, ' ').split(/\s+/)
        .filter(function (w) { return w.length >= 4; })
        .sort(function (a, b) { return b.length - a.length; });
      if (worte.length) add(worte.slice(0, 2).join(' '));
    }
    return out;
  }

  /* ---------------------------------------------------------- EAN-Resolver

     Warum es das gibt: die plattformeigenen Suchen sind einzeln schwach oder
     blockiert - Otto faellt bei EANs auf unscharfe Volltextsuche zurueck und
     findet den eigenen Artikel nicht, Kaufland und bol blocken, Temu kennt
     gar keine EANs. Ein Preisvergleichsportal loest genau diese Aufgabe als
     Kerngeschaeft: eine EAN rein, alle Haendler mit Preis raus.

     Live gemessen 06.08.2026 an vier Deuba-EANs: guenstiger.de fand 4/4 mit
     je 5-6 Haendlerzeilen, darunter Kaufland, OTTO und eBay - also genau die
     Plattformen, an denen die Direktsuche scheitert. Eine Seitenladung
     ersetzt damit sieben Suchen.

     Wichtig: das HTML ist servergerendert, es muss nichts nachgeladen werden.
     Ohne Session antworten die Portale mit 403 - im echten Tab der Extension
     ist das kein Thema. */
  var AGGREGATOREN = [
    { id: 'guenstiger', url: 'https://www.guenstiger.de/Preissuche/{q}.html' },
    { id: 'geizhals',   url: 'https://geizhals.de/?fs={q}' }
  ];

  function aggregatorUrl(quelle, ean) {
    var a = AGGREGATOREN.filter(function (x) { return x.id === quelle; })[0];
    return a ? a.url.replace('{q}', encodeURIComponent(clean(ean))) : '';
  }

  /* Haendlername -> Plattform-ID. Bewusst grob: die verbindliche Zuordnung
     macht spaeter die aufgeloeste Ziel-URL, das hier ist nur die Vorsortierung. */
  function shopZuPlattform(shop) {
    var s = String(shop || '').toLowerCase();
    if (s.indexOf('kaufland') > -1) return 'kaufland';
    if (s.indexOf('otto') > -1) return 'otto';
    if (s.indexOf('ebay') > -1) return 'ebay';
    if (s.indexOf('amazon') > -1) return 'amazon';
    if (s.indexOf('bol') > -1) return 'bol';
    if (s.indexOf('temu') > -1) return 'temu';
    if (s.indexOf('deubaxxl') > -1 || s.indexOf('deuba') === 0) return 'deubaxxl';
    return '';
  }

  /* Alle Angebotszeilen einer Aggregator-Seite. Streng ZEILENVERANKERT:
     Haendler, Preis und Titel kommen aus demselben Element. Genau daran ist
     die alte Textfenster-Heuristik gescheitert - sie las den Preis eines
     Artikels und den Namen eines anderen aus einem Empfehlungskarussell. */
  function parseAggregator(doc, url) {
    doc = doc || document;
    var host = '';
    try { host = new URL(url || doc.location.href).hostname; } catch (e) { /* leer */ }
    var istGeizhals = /geizhals/i.test(host);

    var rows = doc.querySelectorAll(istGeizhals ? '.offerlist .offer' : 'div.offerListItem');
    var out = [];
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i], shop = '', preisText = '', titel = '', link = '', versand = '';
      try {
        if (istGeizhals) {
          shop = clean((row.querySelector('.offer__merchant .merchant__logo-caption') ||
                        row.querySelector('.offer__merchant') || {}).textContent || '');
          preisText = clean((row.querySelector('.offer__price') || {}).textContent || '');
          link = (row.querySelector('a.gh_offerlist__offerurl') || {}).href || '';
        } else {
          var logo = row.querySelector('.sellerLogo img');
          shop = clean((logo && logo.getAttribute('alt')) || '');
          preisText = clean((row.querySelector('.lowestPrice .priceHtmlContainer') || {}).textContent || '');
          versand = clean((row.querySelector('.shippingInfo') || {}).textContent || '');
          var tEl = row.querySelector('.productName');
          titel = clean((tEl && tEl.getAttribute('title')) || (tEl && tEl.textContent) || '');
          var a = row.querySelector('a.stretched-link[href*="/click/"]') ||
                  row.querySelector('a.stretched-link');
          link = (a && a.href) || '';
          // Marktplatzangebote nennen den tatsaechlichen Verkaeufer separat -
          // fuer die Buybox-Frage ist "verkauft durch Deuba" die halbe Antwort.
          var verk = row.querySelector('a.gotoShopPage');
          if (verk) shop = shop + ' / ' + clean(verk.textContent);
        }
      } catch (e) { continue; }

      var preis = LC.parseNum(preisText);
      if (!shop || preis == null) continue;
      out.push({
        shop: shop, plattform: shopZuPlattform(shop), titel: titel,
        preis: preis, versand: versand, url: link
      });
    }
    return out;
  }

  /* BOL ist im Firmennetz haeufig komplett auf IP-Ebene gesperrt. Niederlaendische
     Preisportale fuehren das Angebot trotzdem EAN-verankert und liefern einen
     ausgehenden BOL-Link. Diese Parser akzeptieren eine Zeile NUR, wenn die
     erwartete EAN auf derselben Produktseite im Quelltext steht. Damit ist der
     Portalbeleg schwächer als eine lesbare BOL-Seite, aber wesentlich staerker
     als ein Titel- oder Suchtreffer und vor allem nachvollziehbar. */
  function parseEvidencePortal(doc, url, wantEan) {
    doc = doc || document;
    wantEan = clean(wantEan).replace(/\D/g, '');
    if (!wantEan) return [];
    var host = '';
    try { host = new URL(url || doc.location.href).hostname.toLowerCase(); } catch (e) { /* leer */ }
    var html = '';
    try { html = String(doc.documentElement.innerHTML || ''); } catch (e) { /* leer */ }
    if (html.indexOf(wantEan) < 0) return [];
    var title = '';
    try { title = clean((doc.querySelector('h1') || {}).textContent || doc.title || ''); } catch (e) { /* leer */ }
    var out = [], seen = Object.create(null);
    var add = function (shop, price, targetUrl, shipping) {
      shop = clean(shop);
      var pid = shopZuPlattform(shop);
      price = Number(price);
      targetUrl = clean(targetUrl);
      if (!pid || !isFinite(price) || price <= 0 || !targetUrl) return;
      try { targetUrl = new URL(targetUrl, url || doc.location.href).href; } catch (e) { /* roh */ }
      var key = pid + '|' + targetUrl + '|' + price;
      if (seen[key]) return;
      seen[key] = 1;
      out.push({
        shop: shop, plattform: pid, titel: title,
        preis: price, versand: clean(shipping), url: targetUrl,
        ean: wantEan, ean_beleg_url: url || (doc.location && doc.location.href) || '',
        belegart: 'EAN-verankertes Preisportal'
      });
    };

    if (/beslist\.nl$/.test(host)) {
      /* Next-Hydration enthaelt je Offer einen streng zusammengehoerigen
         Block mit shopName, Preis und outclickUrl. Nicht quer ueber die Seite
         kombinieren: genau das wuerde wieder Preis und Shop vertauschen. */
      var scripts = [];
      try { scripts = Array.prototype.slice.call(doc.querySelectorAll('script')); } catch (e) { /* leer */ }
      var hydration = scripts.map(function (node) { return String(node.textContent || ''); }).join('\n');
      var chunks = hydration.split('"__typename":"Offer"').slice(1);
      var decode = function (raw) {
        if (!raw) return '';
        try { return JSON.parse('"' + raw + '"'); } catch (e) { return raw.replace(/\\\//g, '/'); }
      };
      chunks.forEach(function (chunk) {
        chunk = chunk.slice(0, 6000);
        var shopM = chunk.match(/"shopName":"((?:\\.|[^"\\])*)"/);
        var urlM = chunk.match(/"outclickUrl":"((?:\\.|[^"\\])*)"/);
        var saleM = chunk.match(/"salePrice":([0-9]+(?:\.[0-9]+)?)/);
        var regularM = chunk.match(/"regularPrice":([0-9]+(?:\.[0-9]+)?)/);
        add(shopM && decode(shopM[1]), saleM ? saleM[1] : (regularM && regularM[1]),
          urlM && decode(urlM[1]), '');
      });
    }

    if (/kieskeurig\.nl$/.test(host)) {
      var links = [];
      try { links = Array.prototype.slice.call(doc.querySelectorAll('a[href*="ocean.kieskeurig.nl"]')); }
      catch (e) { /* leer */ }
      links.forEach(function (link) {
        var row = link.closest && link.closest('article, li, [class*="offer" i], [class*="price" i]');
        row = row || link.parentNode;
        var text = clean((row && row.textContent) || '');
        var logo = row && row.querySelector ? row.querySelector('img[alt]') : null;
        var shop = clean((logo && logo.getAttribute('alt')) || text.split(/€|\d+[,.]\d{2}/)[0]);
        var pm = text.match(/€\s*([0-9.]+,[0-9]{2})/) || text.match(/([0-9.]+,[0-9]{2})\s*€/);
        add(shop, pm && LC.parseNum(pm[1]), link.href || link.getAttribute('href'), text);
      });
    }

    return out;
  }

  /* ------------------------------------------------- Google als Notausgang

     Live bewiesen 06.08.2026, nicht vermutet: Otto und Kaufland sind per EAN
     ueber KEINE Suchmaschine auffindbar - "site:otto.de 4250525353426" liefert
     null Ergebnisse. Beide FUEHREN die Artikel, rendern die EAN aber nicht in
     den Index. Mit Marke und Titelwoertern kommt dieselbe Suche dagegen direkt
     auf die Produktseite: "site:otto.de Casaria Gartentisch Akazienholz
     70x70x73cm" -> otto.de/p/casaria-klapptisch-...-S0N0A0LE/.
     Das ist der einzige belegte Weg zu Otto, nachdem dessen eigene Suche bei
     EANs auf unscharfe Volltextsuche zurueckfaellt. */
  function googleUrl(q) {
    return 'https://www.google.com/search?q=' + encodeURIComponent(clean(q)) + '&hl=de&gl=de';
  }

  function googleSiteQuery(host, key) {
    var t = clean(key.titel || '').replace(/[|,;()®™©]/g, ' ')
      .split(/\s+/).filter(Boolean).slice(0, 8).join(' ');
    var marke = clean(key.marke || '');
    // Masse mitgeben: sie unterscheiden Geschwistermodelle und stehen in
    // beiden Titeln - genau deshalb taugen sie als Suchwort.
    var mass = (key.masse && key.masse.length) ? ' ' + key.masse[0] : '';
    return clean('site:' + host + ' ' + marke + ' ' + t + mass);
  }

  /* Trefferliste einer Google-Ergebnisseite. Google verbirgt die Ziel-URL seit
     2026 hinter "/goto?url=<opak>" - sie steht NIRGENDS im DOM. Der Host ist
     aber im cite-Element lesbar, und der Link fuehrt beim Oeffnen im Tab
     trotzdem auf die echte Produktseite. Also: Host zum Sortieren, Link zum
     Oeffnen, den Rest liest dort extract.js. */
  function parseGoogle(doc) {
    doc = doc || document;
    var out = [];
    var heads = doc.querySelectorAll('#search h3, #rso h3');
    for (var i = 0; i < heads.length; i++) {
      var h = heads[i];
      var a = h.closest ? h.closest('a[href]') : null;
      if (!a) continue;
      // Anzeigenbloecke ueberspringen - sie fuehren nie auf eine Produktseite.
      if (a.closest && a.closest('#tads, #tadsb, #bottomads, [data-text-ad]')) continue;

      var block = a.closest('div[data-hveid]') || a.parentNode;
      var cite = block && block.querySelector ? block.querySelector('cite') : null;
      var host = clean((cite && cite.textContent) || '').split(/[\s›»]/)[0]
        .replace(/^https?:\/\//, '').replace(/^www\./, '');
      var text = clean((block && block.textContent) || '');
      var m = text.match(/(\d{1,3}(?:\.\d{3})*,\d{2})\s*€/);

      out.push({
        titel: clean(h.textContent),
        host: host,
        url: a.href,
        preis: m ? LC.parseNum(m[1]) : null
      });
    }
    return out;
  }

  function searchUrl(platformId, query, type) {
    query = clean(query);
    // ASIN ist eine direkte Adresse, keine Suche.
    if (platformId === 'amazon' && (type || detectQueryType(query)) === 'asin') {
      return 'https://www.amazon.de/dp/' + encodeURIComponent(query.toUpperCase());
    }
    var pat = SEARCH_URLS[platformId];
    return pat ? pat.replace('{q}', encodeURIComponent(query)) : '';
  }

  /* Ist die (finale) URL noch die Suchseite der Plattform? Ein echter
     Produkt-Redirect (deubaxxl-SKU, bol-EAN) verlaesst das Suchmuster - eine
     "Keine Ergebnisse"-Seite behaelt es. Der Unterschied entscheidet, ob der
     Produktseiten-Fallback unten ueberhaupt lesen darf. */
  function istSuchUrl(platformId, url) {
    var pat = SEARCH_URLS[platformId];
    if (!pat) return false;
    return String(url || '').indexOf(pat.split('{q}')[0]) === 0;
  }

  // ------------------------------------------------------------ Treffer-Extraktion
  /* Pro Plattform: item = ein Container pro Suchtreffer, link/titel/preis relativ dazu,
     id = Produkt-ID aus der Treffer-URL bzw. einem data-Attribut. */

  var RESULT_RULES = {
    // Live verifiziert: EAN-Suche -> genau 1 s-search-result mit data-asin. Die
    // data-cy-Attribute (title-recipe, price-recipe) sind stabile Zonen-Anker.
    amazon: {
      // :not([data-asin=""]) - sonst zaehlen Layout-/Werbebloecke ("Ergebnisse",
      // Karussell "Auswahl aus sozialen Medien") als Treffer mit.
      items: ['div[data-component-type="s-search-result"][data-asin]:not([data-asin=""])',
              'div.s-result-item[data-asin]:not([data-asin=""])'],
      /* GESPONSERTE Kacheln haben in [data-cy=title-recipe] a.a-link-normal
         href="#" (live 06.08.2026, alle 4 Anzeigen der EAN-Suche). Aufgeloest
         gegen die Suchseite ergab das die SUCHSEITE als "Produkt-URL" - genau
         so entstand die Phantomkarte "Amazon.de : 4250525353426". Nur echte
         /dp/-Links zaehlen; fuer Anzeigenkacheln baut extractSearchResults die
         URL aus data-asin (der /sspa/click-Tracker taete es auch, ist aber ein
         zusaetzlicher Redirect ohne Mehrwert fuers Lesen). */
      link: ['a.a-link-normal[href*="/dp/"]', '[data-cy="title-recipe"] a[href*="/dp/"]', 'h2 a[href*="/dp/"]'],
      titel: ['[data-cy="title-recipe"] h2 span', 'h2 span', 'h2 a span', '.a-text-normal'],
      preis: ['[data-cy="price-recipe"] .a-price:not(.a-text-price) .a-offscreen',
              '.a-price:not(.a-text-price) .a-offscreen', '.a-price .a-offscreen'],
      id: function (el, href) {
        // data-asin ist zuverlaessiger als die URL: Sponsored-Links laufen
        // ueber amazon-adsystem-Redirects ohne /dp/ im Pfad.
        var asin = el.getAttribute('data-asin');
        if (asin) return asin.toUpperCase();
        var m = (href || '').match(/\/dp\/([A-Z0-9]{10})/i);
        return m ? m[1].toUpperCase() : '';
      },
      sponsored: function (el) {
        // Live 06.08.2026: gesponserte Kacheln tragen AdHolder an der KACHEL selbst.
        return /(^|\s)AdHolder(\s|$)/.test(el.className) ||
               !!el.querySelector('[data-component-type="sp-sponsored-result"], .puis-sponsored-label-text, .AdHolder') ||
               /gesponsert|sponsored/i.test(clean((el.querySelector('.a-color-secondary') || {}).textContent || '').slice(0, 40));
      }
    },
    // Live verifiziert: neue s-card-Struktur (2025), li.s-item existiert nicht mehr.
    // Statisches HTML enthaelt Dummy-Karten "Shop on eBay" -> werden per Titel gefiltert.
    ebay: {
      items: ['ul.srp-results li.s-card', 'li.s-card', 'li.s-item', 'ul.srp-results > li'],
      link: ['a.s-card__link[href*="/itm/"]', 'a.s-item__link', 'a[href*="/itm/"]'],
      titel: ['.s-card__title span.su-styled-text', '.s-card__title', '.s-item__title'],
      preis: ['span.s-card__price', '.s-item__price'],
      id: function (el, href) {
        var lid = el.getAttribute('data-listingid');
        var m = (href || '').match(/\/itm\/(?:[^/]*\/)?(\d{9,15})/);
        return m ? m[1] : (lid || '');
      },
      sponsored: function (el) {
        return /anzeige|sponsored/i.test(clean((el.querySelector('.s-card__sep, .s-item__sep, .SECONDARY_INFO') || {}).textContent || ''));
      }
    },
    // Cloudflare-geblockt fuer statisches Fetching - Selektoren sind Attributmuster
    // fuers Live-DOM (Extension/Playwright), JSON-LD/__NUXT__ als Absicherung.
    kaufland: {
      /* Live 06.08.2026: die Kachel ist ein <a>, kein <article> - der alte
         Selektor traf null Elemente, Kauflands Suche lieferte deshalb immer
         eine leere Liste. */
      items: ['a[data-testid$="product-tile"]', 'a.base-product-tile',
              'a[href*="/product/"][class*="product-tile"]'],
      link: ['a[href*="/product/"]'],
      titel: ['.product-title', '[class*="__title"]', 'h2', 'h3'],
      marke: ['[class*="brand"]', '[class*="manufacturer"]'],
      /* Geldpfad: der alte Selektor griff bei Rabattartikeln den STREICHPREIS
         (312,99 statt 289,99) - ein zu hoher Fremdpreis verharmlost genau die
         Unterbietung, die wir suchen. */
      preis: ['.product-price__final-price', '.product-price [class*="final-price"]',
              '[class*="price"]:not([class*="rrp"]):not([class*="strike"])'],
      id: function (el, href) {
        var m = (href || '').match(/\/product\/(\d+)/);
        return m ? m[1] : '';
      },
      sponsored: function (el) {
        return /gesponsert|anzeige/i.test(clean(el.textContent).slice(0, 60));
      }
    },
    // Live verifiziert: reptile-product-tile mit data-product-id/-article-number.
    // Achtung: EAN-/SKU-Suche faellt bei Otto auf unscharfe Volltextsuche zurueck -
    // Treffer koennen irrelevant sein, das Zielprodukt erscheint oft NICHT.
    otto: {
      items: ['article[data-qa="reptile-product-tile"]', 'article[data-product-id]',
              'article[data-productid]', 'article[class*="find_tile"]'],
      /* data-qa sitzt AUF dem <a> selbst - der alte Nachfahren-Kombinator
         '[data-qa=...] a[href^="/p/"]' traf nie, und 'a[data-link-type="tile"]'
         existiert gar nicht (echter Wert ist "text"). Es rettete nur der
         dritte Fallback. */
      link: ['a[data-qa="find_tile__productLink"]', 'a[href*="/p/"]'],
      titel: ['.reptile-product-title__title', 'span.reptile-product-title', '[class*="name"]', 'h2'],
      /* Otto fuehrt die Marke NICHT im Kacheltitel, sondern in einem eigenen
         Element - ohne dieses Feld verwirft der Identitaetscheck eigene
         Listings ("Marke kommt im Treffer nicht vor"). */
      marke: ['.reptile-product-title__brand', '[data-qa*="brand"]', '[class*="brand"]'],
      preis: ['.reptile-price__retailPrice', '[class*="retailPrice"]', '[class*="retail-price"]',
              '[class*="price"]'],
      id: function (el, href) {
        var pid = el.getAttribute('data-product-id') || el.getAttribute('data-article-number') ||
                  el.getAttribute('data-productid');
        if (pid) return pid;
        var m = (href || '').match(/\/p\/[^/]*-(\d{6,})/) || (href || '').match(/\/p\/(?:[a-z0-9-]+-)?([A-Z][A-Z0-9]{5,})\//);
        return m ? m[1] : '';
      },
      /* In der zweiten Kachelvariante steht "gesponsert" nicht in den ersten
         60 Zeichen - das article-Element traegt es aber hart als Attribut. */
      sponsored: function (el) {
        return el.getAttribute('data-origin') === 'sponsored' ||
               /anzeige|gesponsert/i.test(clean(el.textContent).slice(0, 60));
      }
    },
    // Wayback-verifiziert (Live: IP-Block fuer statisches Fetching). data-id am li
    // traegt die Produkt-ID, Preis am sichersten aus meta[itemprop=price] content.
    /* Live neu bestimmt 06.08.2026: bols neues Tailwind-Frontend hat KEINE
       data-test-Attribute mehr - saemtliche alten Selektoren trafen 0 Elemente,
       deshalb kam von bol nie ein Treffer an. */
    bol: {
      items: ['div:has(> div[id] > a[href*="/nl/nl/p/"])', 'li.product-item--row',
              'li[data-test="product-item"]', 'div[data-test="product"]'],
      link: ['div[id] > a[href*="/nl/nl/p/"]', 'a[data-test="product-title"]', 'a[href*="/p/"]'],
      titel: ['div[id] h2', 'a[data-test="product-title"]', '[data-test="title"]', 'h2'],
      // Die Marke steht als eigener Shop-Link ueber dem Titel (/nl/nl/pb/sony/3123135/).
      marke: ['a[href*="/nl/nl/pb/"]', '[data-test*="brand"]', '[class*="brand"]'],
      /* Der sichtbare Preis ist in aria-hidden-Einzelspans zerlegt (203 , 35) -
         kein einzelnes Element traegt "203,35". Der Screenreader-Text daneben
         ist der EINZIGE zusammenhaengende Wert und unterscheidet zugleich
         Verkaufs- von Streichpreis ("De adviesprijs is 207 euro"). */
      preis: function (el) {
        var m = String(el.textContent || '')
          .match(/prijs van dit product is '?(\d+)'?\s*euro(?:\s*en\s*'?(\d+)'?\s*cent)?/i);
        if (m) return m[1] + ',' + (m[2] || '00');
        var alt = el.querySelector('[data-test="priceBlockPrice"] meta[itemprop="price"], meta[itemprop="price"]');
        if (alt) return alt.getAttribute('content') || '';
        var sicht = el.querySelector('[data-test="price"], .promo-price');
        return sicht ? clean(sicht.textContent) : '';
      },
      id: function (el, href) {
        var did = el.getAttribute('data-id');
        if (did) return did;
        var m = (href || '').match(/\/p\/[^/]*\/(\d{7,16})/);
        return m ? m[1] : '';
      },
      sponsored: function (el) {
        return /gesponsord|sponsored/i.test(clean(el.textContent).slice(0, 60));
      }
    },
    /* Temu: Klassen sind generiert/obfuskiert - Struktur-Selektoren ueber das
       stabile URL-Muster ...-g-<goods_id>.html. EAN-Suche kennt Temu nicht
       (eigener Katalog) -> mit Titel-Keywords suchen, Treffer manuell abgleichen.
       ponytail: Best-Effort bis zur Live-Probe; Feintuning im Live-DOM. */
    temu: {
      /* Live 06.08.2026: 'div[data-uniqid]' trifft 35 KATEGORIE-CHIPS der
         Navigation ("Empfohlen", "Damenbekleidung"), kein einziges Produkt.
         Weil extractSearchResults beim ersten Selektor MIT Treffern abbricht,
         wurden die echten Kacheln nie angesehen und jeder Chip fiel mangels
         Link/Preis raus - das ist das gemeldete "findet es, skippt es aber". */
      items: ['div[role="group"][aria-label]', 'a[href*="-g-"]'],
      link: ['a[href*="-g-"]'],
      // Titel steht in <h3><div>BADGE</div><span>TITEL</span></h3> - ohne "> span"
      // klebt "Top-AuswahlLokal" davor.
      titel: ['h3 > span', 'h3', 'img[alt]'],
      marke: ['[class*="brand"]'],
      /* Temu-Klassen sind generiert ("_2myxWHLi") - [class*="price"] trifft
         nichts. Und der ganze data-type=price-Block liefert "€29.9929,99€"
         (sichtbarer Preis + aria-hidden-Ziffernkopie) = 299929,99 nach dem
         Parsen. Nur das erste span traegt den echten Wert. */
      preis: ['[data-type="price"] > span:first-child', '[data-type="price"] span'],
      id: function (el, href) {
        var m = (href || '').match(/-g-(\d+)\.html/);
        return m ? m[1] : '';
      },
      sponsored: function (el) {
        return /anzeige|sponsored|werbung/i.test(clean(el.textContent).slice(0, 60));
      }
    },
    /* Shopware 6 Storefront + Vision-AI-Suchoverlay (live 05.08.2026): die
       Suche rendert jetzt a.vsai-item-Kacheln in einem Overlay; bei exakter
       SKU leitet sie DIREKT auf die Produktseite um (?vsaisearch=... in der
       URL). Preis: --discount/--original sind der Verkaufspreis,
       --strikethrough ist der Streichpreis und darf NICHT greifen. */
    deubaxxl: {
      items: ['a.vsai-item', '.product-box', '.card.product-box'],
      link: ['a.product-name', '.product-image-link', 'a[href]'],
      titel: ['.vsai-item__title', '.product-name', '.product-box-name'],
      preis: ['.vsai-item__price--discount', '.vsai-item__price--original',
              '.product-price', '.product-cheapest-price-price'],
      id: function (el, href) {
        var pn = el.getAttribute('data-product-information') ||
                 el.getAttribute('data-product-id') || '';
        var m = (href || '').match(/\/(\d{4,})\/?(?:[?#]|$)/);
        return m ? m[1] : pn;
      },
      sponsored: function () { return false; }
    },
    generic: {
      items: ['[class*="product-item"]', '[class*="product-box"]', 'article'],
      link: ['a[href]'],
      titel: ['h2', 'h3', '[class*="title"]', '[class*="name"]'],
      marke: ['[class*="brand"]', '[class*="manufacturer"]'],
      preis: ['[class*="price"]'],
      id: function () { return ''; },
      sponsored: function () { return false; }
    }
  };

  var pickEl = function (root, sels) {
    for (var i = 0; i < sels.length; i++) {
      try {
        var el = root.querySelector(sels[i]);
        if (el) return el;
      } catch (e) { /* weiter */ }
    }
    return null;
  };

  // bol legt den Treffer-Preis in meta[itemprop=price] content ab - Text reicht nicht.
  // Temu-Kacheln tragen den Titel teils nur im img-alt.
  var pickText = function (root, sels) {
    var el = pickEl(root, sels);
    if (!el) return '';
    if (el.tagName === 'META') return clean(el.getAttribute('content'));
    if (el.tagName === 'IMG') return clean(el.getAttribute('alt'));
    return clean(el.textContent);
  };

  /* Liefert die Trefferliste einer Suchseite.
     query/qtype sind optional und wandern nur in die Ausgabezeilen. */
  function extractSearchResults(doc, url, query, qtype, limit) {
    doc = doc || document;
    url = url || (doc.location && doc.location.href) || '';
    limit = limit || 5;

    var host = '';
    try { host = new URL(url).hostname; } catch (e) { /* leer */ }
    var plat = LC.detectPlatform(host);
    var R = RESULT_RULES[plat.id] || RESULT_RULES.generic;

    var items = [];
    for (var i = 0; i < R.items.length; i++) {
      try {
        var found = doc.querySelectorAll(R.items[i]);
        if (found && found.length) { items = Array.prototype.slice.call(found); break; }
      } catch (e) { /* weiter */ }
    }

    var out = [];
    var seen = Object.create(null);

    for (var j = 0; j < items.length && out.length < limit; j++) {
      var el = items[j];
      var linkEl = pickEl(el, R.link);
      // Wenn der Treffer-Container selbst der Link ist (Temu), ihn direkt nehmen.
      if (!linkEl && el.tagName === 'A') linkEl = el;
      var href = linkEl ? linkEl.getAttribute('href') || '' : '';
      /* href="#" / javascript: aufgeloest ergibt die SUCHSEITE. Wer die dann als
         "Produktseite" oeffnet, liest doc.title und den erstbesten Kachelpreis -
         die Phantomkarte "Amazon.de : <EAN>" (live 06.08.2026). Lieber keine URL. */
      if (/^\s*(#|javascript:)/i.test(href)) href = '';
      if (href) { try { href = new URL(href, url).href; } catch (e) { /* roh lassen */ } }

      var titel = pickText(el, R.titel);
      var tileMarke = '';

      /* Otto rendert ZWEI Kachelvarianten: eine mit __brand + __title, eine mit
         einem einzigen <span class="reptile-product-title">, das nur den
         Produkttyp traegt - "Klapptisch", ohne Marke, ohne Masse. Damit ist
         jede Identitaetspruefung chancenlos, und genau deshalb war der eigene
         Artikel auf Otto "nicht findbar". Jede Kachel fuehrt aber ihr eigenes
         JSON-LD mit vollem name und brand (live 05./06.08.2026). */
      if (plat.id === 'otto') {
        var ldEl = el.querySelector('script[type="application/ld+json"]');
        if (ldEl) {
          try {
            var ld = JSON.parse(ldEl.textContent);
            if (Array.isArray(ld)) ld = ld[0];
            if (ld && ld.name && clean(ld.name).length > titel.length) titel = clean(ld.name);
            if (ld && ld.brand) tileMarke = clean(ld.brand.name || ld.brand);
          } catch (e) { /* kaputtes JSON - Kacheltext bleibt */ }
        }
      }

      /* Temu klebt UI-Text an die Kacheltitel - ohne Saeuberung faellt die
         Titelaehnlichkeit echter CASARIA-Treffer auf 7-13% (live 05.08.2026). */
      if (plat.id === 'temu') {
        titel = titel
          .replace(/^(Top-Auswahl|Lokal|Anzeige|Gesponsert)+/gi, '')
          .replace(/In neuer Registerkarte öffnen\.?$/i, '')
          .replace(/\s*-\s*Temu( Germany)?$/i, '');
        titel = clean(titel);
      }
      // eBay schiebt "Shop on eBay"-Platzhalter und Werbekacheln dazwischen.
      // Live 05.08.2026: die Karte kam trotz Exakt-Filter durch (Zusatztext) -
      // deshalb Teilstring statt Volltreffer.
      if (/shop on ebay/i.test(titel)) continue;
      if (!titel || /^neues angebot$/i.test(titel)) {
        titel = titel.replace(/^neues angebot\s*/i, '');
        if (!titel) continue;
      }
      if (!href && !titel) continue;

      var id = '';
      try { id = clean(R.id(el, href)); } catch (e) { /* leer */ }
      if (id && seen[id]) continue;
      if (id) seen[id] = 1;

      /* Kein brauchbarer Link, aber eine ID? Dann die kanonische Produkt-URL
         bauen - searchUrl() macht daraus bei Amazon /dp/<ASIN>. Betrifft jede
         gesponserte Kachel, deren einziger Link ein /sspa/click-Tracker ist. */
      if (!href && id && plat.id === 'amazon') href = searchUrl('amazon', id, 'asin');

      // R.preis darf wie R.id eine Funktion sein - bol zerlegt den Preis in
      // aria-hidden-Einzelspans, das ist mit einer Selektorliste nicht lesbar.
      var preisText = '';
      try {
        preisText = clean(typeof R.preis === 'function' ? R.preis(el) : pickText(el, R.preis));
      } catch (e) { /* leer */ }
      var preis = LC.parseNum(preisText);
      // "1,23 bis 4,56" / Preisspannen: nur den ersten Wert nehmen (macht parseNum schon).

      /* Kachel ohne Produkt-ID UND ohne Preis ist keine Ware, sondern ein
         Layout-Block. Live 05.08.2026: Amazons "Keine Ergebnisse fuer deine
         Suchanfrage." steht in einer s-result-item-Huelle mit leerem data-asin
         und wurde so zum Treffer Pos. 1. */
      if (!id && preis == null) continue;

      out.push({
        gesucht_am: new Date(),
        suchbegriff: clean(query || ''),
        suchtyp: qtype || (query ? detectQueryType(query) : ''),
        plattform: plat.label,
        position: out.length + 1,
        produkt_id: id,
        titel: titel,
        // Otto & Co. fuehren die Marke separat, nicht im Kacheltitel -
        // ohne dieses Feld verwirft der Identitaetscheck eigene Listings.
        // JSON-LD der Kachel schlaegt den CSS-Selektor (Otto, s.o.).
        marke: tileMarke || (R.marke ? pickText(el, R.marke) : ''),
        preis: preis,
        waehrung: preisText ? (/£|GBP/.test(preisText) ? 'GBP' : (/\$|USD/.test(preisText) ? 'USD' : 'EUR')) : '',
        gesponsert: (function () { try { return R.sponsored(el) ? 'ja' : ''; } catch (e) { return ''; } })(),
        url: href,
        treffer_gesamt: items.length
      });
    }

    /* Redirect-Fall (live verifiziert): deubaxxl/Shopware leitet bei exaktem
       SKU-Treffer DIREKT auf die Produktseite um, bol macht das bei EAN-Suchen
       vermutlich auch. Dann gibt es keine Trefferliste - die Produktseite selbst
       ist der Treffer.
       ZWEI Bremsen (live 05.08.2026, Kaufland): auf einer URL, die noch die
       Suchseite ist, wird NICHT als Produkt gelesen - sonst wird "Keine
       passenden Suchergebnisse gefunden" mit einem Karussell-Preis (75,99 €)
       zum Treffer. Und ohne echte Kennung (EAN/SKU/ID) zaehlt die Seite nicht -
       ein Preis allein ist kein Produkt. */
    if (!out.length && !istSuchUrl(plat.id, url)) {
      var row = null;
      try { row = LC.extract(doc, url); } catch (e) { /* kein Produkt */ }
      if (row && row.titel && (row.ean || row.sku || row.produkt_id)) {
        out.push({
          gesucht_am: new Date(),
          suchbegriff: clean(query || ''),
          suchtyp: qtype || (query ? detectQueryType(query) : ''),
          plattform: plat.label,
          position: 1,
          produkt_id: row.produkt_id || row.sku || row.ean,
          titel: row.titel,
          // Produktseite = Identitaetsmerkmale liegen vor. Weiterreichen, sonst
          // kann LC.match sie nicht als Beweis verwenden.
          marke: row.marke || '',
          ean: row.ean || '',
          mpn: row.mpn || row.sku || '',
          preis: row.preis,
          waehrung: row.waehrung || 'EUR',
          gesponsert: '',
          url: url,
          treffer_gesamt: 1
        });
      }
    }

    return out;
  }

  // ------------------------------------------------------------ Excel-Felder (Blatt "Suchtreffer")

  var MATCH_FIELDS = [
    { key: 'gesucht_am',     label: 'Gesucht am',     type: 'datetime' },
    { key: 'suchbegriff',    label: 'Suchbegriff',    type: 'text' },
    { key: 'suchtyp',        label: 'Typ',            type: 'text' },
    { key: 'plattform',      label: 'Plattform',      type: 'text' },
    { key: 'position',       label: 'Pos.',           type: 'int' },
    { key: 'produkt_id',     label: 'Produkt-ID/ASIN', type: 'text' },
    { key: 'titel',          label: 'Titel',          type: 'text' },
    { key: 'marke',          label: 'Marke',          type: 'text' },
    { key: 'preis',          label: 'Preis',          type: 'money' },
    { key: 'waehrung',       label: 'Waehrung',       type: 'text' },
    // Identitaetspruefung aus shared/match.js - ein Preis ohne Nachweis zaehlt nicht.
    { key: 'match_bestaetigt', label: 'belegt?',      type: 'text' },
    { key: 'match_stufe',      label: 'Nachweis',     type: 'text' },
    { key: 'match_grund',      label: 'Begruendung',  type: 'text' },
    { key: 'gesponsert',     label: 'Gesponsert',     type: 'text' },
    { key: 'treffer_gesamt', label: 'Treffer gesamt', type: 'int' },
    { key: 'url',            label: 'URL',            type: 'text' }
  ];

  LC.search = {
    detectQueryType: detectQueryType,
    searchUrl: searchUrl,
    extractSearchResults: extractSearchResults,
    comparePlatforms: comparePlatforms,
    sellingPlatforms: sellingPlatforms,
    queryFor: queryFor,
    targetQueries: targetQueries,
    shopQueries: shopQueries,
    istSuchUrl: istSuchUrl,
    aggregatorUrl: aggregatorUrl,
    parseAggregator: parseAggregator,
    parseEvidencePortal: parseEvidencePortal,
    shopZuPlattform: shopZuPlattform,
    AGGREGATOREN: AGGREGATOREN,
    googleUrl: googleUrl,
    googleSiteQuery: googleSiteQuery,
    parseGoogle: parseGoogle,
    SEARCH_URLS: SEARCH_URLS,
    MATCH_FIELDS: MATCH_FIELDS
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = LC.search;
})();
