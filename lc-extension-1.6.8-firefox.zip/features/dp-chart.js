/* Verlaufs-Chart (Keepa-artig) fuer die Karte auf der Produktseite - ersetzt die
   Mini-Sparkline aus onpage.js ueber LC.onpage.chart(container, samples, ui).

   samples = [[iso, preis, bsr, buyboxCode, anbieter, angebotMin, bestand?,
   uvp?, verkaeufe?], ...] aus dem lokalen Verlauf (hist:<ASIN>, background.js),
   ergaenzt um die Historie von Helium 10 (mitH10, idx 7/8 kommen nur von dort).
   buyboxCode 2 = Buybox unterdrueckt. Kurven (SERIEN-Konfig, feste Farben - auf hell UND dunkel lesbar):
     - Buybox (idx 1) #e47911 mit Flaeche, Angebot min. (idx 5, AOD-Gesamtmarkt)
       #2e8b57 mit Luecken statt Ueberbrueckung - beide auf der Preisachse
     - BSR (idx 2) #7c7cd0 gestrichelt, eigene Achse rechts, NICHT invertiert:
       kleiner Rang unten, gleiche Leserichtung wie die Preiskurve (LO 04.09.)
     - Anbieterzahl (idx 4) #999 und Bestand (idx 6) #b8860b als normierte
       Stufenlinien, eigene Skala, default ausgeblendet (Bestand nur ab 2 Werten)
     - UVP (idx 7) #d9a05b gepunktet auf der Preisachse und Verkaeufe (idx 8)
       #00758f als Stufenlinie mit eigener Skala - beide aus Helium 10
     - Buybox-unterdrueckt-Zeitraeume als dezente rote Flaeche im Hintergrund,
       zusaetzlich rote Punkte auf der Buybox-Linie
   Legende zum Ein-/Ausblenden je Kurve (sichtbar{}, IIFE-Ebene, ueberlebt den
   Neuaufbau, gilt fuer inline+Overlay gleich). Keine Requests, kein eigenes
   CSS ausser den paar Overlay-/Legende-Inline-Styles: Texte mit fill=
   "currentColor", Gitter mit stroke="currentColor" -> Dark Mode groesstenteils
   gratis.

   Fenster = Zeitraum + Zoom in EINEM Modell (zoomState[asin] = {t0,t1} in ms,
   IIFE-Ebene, ueberlebt den 800ms-Panel-Neuaufbau): die Zeitraum-Links (24h/7T/
   30T/90T/1J/Alles) setzen zoomState direkt (Fenster = letzte Messung minus
   Zeitraum), Drag im SVG + Mausrad um den Cursor + die Zeitstrahl-Leiste unter
   dem Chart (Keepa/Highcharts-Navigator: Track = kompletter Datenbestand, Fenster
   darin ziehbar/verschiebbar) schreiben denselben zoomState - eine Quelle der
   Wahrheit. Aktiver Zeitraum-Link ist nur fett, wenn das Fenster ihm entspricht;
   nach freiem Zoom keiner. "Zoom zuruecksetzen" + Doppelklick loeschen das Fenster.
   Beim allerersten Rendern einer ASIN ohne zoomState wird einmalig ein Start-
   Fenster aus dem gemerkten Zeitraum (chrome.storage lcChartRange) abgeleitet.

   Popup: Chip "Gross anzeigen" oeffnet ein Singleton-Overlay an document.body
   (nicht im Panel - abraeumen() darf es nicht greifen), render() wird darin nur
   groesser (Breite/Hoehe parametrisiert) mit denselben Gesten aufgerufen. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};

  var NS = 'http://www.w3.org/2000/svg';
  var RANGES = [['1', '24h'], ['7', '7T'], ['30', '30T'], ['90', '90T'], ['365', '1J'], ['alles', 'Alles']];
  var TAGE = { '1': 1, '7': 7, '30': 30, '90': 90, '365': 365 };  // Tage je Zeitraum-Key (fuer 'alles' kein Eintrag)
  var range = null;                                               // null = noch nicht aus dem Speicher gelesen
  var zoomState = {};                                              // asin -> {t0,t1} in ms, ueberlebt den 800ms-Neuaufbau


  var initialisiert = {};                                          // asin -> true nach dem ersten Rendern (Start-Fenster
                                                                    // aus range nur EINMAL ableiten, sonst ueberschreibt
                                                                    // range bei jedem Neuaufbau einen manuellen Zoom)
  var SERIEN = [                                                   // Kurven-Konfig: id/Label/Sample-Index/Farbe/Default-an
    { id: 'preis', label: 'Buybox', idx: 1, farbe: '#e47911', an: true },
    { id: 'angebot', label: 'Angebot min.', idx: 5, farbe: '#2e8b57', an: true },
    { id: 'bsr', label: 'BSR', idx: 2, farbe: '#7c7cd0', an: true },
    { id: 'anbieter', label: 'Anbieter', idx: 4, farbe: '#999', an: false },
    { id: 'bestand', label: 'Bestand', idx: 6, farbe: '#b8860b', an: false },
    { id: 'uvp', label: 'UVP', idx: 7, farbe: '#d9a05b', an: false },
    { id: 'verkaeufe', label: 'Verkäufe', idx: 8, farbe: '#00758f', an: true }
  ];
  var h10Info = {};                                                // asin -> Herkunftszeile, ueberlebt den Neuaufbau von render()
  var sichtbar = {};                                               // id -> an/aus, IIFE-Ebene, ueberlebt den Neuaufbau
  SERIEN.forEach(function (s) { sichtbar[s.id] = s.an; });

  var sv = function (tag, attrs) {
    var e = document.createElementNS(NS, tag);
    for (var k in attrs) if (attrs[k] != null) e.setAttribute(k, attrs[k]);
    return e;
  };
  var t = function (s) { return Date.parse(s[0]); };
  var datum = function (ui, ms) { var d = new Date(ms); return ui.tag(d) + d.getFullYear(); };

  // ------------------------------------------------------------ Vollbild-Overlay
  // Singleton an document.body - wird nur EINMAL erzeugt, ueberlebt jeden Panel-Neuaufbau.
  var overlayEl = null, overlayBody = null;

  function overlaySchliessen() {
    if (overlayEl) overlayEl.style.display = 'none';
  }

  function overlayAufbauen() {
    if (overlayEl) return;                                        // idempotent: Listener nur einmal, nicht pro Oeffnen
    overlayEl = document.createElement('div');
    overlayEl.id = 'lc-chart-overlay';
    // data-lc-keep: nimmt Overlay + Kinder aus der Dark-Mode-Grundregel aus
    // (die wuerde die Inline-Farben ueberschreiben), ohne dass abraeumen()
    // ([data-lc]-Selektor) das Overlay beim Panel-Neuaufbau loescht.
    overlayEl.setAttribute('data-lc-keep', '1');
    // Abdunkler und Schlagschatten bleiben absolutes Schwarz-Transparent: sie
    // faerben nicht, sie dimmen die Seite dahinter - das gehoert in beiden Modi gleich.
    overlayEl.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:2147483647;display:none;align-items:center;justify-content:center;padding:16px';
    overlayEl.addEventListener('click', function (ev) { if (ev.target === overlayEl) overlaySchliessen(); });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape' && overlayEl.style.display !== 'none') overlaySchliessen();
    });

    var box = document.createElement('div');
    box.style.cssText = 'position:relative;background:var(--lc-card,#fff);color:var(--lc-fg,#0F1111);' +
      'border:1px solid var(--lc-line,#E7E7E7);border-radius:8px;box-shadow:0 8px 32px rgba(0,0,0,.4);' +
      'width:90vw;height:90vh;max-width:1500px;padding:16px 20px;overflow:auto;font-family:"Amazon Ember",Arial,sans-serif';

    var close = document.createElement('span');
    close.textContent = '×';
    close.title = 'Schließen (Esc)';
    close.style.cssText = 'position:absolute;top:4px;right:14px;cursor:pointer;font-size:28px;line-height:1;color:var(--lc-fg2,#565959);user-select:none';
    close.addEventListener('mouseenter', function () { close.style.color = 'var(--lc-price,#C7511F)'; });
    close.addEventListener('mouseleave', function () { close.style.color = 'var(--lc-fg2,#565959)'; });
    close.addEventListener('click', overlaySchliessen);

    overlayBody = document.createElement('div');
    overlayBody.style.cssText = 'margin-top:8px';

    box.appendChild(close); box.appendChild(overlayBody);
    overlayEl.appendChild(box);
    document.body.appendChild(overlayEl);
  }

  function overlayOeffnen(asin, all, ui) {
    overlayAufbauen();
    overlayEl.style.display = 'flex';
    render(overlayBody, all, ui, asin, { w: 1200, h: 560, overlay: true });
  }

  function render(container, all, ui, asin, dims) {
    dims = dims || {};
    var W = dims.w || 400, H_ = dims.h || 200, PL = 58, PR = 48, PT = 8, PB = 18;      // viewBox -> bei 300 px Breite ~150 px hoch
    var PH = H_ - PT - PB, PW = W - PL - PR;

    container.innerHTML = '';

    // -- Fenster (= Zeitraum + Zoom, EIN Modell): Track/Grenzen sind immer der
    // volle Datenbestand (all[0]..all[letzte]). zoomState haelt das sichtbare
    // Fenster je ASIN. Beim allerersten Rendern einer ASIN ohne zoomState wird
    // einmalig aus dem gemerkten Zeitraum (range) ein Start-Fenster abgeleitet
    // und in zoomState geschrieben - danach ist zoomState die einzige Quelle
    // der Wahrheit (sonst wuerde z.B. ein Wheel-Zoom auf "Alles" beim naechsten
    // Neuaufbau durch den alten range-Wert wieder eingeengt, LO-Feedback 31.08.).
    var basisT0 = t(all[0]), basisT1 = Math.max(basisT0 + 1, t(all[all.length - 1]));
    var zoom = asin ? zoomState[asin] : null;
    if (!zoom && asin && !initialisiert[asin] && range && range !== 'alles' && TAGE[range]) {
      zoomState[asin] = { t0: Math.max(basisT0, basisT1 - TAGE[range] * 864e5), t1: basisT1 };
      zoom = zoomState[asin];
    }
    if (asin) initialisiert[asin] = true;
    var t0 = basisT0, t1 = basisT1;
    if (zoom) { t0 = Math.max(basisT0, zoom.t0); t1 = Math.min(basisT1, zoom.t1); if (t1 <= t0) t1 = Math.min(basisT1, t0 + 1); }

    var pts = all.filter(function (s) { var tt = t(s); return tt >= t0 && tt <= t1; });
    var hinweis = pts.length < 2 ? ' · nur ' + pts.length + (pts.length === 1 ? ' Messung' : ' Messungen') + ' im Ausschnitt' : '';

    var TOLERANZ = 60000;                                          // 1 Minute Toleranz gegen Rundung beim Preset-Vergleich
    var eingeschraenkt = t0 > basisT0 || t1 < basisT1;
    var presetAktiv = function (key) {
      if (key === 'alles') return !eingeschraenkt;
      if (!eingeschraenkt) return false;
      var soll = TAGE[key] * 864e5;
      return Math.abs(t1 - basisT1) < TOLERANZ && Math.abs((t1 - t0) - soll) < TOLERANZ;
    };

    // -- Zeitraum-Links + Zoom-Reset + Vollbild
    var row = ui.el('div', 'a-size-small lc-chart-range');
    RANGES.forEach(function (r, i) {
      if (i) row.appendChild(document.createTextNode(' · '));
      var a = ui.el('a', 'a-link-normal' + (presetAktiv(r[0]) ? ' a-text-bold' : ''), r[1]);
      a.href = '#'; a.title = 'Verlauf der letzten ' + (r[0] === 'alles' ? 'Aufrufe komplett' : r[1]) + ' zeigen';
      a.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        range = r[0];
        try { chrome.storage.local.set({ lcChartRange: range }); } catch (e) { /* Speicher weg - egal */ }
        if (asin) {
          if (r[0] === 'alles') delete zoomState[asin];
          else zoomState[asin] = { t0: Math.max(basisT0, basisT1 - TAGE[r[0]] * 864e5), t1: basisT1 };
        }
        render(container, all, ui, asin, dims);
      });
      row.appendChild(a);
    });
    if (eingeschraenkt) {
      row.appendChild(document.createTextNode(' · '));
      var zr = ui.el('a', 'a-link-normal', 'Zoom zurücksetzen');
      zr.href = '#'; zr.title = 'Zeitachse wieder auf den vollen Zeitraum stellen';
      zr.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        if (asin) delete zoomState[asin];
        range = 'alles';
        try { chrome.storage.local.set({ lcChartRange: range }); } catch (e) { /* egal */ }
        render(container, all, ui, asin, dims);
      });
      row.appendChild(zr);
    }
    if (!dims.overlay) {
      row.appendChild(document.createTextNode(' · '));
      var gross = ui.el('a', 'a-link-normal', 'Groß anzeigen ⛶');
      gross.href = '#'; gross.title = 'Verlauf groß in einem Overlay anzeigen';
      gross.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        overlayOeffnen(asin, all, ui);
      });
      row.appendChild(gross);
    }
    container.appendChild(row);

    // -- Legende: farbiges Kaestchen + Name je Kurve, klickbar zum Ein-/Ausblenden
    var legRow = ui.el('div', 'a-size-mini lc-chart-legende');
    legRow.style.cssText = 'display:flex;flex-wrap:wrap;gap:4px 10px;margin:4px 0 2px;align-items:center';
    SERIEN.forEach(function (ser) {
      var an = !!sichtbar[ser.id];
      // Ehrlich zeigen, WARUM eine Kurve fehlt (LO 01.09. "ich seh nur 1 kurve"):
      // ohne Werte im Verlauf gibt es nichts zu zeichnen - ausgegraut + erklaert.
      var hatDaten = pts.some(function (s) { return s[ser.idx] != null; });
      var item = ui.el('span', 'lc-chart-leg-item');
      item.style.cssText = 'cursor:pointer;display:inline-flex;align-items:center;gap:4px;opacity:' + (!hatDaten ? '.3' : an ? '1' : '.45');
      var swatch = document.createElement('span');
      swatch.style.cssText = 'display:inline-block;width:9px;height:9px;border-radius:2px;background:' + ser.farbe;
      item.appendChild(swatch);
      item.appendChild(document.createTextNode(ser.label + (hatDaten ? '' : ' (keine Daten)')));
      item.title = hatDaten ? (an ? 'Ausblenden: ' : 'Einblenden: ') + ser.label
        : 'Noch keine Werte im Verlauf – ' +
          (ser.id === 'angebot' ? 'entsteht, wenn die Angebotsliste (AOD) der Seite geladen wurde'
           : ser.id === 'bestand' ? 'entsteht, wenn Amazon „Nur noch X auf Lager" zeigt'
           : ser.id === 'uvp' ? 'kommt von Helium 10, sobald Amazon einen Streichpreis führt'
           : ser.id === 'verkaeufe' ? 'liefert Helium 10 erst ab Platinum – mit dem Gratis-Zugang gesperrt'
           : 'entsteht bei künftigen Seitenbesuchen');
      item.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        sichtbar[ser.id] = !sichtbar[ser.id];
        render(container, all, ui, asin, dims);
      });
      legRow.appendChild(item);
    });
    container.appendChild(legRow);

    // -- Skalen
    var x = function (s) { return PL + PW * (t(s) - t0) / (t1 - t0); };
    var xZuT = function (xv) { return t0 + (xv - PL) / PW * (t1 - t0); };
    var minmax = function (vals) { return vals.length ? { mn: Math.min.apply(null, vals), mx: Math.max.apply(null, vals) } : null; };
    var werte = function (idx) { return pts.map(function (s) { return s[idx]; }).filter(function (v) { return v != null; }); };
    var pr = minmax(werte(1).concat(werte(5)).concat(werte(7)));  // Buybox + Angebot min. + UVP auf einer Achse
    var bs = minmax(werte(2));
    var anbieterSkala = minmax(werte(4));
    var bestandWerte = werte(6);
    var bestandSkala = bestandWerte.length >= 2 ? minmax(bestandWerte) : null;   // oft lueckenhaft - erst ab 2 Werten zeichnen
    /* nullBasis: die Achse beginnt bei 0 statt beim kleinsten Messwert.
       Vorher lag der niedrigste Preis IMMER am unteren Rand — 89 EUR statt
       100 sah aus wie ein Sturz auf null, obwohl es 11 % waren (LO 04.09.:
       "lass y bei 0 EUR starten"). Gilt fuer alle Mengengroessen: Preis,
       Anbieterzahl, Bestand, Verkaeufe.
       NICHT fuer den Bestseller-Rang: der laeuft von 1 bis in die
       Hunderttausende, eine Nullbasis wuerde jede Bewegung plattdruecken.

       Die gezeichnete Spanne wird EINMAL berechnet und sowohl von der Kurve
       als auch von der Achsenbeschriftung benutzt — sonst laufen die Zahlen
       an der Achse und die Linie auseinander, und die Beschriftung luegt. */
    var gezeichnet = function (sc, nullBasis) {
      if (!sc) return null;
      if (!nullBasis) return sc;
      // Bis zum doppelten Hoechstwert: die Kurve liegt mittig in der Flaeche
      // statt am oberen Rand zu kleben (LO 04.09.: "er soll mittig liegen").
      return { mn: 0, mx: sc.mx > 0 ? sc.mx * 2 : 1 };
    };
    var yOf = function (sc, invert) {
      return function (v) {
        var f = sc.mx === sc.mn ? 0.5 : (v - sc.mn) / (sc.mx - sc.mn);
        if (invert) f = 1 - f;
        return PT + PH * (1 - f);
      };
    };
    var verkaufSkala = minmax(werte(8));
    var prG = gezeichnet(pr, true), bsG = gezeichnet(bs, false);
    var anbieterG = gezeichnet(anbieterSkala, true);
    var bestandG = gezeichnet(bestandSkala, true);
    var verkaufG = gezeichnet(verkaufSkala, true);
    /* Der Bestseller-Rang laeuft jetzt in derselben Richtung wie der Preis:
       kleiner Wert unten, grosser oben (LO 04.09.: "unten = kleiner bsr").
       Vorher war die Achse gespiegelt, damit "besser" oben liegt — bei zwei
       Linien in einer Flaeche hiess das zwei Leserichtungen gleichzeitig. */
    var yPr = prG ? yOf(prG, false) : null, yBs = bsG ? yOf(bsG, false) : null;
    var yAnbieter = anbieterG ? yOf(anbieterG, false) : null;
    var yBestand = bestandG ? yOf(bestandG, false) : null;
    var yVerkauf = verkaufG ? yOf(verkaufG, false) : null;
    var pfad = function (idx, y, luecken) {
      if (luecken) {                                              // Lauf abbrechen statt ueber Nullwerte hinwegzuzeichnen
        var d = '', offen = false;
        pts.forEach(function (s) {
          if (s[idx] == null) { offen = false; return; }
          d += (offen ? 'L' : 'M') + x(s).toFixed(1) + ' ' + y(s[idx]).toFixed(1) + ' ';
          offen = true;
        });
        return d.trim();
      }
      var v = pts.filter(function (s) { return s[idx] != null; });
      if (v.length < 2) return '';
      return v.map(function (s, i) { return (i ? 'L' : 'M') + x(s).toFixed(1) + ' ' + y(s[idx]).toFixed(1); }).join(' ');
    };
    var pfadStufe = function (idx, y) {                            // Stufenlinie fuer Anbieter/Bestand
      var v = pts.filter(function (s) { return s[idx] != null; });
      if (v.length < 2) return '';
      var d = 'M' + x(v[0]).toFixed(1) + ' ' + y(v[0][idx]).toFixed(1);
      for (var i = 1; i < v.length; i++) {
        d += ' L' + x(v[i]).toFixed(1) + ' ' + y(v[i - 1][idx]).toFixed(1) + ' L' + x(v[i]).toFixed(1) + ' ' + y(v[i][idx]).toFixed(1);
      }
      return d;
    };

    /* Preis, guenstigstes Angebot und UVP sind ZUSTANDSgroessen: ein Preis gilt,
       bis er sich aendert. Eine gerade Verbindung zwischen zwei Messungen
       behauptet dagegen eine gleitende Bewegung, die nie stattfand - aus einem
       Wechsel zwischen zwei Niveaus wurden spitze V-Zacken statt Plateaus
       (LO 04.09.: "geht immer zu 0 ... -_-_- statt VVVVV").
       Deshalb Treppenstufen. maxLuecke bricht den Lauf ab, wenn zwischen zwei
       Messungen so lange nichts kam, dass ein durchgezogenes Plateau eine
       Behauptung waere; ohne Angabe laeuft die Stufe durch.
       Der Bestseller-Rang bleibt linear - er ist eine fortlaufend gemessene
       Groesse, keine Stufe. */
    /* bisRand verlaengert das letzte Plateau bis zum rechten Rand der
       Zeichenflaeche. Ohne das endet die Linie am letzten Messpunkt DIESER
       Reihe, waehrend der Tooltip rechts davon ihren Wert weiterhin nennt —
       bei 13 Preis- gegen 201 BSR-Messungen ist das der ganze rechte Teil des
       Charts. Seit letzterWert() nach vorne durchfuellt, muss die Kurve
       dieselbe Aussage treffen, sonst widersprechen sich Bild und Tooltip.
       Nicht fuer "Angebot min.": dort bricht LUECKE_ANGEBOT laengere
       Messluecken bewusst auf, ein durchgezogenes Plateau waere dort eine
       Behauptung ueber den Markt, die keine Messung deckt. */
    var pfadStufeLuecke = function (idx, y, maxLuecke, bisRand) {
      var v = pts.filter(function (s) { return s[idx] != null; });
      if (v.length < 2) return '';
      var d = 'M' + x(v[0]).toFixed(1) + ' ' + y(v[0][idx]).toFixed(1);
      for (var i = 1; i < v.length; i++) {
        if (maxLuecke && t(v[i]) - t(v[i - 1]) > maxLuecke) {
          d += ' M' + x(v[i]).toFixed(1) + ' ' + y(v[i][idx]).toFixed(1);   // Lauf neu ansetzen
          continue;
        }
        d += ' L' + x(v[i]).toFixed(1) + ' ' + y(v[i - 1][idx]).toFixed(1) +
             ' L' + x(v[i]).toFixed(1) + ' ' + y(v[i][idx]).toFixed(1);
      }
      if (bisRand) {
        var rand = PL + PW;
        if (rand > x(v[v.length - 1]) + 0.5) d += ' L' + rand.toFixed(1) + ' ' + y(v[v.length - 1][idx]).toFixed(1);
      }
      return d;
    };
    var LUECKE_ANGEBOT = 30 * 86400000;   // 30 Tage ohne Messung: kein Plateau behaupten

    // -- SVG
    var svg = sv('svg', { viewBox: '0 0 ' + W + ' ' + H_, 'data-lc': '1', class: 'lc-chart' });
    svg.setAttribute('style', 'display:block;width:100%;height:auto;margin-top:2px;cursor:crosshair');
    // Buybox-unterdrueckt-Zeitraeume (Code 2) als dezente rote Flaeche im Hintergrund -
    // ZUERST gezeichnet, damit Gitter/Kurven optisch darueber liegen.
    // #B12704 bleibt absolut: "Buybox verloren" soll in beiden Modi dasselbe Rot
    // sein, sonst heisst dieselbe Warnung je nach Theme etwas anderes.
    var bbBand = function (lauf) {
      svg.appendChild(sv('rect', { x: x(lauf.von).toFixed(1), y: PT, width: Math.max(2, x(lauf.bis) - x(lauf.von)).toFixed(1), height: PH, fill: '#B12704', opacity: '.08' }));
    };
    var bbLauf = null;
    pts.forEach(function (s) {
      if (s[3] === 2) { if (!bbLauf) bbLauf = { von: s, bis: s }; else bbLauf.bis = s; }
      else if (bbLauf) { bbBand(bbLauf); bbLauf = null; }
    });
    if (bbLauf) bbBand(bbLauf);
    for (var g = 1; g <= 3; g++) {                                // feines Gitter, 3 Linien
      var gy = (PT + PH * g / 4).toFixed(1);
      svg.appendChild(sv('line', { x1: PL, x2: W - PR, y1: gy, y2: gy, stroke: 'currentColor', opacity: '.15', 'stroke-width': '1' }));
    }
    if (sichtbar.anbieter && yAnbieter) {
      var dAnbieter = pfadStufe(4, yAnbieter);
      if (dAnbieter) svg.appendChild(sv('path', { d: dAnbieter, fill: 'none', stroke: '#999', 'stroke-width': '1.25', class: 'lc-chart-anbieter' }));
    }
    if (sichtbar.bestand && yBestand) {
      var dBestand = pfadStufe(6, yBestand);
      if (dBestand) svg.appendChild(sv('path', { d: dBestand, fill: 'none', stroke: '#b8860b', 'stroke-width': '1.25', class: 'lc-chart-bestand' }));
    }
    if (sichtbar.verkaeufe && yVerkauf) {
      var dVerkauf = pfadStufe(8, yVerkauf);
      if (dVerkauf) svg.appendChild(sv('path', { d: dVerkauf, fill: 'none', stroke: '#00758f', 'stroke-width': '1.25', class: 'lc-chart-verkaeufe' }));
    }
    if (sichtbar.uvp && yPr) {
      var dUvp = pfadStufeLuecke(7, yPr, 0, true);   // UVP haelt bis zur naechsten Aenderung, auch bis zum Rand
      if (dUvp) svg.appendChild(sv('path', { d: dUvp, fill: 'none', stroke: '#d9a05b', 'stroke-width': '1.25', 'stroke-dasharray': '2 3', class: 'lc-chart-uvp' }));
    }
    var dPr = yPr ? pfadStufeLuecke(1, yPr, 0, true) : '';   // Treppe, letztes Plateau bis zum rechten Rand
    if (sichtbar.preis && dPr) {
      var v1 = pts.filter(function (s) { return s[1] != null; });
      /* Die Flaeche schliesst an derselben Stelle wie die Linie — sonst
         klafft rechts eine Luecke neben dem verlaengerten Plateau. */
      var prRechts = Math.max(PL + PW, x(v1[v1.length - 1]));
      svg.appendChild(sv('path', { d: dPr + ' L' + prRechts.toFixed(1) + ' ' + (PT + PH) + ' L' + x(v1[0]).toFixed(1) + ' ' + (PT + PH) + ' Z',
        fill: '#e47911', opacity: '.12', stroke: 'none', class: 'lc-chart-area' }));
    }
    var dBs = yBs ? pfad(2, yBs) : '';
    if (sichtbar.bsr && dBs) svg.appendChild(sv('path', { d: dBs, fill: 'none', stroke: '#7c7cd0', 'stroke-width': '1.5', 'stroke-dasharray': '4 3', class: 'lc-chart-bsr' }));
    var dAn = yPr ? pfadStufeLuecke(5, yPr, LUECKE_ANGEBOT) : '';   // Angebot min.: Treppe, aber lange Messluecken offen lassen
    if (sichtbar.angebot && dAn) svg.appendChild(sv('path', { d: dAn, fill: 'none', stroke: '#2e8b57', 'stroke-width': '1.25', class: 'lc-chart-angebot' }));
    if (sichtbar.preis && dPr) svg.appendChild(sv('path', { d: dPr, fill: 'none', stroke: '#e47911', 'stroke-width': '2', 'stroke-linejoin': 'round', class: 'lc-chart-preis' }));
    pts.forEach(function (s) {
      if (s[3] !== 2) return;
      var c = sv('circle', { cx: x(s).toFixed(1), cy: (yPr && s[1] != null ? yPr(s[1]) : PT + PH / 2).toFixed(1), r: '4', fill: '#B12704', class: 'lc-chart-bb' });
      var ti = sv('title'); ti.textContent = 'Buybox unterdrückt ' + datum(ui, t(s)); c.appendChild(ti);
      svg.appendChild(c);
    });
    // Achsentexte: fill=currentColor, damit Dark Mode nichts ueberschreiben muss
    var text = function (str, tx, ty, anchor) {
      var e = sv('text', { x: tx, y: ty, fill: 'currentColor', 'text-anchor': anchor, class: 'a-size-mini lc-chart-label' });
      e.textContent = str; return e;
    };
    /* An JEDER Gitterlinie ein Wert, nicht nur ganz oben und ganz unten: mit
       zwei Zahlen liess sich aus einer vollen Kurve nichts ablesen (LO 04.09.).
       Die Beschriftung sitzt im Rand (PL=58 links, PR=48 rechts) und liegt
       deshalb nie ueber den Daten. Bei konstantem Wert bleibt es bei einer Zahl. */
    var achse = function (skala, fmt, tx, anchor, invert) {
      if (!skala) return;
      if (skala.mx === skala.mn) {
        svg.appendChild(text(fmt(skala.mn), tx, PT + PH / 2 + 3.5, anchor));
        return;
      }
      for (var g = 0; g <= 4; g++) {
        var anteil = g / 4;                                   // 0 = oben
        var wert = invert ? skala.mn + (skala.mx - skala.mn) * anteil
                          : skala.mx - (skala.mx - skala.mn) * anteil;
        var ty = PT + PH * anteil;
        // oben/unten einruecken, damit die Zeile nicht aus der Flaeche laeuft
        svg.appendChild(text(fmt(wert), tx, g === 0 ? ty + 9 : (g === 4 ? ty : ty + 3.5), anchor));
      }
    };
    // Beschriftung aus DERSELBEN Spanne wie die Kurve — siehe gezeichnet().
    achse(prG, function (v) { return ui.eur(v); }, 2, 'start', false);
    achse(bsG, function (v) { return ui.nf(Math.round(v)); }, W - 2, 'end', false);
    svg.appendChild(text(ui.tag(new Date(t0)), PL, H_ - 4, 'start'));
    svg.appendChild(text(ui.tag(new Date((t0 + t1) / 2)), PL + PW / 2, H_ - 4, 'middle'));
    svg.appendChild(text(ui.tag(new Date(t1)), PL + PW, H_ - 4, 'end'));
    var hover = sv('line', { y1: PT, y2: PT + PH, x1: PL, x2: PL, stroke: 'currentColor', opacity: '.5', 'stroke-dasharray': '2 2', visibility: 'hidden', class: 'lc-chart-hover' });
    svg.appendChild(hover);
    /* Auswahlrechteck des Drag-Zooms ist Bedien-Feedback, keine Datenfarbe:
       Amazons Link-Teal #007185 kam auf var(--lc-card) nur auf 2,5:1. Darum der
       Theme-Akzent mit Hellmodus-Rueckfall. WICHTIG: var() wirkt nur im
       style-Attribut - in SVG-Praesentationsattributen (fill=/stroke=) ist es
       ungueltig und faellt auf Schwarz zurueck. */
    var auswahl = sv('rect', { x: PL, y: PT, width: 0, height: PH, opacity: '.15', 'stroke-width': '1', 'stroke-dasharray': '3 2', visibility: 'hidden',
      style: 'fill:var(--lc-link,#007185);stroke:var(--lc-link,#007185)' });
    svg.appendChild(auswahl);
    container.appendChild(svg);

    // -- Zeitstrahl/Scroll-Leiste: Track ist immer der KOMPLETTE Datenbestand
    // (basisT0..basisT1 = all[0]..all[letzte]), das aktuelle Fenster (t0..t1)
    // darin per Drag verschieb- und an den Raendern ziehbar. Schreibt denselben
    // zoomState wie die Chart-Gesten oben und die Zeitraum-Links - eine Quelle
    // der Wahrheit.
    var navH = 14;
    var navSvg = sv('svg', { viewBox: '0 0 ' + W + ' ' + navH, 'data-lc': '1', class: 'lc-chart-nav' });
    navSvg.setAttribute('style', 'display:block;width:100%;height:' + navH + 'px;margin-top:6px;cursor:pointer');
    // Track + Fenster ueber style=, nicht ueber fill=/stroke=: in SVG-Praesentations-
    // attributen ist var() ungueltig, die Leiste waere schwarz statt kartenfarben.
    navSvg.appendChild(sv('rect', { x: PL, y: 0, width: PW, height: navH, style: 'fill:var(--lc-card,#fff);stroke:var(--lc-line,#E7E7E7)' }));
    var navX = function (tt) { return PL + PW * (tt - basisT0) / (basisT1 - basisT0); };
    var navZuT = function (px) { return basisT0 + (px - PL) / PW * (basisT1 - basisT0); };
    // Sichtbares Fenster im selben Theme-Akzent wie das Auswahlrechteck oben
    var navWin = sv('rect', { x: navX(t0).toFixed(1), y: 0.5, width: Math.max(1, navX(t1) - navX(t0)).toFixed(1), height: navH - 1, opacity: '.18', 'stroke-width': '1',
      style: 'fill:var(--lc-link,#007185);stroke:var(--lc-link,#007185)' });
    navSvg.appendChild(navWin);
    container.appendChild(navSvg);

    var navPxVonEvent = function (ev) {
      var rect = navSvg.getBoundingClientRect ? navSvg.getBoundingClientRect() : { left: 0, width: 0 };
      return (ev.clientX - rect.left) * (rect.width ? W / rect.width : 1);
    };
    var griffNav = Math.max(6, PW * 0.02);                         // Griffzone an den Fensterraendern
    var navModusBei = function (px) {
      var x0 = navX(t0), x1 = navX(t1);
      if (Math.abs(px - x0) <= griffNav) return 'links';
      if (Math.abs(px - x1) <= griffNav) return 'rechts';
      if (px >= x0 && px <= x1) return 'verschieben';
      return 'springen';
    };
    var navDrag = null;                                            // {modus, offset, t0, t1} waehrend des Ziehens
    navSvg.addEventListener('pointermove', function (ev) {
      if (navDrag) return;                                         // Cursor waehrend des Ziehens nicht neu bestimmen
      var m = navModusBei(navPxVonEvent(ev));
      navSvg.style.cursor = (m === 'links' || m === 'rechts') ? 'ew-resize' : (m === 'verschieben' ? 'grab' : 'pointer');
    });
    navSvg.addEventListener('pointerdown', function (ev) {
      if (ev.button !== 0) return;
      ev.preventDefault();
      var px = navPxVonEvent(ev), modus = navModusBei(px);
      if (modus === 'springen') {                                  // Klick ausserhalb des Fensters - dort zentrieren
        var breite = t1 - t0;
        var neuT0 = Math.max(basisT0, Math.min(basisT1 - breite, navZuT(px) - breite / 2));
        if (asin) {
          if (neuT0 <= basisT0 && neuT0 + breite >= basisT1) delete zoomState[asin];
          else zoomState[asin] = { t0: neuT0, t1: neuT0 + breite };
        }
        render(container, all, ui, asin, dims);
        return;
      }
      navDrag = { modus: modus, offset: modus === 'verschieben' ? navZuT(px) - t0 : 0 };
      try { navSvg.setPointerCapture(ev.pointerId); } catch (e) { /* egal */ }
      navSvg.style.cursor = modus === 'verschieben' ? 'grabbing' : 'ew-resize';
    });
    navSvg.addEventListener('pointermove', function (ev) {
      if (!navDrag) return;
      var px = navPxVonEvent(ev), breite = t1 - t0;
      var neuT0 = t0, neuT1 = t1;
      if (navDrag.modus === 'links') neuT0 = Math.min(t1 - 1000, Math.max(basisT0, navZuT(px)));
      else if (navDrag.modus === 'rechts') neuT1 = Math.max(t0 + 1000, Math.min(basisT1, navZuT(px)));
      else { neuT0 = Math.max(basisT0, Math.min(basisT1 - breite, navZuT(px) - navDrag.offset)); neuT1 = neuT0 + breite; }
      navWin.setAttribute('x', navX(neuT0).toFixed(1));
      navWin.setAttribute('width', Math.max(1, navX(neuT1) - navX(neuT0)).toFixed(1));
      navDrag.t0 = neuT0; navDrag.t1 = neuT1;
    });
    navSvg.addEventListener('pointerup', function (ev) {
      if (!navDrag) return;
      var geaendert = navDrag.t0 != null;
      var neuT0 = geaendert ? navDrag.t0 : t0, neuT1 = geaendert ? navDrag.t1 : t1;
      navDrag = null;
      try { navSvg.releasePointerCapture(ev.pointerId); } catch (e) { /* egal */ }
      if (!geaendert) return;                                      // reiner Klick, kein Ziehen - kein Zoom-Wechsel
      if (asin) {
        if (neuT0 <= basisT0 && neuT1 >= basisT1) delete zoomState[asin];
        else zoomState[asin] = { t0: neuT0, t1: neuT1 };
      }
      render(container, all, ui, asin, dims);
    });

    // -- Zeile unter dem Chart: Zusammenfassung, bei Hover die naechste Messung
    var span = function (sc, fmt) { return sc ? (sc.mn === sc.mx ? fmt(sc.mn) : fmt(sc.mn) + '–' + fmt(sc.mx)) : '–'; };

    /* Jede eingeschaltete Reihe steht IMMER in der Uebersicht — auch wenn im
       gezoomten Ausschnitt keine einzige Messung von ihr liegt und die Kurve
       darum nicht zu sehen ist (LO 04.09.: "wenn ich reinzoom und der buybox
       graph nicht mehr sichtbar wird, ist seine value auch weg unten, die
       sollte aber immer da sein ... zur uebersicht").
       Liegt im Ausschnitt nichts, wird der letzte bekannte Stand VOR dem
       Ausschnitt gezeigt und als solcher gekennzeichnet — bei Zustandsgroessen
       wie Preis oder UVP gilt der ja weiter. Gibt es auch davor nichts, steht
       "n. v." da; der Eintrag verschwindet nie. */
    var standVor = function (idx) {
      for (var i = all.length - 1; i >= 0; i--) {
        var s = all[i];
        if (t(s) < t0 && s[idx] != null) return s[idx];
      }
      return null;
    };
    var reihenWert = function (idx, fmt) {
      var sc = minmax(werte(idx));
      if (sc) return span(sc, fmt);
      var v = standVor(idx);
      return v != null ? 'Stand ' + fmt(v) : 'n. v.';
    };

    var teile = [];
    if (sichtbar.preis) teile.push('Buybox ' + reihenWert(1, ui.eur));
    if (sichtbar.angebot) teile.push('Angebot min. ' + reihenWert(5, ui.eur));
    if (sichtbar.bsr) teile.push('BSR ' + reihenWert(2, ui.nf));
    if (sichtbar.anbieter) teile.push('Anbieter ' + reihenWert(4, ui.nf));
    if (sichtbar.bestand) teile.push('Bestand ' + reihenWert(6, ui.nf));
    if (sichtbar.uvp) teile.push('UVP ' + reihenWert(7, ui.eur));
    if (sichtbar.verkaeufe) teile.push('Verkäufe ' + reihenWert(8, ui.nf));
    var zusammen = pts.length + ' Messungen seit ' + ui.tag(new Date(t0)) + (teile.length ? ' · ' + teile.join(' · ') : '') + hinweis;
    var info = ui.el('div', 'a-size-mini lc-k lc-chart-info', ui.esc(zusammen));
    info.title = 'Eigene Aufrufe dieser Seite plus die Historie von Helium 10. Maus über den Chart zeigt die einzelne Messung, ziehen zoomt, Mausrad zoomt um den Cursor.';
    container.appendChild(info);

    // Herkunftszeile: sagt, ob und was Helium 10 geliefert hat. Ohne sie sah ein
    // Fehlschlag genauso aus wie „gibt es nicht" (LO 03.09.).
    var quelle = asin ? h10Info[asin] : '';
    if (quelle) container.appendChild(ui.el('div', 'a-size-mini lc-k lc-chart-quelle', ui.esc(quelle)));

    var xVonEvent = function (ev) {
      var rect = svg.getBoundingClientRect ? svg.getBoundingClientRect() : { left: 0, width: 0 };
      return (ev.clientX - rect.left) * (rect.width ? W / rect.width : 1);
    };
    /* Hover zeigt je Reihe den ZULETZT bekannten Wert statt nur die Werte der
       einen naechstgelegenen Messung. Grund: h10Punkte() legt jede Helium-Reihe
       als EIGENE Zeile ab (BSR-Zeile hat nur idx 2, Preis-Zeile nur idx 1) - bei
       2850 BSR- gegen 145 Preis-Zeilen war die naechste Zeile am Cursor fast
       immer eine BSR-Zeile, also stand an fast keiner Position ein Preis, obwohl
       die Buybox-Kurve durchgehend gezeichnet ist (LO 04.09.). Genauso liest
       sich die Kurve auch: sie haelt den Preis bis zur naechsten Aenderung.
       Ausserhalb der Reihe (vor dem ersten, nach dem letzten Punkt) bleibt es
       leer - dort zeichnet pfad() auch keine Linie. */
    var reihenX = {};                                              // Sample-Index -> [{x,v}], nur Messungen MIT Wert, zeitlich sortiert
    SERIEN.forEach(function (ser) {
      var arr = [];
      pts.forEach(function (s) { if (s[ser.idx] != null) arr.push({ x: x(s), v: s[ser.idx] }); });
      reihenX[ser.idx] = arr;
    });
    /* Letzter Punkt dieser Reihe mit x <= xv — nach vorne durchgefuellt.
       Die obere Grenze ist bewusst weg: sie lieferte null, sobald die
       Leseposition hinter dem letzten Punkt DIESER Reihe lag. Weil die Reihen
       unterschiedlich dicht sind (LO-Screenshot 04.09.: 201 BSR-Messungen
       gegen 13 Preis-Messungen), lag der Preis fast ueberall dahinter und
       fehlte im Tooltip. Fuer Zustandsgroessen ist das falsch: ein Preis gilt
       bis zur naechsten Aenderung weiter, auch wenn danach nur noch BSR
       gemessen wurde. VOR der ersten Messung bleibt es bei null — dort gibt
       es wirklich nichts zu wissen. */
    var letzterWert = function (idx, xv) {
      var arr = reihenX[idx];
      if (!arr || !arr.length || xv < arr[0].x) return null;
      var lo = 0, hi = arr.length - 1, tr = 0;
      while (lo <= hi) { var m = (lo + hi) >> 1; if (arr[m].x <= xv) { tr = m; lo = m + 1; } else hi = m - 1; }
      return arr[tr].v;
    };
    /* Fadenkreuz rastet auf ganze TAGE ein, nicht auf einzelne Messungen
       (LO 04.09.: "i wanna see what bsr it had at what day ... it snaps on
       the single days"). Gefragt ist der Stand AN EINEM TAG — dafuer zaehlt
       der letzte bekannte Wert bis zum Ende dieses Tages, nicht der Wert der
       zufaellig naechstgelegenen Messung.
       Nur wenn ein Tag breit genug gezeichnet ist: bei einem Fenster ueber
       mehrere Jahre ist ein Tag schmaler als ein Pixel, dort bleibt es beim
       Einrasten auf die naechste Messung. */
    var xVonZeit = function (ms) { return PL + PW * (ms - t0) / (t1 - t0); };
    var tagBreitePx = PW * 864e5 / (t1 - t0);
    var tagSnap = tagBreitePx >= 3;
    svg.addEventListener('mousemove', function (ev) {
      /* Leerer Ausschnitt: in eine Messluecke gezoomt. Der Tages-Zweig unten
         liest pts[pts.length - 1] und wuerde bei jedem Mausschritt werfen -
         der Zweig darunter faengt es ueber sein "best", dieser nicht. */
      if (!pts.length) return;
      /* Auf die Zeichenflaeche klemmen: der Listener haengt am ganzen SVG, in
         den Raendern (PL=58 links fuer die Preisbeschriftung) rechnet xZuT()
         eine Zeit ausserhalb des Fensters hoch und das Fadenkreuz stuende
         neben dem Chart. Am Rand gilt der Rand. */
      var xv = Math.max(PL, Math.min(PL + PW, xVonEvent(ev)));
      var bx, kopf, unterdrueckt = false, leseX;

      if (tagSnap) {
        var d0 = new Date(xZuT(xv)); d0.setHours(0, 0, 0, 0);
        var tagAnfang = Math.max(t0, d0.getTime());
        var tagEnde = Math.min(t1, d0.getTime() + 864e5 - 1);
        bx = xVonZeit((tagAnfang + tagEnde) / 2);                  // Fadenkreuz in die Tagesmitte
        /* Stand am Ende des Tages. Die frueher noetige Klemme auf die letzte
           Messung ist entfallen: letzterWert() fuellt jetzt nach vorne durch
           und liefert auch hinter dem letzten Punkt einer Reihe deren letzten
           Wert — genau das, was eine Treppenkurve aussagt. */
        leseX = xVonZeit(tagEnde);
        kopf = datum(ui, d0.getTime());
        // Buybox-Hinweis, wenn sie an IRGENDEINER Messung dieses Tages weg war
        pts.forEach(function (s) {
          var ts = t(s);
          if (ts >= tagAnfang && ts <= tagEnde && s[3] === 2) unterdrueckt = true;
        });
      } else {
        var best = pts[0], bd = Infinity;
        pts.forEach(function (s) { var dd = Math.abs(x(s) - xv); if (dd < bd) { bd = dd; best = s; } });
        if (!best) return;
        bx = x(best); leseX = bx;
        kopf = datum(ui, t(best));
        unterdrueckt = best[3] === 2;
      }

      hover.setAttribute('x1', bx.toFixed(1)); hover.setAttribute('x2', bx.toFixed(1)); hover.setAttribute('visibility', 'visible');
      /* Wie in der Uebersichtszeile: jede eingeschaltete Reihe steht auch im
         Tooltip IMMER da (LO 04.09.: "die buybox fehlt" zum Screenshot, in dem
         nur "BSR 10.076" stand). Zwei Stufen: letzterWert() fuellt innerhalb
         des Ausschnitts nach vorne durch, standVor() greift davor. Bleibt
         beides leer, steht "n. v." — der Eintrag verschwindet nie. */
      var teileHover = [];
      var zeig = function (an, idx, label, fmt) {
        if (!an) return;
        var v = letzterWert(idx, leseX);
        if (v == null) v = standVor(idx);       // vor der ersten Messung im Ausschnitt
        teileHover.push(label + ' ' + (v == null ? 'n. v.' : fmt(v)));
      };
      zeig(sichtbar.preis, 1, 'Buybox', ui.eur);
      zeig(sichtbar.angebot, 5, 'Angebot min.', ui.eur);
      zeig(sichtbar.bsr, 2, 'BSR', ui.nf);
      zeig(sichtbar.anbieter, 4, 'Anbieter', ui.nf);
      zeig(sichtbar.bestand, 6, 'Bestand', ui.nf);
      zeig(sichtbar.uvp, 7, 'UVP', ui.eur);
      zeig(sichtbar.verkaeufe, 8, 'Verkäufe', ui.nf);
      info.textContent = kopf + (teileHover.length ? ' · ' + teileHover.join(' · ') : '') +
        (unterdrueckt ? ' · Buybox unterdrückt' : '');
    });
    svg.addEventListener('mouseleave', function () { hover.setAttribute('visibility', 'hidden'); info.textContent = zusammen; });

    // -- Zoom: Drag-Auswahl (Pointer Capture -> braucht keinen document-Listener,
    // stirbt automatisch mit dem SVG beim naechsten Neuaufbau)
    var dragVon = null;
    var schwelle = Math.max(4, PW * 0.01);
    svg.addEventListener('pointerdown', function (ev) {
      if (ev.button !== 0) return;
      ev.preventDefault();
      dragVon = xVonEvent(ev);
      try { svg.setPointerCapture(ev.pointerId); } catch (e) { /* egal */ }
      auswahl.setAttribute('x', dragVon.toFixed(1)); auswahl.setAttribute('width', '0'); auswahl.setAttribute('visibility', 'visible');
    });
    svg.addEventListener('pointermove', function (ev) {
      if (dragVon == null) return;
      var cur = xVonEvent(ev);
      var lo = Math.min(dragVon, cur), hi = Math.max(dragVon, cur);
      auswahl.setAttribute('x', lo.toFixed(1)); auswahl.setAttribute('width', (hi - lo).toFixed(1));
    });
    svg.addEventListener('pointerup', function (ev) {
      if (dragVon == null) return;
      var von = dragVon, cur = xVonEvent(ev);
      dragVon = null;
      auswahl.setAttribute('visibility', 'hidden');
      try { svg.releasePointerCapture(ev.pointerId); } catch (e) { /* egal */ }
      if (Math.abs(cur - von) < schwelle) return;                 // Klick, kein Zoom
      var tA = Math.max(basisT0, xZuT(Math.min(von, cur)));
      var tB = Math.min(basisT1, xZuT(Math.max(von, cur)));
      if (tB - tA < 1000) return;                                 // Mindestfenster 1s
      if (asin) zoomState[asin] = { t0: tA, t1: tB };
      render(container, all, ui, asin, dims);
    });
    svg.addEventListener('dblclick', function (ev) {
      ev.preventDefault();
      if (asin && zoomState[asin]) { delete zoomState[asin]; render(container, all, ui, asin, dims); }
    });
    svg.addEventListener('wheel', function (ev) {
      ev.preventDefault();
      var tCursor = xZuT(xVonEvent(ev));
      var faktor = ev.deltaY < 0 ? 0.8 : 1.25;                     // rauf = rein, runter = raus
      var neuT0 = Math.max(basisT0, tCursor - (tCursor - t0) * faktor);
      var neuT1 = Math.min(basisT1, tCursor + (t1 - tCursor) * faktor);
      if (neuT1 - neuT0 < 1000) return;
      if (asin) {
        if (neuT0 <= basisT0 && neuT1 >= basisT1) delete zoomState[asin];
        else zoomState[asin] = { t0: neuT0, t1: neuT1 };
      }
      render(container, all, ui, asin, dims);
    }, { passive: false });

    // Overlay-Inhalt darf kein data-lc tragen - sonst greift onpage.js' abraeumen()
    // (document.querySelectorAll('[data-lc]')) beim naechsten Panel-Neuaufbau durch
    // und reisst das offene Popup leer, obwohl es gar nicht im Panel haengt.
    if (dims.overlay) {
      container.querySelectorAll('[data-lc]').forEach(function (n) { n.removeAttribute('data-lc'); });
    }
  }

  /* --------------------------------------------------- Historie von Helium 10
     Die bsr-chart-Route liefert in EINER Antwort vier Reihen - BSR, Neupreis,
     UVP und Anbieterzahl - dazu den Kategorienamen. Genommen wurde davon frueher
     nur der BSR, der Rest ging weg; deshalb sah es aus, als koenne das Plugin
     keinen Preisverlauf (LO 03.09.). Verkaeufe liegen in einer zweiten Route
     (sales-chart), die mit dem Gratis-Zugang 403 gibt, mit Platinum/Enterprise
     aber Zahlen - sie wird deshalb mitgefragt und ein Fehlschlag nur vermerkt,
     nicht als Stoerung gezeigt. Beides 24 h zwischengespeichert. Die eigenen
     Messungen bleiben unberuehrt und laufen weiter mit. */
  var H10_REIHEN = [
    { feld: 'bsrHistory', ersatz: 'bsrChart', idx: 2, name: 'BSR' },
    { feld: 'newPriceHistory', idx: 1, name: 'Preis', preis: true },
    { feld: 'listPriceHistory', idx: 7, name: 'UVP', preis: true },
    { feld: 'newOffersHistory', idx: 4, name: 'Anbieter' }
  ];

  function h10Zeit(x) {                                            // {start,end,value}; Sekunden oder Millisekunden
    var ts = x.start != null ? x.start : x.timestamp != null ? x.timestamp : x.date != null ? x.date : x.x != null ? x.x : x.end;
    if (typeof ts === 'string') ts = Date.parse(ts) / 1000;
    if (!ts || !isFinite(ts)) return 0;
    return ts > 1e11 ? ts / 1000 : ts;
  }
  function h10Wert(x) {
    var v = x.value != null ? x.value : x.count != null ? x.count : x.y != null ? x.y : x.sales;
    return typeof v === 'number' && isFinite(v) ? v : null;
  }
  /* Live gepruefte Einheit (03.09.2026, B07BLTT2MR): Helium liefert Preise in
     EURO, nicht in Cent - newPriceHistory lag zwischen 39,16 und 69,95. Ohne
     eigenen Vergleichswert wird deshalb NICHT umgerechnet; eine reine
     Groessenheuristik haette Artikel ueber 1000 EUR durch 100 geteilt. Nur wenn
     eine eigene Messung vorliegt und die Helium-Werte dazu um Faktor 100
     danebenliegen, wird geteilt - das faengt einen spaeteren Formatwechsel ab. */
  function h10Teiler(werte, eigen) {
    if (!werte.length || !(eigen > 0)) return 1;
    var m = werte.slice().sort(function (a, b) { return a - b; })[werte.length >> 1];
    return Math.abs(m / 100 - eigen) < Math.abs(m - eigen) ? 100 : 1;
  }
  function h10Punkte(arr, idx, teiler, raus) {
    arr.forEach(function (x) {
      var t = h10Zeit(x), v = h10Wert(x);
      if (!t || v == null) return;
      var s = [new Date(t * 1000).toISOString(), null, null, 0, null, null, null, null, null];
      s[idx] = v / teiler;
      raus.push(s);
    });
  }

  function mitH10(asin, samples, info) {
    var merk = function (txt) { if (info) info.text = txt; };
    if (!LC.h10 || !LC.h10.ready) { merk('Helium-Modul nicht geladen'); return Promise.resolve(samples); }
    return LC.h10.ready().then(function (login) {
      /* Zwischen "Schalter aus" und "an, aber abgemeldet" unterscheiden: wer
         Helium gar nicht nutzt, soll unter seinem Verlauf keine Fremdwerbung
         lesen - gemeldet wird nur, was der Nutzer auch abstellen kann. */
      if (!login) {
        return new Promise(function (fertig) {
          try {
            chrome.storage.local.get('lcH10Enabled', function (d) {
              if (d && d.lcH10Enabled) merk('Helium 10 ist eingeschaltet, aber nicht angemeldet – bei helium10.com anmelden, dann kommt die Historie');
              fertig(samples);
            });
          } catch (e) { fertig(samples); }
        });
      }
      var sicher = function (pr) { return pr.then(function (r) { return r; }, function (e) { return { ok: false, fehler: (e && e.message) || String(e) }; }); };
      return Promise.all([
        sicher(LC.h10.cache('bsrchart:' + asin, 24 * 60, function () { return LC.h10.bsrChart(asin, 'amazon.de', { fullHistory: true }); })),
        sicher(LC.h10.cache('saleschart:' + asin, 24 * 60, function () { return LC.h10.salesChart(asin, 'amazon.de', 365); }))
      ]).then(function (antw) {
        var bsrRes = antw[0], salesRes = antw[1];
        var eigenPreis = 0;
        for (var i = samples.length - 1; i >= 0; i--) if (samples[i] && samples[i][1] > 0) { eigenPreis = samples[i][1]; break; }
        var extra = [], notizen = [], kategorie = '';
        var r = bsrRes && bsrRes.ok && bsrRes.data && bsrRes.data.results;
        if (r) {
          kategorie = r.categoryName || '';
          H10_REIHEN.forEach(function (def) {
            var arr = r[def.feld] || (def.ersatz && r[def.ersatz]) || [];
            if (!arr.length) return;
            var teiler = 1;
            if (def.preis) {
              var roh = arr.map(h10Wert).filter(function (v) { return v != null; });
              teiler = h10Teiler(roh, eigenPreis);
            }
            var vorher = extra.length;
            h10Punkte(arr, def.idx, teiler, extra);
            if (extra.length > vorher) notizen.push((extra.length - vorher) + '× ' + def.name);
          });
          if (!notizen.length) notizen.push('keine Historie zu dieser ASIN');
        } else {
          notizen.push('BSR/Preis: ' + (bsrRes && bsrRes.status ? 'HTTP ' + bsrRes.status : (bsrRes && bsrRes.fehler) || 'keine Antwort'));
        }
        /* Verkaufsreihe: Feldname der Antwort ist auf dem Gratis-Zugang nicht
           pruefbar (403), deshalb die bekannten Namen zuerst und sonst das erste
           Array aus Objekten nehmen. */
        var sr = salesRes && salesRes.ok && salesRes.data && salesRes.data.results;
        if (sr) {
          var reihe = sr.sales || sr.salesHistory || sr.unitsSold || sr.salesGraph || (Array.isArray(sr) ? sr : null);   // Form laut dp-h10.js: results.sales = [{x,y}]
          if (!reihe) {
            for (var k in sr) if (Array.isArray(sr[k]) && sr[k].length && typeof sr[k][0] === 'object') { reihe = sr[k]; break; }
          }
          if (reihe && reihe.length) {
            var vor = extra.length;
            h10Punkte(reihe, 8, 1, extra);
            if (extra.length > vor) notizen.push((extra.length - vor) + '× Verkäufe');
          }
        } else if (salesRes && salesRes.status === 403) notizen.push('Verkäufe: ab Platinum');
        else if (salesRes && !salesRes.ok) notizen.push('Verkäufe: ' + (salesRes.status ? 'HTTP ' + salesRes.status : salesRes.fehler || 'keine Antwort'));

        merk('Helium 10: ' + notizen.join(' · ') + (kategorie ? ' · ' + kategorie : ''));
        if (!extra.length) return samples;
        /* Die Helium-Punkte gehoeren in UNSERE Reihe, nicht nur in dieses eine
           Diagramm: bis 04.09. lebten sie ausschliesslich in der Variable
           unten, und das Popup zeigte zur selben ASIN "1 Messung". Der Worker
           fuehrt sie ueber den Zeitstempel mit hist:<ASIN> zusammen (idempotent),
           danach hat jeder Leser dieselbe Historie. Das Zeichnen wartet nicht
           darauf - der Merge hier bleibt, damit die Kurve sofort steht. */
        try {
          chrome.runtime.sendMessage({ type: 'histImport', asin: asin, punkte: extra },
            function () { void chrome.runtime.lastError; });
        } catch (e) { /* Kontext weg (Extension-Reload): naechster Aufbau holt es nach */ }
        return samples.concat(extra).sort(function (a, b) { return Date.parse(a[0]) - Date.parse(b[0]); });
      });
    }, function (e) { merk('Helium 10 nicht erreichbar (' + ((e && e.message) || e) + ')'); return samples; });
  }

  H.chart = function (container, samples, ui) {
    if (!container || !ui) return;
    var hatWert = function (s) {
      return s && s[0] && (s[1] != null || s[2] != null || s[4] != null || s[5] != null || s[7] != null || s[8] != null);
    };
    var pts = (samples || []).filter(hatWert);
    container.innerHTML = '';
    /* ASIN VOR der Punktzahl-Pruefung bestimmen: der Frueh-Ausstieg ("die Kurve
       entsteht mit jedem Aufruf") stand hier frueher oben - die Helium-Historie
       wurde also genau dann NIE geholt, wenn man sie braucht: auf jeder Seite mit
       weniger als zwei eigenen Messungen (LO 03.09.: "er versucht ja gar nicht,
       Daten zu holen"). */
    var asinEl = document.querySelector('#ASIN, input[name="ASIN"]');
    var asin = asinEl ? (asinEl.value || asinEl.getAttribute('value')) : (location.pathname.match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})/) || [])[1];
    var run = function (alle) {
      var los = function () { render(container, alle, ui, asin); };
      if (range != null) los();
      else {
        try { chrome.storage.local.get('lcChartRange', function (d) { range = (d && d.lcChartRange) || 'alles'; los(); }); }
        catch (e) { range = 'alles'; los(); }
      }
    };
    var info = { text: '' };
    var weiter = function (alle) {
      var p2 = (alle || []).filter(hatWert);
      if (asin) h10Info[asin] = info.text;
      if (p2.length >= 2) return run(p2);
      container.innerHTML = '';
      container.appendChild(ui.el('div', 'lc-k', p2.length + (p2.length === 1 ? ' Messung' : ' Messungen') + ' – eigene Messwerte kommen höchstens einmal pro Stunde dazu'));
      if (info.text) container.appendChild(ui.el('div', 'a-size-mini lc-k lc-chart-quelle', ui.esc(info.text)));
    };
    if (asin && LC.h10 && LC.h10.ready) mitH10(asin, pts, info).then(weiter, function () { weiter(pts); });
    else weiter(pts);                                              // ohne H10 sofort synchron rendern
  };
})();
