/* Watchlist (nach Keepa "Tracking", aber rein lokal): ASINs merken, auf der
   Produktseite ein Chip hinter dem ASIN-Kopier-Chip (☆ Beobachten / ★ Beobachtet),
   in der Karte eine Sektion mit allen beobachteten ASINs samt letztem Preis/BSR
   aus dem lokalen Verlauf (hist:<ASIN>), ein Knopf fuer die Sammelpruefung
   (proCheck) und in der Suche ein "★ beobachtet"-Chip an jeder beobachteten Kachel.
   Speicher: chrome.storage.local "watch" = [{asin, titel, preis, bsr, ts}].
   Keine Requests, keine Rechte. Nur ui.el/ui.chip (data-lc, Scrape-Filter). */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || []; H.serp = H.serp || [];

  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  var num = function (s) { var n = parseInt(String(s == null ? '' : s).replace(/\D/g, ''), 10); return isFinite(n) && n > 0 ? n : null; };
  var kurz = function (s, n) { s = clean(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };

  var watch = [], geladen = false, listener = null, ui = null;
  var aktiv = null;   // Zustand der sichtbaren Produktseite: {asin, render}
  var serpNeu = null; // Neuzeichnen der Suchseite nach Aenderung
  /* P5: hist:* sind im Ordner-Modus einzelne Dateien - 60 s zwischenspeichern,
     sonst liest jeder Panel-Aufbau (Variantenwechsel) alle beobachteten ASINs
     von Platte neu. Der onChanged-Listener invalidiert bei watch-Aenderung. */
  var histCache = { ts: 0, d: null };

  // ---- Speicher ---------------------------------------------------------------
  function laden() {
    if (geladen) return Promise.resolve(watch);
    return ui.storage('watch').then(function (d) {
      watch = Array.isArray(d.watch) ? d.watch : []; geladen = true; return watch;
    }).catch(function () { geladen = true; return watch; });
  }
  function speichern(list) {
    watch = list;
    ui.storageSet({ watch: list }).catch(function (e) { console.warn('[LC] Watchlist speichern', e); });
  }
  var drin = function (asin) { return watch.some(function (w) { return w.asin === asin; }); };
  var ohne = function (asin) { return watch.filter(function (w) { return w.asin !== asin; }); };

  /* EIN Listener fuer alle Seiten: andere Tabs/Popup aendern "watch" -> neu zeichnen.
     Auf der Produktseite nur, wenn noch dieselbe ASIN sichtbar ist.
     "watch" liegt im OPFS-Store des Workers: Aenderungen kommen als
     lcDiskChanged; chrome.storage.onChanged feuert nur noch fuer die Alt-Kopie
     (Migration entfernt sie -> newValue undefined). Beides fuehrt zu einem
     frischen Read - vorher setzte undefined die Liste auf [] und der naechste
     Klick haette sie mit einem einzigen Eintrag ueberschrieben (Audit 03.09., D4). */
  function neuLesen() {
    geladen = false; histCache.ts = 0;
    return laden().then(function () {
      if (aktiv && ui.aktuelleAsin() === aktiv.asin) aktiv.render();
      if (serpNeu) serpNeu();
    });
  }
  function hoeren() {
    if (listener) return;
    listener = function (ch, area) {
      if (area !== 'local' || !ch.watch) return;
      neuLesen();
    };
    try { chrome.storage.onChanged.addListener(listener); } catch (e) { listener = null; }
    try {
      chrome.runtime.onMessage.addListener(function (msg) {
        if (msg && msg.type === 'lcDiskChanged' && (msg.keys || []).indexOf('watch') >= 0) neuLesen();
      });
    } catch (e) { /* Kontext ohne runtime */ }
  }

  // ---- Produktseite -----------------------------------------------------------
  H.panel.push(function (ctx) {
    ui = ctx.ui;
    if (!ui || !ctx.asin) return;
    var asin = ctx.asin, r = ctx.row || {};
    hoeren();

    // Chip direkt HINTER dem ASIN-Kopier-Chip (Geschwister von #productTitle)
    var anker = null, n = ctx.titleEl ? ctx.titleEl.nextElementSibling : null;
    while (n && n.hasAttribute('data-lc')) { if (n.classList.contains('lc-copy')) { anker = n; break; } n = n.nextElementSibling; }
    anker = anker || ctx.titleEl;
    var chip = ui.chip('☆ Beobachten', '', 'ASIN lokal beobachten: Preis/BSR-Verlauf, Sammelprüfung, Markierung in der Suche');
    chip.classList.add('lc-copy', 'lc-watch-chip');
    if (anker) anker.insertAdjacentElement('afterend', chip);
    var chipOptik = function () {
      var ist = drin(asin);
      chip.className = 'lc-chip lc-copy lc-watch-chip' + (ist ? ' ok' : '');
      chip.innerHTML = ist ? '★ Beobachtet' : '☆ Beobachten';
    };
    chip.addEventListener('click', function (ev) {
      ev.preventDefault(); ev.stopPropagation();
      laden().then(function () {
        if (drin(asin)) speichern(ohne(asin));
        else speichern(watch.concat([{ asin: asin, titel: kurz(r.titel, 80), preis: r.preis == null ? null : Number(r.preis), bsr: num(r.bsr), ts: Date.now() }]));
        /* Neuzeichnen macht der onChanged-Listener (hoeren) - der Write feuert ihn
           auch in diesem Kontext. Ein zusaetzliches render() hier hiess Doppel-
           Render mit doppeltem hist:*-Lesen aller beobachteten ASINs (P5). */
      });
    });

    // Knopf: Sammelpruefung aller beobachteten ASINs (Buybox/Preis, wie "Buybox-Check")
    var knopf = ui.button('Alle beobachteten prüfen', false, 'Buybox-/Preis-Check für alle beobachteten ASINs starten', function (b) {
      var asins = watch.map(function (w) { return w.asin; });
      if (!asins.length) { ctx.status.textContent = 'Keine beobachteten ASINs.'; return; }
      b.disabled = true;
      ui.send({ type: 'proCheck', asins: asins, origin: location.origin });
      ctx.status.textContent = 'Prüfung für ' + asins.length + ' beobachtete ASIN' + (asins.length === 1 ? '' : 's') + ' gestartet – Ergebnis im Popup und unter dem Preis.';
      setTimeout(function () { b.disabled = false; }, 8000);
    });
    if (ctx.stack) ctx.stack.appendChild(knopf);

    // Sektion "Beobachtet (n)" - nur bei n > 0, bei jeder Aenderung komplett neu
    var sec = null;
    var render = function () {
      if (sec) { if (sec.previousElementSibling && sec.previousElementSibling.tagName === 'H3') sec.previousElementSibling.remove(); sec.remove(); sec = null; }
      knopf.style.display = watch.length ? '' : 'none';
      if (!watch.length || typeof ctx.sec !== 'function') return;
      var list = watch.slice();
      var box = sec = ctx.sec('Beobachtet (' + list.length + ')');
      var keys = list.map(function (w) { return 'hist:' + w.asin; });
      var lesen = histCache.d && Date.now() - histCache.ts < 60000
        ? Promise.resolve(histCache.d)
        : ui.storage(keys).then(function (d) { histCache = { ts: Date.now(), d: d }; return d; });
      lesen.then(function (d) {
        if (sec !== box || ui.aktuelleAsin() !== asin) return;   // inzwischen neu gezeichnet / Variante gewechselt
        list.forEach(function (w) {
          var h = d['hist:' + w.asin], last = Array.isArray(h) && h.length ? h[h.length - 1] : null;
          var preis = last && last[1] != null ? last[1] : w.preis, bsr = last && last[2] != null ? last[2] : w.bsr;
          var wann = last ? new Date(last[0]) : new Date(w.ts || 0);
          var zeile = ui.el('div', 'lc-row a-spacing-micro' + (w.asin === asin ? ' lc-ok' : ''),
            '<a class="a-link-normal" href="/dp/' + ui.esc(w.asin) + '" title="' + ui.esc(w.titel || w.asin) + '">' + ui.esc(kurz(w.titel || w.asin, 48)) + '</a>' +
            '<span class="lc-mono lc-k">' + ui.esc(w.asin) + '</span>' +
            '<span class="lc-mono" title="letzter gemessener Preis">' + ui.esc(ui.eur(preis)) + '</span>' +
            '<span class="lc-k" title="letzter Bestseller-Rang">BSR ' + ui.esc(ui.nf(bsr)) + '</span>' +
            '<span class="lc-k" title="Datum der letzten Messung">' + ui.esc(ui.tag(wann)) + '</span>');
          var x = ui.chip('✕', 'mut', 'aus der Beobachtung entfernen');
          x.classList.add('lc-copy');
          x.addEventListener('click', function (ev) {
            ev.preventDefault(); ev.stopPropagation();
            speichern(ohne(w.asin));   // Neuzeichnen via onChanged-Listener, s. o. (P5)
          });
          zeile.appendChild(x);
          box.appendChild(zeile);
        });
      }).catch(function (e) { console.warn('[LC] Watchlist', e); });
    };
    aktiv = { asin: asin, render: function () { chipOptik(); render(); } };
    laden().then(function () { if (ui.aktuelleAsin() === asin) aktiv.render(); }).catch(function () { /* ohne Speicher nichts zu zeigen */ });
  });

  // ---- Suchseite --------------------------------------------------------------
  H.serp.push(function (ctx) {
    ui = ctx.ui;
    if (!ui) return;
    hoeren();
    serpNeu = function () {
      var set = {}; watch.forEach(function (w) { set[w.asin] = 1; });
      var n = 0;
      ctx.tiles.forEach(function (t) {
        if (!t.badges) return;
        var da = t.badges.querySelector('.lc-watch');
        if (!set[t.asin]) { if (da) da.remove(); return; }
        n++;
        if (da) return;
        var c = ui.chip('★ beobachtet', 'ok', 'steht auf der lokalen Beobachtungsliste');
        c.classList.add('lc-watch');
        if (ui.badgeNeben) ui.badgeNeben(t, c, false); else t.badges.appendChild(c);
      });
      var alt = ctx.head.querySelector('.lc-watch-head');
      if (alt) alt.remove();
      if (n) {
        var hc = ui.chip(n + ' <span class="lc-k">beobachtete hier</span>', 'ok', n + ' Treffer dieser Seite stehen auf der Beobachtungsliste');
        hc.classList.add('lc-watch-head');
        ctx.head.insertBefore(hc, ctx.head.querySelector('.lc-sp'));
      }
    };
    laden().then(serpNeu).catch(function () { /* ohne Speicher keine Markierung */ });
  });

  /* ---- Auto-Research (LO 01.09. "er holt keine auto daten"): stuendlich,
     solange irgendein Amazon-Tab offen ist, alle beobachteten ASINs per
     fetch messen - BSR/Preis/Buybox in den Verlauf (hist:, via background-
     Kette) und Kaufzahl+BSR als Kalibrier-Punkt (macht quickview.lesen()
     intern). Lock ueber arLast-Zeitstempel (sofort gesetzt - ein zweiter Tab
     im RMW-Fenster misst schlimmstenfalls doppelt, recordSample dedupliziert).
     Gate: derselbe lcAutoLearn-Toggle wie das passive Sammeln. Cookielos
     (organisch); max 40 ASINs, 1,5 s Abstand - sanfter als jeder Nutzer. */
  var AR_INTERVALL = 3600 * 1000, AR_GAP = 1500, AR_MAX = 40;
  function autoResearch() {
    var uiH = LC.onpage && LC.onpage.ui;
    var lesen = LC.onpage && LC.onpage.quickview && LC.onpage.quickview.lesen;
    if (!uiH || !lesen) return;
    uiH.storage(['lcAutoResearch', 'arLast', 'watch']).then(function (d) {
      /* Es gibt keinen Timer — die Extension hat bewusst keine alarms-
         Permission. Die "stuendliche" Messung passiert AUSSCHLIESSLICH hier,
         opportunistisch, solange ein Amazon-Tab offen ist. Faellt einer der
         Ausstiege unten, misst gar nichts mehr: der Verlauf bleibt auf dem
         einen Punkt vom Hinzufuegen stehen, und weil derselbe Lauf ueber
         quickview.lesen() auch die Kalibrierpunkte (cal:) sammelt, trocknet
         gleichzeitig der Schaetzer aus — beide Symptome, eine Ursache.

         Die Kopplung an die Ordner-Sicherung ist deshalb am 04.09. ENTFERNT
         worden. Sie stammte vom 01.09. und hatte damals einen guten Grund:
         Messreihen lagen in chrome.storage.local, ein neues Browserprofil
         haette Wochen an Arbeit vernichtet. Seit dem OPFS-Umbau am 03.09. ist
         der Nutzerordner nur noch SPIEGEL, fuehrend ist OPFS — persistent,
         ohne Freigabe, aus dem Worker immer erreichbar. Die Voraussetzung war
         weg, die Kopplung blieb; und weil die Ordner-Freigabe nur fuer die
         laufende Sitzung gilt, hat sie Auto-Research praktisch dauerhaft
         abgeschaltet (LO 04.09., im Protokoll belegt mit "cal:-Schluessel
         gelesen: 0"). */
      var warum = null;
      if (d.lcAutoResearch === false) warum = 'Toggle „Auto-Recherche" ist AUS';
      else if (Date.now() - (d.arLast || 0) < AR_INTERVALL) warum = 'zuletzt vor ' + Math.round((Date.now() - (d.arLast || 0)) / 60000) + ' min gelaufen, Intervall 60 min';
      else if (!Array.isArray(d.watch) || !d.watch.length) warum = 'keine ASIN auf der Beobachtungsliste';
      if (warum) { console.log('[LC auto] Auto-Research läuft NICHT: ' + warum); return; }
      var liste = d.watch;
      console.log('[LC auto] Auto-Research startet für ' + Math.min(liste.length, AR_MAX) + ' von ' + liste.length + ' ASINs');
      try { chrome.storage.local.set({ arLast: Date.now() }); } catch (e) { return; }
      var i = 0;
      (function next() {
        if (i >= liste.length || i >= AR_MAX) return;
        var w = liste[i++];
        if (!w || !w.asin) return next();
        fetch('/dp/' + w.asin, { credentials: 'omit' })
          .then(function (r) { return r.ok ? r.text() : null; })
          .then(function (html) {
            if (!html) return;
            var dta = lesen(html, w.asin);   // lernt Kalibrier-Punkt selbst mit
            if (dta && !dta.leer) {
              try {
                chrome.runtime.sendMessage({ type: 'histSample', asin: w.asin,
                  sample: { preis: dta.preis, bsr: dta.bsr, buybox: dta.buybox } });
              } catch (e) { /* Kontext weg */ }
            }
          })
          .catch(function () { /* einzelner Fehlschlag egal */ })
          .then(function () { setTimeout(next, AR_GAP); });
      })();
    }).catch(function () { /* Speicher weg */ });
  }
  setTimeout(autoResearch, 20 * 1000);           // kurz nach Seitenladen einmal pruefen
  var arIv = setInterval(autoResearch, 5 * 60 * 1000);
  // Orphan-Stop NUR bei echter Nachinjektion: onpage.js feuert das Event auch
  // beim allerersten Laden (laeuft NACH dieser Datei) - das darf den frischen
  // Timer nicht killen, deshalb Zeitfenster statt once-Listener.
  var arStart = Date.now();
  document.addEventListener('lc-onpage-neu', function () {
    if (Date.now() - arStart > 5000) clearInterval(arIv);
  });
})();
