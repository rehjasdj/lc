'use strict';

/* Cockpit-Ansichten und Verdrahtung des Popups: Ansicht "Aktuell" (Dossier des
   offenen Produkts bzw. Überblick), Beobachtung, Ränge, Kommandopalette,
   Job-Ticker, Kontextstreifen, Tastatur, Menüs, Zähler-Animation.
   Wird VOR popup.js geladen, aber erst NACH dessen Start aufgerufen - alle hier
   benutzten Helfer ($, load, render, switchView, storeGet, storeGetPrefix,
   saveViele, sendMsg, auftrag, setStatus, bestaetigen, mkBtn, fmtPreis,
   checkedPlats, aktivTab, proCheckStarten, startCompare, renderAnalyse,
   rerunHarvest, istShop, view, letzteZaehler, IST_FENSTER) existieren dann. */

var ALT_VIEWS = { '1': 'home', '2': 'rows', '3': 'matches', '4': 'keywords', '5': 'pro', '6': 'watch' };
var RAIL_IDS = { rows: 'viewRows', matches: 'viewMatches', keywords: 'viewKeywords', pro: 'viewPro', watch: 'viewWatch' };

/* undefined = noch nicht ermittelt (Start), null = kein Shop-Tab, sonst chrome.tabs.Tab */
var letzterTab;
/* Kürzel für den Kontextstreifen. Die ersten drei Buchstaben allein ergaben
   "AMA" und "DEU" - lesbar, aber nicht wiedererkennbar. */
var PLAT_KURZ = { amazon: 'AMZ', ebay: 'EBY', kaufland: 'KFL', otto: 'OTT', bol: 'BOL',
  temu: 'TEM', deubaxxl: 'DXL', google: 'GGL', guenstiger: 'GNS', geizhals: 'GHL',
  beslist: 'BES', kieskeurig: 'KKR' };
var ersterAufbau = false;   // steuert den Oeffnungsmoment, siehe nachRender()

// ------------------------------------------------------------------ Helfer

function nfDe(n) {
  if (n == null || n === '' || isNaN(n)) return '';
  try { return new Intl.NumberFormat('de-DE').format(n); } catch (e) { return String(n); }
}

/* Relative Zeit auf Deutsch. Nimmt ISO-String (hist/rank) oder Millisekunden
   (watch.ts) - beides kommt vor, je nachdem wer den Eintrag geschrieben hat. */
function vorZeit(ts) {
  var t = typeof ts === 'string' ? Date.parse(ts) : ts;
  if (!t || isNaN(t)) return '';
  var s = Math.floor((Date.now() - t) / 1000);
  if (s < 60) return 'gerade';
  if (s < 3600) return 'vor ' + Math.floor(s / 60) + ' min';
  if (s < 172800) return 'vor ' + Math.floor(s / 3600) + ' h';
  return 'vor ' + Math.floor(s / 86400) + ' T';
}

/* Im Hintergrund öffnen: das Popup schliesst sonst mit dem Tabwechsel und
   der Nutzer verliert seine Liste. */
function neuerTab(url) {
  try { chrome.tabs.create({ url: url, active: false }); } catch (e) { /* kein Tab-Recht */ }
}

function el(tag, cls, text) {
  var e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text != null) e.textContent = text;
  return e;
}

function zelle(eltern, cls, text, titel) {
  var d = el('div', cls, text);
  if (titel) d.title = titel;
  eltern.appendChild(d);
  return d;
}

function kopfZeile(list, cls, spalten) {
  var k = el('div', cls);
  spalten.forEach(function (t) { zelle(k, '', t); });
  list.appendChild(k);
}

function asinLink(asin) {
  var a = el('a', 'tag', asin);
  a.href = 'https://www.amazon.de/dp/' + encodeURIComponent(asin);
  a.addEventListener('click', function (ev) { ev.preventDefault(); neuerTab(a.href); });
  return a;
}

function leerZustand(list, text, schritte) {
  var e = el('div', 'empty');
  e.appendChild(document.createTextNode(text));
  if (schritte && schritte.length) {
    var ol = el('ol');
    schritte.forEach(function (s) { ol.appendChild(el('li', '', s)); });
    e.appendChild(ol);
  }
  list.appendChild(e);
  return e;
}

/* Zwei render()-Laeufe kurz hintereinander (z. B. eigener Aufruf + Meldung des
   Workers nach einem Write) leeren die Liste beide SOFORT, haengen ihre Zeilen
   aber erst nach dem Lesen aus dem Speicher an - dadurch stand am Ende alles
   doppelt da (LO 04.09., nach dem Recheck der Beobachtung).
   Jeder Aufbau markiert deshalb die Liste; wer beim Anhaengen nicht mehr die
   aktuelle Marke traegt, bricht ab. */
var LIST_GEN = 0;
function generation(list) {
  var g = String(++LIST_GEN);
  list.dataset.gen = g;
  return function () { return list.dataset.gen === g; };
}

function reduzierteBewegung() {
  try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; }
}

function tabAsin(tab) {
  var m = tab && tab.url && String(tab.url).match(/\/(?:dp|gp\/product)\/([A-Za-z0-9]{10})(?:[/?#]|$)/);
  return m ? m[1].toUpperCase() : '';
}

function bsrZahl(v) {
  if (typeof v === 'number') return isFinite(v) && v > 0 ? v : null;
  var n = parseInt(String(v == null ? '' : v).replace(/\D/g, ''), 10);
  return isFinite(n) && n > 0 ? n : null;
}

function httpBild(row) {
  var b = row && row.bilder;
  var u = Array.isArray(b) ? b[0] : b;
  return typeof u === 'string' && /^https:\/\//i.test(u) ? u : '';
}

function zeileZurAsin(rows, asin) {
  if (!asin) return null;
  var a = asin.toUpperCase();
  for (var i = (rows || []).length - 1; i >= 0; i--) {
    var r = rows[i];
    if (String(r.produkt_id || '').toUpperCase() === a) return r;
    if (r.url && String(r.url).toUpperCase().indexOf('/DP/' + a) >= 0) return r;
  }
  return null;
}

function zeileZurUrl(rows, url) {
  if (!url) return null;
  var ziel = String(url).split(/[?#]/)[0];
  for (var i = (rows || []).length - 1; i >= 0; i--) {
    if (rows[i].url && String(rows[i].url).split(/[?#]/)[0] === ziel) return rows[i];
  }
  return null;
}

/* Zahl weich zum Zielwert zählen. Merkt sich den letzten Wert am Element -
   beim ersten Setzen (oder bei reduzierter Bewegung) steht die Zahl sofort. */
function countUp(elm, ziel, fmt) {
  if (!elm) return;
  var z = Number(ziel);
  if (!isFinite(z)) { elm.textContent = fmt(ziel); return; }
  var alt = elm.dataset.alt !== undefined && elm.dataset.alt !== '' ? Number(elm.dataset.alt) : null;
  elm.dataset.alt = String(z);
  if (alt == null || alt === z || reduzierteBewegung()) { elm.textContent = fmt(z); return; }
  /* nachRender() laeuft pro Aktualisierung mehrfach (render()-rAF + die
     Speicher-Rueckmeldungen von renderWatch/renderPro/renderRank). Ohne Marke
     lief dann fuer DASSELBE Element mehr als eine rAF-Schleife gleichzeitig -
     beide schrieben abwechselnd ihren Zwischenwert, die Zahl zappelte und war
     scheinbar doppelt so schnell. Die juengste Schleife gewinnt. */
  var tok = String(++countUp.lauf);
  elm.dataset.up = tok;
  var t0 = performance.now(), dauer = 420;
  (function tick(now) {
    if (elm.dataset.up !== tok) return;
    var p = Math.min(1, (now - t0) / dauer), e = 1 - Math.pow(1 - p, 3);
    elm.textContent = fmt(alt + (z - alt) * e);
    if (p < 1) requestAnimationFrame(tick);
  })(t0);
}
countUp.lauf = 0;

/* Der Zähler nennt NUR den Zuwachs seit dem letzten Ansehen. Der Gesamtstand
   ist kein Signal - bei 2.066 Keywords stand dort immer "99+", also nie etwas
   anderes (LO 04.09.). Der Gesamtstand steht weiterhin im Tooltip. */
var gesehen = {};
try {
  chrome.storage.local.get('lcGesehen', function (d) {
    gesehen = (d && d.lcGesehen) || {};
    if (typeof nachRender === 'function') nachRender();
  });
} catch (e) { /* ohne Speicher bleibt jeder Stand "neu" */ }

function gesehenMerken(k, n) {
  if (gesehen[k] === n) return;
  gesehen[k] = n;
  try { chrome.storage.local.set({ lcGesehen: gesehen }); } catch (e) { /* nicht kritisch */ }
}

function zaehlText(n) {
  n = Math.round(n);
  if (!(n > 0)) return '';
  return '+' + (n > 99 ? '99' : n);
}

// ------------------------------------------------------- Ansicht Beobachtung

function renderWatch(list, data) {
  var watch = (data && data.watch) || [];
  if (!watch.length) {
    return leerZustand(list, 'Noch nichts beobachtet.', [
      'Amazon-Produktseite öffnen',
      'Auf den ☆-Chip hinter der ASIN klicken – oder die ASIN hier oben eintragen',
      'Preis, BSR und Buybox werden stündlich gemessen; „Jetzt messen“ misst sofort'
    ]);
  }
  /* Verlauf UND Vollprofil je ASIN: der Verlauf liefert die Trends, das
     Profil (wdata:) alles, was die Produktseite des Wettbewerbers hergibt. */
  var keys = [], aktuell = generation(list);
  watch.forEach(function (w) { keys.push('hist:' + w.asin); keys.push('wdata:' + w.asin); });
  storeGet(keys).then(function (d) {
    if (!aktuell()) return;
    kopfZeile(list, 'grid wl thead', ['ASIN', 'Artikel', 'Preis', 'BSR · zuletzt', '']);
    watch.forEach(function (w) {
      list.appendChild(watchZeile(w, (d && d['hist:' + w.asin]) || [], (d && d['wdata:' + w.asin]) || null));
    });
    nachRender();
  }).catch(function (e) {
    setStatus('Speicher nicht erreichbar: ' + ((e && e.message) || e), 'err');
  });
}

/* Trendzeiger hinter einer Zahl. Bei Preisen ist "rauf" schlecht (teurer
   geworden), beim Bestseller-Rang ist "rauf" ebenfalls schlecht (schlechter
   platziert) - deshalb dieselbe Farblogik für beide. */
function trend(neu, alt, formatiert) {
  if (neu == null || alt == null || neu === alt) return el('span', 'trend neutral', '');
  var t = el('span', 'trend ' + (neu > alt ? 'auf' : 'ab'), neu > alt ? '▲' : '▼');
  t.title = 'vorher ' + (formatiert ? formatiert(alt) : alt);
  return t;
}

/* hist-Sample: [iso, preis, bsr, buyboxCode, anbieter, angebotMin, bestand] */
function watchZeile(w, hist, prof) {
  var letzte = hist.length ? hist[hist.length - 1] : null;
  var vor = hist.length > 1 ? hist[hist.length - 2] : null;

  var zeile = el('div', 'grid item wl');
  zeile.appendChild(asinLink(w.asin));

  var t = zelle(zeile, 't', w.titel || (prof && prof.titel) || '', w.titel || w.asin);
  t.style.cursor = 'pointer';
  t.title = (w.titel || '') + '\nKlick: alle gespeicherten Daten';

  var preis = letzte && letzte[1] != null ? letzte[1] : (w.preis != null ? w.preis : null);
  var pz = zelle(zeile, preis == null ? 'preis leer' : 'preis', preis == null ? '–' : fmtPreis(preis));
  var vorher = vor && vor[1] != null ? vor[1] : null;
  if (preis != null && vorher != null) pz.appendChild(trend(preis, vorher, function (v) { return fmtPreis(v); }));

  /* Zustandsspalte: BSR und Zeitpunkt teilen sich EINE Zelle (JOURNEY.md,
     Feldinventur). Bewertung und Anbieterzahl aendern sich zu selten fuer
     eine Dauerspalte und stehen jetzt im Tooltip — kein Datenverlust, sie
     bleiben in Speicher und Export unveraendert. */
  var bsr = letzte && letzte[2] != null ? letzte[2] : (w.bsr != null ? w.bsr : null);
  var bsrVor = vor && vor[2] != null ? vor[2] : null;
  var bew = prof && prof.bewertung != null ? prof.bewertung : null;
  var anz = prof && prof.anbieter_anzahl != null ? prof.anbieter_anzahl
    : (letzte && letzte[4] != null ? letzte[4] : null);
  var buyboxWeg = letzte && letzte[3] === 2;

  var zst = zelle(zeile, buyboxWeg ? 'meta w' : 'meta',
    buyboxWeg ? 'Buybox weg' : (bsr != null ? nfDe(bsr) : '–'));
  if (!buyboxWeg && bsr != null && bsrVor != null) zst.appendChild(trend(bsr, bsrVor, nfDe));
  zst.title = [
    bsr != null ? 'Nr. ' + nfDe(bsr) + (prof && prof.bsr_kategorie ? ' in ' + prof.bsr_kategorie : '') : '',
    bew != null ? String(bew).replace('.', ',') + ' ★' +
      (prof && prof.anzahl_bewertungen ? ' aus ' + nfDe(prof.anzahl_bewertungen) + ' Bewertungen' : '') : '',
    anz != null ? anz + ' Anbieter' : ((prof && prof.verkaeufer) || ''),
    (prof && prof.andere_angebote) || ''
  ].filter(Boolean).join('\n');

  zelle(zeile, 'meta', vorZeit(letzte ? letzte[0] : w.ts));

  var akt = el('div', 'akt');
  var x = mkBtn('✕', 'Aus der Beobachtung entfernen', 'mini danger', function () { watchEntfernen(w.asin); });
  x.setAttribute('aria-label', 'Aus der Beobachtung entfernen');
  akt.appendChild(x);
  zeile.appendChild(akt);

  // Klick auf den Titel klappt das Vollprofil auf
  t.addEventListener('click', function () {
    var da = zeile.nextSibling && zeile.nextSibling.classList && zeile.nextSibling.classList.contains('wl-det');
    if (da) { zeile.parentNode.removeChild(zeile.nextSibling); return; }
    zeile.parentNode.insertBefore(profilBlock(w, prof, hist), zeile.nextSibling);
  });
  return zeile;
}

var PROFIL_FELDER = [
  ['marke', 'Marke'], ['ean', 'EAN'], ['sku', 'SKU'], ['kategorie', 'Kategorie'],
  ['bsr_text', 'Ränge'], ['kaufzahl_text', 'Gekauft'], ['verkaeufer', 'Verkäufer'],
  ['buybox', 'Buybox'], ['andere_angebote', 'Angebote'], ['verfuegbarkeit', 'Verfügbar'],
  ['lieferzeit', 'Lieferzeit'], ['versand', 'Versand'], ['uvp', 'UVP'],
  ['rabatt_prozent', 'Rabatt %'], ['bewertung', 'Bewertung'], ['anzahl_bewertungen', 'Bewertungen'],
  ['varianten', 'Varianten'], ['aplus', 'A+'], ['bilder_anzahl', 'Bilder'],
  ['bullets_anzahl', 'Bullets'], ['titel_laenge', 'Titel-Zeichen'],
  ['beschreibung_laenge', 'Beschreibung'], ['seit', 'Im Angebot seit'],
  ['eig_material', 'Material'], ['eig_farbe', 'Farbe'], ['eig_masse', 'Maße'],
  ['eig_gewicht', 'Gewicht'], ['eig_hersteller', 'Hersteller'], ['eig_modell', 'Modell']
];

function profilBlock(w, prof, hist) {
  var d = el('div', 'wl-det');
  if (!prof) {
    d.appendChild(el('div', 'hint', 'Noch kein Profil gespeichert – „Jetzt messen“ liest die Produktseite aus und legt alles ab.'));
    return d;
  }
  var dl = el('dl', 'wl-feld');
  PROFIL_FELDER.forEach(function (f) {
    var v = prof[f[0]];
    if (v == null || v === '' || v === 0) return;
    dl.appendChild(el('dt', '', f[1]));
    dl.appendChild(el('dd', '', String(v)));
  });
  dl.appendChild(el('dt', '', 'Messungen'));
  dl.appendChild(el('dd', '', hist.length + (prof.ts ? ' · zuletzt ' + new Date(prof.ts).toLocaleString('de-DE') : '')));
  d.appendChild(dl);

  var akt = el('div', 'dos-akt');
  akt.style.marginTop = '8px';
  akt.appendChild(mkBtn('Seite öffnen', 'Produktseite in einem Hintergrund-Tab öffnen', 'mini',
    function () { neuerTab('https://www.amazon.de/dp/' + w.asin); }));
  akt.appendChild(mkBtn('Profil kopieren', 'Alle gespeicherten Felder als Text kopieren', 'mini', function () {
    var z = ['ASIN\t' + w.asin];
    PROFIL_FELDER.forEach(function (f) {
      if (prof[f[0]] != null && prof[f[0]] !== '') z.push(f[1] + '\t' + prof[f[0]]);
    });
    navigator.clipboard.writeText(z.join('\n')).then(function () { setStatus('Profil kopiert.', 'ok'); })
      .catch(function (e) { setStatus('Kopieren fehlgeschlagen: ' + ((e && e.message) || e), 'err'); });
  }));
  d.appendChild(akt);
  return d;
}

function watchEntfernen(asin) {
  load().then(function (d) {
    var rest = (d.watch || []).filter(function (x) { return x.asin !== asin; });
    return saveViele({ watch: rest }).then(function () {
      load().then(render);
      setStatus(asin + ' wird nicht mehr beobachtet.', 'ok');
    });
  }).catch(function (e) {
    setStatus('Entfernen fehlgeschlagen: ' + ((e && e.message) || e), 'err');
  });
}

// --------------------------------------------------- Ansicht Preisprüfung

/* Zu jeder geprüften ASIN liegt im Verlauf (hist:) die ganze Reihe: Preis,
   günstigstes Fremdangebot und der Buybox-Zustand je Messung. Angezeigt wurde
   davon nur das Urteil der letzten Prüfung (LO 04.09.: „buybox hat ganze
   Kurve, zeigt nur ganz neuestem Ding Preise an"). Jetzt steht unter jeder
   Zeile das Buybox-Band über die Zeit, die Preiskurve und die Quote. */
function renderPro(list, data) {
  var pro = (data && data.pro) || [];
  if (!pro.length) {
    return leerZustand(list, 'Noch keine ASIN geprüft.', [
      'Amazon-Produktseite öffnen – oder ASIN oben in die Kommandozeile',
      '„Buybox für ASIN prüfen“ klicken',
      'Ergebnis erscheint hier, mit Verlauf sobald mehrere Messungen vorliegen'
    ]);
  }
  var aktuell = generation(list);
  var keys = pro.map(function (r) { return 'hist:' + String(r.asin || '').toUpperCase(); });
  storeGet(keys).then(function (d) {
    if (!aktuell()) return;
    pro.forEach(function (r) {
      list.appendChild(proZeile(r, (d && d['hist:' + String(r.asin || '').toUpperCase()]) || [], data));
    });
    nachRender();
  }).catch(function (e) {
    setStatus('Speicher nicht erreichbar: ' + ((e && e.message) || e), 'err');
  });
}

var BB_TEXT = { 1: 'Buybox da', 2: 'Buybox weg', 3: 'nicht verfügbar' };
var BB_KLASSE = { 1: 'ok', 2: 'bad', 3: 'warn' };

function proZeile(r, hist, data) {
  var item = el('div', 'item pro');
  var body = el('div', 'body');
  body.appendChild(el('span', 'tag', r.asin || '?'));

  var t = el('span', 't', r.urteil || ('Buybox: ' + (r.buybox || '?')));
  t.title = r.urteil || '';
  body.appendChild(t);

  var m = el('span', /UNTERBOTEN/.test(r.urteil || '') ? 'w' : 'meta', [
    r.guenstigster_beleg ? 'Nachweis: ' + r.guenstigster_beleg : '',
    (r.bestaetigte != null ? r.bestaetigte + ' von ' + r.kandidaten + ' Treffern belegt' : ''),
    'Buybox ' + (r.buybox || '?'),
    r.angebot_min != null ? 'Amazon ab ' + fmtPreis(r.angebot_min) : '',
    r.fehler ? '! ' + r.fehler : ''
  ].filter(Boolean).join(' · '));
  m.title = m.textContent;
  body.appendChild(m);

  if (r.wettbewerb) {
    var det = el('details', 'feld');
    var sum = el('summary', '', (r.anbieter_extern || 0) + ' Anbieter im Markt' +
      (r.luecke != null ? (r.luecke < 0
        ? ' · günstigster liegt ' + fmtPreis(Math.abs(r.luecke)) + ' darunter'
        : ' · niemand unterbietet') : ''));
    det.appendChild(sum);
    var pre = el('pre', 'feldtext', r.wettbewerb);
    det.appendChild(pre);
    body.appendChild(det);
  }
  if (r.verworfen) {
    var v = el('span', 'meta', 'verworfen: ' + r.verworfen);
    v.title = r.verworfen;
    body.appendChild(v);
  }

  // ---- Verlauf: das ist der eigentliche Zugewinn gegenüber dem Einzelurteil
  var messungen = hist.filter(function (s) { return s && (s[1] != null || s[3]); });
  if (messungen.length >= 2) body.appendChild(verlaufsBlock(messungen));

  item.appendChild(body);
  var akt = el('div', 'akt');
  var x = mkBtn('✕', 'Eintrag entfernen', 'mini danger', function () { proEintragLoeschen(r); });
  x.setAttribute('aria-label', 'Eintrag entfernen');
  akt.appendChild(x);
  item.appendChild(akt);
  return item;
}

/* Buybox-Band + Preiskurve + Quote. Das Band zeigt die letzten 60 Messungen
   als Streifen: grün = Buybox beim eigenen Angebot, rot = weg, gelb = nicht
   verfügbar, grau = damals nicht erfasst. */
function verlaufsBlock(hist) {
  var box = el('div', 'verlauf');
  var letzte = hist.slice(-60);

  var band = el('div', 'bbband');
  band.setAttribute('role', 'img');
  letzte.forEach(function (s) {
    var i = el('i', BB_KLASSE[s[3]] || '');
    i.title = ui_datum(s[0]) + ': ' + (BB_TEXT[s[3]] || 'nicht erfasst') +
      (s[1] != null ? ' · ' + fmtPreis(s[1]) : '') +
      (s[5] != null ? ' · Markt ab ' + fmtPreis(s[5]) : '');
    band.appendChild(i);
  });
  box.appendChild(band);

  var bewertet = hist.filter(function (s) { return s[3] === 1 || s[3] === 2 || s[3] === 3; });
  var mitBb = bewertet.filter(function (s) { return s[3] === 1; }).length;
  var preise = hist.map(function (s) { return Number(s[1]); }).filter(function (v) { return v > 0; });
  var markt = hist.map(function (s) { return Number(s[5]); }).filter(function (v) { return v > 0; });

  var f = el('div', 'verlauf-f');
  if (bewertet.length) {
    var q = Math.round(mitBb / bewertet.length * 100);
    f.appendChild(legende('Buybox', q + ' %'));
  }
  f.appendChild(legende('Messungen', String(hist.length)));
  if (preise.length >= 2) {
    var pMin = Math.min.apply(null, preise), pMax = Math.max.apply(null, preise);
    f.appendChild(legende('eigener Preis', pMax > pMin ? fmtPreis(pMin) + ' – ' + fmtPreis(pMax) : fmtPreis(pMin)));
  }
  if (markt.length) f.appendChild(legende('Markt ab', fmtPreis(Math.min.apply(null, markt))));
  f.appendChild(legende('seit', ui_datum(hist[0][0])));
  box.appendChild(f);

  /* Kurve nur bei echter Bewegung: bei konstantem Preis wiederholt sie nur,
     was in der Zeile darüber schon steht. */
  if (preise.length >= 2 && Math.min.apply(null, preise) < Math.max.apply(null, preise)) {
    box.appendChild(spark(hist, 1, {}));
  }
  return box;
}

function ui_datum(iso) {
  var t = Date.parse(iso);
  if (!t || isNaN(t)) return '';
  return new Date(t).toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit', year: '2-digit' });
}

function proEintragLoeschen(r) {
  storeGet(['pro']).then(function (d) {
    var arr = d.pro || [];
    var ix = arr.findIndex(function (x) { return x.asin === r.asin && x.geprueft_am === r.geprueft_am; });
    if (ix < 0) ix = arr.findIndex(function (x) { return x.asin === r.asin; });
    if (ix > -1) arr.splice(ix, 1);
    return saveViele({ pro: arr }).then(function () { load().then(render); });
  }).catch(function (e) {
    setStatus('Entfernen fehlgeschlagen: ' + ((e && e.message) || e), 'err');
  });
}

// ------------------------------------------------------------ Ansicht Ränge

/* rank:<keyword> = { asins: { <ASIN>: [[iso, orgPos|null, pos], ...] }, letzte }
   Letztes Element = neueste Messung. orgPos null = nur Anzeigenplatz. */
function renderRank(list) {
  var aktuell = generation(list);
  storeGetPrefix('rank:').then(function (d) {
    if (!aktuell()) return;
    var zeilen = [];
    Object.keys(d || {}).forEach(function (key) {
      if (key.indexOf('rank:') !== 0) return;
      var kw = key.slice(5), asins = (d[key] && d[key].asins) || {};
      Object.keys(asins).forEach(function (asin) {
        var m = asins[asin] || [];
        if (!m.length) return;
        zeilen.push({
          kw: kw, asin: asin, alle: asins,
          last: m[m.length - 1], prev: m.length > 1 ? m[m.length - 2] : null
        });
      });
    });
    if (!zeilen.length) {
      return leerZustand(list, 'Noch keine Ränge gemessen. Ränge entstehen von selbst beim Besuch von ' +
        'Amazon-Suchseiten, auf denen eigene Artikel (Deuba/Casaria/Monzana/Gardebruk) erscheinen.', null);
    }
    zeilen.sort(function (a, b) {
      if (a.kw !== b.kw) return a.kw.localeCompare(b.kw, 'de');
      return rangWert(a.last) - rangWert(b.last);
    });
    kopfZeile(list, 'grid rk thead', ['', 'Keyword', 'Pos.', 'Trend · zuletzt', '']);
    zeilen.forEach(function (z) { list.appendChild(rankZeile(z)); });
    nachRender();
  }).catch(function (e) {
    setStatus('Speicher nicht erreichbar: ' + ((e && e.message) || e), 'err');
  });
}

// Anzeigenplätze ans Ende - ein bezahlter Platz ist kein organischer Rang.
function rangWert(m) { return m && m[1] != null ? m[1] : 9999; }

function rankZeile(z) {
  var zeile = el('div', 'grid item rk');

  /* Kennungsspalte bleibt LEER statt zu entfallen — nur so beginnt das
     Keyword an derselben Kante wie der Titel in allen anderen Listen
     (DESIGN.md, Spaltenordnung). Die ASIN steht im Tooltip: bei einer
     eigenen ASIN je Keyword war die Dauerspalte verschenkt. */
  zeile.appendChild(el('span', ''));

  var a = el('a', 't', z.kw);
  a.href = 'https://www.amazon.de/s?k=' + encodeURIComponent(z.kw);
  a.title = z.kw + (z.asin ? '\nASIN ' + z.asin : '');
  a.addEventListener('click', function (ev) { ev.preventDefault(); neuerTab(a.href); });
  zeile.appendChild(a);

  if (z.last[1] != null) {
    var pz = zelle(zeile, 'num', 'Pos. ' + z.last[1]);
    // Balken: Seite 1 hat 48 Plätze - je kürzer, desto besser
    var bar = el('span', 'bar' + (z.last[1] <= 10 ? ' ok' : ''));
    var f = el('i'); f.style.width = Math.max(4, Math.round(100 - Math.min(48, z.last[1]) / 48 * 100)) + '%';
    bar.appendChild(f); pz.appendChild(bar);
  } else zelle(zeile, 'meta', 'Anzeige');

  // Zustandsspalte: Trend und Zeitpunkt teilen sich eine Zelle.
  var alt = z.prev ? z.prev[1] : null, neu = z.last[1], zTxt = vorZeit(z.last[0]);
  var tz;
  if (alt == null || neu == null) tz = zelle(zeile, 'meta', zTxt);
  else if (alt === neu) tz = zelle(zeile, 'meta', '= · ' + zTxt);
  else {
    var delta = alt - neu;   // kleinerer Rang = besser
    tz = zelle(zeile, delta > 0 ? 'ok' : 'w',
      (delta > 0 ? '▲ +' : '▼ −') + Math.abs(delta) + ' · ' + zTxt);
  }
  tz.title = 'zuletzt gemessen: ' + zTxt + (alt != null ? '\nvorher Pos. ' + alt : '');

  var akt = el('div', 'akt');
  akt.appendChild(mkBtn('Markdown', 'Alle Messungen dieses Keywords als Tabelle kopieren', 'mini',
    function () { rankKopieren(z.kw, z.alle); }));
  var x = mkBtn('✕', 'Messreihe dieses Keywords löschen', 'mini danger', function () {
    bestaetigen(x, 'Messreihe „' + z.kw + '“ löschen', function () {
      return sendMsg({ type: 'lcStoreRemove', keys: 'rank:' + z.kw }).then(function () {
        load().then(render);
        setStatus('Messreihe „' + z.kw + '“ gelöscht.', 'ok');
      });
    });
  });
  x.setAttribute('aria-label', 'Messreihe dieses Keywords löschen');
  akt.appendChild(x);
  zeile.appendChild(akt);
  return zeile;
}

function rankKopieren(kw, asins) {
  var z = ['| Keyword | ASIN | Pos. | Datum |', '| --- | --- | --- | --- |'];
  Object.keys(asins).forEach(function (asin) {
    (asins[asin] || []).forEach(function (m) {
      z.push('| ' + kw + ' | ' + asin + ' | ' +
        (m[1] != null ? m[1] : 'Anzeige' + (m[2] != null ? ' (' + m[2] + ')' : '')) + ' | ' +
        String(m[0] || '').slice(0, 10) + ' |');
    });
  });
  navigator.clipboard.writeText(z.join('\n')).then(function () {
    setStatus((z.length - 2) + ' Messungen als Markdown kopiert.', 'ok');
  }).catch(function (e) {
    setStatus('Kopieren fehlgeschlagen: ' + ((e && e.message) || e), 'err');
  });
}

// ---------------------------------------------------------- Ansicht Aktuell

function tile(parent, label, wert, cls, sub) {
  var t = el('div', 'tile' + (cls ? ' ' + cls : ''));
  t.appendChild(el('div', 'tile-l', label));
  t.appendChild(el('div', 'tile-v', wert));
  if (sub) t.appendChild(el('div', 'tile-s', sub));
  parent.appendChild(t);
  return t;
}

function sektion(titel, sub) {
  var s = el('section', 'dos-sec');
  var h = el('h3', '', titel);
  if (sub) h.appendChild(el('span', 'dos-sub', sub));
  s.appendChild(h);
  return s;
}

function schaetzung(bsr, kat) {
  try {
    /* Diagnose (LO 04.09.): die Kachel zeigt bei JEDEM dieser vier Faelle
       dasselbe "–", darum hier einzeln benennen. Haeufigster Fall ist eine
       fehlende Kategorie: der BSR kommt aus Helium 10, die Kategorie aber
       aus dem Seiten-Scrape — fehlt sie, faellt die Schaetzung aus, obwohl
       Daten da sind. */
    if (!(bsr > 0)) { console.log('[LC popup] Schätzung: kein BSR (bsr=' + bsr + ')'); return null; }
    if (!kat) { console.log('[LC popup] Schätzung: keine Kategorie zum BSR ' + bsr); return null; }
    if (!window.LC || !LC.sales || typeof LC.sales.schaetzeSync !== 'function') {
      console.warn('[LC popup] Schätzung: LC.sales nicht geladen — shared/sales.js in popup.html prüfen');
      return null;
    }
    var r = LC.sales.schaetzeSync(bsr, String(kat).toLowerCase());
    if (!(r && r.menge > 0)) console.log('[LC popup] Schätzung: kein Ergebnis für bsr=' + bsr + ' kat="' + kat + '"');
    return r && r.menge > 0 ? r : null;
  } catch (e) { console.warn('[LC popup] Schätzung warf: ' + ((e && e.message) || e)); return null; }
}

function quelleText(q) {
  if (q === 'eigen') return 'eigener Messwert';
  if (q === 'kalibriert' || q === 'fit' || q === 'fitAlle') return 'kalibriert';
  if (q === 'anker') return 'aus eigenen Punkten';
  return 'Startkurve, lernt noch';
}

function seedAusTitel(row) {
  var marke = String(row.marke || '').toLowerCase();
  var w = String(row.titel || '').toLowerCase().replace(/[^a-zäöüß0-9\s-]/g, ' ').split(/\s+/)
    .filter(function (x) { return x && x.length > 2 && x !== marke && !/^\d+$/.test(x); });
  return w.slice(0, 3).join(' ');
}

function renderHome(list, data) {
  // Der aktive Tab ist beim allerersten render() noch unbekannt - kontextZeigen
  // stösst den Aufbau an, sobald er da ist (Fallback nach 1,2 s: Überblick).
  if (letzterTab === undefined) {
    setTimeout(function () {
      if (letzterTab === undefined) { letzterTab = null; if (view === 'home') load().then(render); }
    }, 1200);
    return;
  }
  var aktuell = generation(list);
  var asin = tabAsin(letzterTab);
  if (!asin) return renderUebersicht(list, data);
  var row = zeileZurAsin(data.rows, asin);
  if (!row) {
    var e = leerZustand(list, 'Dieses Produkt ist noch nicht erfasst.', [
      '„Erfassen“ liest Titel, Preis, Buybox, BSR und Bilder aus der offenen Seite',
      'Danach erscheinen hier Preisleiter, Verlauf und die Aktionen'
    ]);
    var b = el('button', 'primary', 'Jetzt erfassen');
    b.style.marginTop = '12px';
    b.addEventListener('click', function () { if ($('grab')) $('grab').click(); });
    e.appendChild(b);
    return;
  }
  list.appendChild(dossier(row, asin, data, aktuell));
}

function dossier(row, asin, data, aktuell) {
  var d = el('div', 'dossier');

  // Kopf: Bild, Titel, Kennungen, Preis
  var kopf = el('div', 'dos-kopf');
  var bild = httpBild(row);
  if (bild) { var img = el('img', 'dos-bild'); img.src = bild; img.alt = ''; kopf.appendChild(img); }
  var kt = el('div');
  kt.appendChild(el('div', 'dos-titel', row.titel || asin));
  kt.appendChild(el('div', 'dos-meta', [asin, row.marke, row.ean ? 'EAN ' + row.ean : '', row.sku ? 'SKU ' + row.sku : '']
    .filter(Boolean).join(' · ')));
  kopf.appendChild(kt);
  var pr = el('div', 'dos-preis');
  pr.appendChild(el('b', '', row.preis == null ? '–' : fmtPreis(row.preis, row.waehrung)));
  pr.appendChild(el('small', '', (row.plattform || 'Amazon') + ' · erfasst'));
  kopf.appendChild(pr);
  d.appendChild(kopf);

  /* Kennzahlen. Die Werte werden auf ein Wort gekürzt - die Rohtexte
     ("A+ + Brand Story", "Andere Verkäufer auf Amazon: 3") sprengten die
     Kachel und wurden mitten im Wort abgeschnitten (Test 04.09.).
     Der volle Text steht als Untertitel bzw. im Tooltip. */
  var kpis = el('div', 'kpis');
  var bb = row.buybox || '?';
  tile(kpis, 'Buybox', bb === 'UNTERDRUECKT' ? 'weg' : bb,
    bb === 'ja' ? 'ok' : (bb === 'UNTERDRUECKT' ? 'bad' : 'warn'),
    bb === 'UNTERDRUECKT' ? 'irgendwo günstiger' : '');
  var apl = String(row.aplus || '');
  tile(kpis, 'A+', !apl ? '?' : (/^KEIN/i.test(apl) ? 'fehlt' : 'da'),
    /^KEIN/i.test(apl) ? 'bad' : (apl ? 'ok' : ''), /Brand/i.test(apl) ? '+ Brand Story' : '')
    .title = apl;
  var bsr = bsrZahl(row.bsr);
  tile(kpis, 'BSR', bsr ? nfDe(bsr) : '–', '', row.bsr_kategorie || '');
  var ang = String(row.andere_angebote || '');
  var angN = (ang.match(/\d+/) || [])[0];
  tile(kpis, 'Angebote', angN || (ang ? 'ja' : '–'), '', angN ? 'weitere Anbieter' : '').title = ang;
  var sch = schaetzung(bsr, row.bsr_kategorie);
  tile(kpis, 'Schätzung', sch ? nfDe(sch.menge) + ' / Monat' : '–', '', sch ? quelleText(sch.quelle) : (bsr ? 'keine Kategorie' : 'kein BSR'));
  var beobachtet = (data.watch || []).some(function (w) { return w.asin === asin; });
  tile(kpis, 'Beobachtung', beobachtet ? 'aktiv' : 'aus', beobachtet ? 'ok' : '', beobachtet ? 'stündliche Messung' : '');
  d.appendChild(kpis);

  // Preisleiter: alle belegten Treffer zur EAN dieses Artikels
  var ean = String(row.ean || (data.eanMap || {})[asin] || (data.eanMap || {})[row.sku] || '');
  var treffer = ean ? (data.matches || []).filter(function (m) {
    return m && m.preis != null && String(m.ean || '') === ean && m.match_stufe !== 'FREMD';
  }) : [];
  var unterbietet = null;
  if (row.preis > 0) {
    treffer.forEach(function (m) {
      if (istShop(m) || m.match_bestaetigt !== 'ja') return;
      if (Number(m.preis) < row.preis && (unterbietet == null || Number(m.preis) < unterbietet)) unterbietet = Number(m.preis);
    });
  }
  var s1 = sektion('Preisleiter', treffer.length
    ? (unterbietet != null ? 'günstigster ' + fmtPreis(unterbietet) : 'niemand unterbietet') + ' · ' + treffer.length + ' Treffer'
    : (ean ? 'noch kein Preisvergleich' : 'keine EAN bekannt'));
  if (treffer.length) s1.appendChild(leiter(row, treffer));
  else {
    s1.appendChild(el('div', 'hint', ean
      ? 'Der Preisvergleich sucht denselben Artikel auf den angehakten Plattformen und stellt die Preise hier nebeneinander.'
      : 'Ohne EAN läuft der Vergleich über Marke und Titel – die Treffer landen in „Suche“.'));
    var pv = el('button', 'primary sm', 'Preisvergleich starten');
    pv.style.marginTop = '8px';
    pv.addEventListener('click', function () { startCompare(row, data.eanMap || {}); });
    s1.appendChild(pv);
  }
  d.appendChild(s1);

  // Verlauf aus hist:<ASIN> (asynchron nachgeladen)
  var s2 = sektion('Verlauf', '');
  d.appendChild(s2);
  storeGet(['hist:' + asin]).then(function (h) {
    if (aktuell && !aktuell()) return;
    var samples = (h && h['hist:' + asin]) || [];
    var sub = s2.querySelector('h3');
    if (samples.length < 2) {
      s2.appendChild(el('div', 'hint', 'Der Verlauf entsteht beim Surfen und mit der Beobachtung – ab zwei Messungen erscheint hier die Kurve.'));
      return;
    }
    if (sub) sub.appendChild(el('span', 'dos-sub', samples.length + ' Messungen · seit ' + String(samples[0][0] || '').slice(0, 10)));
    /* Beschriftung ÜBER die zugehörige Kurve, nicht darunter: dazwischen
       gesetzt las sie sich als Titel der jeweils folgenden (Test 04.09.). */
    var preise = samples.map(function (s) { return Number(s[1]); }).filter(function (v) { return v > 0; });
    var bsrs = samples.map(function (s) { return Number(s[2]); }).filter(function (v) { return v > 0; });
    if (preise.length >= 2) {
      var pMin = Math.min.apply(null, preise), pMax = Math.max.apply(null, preise);
      s2.appendChild(kurvenKopf('Preis', '', pMax > pMin
        ? [['zuletzt', fmtPreis(preise[preise.length - 1])], ['Spanne', fmtPreis(pMin) + ' – ' + fmtPreis(pMax)]]
        : [['unverändert', fmtPreis(pMin)]]));
      s2.appendChild(spark(samples, 1, {}));
    }
    if (bsrs.length >= 2) {
      var bMin = Math.min.apply(null, bsrs), bMax = Math.max.apply(null, bsrs);
      s2.appendChild(kurvenKopf('Bestseller-Rang', 'bsr', bMax > bMin
        ? [['zuletzt', nfDe(bsrs[bsrs.length - 1])], ['bester', nfDe(bMin)]]
        : [['unverändert', nfDe(bMin)]]));
      s2.appendChild(spark(samples, 2, { bsr: true }));
    }
  }).catch(function (e) {
    s2.appendChild(el('div', 'hint', 'Verlauf nicht lesbar: ' + ((e && e.message) || e)));
  });

  // Aktionen
  var s3 = sektion('Aktionen', '');
  var akt = el('div', 'dos-akt');
  akt.appendChild(knopf('Preisvergleich', 'Denselben Artikel auf den anderen Plattformen suchen', 'primary sm', function () {
    startCompare(row, data.eanMap || {});
  }));
  var seed = seedAusTitel(row);
  akt.appendChild(knopf('Keywords ernten', 'Autocomplete-Ränge zu „' + seed + '“', 'sm', function () {
    if ($('kwSeed')) $('kwSeed').value = seed;
    rerunHarvest(seed, false);
  }));
  akt.appendChild(knopf('Buybox prüfen', 'Angebotslage und günstigere Anbieter zu dieser ASIN', 'sm', function () { proCheckStarten(); }));
  akt.appendChild(knopf('Analyse', 'A+, Buybox, EAN und Varianten dieses Listings', 'sm', function () {
    switchView('rows');
    renderAnalyse(row, data.eanMap || {});
  }));
  var stern = el('button', 'stern' + (beobachtet ? ' an' : ''), beobachtet ? '★' : '☆');
  stern.title = beobachtet ? 'Beobachtung beenden' : 'Beobachten: Preis, BSR und Buybox stündlich messen';
  stern.setAttribute('aria-label', stern.title);
  stern.addEventListener('click', function () { watchUmschalten(row, asin, beobachtet); });
  akt.appendChild(stern);
  s3.appendChild(akt);
  d.appendChild(s3);
  return d;
}

function knopf(text, titel, cls, fn) {
  var b = el('button', cls, text);
  b.type = 'button';
  b.title = titel;
  b.addEventListener('click', fn);
  return b;
}

function legende(label, wert) {
  var s = el('span', '', label + ' ');
  s.appendChild(el('b', '', wert));
  return s;
}

/* Kopfzeile einer Kurve: Farbpunkt, Name, dann die Kennzahlen. */
function kurvenKopf(name, art, paare) {
  var k = el('div', 'kurve-kopf' + (art ? ' ' + art : ''));
  k.appendChild(el('span', 'pkt'));
  k.appendChild(el('span', 'kn', name));
  var w = el('span', 'kw');
  paare.forEach(function (p) { w.appendChild(legende(p[0], p[1])); });
  k.appendChild(w);
  return k;
}

function watchUmschalten(row, asin, an) {
  load().then(function (d) {
    var watch = (d.watch || []).filter(function (w) { return w.asin !== asin; });
    if (!an) {
      watch.push({ asin: asin, titel: String(row.titel || '').slice(0, 80), preis: row.preis == null ? null : Number(row.preis),
        bsr: bsrZahl(row.bsr), ts: Date.now() });
    }
    return saveViele({ watch: watch }).then(function () {
      load().then(render);
      setStatus(an ? asin + ' wird nicht mehr beobachtet.' : asin + ' wird jetzt beobachtet.', 'ok');
    });
  }).catch(function (e) {
    setStatus('Speichern fehlgeschlagen: ' + ((e && e.message) || e), 'err');
  });
}

/* Preisleiter: je Anbieter ein Balken, sortiert nach Preis. Eine Achse mit
   Punkten war unbrauchbar, sobald mehrere Anbieter denselben Preis haben -
   dann lagen alle Marker samt Beschriftung übereinander (Test 04.09.).
   Balkenlänge: der teuerste Anbieter füllt aus, der günstigste behält 30 %,
   damit auch kleine Unterschiede sichtbar bleiben und nichts verschwindet. */
function leiter(row, treffer) {
  var punkte = [];
  var eigen = Number(row.preis);
  if (eigen > 0) punkte.push({ label: row.plattform || 'Amazon', preis: eigen, cls: 'eigen', titel: 'Dieses Listing' });
  var best = null;
  treffer.forEach(function (m) {
    var p = Number(m.preis), shop = istShop(m), ok = m.match_bestaetigt === 'ja';
    if (!(p > 0)) return;
    if (!ok && !shop) return;   // unbelegte Kandidaten verwirren die Leiter
    if (!shop && (best == null || p < best)) best = p;
    punkte.push({ label: m.plattform || '?', preis: p, cls: shop ? 'ref' : '',
      titel: (m.titel || '') + (m.match_grund ? '\n' + m.match_grund : '') });
  });
  /* "best" ist ein Alarm, keine Sortierung: nur wer den eigenen Preis
     tatsächlich UNTERBIETET, wird rot. Vorher bekamen alle Anbieter mit
     demselben Preis die Alarmfarbe, obwohl niemand unterbot (Test 04.09.). */
  if (eigen > 0 && !(best < eigen)) best = null;
  var einmal = false;
  punkte.forEach(function (p) {
    if (p.cls === '' && best != null && p.preis === best && !einmal) { p.cls = 'best'; einmal = true; }
  });
  punkte.sort(function (a, b) { return a.preis - b.preis; });
  if (!punkte.length) return el('div', 'hint', 'Keine belegten Preise.');

  var max = punkte[punkte.length - 1].preis;
  var wrap = el('div', 'leiter');
  punkte.forEach(function (p, i) {
    var z = el('div', 'lz' + (p.cls ? ' ' + p.cls : ''));
    z.title = p.titel || p.label;
    z.appendChild(el('span', 'lz-l', p.label));
    var spur = el('span', 'lz-bar');
    var f = el('i');
    f.style.width = Math.round(30 + (max > 0 ? p.preis / max : 1) * 70) + '%';
    f.style.transitionDelay = (i * 45) + 'ms';
    spur.appendChild(f);
    z.appendChild(spur);
    z.appendChild(el('span', 'lz-p', fmtPreis(p.preis).replace(' EUR', ' €')));
    // Abstand zum eigenen Preis - die Zahl, wegen der man hinsieht
    var d = eigen > 0 && p.cls !== 'eigen' ? p.preis - eigen : null;
    z.appendChild(el('span', 'lz-d' + (d != null && d < 0 ? ' bad' : ''),
      d == null || d === 0 ? '' : (d < 0 ? '−' : '+') + fmtPreis(Math.abs(d)).replace(' EUR', ' €')));
    wrap.appendChild(z);
  });
  // Balken von 0 auf ihre Länge wachsen lassen (ein Frame später, sonst kein Übergang)
  if (!reduzierteBewegung()) {
    var breiten = [];
    Array.prototype.forEach.call(wrap.querySelectorAll('.lz-bar>i'), function (f) {
      breiten.push([f, f.style.width]); f.style.width = '0%';
    });
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { breiten.forEach(function (x) { x[0].style.width = x[1]; }); });
    });
  }
  return wrap;
}

/* Sparkline als SVG: idx 1 = Preis (hoch = teuer), idx 2 = BSR (klein = oben).
   Bei konstantem Wert bleibt die Fläche weg - sonst steht da ein massiver
   Block, der nach Datenmenge aussieht statt nach "unverändert" (Test 04.09.). */
/* Treppenkurve, keine Rampe.
   Ein Preis (und ebenso ein Bestseller-Rang) ist zwischen zwei Messungen
   KONSTANT — er steht still und springt dann. Die frueher schraege
   Verbindung zwischen den Punkten hat Uebergaenge erfunden, die es nie gab:
   bei abwechselnden Werten wurde daraus ein durchgehendes Zickzack (VVVV)
   statt der tatsaechlichen Stufen (-_-_-). Deshalb step-after: waagerecht
   halten bis zur naechsten Messung, dann senkrecht springen.

   Zweite Korrektur: die Y-Achse spannte von min bis max. Der niedrigste
   gemessene Preis lag damit IMMER ganz unten am Rand, egal wie klein die
   Aenderung war — 89 statt 100 sah aus wie ein Sturz auf null. Die Achse
   beginnt jetzt bei 0 €: die Kurve bleibt oben und sinkt genau um den
   Anteil, um den der Preis wirklich gefallen ist. */
function spark(samples, idx, opts) {
  var NS = 'http://www.w3.org/2000/svg', W = 300, H = 44, P = 3;
  var werte = [];
  samples.forEach(function (s) { var v = Number(s[idx]); if (v > 0) werte.push(v); });
  var min = Math.min.apply(null, werte), max = Math.max.apply(null, werte);
  var flach = !(max > min);

  /* Achse von 0 bis zum doppelten Hoechstwert: die Kurve liegt damit mittig
     in der Flaeche statt am oberen Rand zu kleben. Der Preis bleibt in seinem
     echten Verhaeltnis zu 0 lesbar — eine Ruecknahme um 11 % sinkt um 11 %
     des Abstands zur Nulllinie, nicht um die halbe Bildhoehe. */
  var uMin = 0, uMax = max * 2 || 1;

  /* Beide Kurven laufen gleich herum: kleiner Wert unten, grosser oben.
     Der Bestseller-Rang war frueher gespiegelt (kleiner Rang = oben, weil
     "besser"), was beim Vergleich mit der Preiskurve daneben in die Irre
     fuehrte — zwei Linien, zwei Leserichtungen. LO 04.09.: "bsr kurve
     invertieren, unten = kleiner bsr". Dass ein kleiner Rang der bessere
     ist, sagt die Beschriftung, nicht die Achsenrichtung. */
  var y = function (v) {
    var t = uMax > uMin ? (v - uMin) / (uMax - uMin) : 0.5;
    return H - P - t * (H - 2 * P);
  };
  var x = function (i) { return werte.length > 1 ? P + i / (werte.length - 1) * (W - 2 * P) : W / 2; };

  // step-after: erst waagerecht auf die neue x-Position, dann senkrecht.
  var d = '';
  werte.forEach(function (v, i) {
    var xi = x(i).toFixed(1), yi = y(v).toFixed(1);
    if (!i) { d = 'M' + xi + ' ' + yi; return; }
    d += ' L' + xi + ' ' + y(werte[i - 1]).toFixed(1) + ' L' + xi + ' ' + yi;
  });

  var svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
  svg.setAttribute('preserveAspectRatio', 'none');
  svg.setAttribute('class', 'spark' + (opts && opts.bsr ? ' bsr' : '') + (flach ? ' flach' : ''));
  if (!flach) {
    var f = document.createElementNS(NS, 'path');
    f.setAttribute('class', 'f');
    f.setAttribute('d', d + ' L' + x(werte.length - 1).toFixed(1) + ' ' + H + ' L' + x(0).toFixed(1) + ' ' + H + ' Z');
    svg.appendChild(f);
  }
  var l = document.createElementNS(NS, 'path');
  l.setAttribute('class', 'l');
  l.setAttribute('d', d);
  svg.appendChild(l);
  var c = document.createElementNS(NS, 'circle');
  c.setAttribute('cx', x(werte.length - 1).toFixed(1));
  c.setAttribute('cy', y(werte[werte.length - 1]).toFixed(1));
  c.setAttribute('r', '2.5');
  svg.appendChild(c);
  return svg;
}

function renderUebersicht(list, data) {
  var rows = data.rows || [], matches = data.matches || [], keywords = data.keywords || [];
  var pro = data.pro || [], watch = data.watch || [];
  var d = el('div', 'dossier');

  var kpis = el('div', 'kpis');
  tile(kpis, 'Listings', String(rows.length), '', rows.length ? 'erfasst' : 'noch keins');
  var best = matches.filter(function (m) { return m.match_bestaetigt === 'ja'; }).length;
  tile(kpis, 'Belegte Treffer', String(best), best ? 'ok' : '', matches.length + ' gesamt');
  var seeds = {};
  keywords.forEach(function (k) { seeds[String(k.seed || '').toLowerCase()] = 1; });
  tile(kpis, 'Keywords', nfDe(keywords.length), '', Object.keys(seeds).length + ' Seeds');
  var unter = pro.filter(function (p) { return /UNTERBOTEN/.test(p.urteil || ''); }).length;
  tile(kpis, 'Unterboten', String(unter), unter ? 'bad' : (pro.length ? 'ok' : ''), pro.length + ' geprüft');
  tile(kpis, 'Beobachtet', String(watch.length), '', watch.length ? 'stündlich gemessen' : '');
  d.appendChild(kpis);

  var s1 = sektion('Zuletzt erfasst', rows.length ? rows.length + ' Listings' : '');
  if (rows.length) {
    rows.slice(-5).reverse().forEach(function (r) {
      var z = el('div', 'grid item' + (istShop(r) ? ' ref' : ''));
      zelle(z, 'tag', r.plattform || '?');
      if (r.url) {
        var a = el('a', 't', r.titel || '(ohne Titel)');
        a.href = r.url; a.title = r.titel || '';
        a.addEventListener('click', function (ev) { ev.preventDefault(); neuerTab(r.url); });
        z.appendChild(a);
      } else zelle(z, 't', r.titel || '(ohne Titel)');
      zelle(z, r.preis == null ? 'preis leer' : 'preis', r.preis == null ? '–' : fmtPreis(r.preis, r.waehrung));
      zelle(z, r.warnungen ? 'w' : 'ok', r.warnungen || 'ok', r.warnungen || '');
      var akt = el('div', 'akt');
      akt.appendChild(mkBtn('⌕', 'Analyse anzeigen', 'mini', function () { switchView('rows'); renderAnalyse(r, data.eanMap || {}); }));
      z.appendChild(akt);
      s1.appendChild(z);
    });
  } else {
    s1.appendChild(el('div', 'hint', 'Noch nichts erfasst – eine Produktseite öffnen und oben „Erfassen“ klicken.'));
  }
  d.appendChild(s1);

  var s2 = sektion('So geht’s', '');
  var ol = el('ol');
  ol.style.margin = '0';
  ol.style.paddingLeft = '18px';
  ['Produktseite bei Amazon, eBay, Otto oder Kaufland öffnen – dieses Fenster zeigt dann das Dossier des Artikels',
   '„Erfassen“ liest das Listing; der Preisvergleich findet denselben Artikel auf den anderen Plattformen',
   'Oben in der Kommandozeile: EAN, ASIN oder Keyword eintippen – die passenden Aktionen erscheinen darunter']
    .forEach(function (t) { ol.appendChild(el('li', '', t)); });
  s2.appendChild(ol);
  d.appendChild(s2);

  list.appendChild(d);
}

// ------------------------------------------------- Bewegung und Kopfzeile

/* Nach jedem Aufbau der Liste: Stagger-Index setzen (nur direkt nach einem
   Ansichtswechsel - eine Datenaktualisierung im laufenden Betrieb soll nicht
   erneut aufsteigen) und die Zähler in der Leiste weich nachziehen. */
function nachRender() {
  /* Die Staffelung haengt allein an der Klasse .wechsel, die viewWechsel()
     setzt und nach 460 ms wieder abraeumt. Eine reine Datenaktualisierung
     setzt sie nie — damit steht die Flaeche still.
     Ausnahme ist der ERSTE Aufbau: beim Oeffnen wechselt niemand die
     Ansicht, also wuerde sie hier nie gesetzt und die Zeilen erschienen
     ohne Bewegung. Einmal nachhelfen, sobald wirklich Inhalt da ist. */
  if (!ersterAufbau) {
    var l0 = $('list');
    if (l0 && l0.children.length) { ersterAufbau = true; viewWechsel(); }
  }
  var z = (typeof letzteZaehler === 'object' && letzteZaehler) || {};
  var offen = (typeof view !== 'undefined' ? view : 'home');
  if (offen === 'rank') offen = 'keywords';
  Object.keys(RAIL_IDS).forEach(function (k) {
    var b = $(RAIL_IDS[k]), c = b && b.querySelector('.cnt');
    if (!b) return;
    var gesamt = z[k] || 0;
    // Was man gerade ansieht, hat man gesehen - dort nie ein Abzeichen.
    var neu = k === offen ? 0 : Math.max(0, gesamt - (gesehen[k] || 0));
    if (c) countUp(c, neu, zaehlText);
    if (!b.dataset.basisTitel) b.dataset.basisTitel = b.title || '';
    b.title = b.dataset.basisTitel + (gesamt ? ' · ' + nfDe(gesamt) + ' gesamt' : '') +
      (neu ? ' · ' + neu + ' neu' : '');
  });
  if (z[offen] != null) gesehenMerken(offen, z[offen]);
  stapelAnimieren();
}

/* viewWechsel() setzt nur noch VOR, dass die naechste fertige Liste aufsteigen
   darf - animiert wird in stapelAnimieren(), am Ende von nachRender().
   Vorher hing .wechsel 460 ms an #list, waehrend der Aufbau selbst asynchron
   war: jeder Rebuild in diesem Fenster (Ansichtswechsel + storage.onChanged +
   lcDiskChanged feuern regelmaessig mehrfach) erzeugte neue Kinder, die alle
   erneut aufstiegen - die Staffel lief doppelt und uebereinander versetzt
   (LO 04.09.). Jetzt animiert genau EIN Aufbau je Wechsel; mehrfaches
   viewWechsel() vor dem Aufbau bleibt folgenlos. */
var wechselTimer = null, wechselOffen = false;
function viewWechsel() { wechselOffen = true; }

function stapelAnimieren() {
  if (!wechselOffen) return;
  var l = $('list');
  if (!l || !l.children.length) return;   // Aufbau laeuft noch (asynchrone Ansicht): Flag bleibt stehen
  wechselOffen = false;
  l.classList.remove('wechsel');
  void l.offsetWidth;          // Reflow erzwingen, sonst startet sie nicht neu
  l.classList.add('wechsel');
  /* Klasse wieder abraeumen, sobald die Staffel durch ist (--rise-dauer +
     13 * --rise-versatz, siehe :root in popup.html). Sonst bliebe sie kleben
     und die naechste Datenaktualisierung wuerde erneut aufsteigen lassen.
     Grosszuegig gerundet: zu frueh schneidet die letzten Zeilen ab, zu spaet
     kostet nichts ausser einem laengeren Fenster. */
  clearTimeout(wechselTimer);
  wechselTimer = setTimeout(function () { l.classList.remove('wechsel'); }, 1500);
}

function fortschritt(s) {
  var laeuft = !!(s && s.running), p = $('progress');
  var total = (s && s.total) || 0, done = (s && s.done) || 0;
  if (p) {
    p.classList.toggle('on', laeuft);
    p.classList.toggle('indet', laeuft && !total);
    p.style.width = laeuft && total ? Math.round((done / total) * 100) + '%' : '0';
  }
  document.body.classList.toggle('busy', laeuft);
  var t = $('ticker');
  if (t) {
    t.hidden = !laeuft;
    var dots = $('tickerDots');
    if (dots) {
      dots.textContent = '';
      var n = Math.min(40, total);
      for (var i = 0; i < n; i++) {
        var d = document.createElement('i');
        if (i < done) d.className = 'done'; else if (i === done) d.className = 'now';
        dots.appendChild(d);
      }
    }
    if ($('tickerText')) $('tickerText').textContent = laeuft ? (s.current || 'läuft …') : '';
  }
}

/* Zeigt, WORAUF sich "Erfassen" gerade bezieht, und stösst die Ansicht
   "Aktuell" an, sobald der Tab bekannt ist. */
function kontextZeigen(tab) {
  var vorher = letzterTab;
  letzterTab = tab || null;
  var host = '', id = tabAsin(tab);
  try { if (tab && tab.url) host = new URL(tab.url).hostname; } catch (e) { /* interne Seite */ }
  var plat = (host && window.LC && LC.detectPlatform) ? LC.detectPlatform(host) : null;
  var generic = !plat || plat.id === 'generic';

  var ctx = $('ctx');
  if (ctx) ctx.hidden = generic;
  if ($('grab')) $('grab').disabled = generic;

  if (!generic) {
    var titel = ((tab && tab.title) || '').replace(/\s*[:|]\s*Amazon\..*$/i, '').replace(/^Amazon\.[a-z.]+\s*[:|]\s*/i, '');
    if (titel.length > 70) titel = titel.slice(0, 69) + '…';
    if ($('ctxPlat')) {
      $('ctxPlat').textContent = PLAT_KURZ[plat.id] || String(plat.label || plat.id).slice(0, 3).toUpperCase();
      $('ctxPlat').title = plat.label || plat.id;
    }
    if ($('ctxTitel')) { $('ctxTitel').textContent = titel; $('ctxTitel').title = (tab && tab.title) || ''; }
    if ($('ctxId')) { $('ctxId').textContent = id; $('ctxId').hidden = !id; }
    if ($('ctxBild')) $('ctxBild').hidden = true;
    if ($('ctxPreis')) $('ctxPreis').textContent = '';
    if ($('ctxBsr')) $('ctxBsr').textContent = '';
    load().then(function (d) {
      var row = id ? zeileZurAsin(d.rows, id) : zeileZurUrl(d.rows, tab && tab.url);
      if (!row) return;
      var bild = httpBild(row);
      if ($('ctxBild') && bild) { $('ctxBild').src = bild; $('ctxBild').hidden = false; }
      if ($('ctxPreis') && row.preis != null) $('ctxPreis').textContent = fmtPreis(row.preis, row.waehrung);
      var bsr = bsrZahl(row.bsr);
      if ($('ctxBsr') && bsr) $('ctxBsr').textContent = 'BSR ' + nfDe(bsr);
    }).catch(function () { /* Kontext ist Beiwerk */ });
  }

  var neuUrl = tab && tab.url, altUrl = vorher && vorher.url;
  if (view === 'home' && (vorher === undefined || neuUrl !== altUrl)) {
    load().then(render).catch(function (e) { setStatus('Speicher nicht erreichbar: ' + e.message, 'err'); });
  }
}

// ------------------------------------------------------------- Verdrahtung

function verdrahteOberflaeche() {
  einstellungenVerdrahten();
  tastaturVerdrahten();
  menuesVerdrahten();
  watchVerdrahten();
  paletteVerdrahten();
  if ($('kwSegErnte')) $('kwSegErnte').addEventListener('click', function () { switchView('keywords'); });
  if ($('kwSegRaenge')) $('kwSegRaenge').addEventListener('click', function () { switchView('rank'); });
  if ($('ctxId')) $('ctxId').addEventListener('click', function () {
    var t = $('ctxId').textContent;
    if (!t) return;
    navigator.clipboard.writeText(t).then(function () { setStatus(t + ' kopiert.', 'ok'); }).catch(function () {});
  });
  /* Als eigenes Fenster bleibt das Popup offen, während man weitersurft -
     dann muss der Kontext dem aktiven Tab folgen. */
  if (typeof IST_FENSTER !== 'undefined' && IST_FENSTER && typeof aktivTab === 'function') {
    setInterval(function () {
      aktivTab(function (tabs) {
        var tab = tabs && tabs[0];
        var alt = letzterTab && letzterTab.url;
        if ((tab && tab.url) !== alt) kontextZeigen(tab || null);
      });
    }, 2000);
  }
}

function einstellungenOffen() { return !!($('settings') && !$('settings').hidden); }

function einstellungenZeigen(an) {
  if (!$('settings')) return;
  $('settings').hidden = !an;
  if ($('settingsBtn')) $('settingsBtn').setAttribute('aria-pressed', an ? 'true' : 'false');
}

function navMarkieren(link) {
  var nav = $('settingsNav');
  if (!nav || !link) return;
  var alle = nav.querySelectorAll('.navlink');
  for (var i = 0; i < alle.length; i++) alle[i].classList.toggle('active', alle[i] === link);
}

function einstellungenVerdrahten() {
  if ($('settingsBtn')) $('settingsBtn').addEventListener('click', function () { einstellungenZeigen(!einstellungenOffen()); });
  if ($('settingsClose')) $('settingsClose').addEventListener('click', function () { einstellungenZeigen(false); });

  var nav = $('settingsNav'), body = $('settingsBody');
  var spyRuhe = 0;
  if (nav) nav.addEventListener('click', function (ev) {
    var b = ev.target && ev.target.closest ? ev.target.closest('.navlink') : null;
    if (!b) return;
    var ziel = document.getElementById(b.getAttribute('data-target') || '');
    if (ziel && ziel.scrollIntoView) ziel.scrollIntoView({ block: 'start' });
    navMarkieren(b);
    // Der Klick bestimmt die Markierung; die Scroll-Spy darf sie 600 ms nicht überschreiben
    spyRuhe = Date.now() + 600;
  });

  /* ponytail: einfacher offsetTop-Vergleich statt IntersectionObserver - die
     Sektionen sind ein Dutzend, nicht tausend. */
  if (nav && body) body.addEventListener('scroll', function () {
    if (Date.now() < spyRuhe) return;
    var secs = body.querySelectorAll('section.sec'), oben = body.scrollTop + 8, treffer = null;
    for (var i = 0; i < secs.length; i++) if (secs[i].offsetTop <= oben) treffer = secs[i];
    // Am Ende der Seite gilt der letzte Abschnitt, auch wenn er nicht oben anliegt
    if (secs.length && body.scrollTop + body.clientHeight >= body.scrollHeight - 2) treffer = secs[secs.length - 1];
    if (!treffer && secs.length) treffer = secs[0];
    if (treffer) navMarkieren(nav.querySelector('.navlink[data-target="' + treffer.id + '"]'));
  });
}

function tastaturVerdrahten() {
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape') {
      if (PAL.offen) return paletteSchliessen();
      if (einstellungenOffen()) return einstellungenZeigen(false);
      var offen = document.querySelectorAll('details.menu[open]');
      for (var i = 0; i < offen.length; i++) offen[i].open = false;
      return;
    }
    var ziel = ev.target, tag = (ziel && ziel.tagName) || '';
    var imFeld = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || !!(ziel && ziel.isContentEditable);

    // Alt+Ziffer: ev.key ist auf manchen Layouts ein Sonderzeichen, deshalb auch ev.code.
    if (ev.altKey && !ev.ctrlKey && !ev.metaKey) {
      var v = ALT_VIEWS[ev.key] || ALT_VIEWS[String(ev.code || '').replace('Digit', '')];
      if (v) { ev.preventDefault(); switchView(v); }
      return;
    }
    if (ev.key === '/' && !imFeld && !ev.ctrlKey && !ev.metaKey) {
      ev.preventDefault();
      if ($('query')) $('query').focus();
    }
  });
}

function menuesVerdrahten() {
  document.addEventListener('click', function (ev) {
    var menus = document.querySelectorAll('details.menu');
    for (var i = 0; i < menus.length; i++) {
      if (!menus[i].open) continue;
      if (!menus[i].contains(ev.target)) { menus[i].open = false; continue; }
      // Knopf im Menü: erst dessen eigenen Handler laufen lassen, dann zuklappen -
      // ausser "kopieren" im Protokoll, das bleibt offen.
      if (ev.target.closest && ev.target.closest('button') && !ev.target.closest('#logCopy')) {
        (function (m) { setTimeout(function () { m.open = false; }, 0); })(menus[i]);
      }
    }
  });
}

function watchVerdrahten() {
  var feld = $('watchAdd');
  if ($('watchAddBtn')) $('watchAddBtn').addEventListener('click', function () { watchHinzufuegen(); });
  if (feld) feld.addEventListener('keydown', function (ev) {
    if (ev.key === 'Enter') { ev.preventDefault(); watchHinzufuegen(); }
  });
  if ($('watchCheck')) $('watchCheck').addEventListener('click', watchRecheck);
  if ($('watchPreise')) $('watchPreise').addEventListener('click', watchAllePruefen);
  /* Der Abbrechen-Knopf meldet sonst nur dem Worker; die Messung läuft aber
     hier im Fenster und braucht ihr eigenes Stopp-Signal. */
  if ($('abbrechen')) $('abbrechen').addEventListener('click', recheckStoppen);
}

function watchHinzufuegen(asinDirekt) {
  var feld = $('watchAdd');
  var asin = String(asinDirekt || (feld && feld.value) || '').trim().toUpperCase();
  if (!/^B0[A-Z0-9]{8}$/i.test(asin)) return setStatus('Keine gültige ASIN – erwartet wird B0 plus 8 Zeichen.', 'err');
  load().then(function (d) {
    var watch = d.watch || [];
    for (var i = 0; i < watch.length; i++) {
      if (watch[i].asin === asin) return setStatus(asin + ' ist bereits in der Beobachtung', 'warn');
    }
    var row = zeileZurAsin(d.rows, asin);
    return saveViele({
      watch: watch.concat([{ asin: asin, titel: row ? String(row.titel || '').slice(0, 80) : '',
        preis: row && row.preis != null ? Number(row.preis) : null, bsr: row ? bsrZahl(row.bsr) : null, ts: Date.now() }])
    }).then(function () {
      if (feld && !asinDirekt) feld.value = '';
      load().then(render);
      setStatus(asin + ' wird jetzt beobachtet.', 'ok');
    });
  }).catch(function (e) {
    setStatus('Speichern fehlgeschlagen: ' + ((e && e.message) || e), 'err');
  });
}

function watchAllePruefen() {
  load().then(function (d) {
    var asins = (d.watch || []).map(function (w) { return w.asin; });
    if (!asins.length) return setStatus('Nichts beobachtet – erst eine ASIN hinzufügen.', 'err');
    // Leere Plattformliste hiesse im Worker "alle" - dann laufen eBay/Otto ueberraschend los.
    var plats = checkedPlats().filter(function (p) { return p !== 'amazon' && p !== 'deubaxxl'; });
    var msg = { type: 'proCheck', asins: asins };
    if (plats.length) msg.platforms = plats;
    auftrag(msg, 'Prüfe ' + asins.length + ' beobachtete ASINs … Popup darf zugehen.');
    switchView('pro');
  }).catch(function (e) {
    setStatus('Speicher nicht erreichbar: ' + ((e && e.message) || e), 'err');
  });
}

/* ------------------------------------------------------- Recheck (Messung)

   Liest die Produktseiten der beobachteten ASINs neu aus und legt ALLES ab,
   was die Seite hergibt - der Sinn der Beobachtung ist, Wettbewerber über die
   Zeit zu kennen, nicht nur den eigenen Preis.
   Gespeichert wird je ASIN:
     hist:<ASIN>   Verlaufspunkt (über den Worker, damit Dedupe und Deckel greifen)
     wdata:<ASIN>  Vollprofil der Seite (Marke, Bewertung, Verkäufer, Maße …)
     watch         Kurzfelder für die Tabelle
     cal:<kat>     Kalibrier-Paar für den Verkaufsschätzer (BSR + Kaufzahl)
   Nach JEDER ASIN wird geschrieben: schließt das Popup mitten im Lauf, ist
   alles bis dahin gesichert. Abstand 1,2 s, damit Amazon nicht drosselt. */
var RECHECK = { laeuft: false, stop: false };
var KAUF_RE = /([\d.,]+\s*(?:Tsd\.|Tausend|k)?)\+?\s*mal\s+im\s+letzten\s+Monat\s+gekauft/i;

function kaufzahlAus(doc) {
  var n = doc.getElementById('pqv-bought-in-last-month') ||
    doc.querySelector('[id*="socialProofing" i], #social-proofing-faceout-title-tk_bought');
  var txt = (n && n.textContent) || '';
  if (!KAUF_RE.test(txt)) {
    var haupt = doc.getElementById('ppd') || doc.getElementById('centerCol');
    txt = (haupt && haupt.textContent) || '';
  }
  var m = txt.match(KAUF_RE);
  if (!m) return null;
  /* Der Tausender-Test darf NUR auf der Zahlengruppe laufen: gegen den ganzen
     Treffer geprüft traf das "k" in "gekauft" und machte aus "50+ Mal im
     letzten Monat gekauft" 50.000 (Live-Test 04.09.). Ein solcher Punkt wäre
     als Kalibrier-Paar in den Verkaufsschätzer gewandert. */
  var roh = m[1].replace(/\s/g, '');
  var tausend = /Tsd|Tausend|k/i.test(roh);
  var zahl = tausend ? parseFloat(roh.replace(',', '.')) * 1000
    : parseFloat(roh.replace(/\./g, '').replace(',', '.'));
  return isFinite(zahl) && zahl > 0 ? { zahl: Math.round(zahl), text: m[0].trim() } : null;
}

/* Erst anonym (Popup-Schalter „Messungen ohne Cookies"), sonst mit Session.
   Anonym misst die organische Sicht ohne Login und Standort. */
function seiteHolen(asin, ohneCookies) {
  var url = 'https://www.amazon.de/dp/' + encodeURIComponent(asin);
  var zug = function (modus) {
    return fetch(url, { credentials: modus, headers: { 'Accept-Language': 'de-DE,de;q=0.9' } })
      .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); });
  };
  var p = ohneCookies ? zug('omit').catch(function () { return zug('include'); }) : zug('include');
  return p.then(function (html) {
    if (/validateCaptcha|opfcaptcha/i.test(html)) throw new Error('Amazon verlangt ein Captcha – kurz warten');
    var doc = new DOMParser().parseFromString(html, 'text/html');
    if (!doc.getElementById('productTitle')) throw new Error('Seite ohne Produkttitel (Layout oder Sperre)');
    return doc;
  });
}

function profilAus(doc, asin) {
  var r = (window.LC && LC.extract) ? (LC.extract(doc, 'https://www.amazon.de/dp/' + asin) || {}) : {};
  var kauf = kaufzahlAus(doc);
  var p = {
    titel: r.titel || '', marke: r.marke || '', ean: r.ean || '', sku: r.sku || '',
    preis: r.preis == null ? null : Number(r.preis), waehrung: r.waehrung || 'EUR',
    uvp: r.uvp == null ? null : Number(r.uvp), rabatt_prozent: r.rabatt_prozent || null,
    bsr: bsrZahl(r.bsr), bsr_kategorie: r.bsr_kategorie || '',
    bsr_unter: bsrZahl(r.bsr_unter), bsr_unter_kategorie: r.bsr_unter_kategorie || '',
    bsr_text: r.bsr_text || '', kategorie: r.kategorie || '',
    bewertung: r.bewertung == null ? null : Number(r.bewertung),
    anzahl_bewertungen: r.anzahl_bewertungen == null ? null : Number(r.anzahl_bewertungen),
    verkaeufer: r.verkaeufer || '', buybox: r.buybox || '', andere_angebote: r.andere_angebote || '',
    verfuegbarkeit: r.verfuegbarkeit || '', lieferzeit: r.lieferzeit || '', versand: r.versand || '',
    varianten: r.varianten || null, aplus: r.aplus || '',
    bilder_anzahl: r.bilder_anzahl || null, bullets_anzahl: r.bullets_anzahl || null,
    titel_laenge: r.titel_laenge || null, beschreibung_laenge: r.beschreibung_laenge || null,
    eig_material: r.eig_material || '', eig_farbe: r.eig_farbe || '', eig_masse: r.eig_masse || '',
    eig_gewicht: r.eig_gewicht || '', eig_hersteller: r.eig_hersteller || '', eig_modell: r.eig_modell || '',
    kaufzahl: kauf ? kauf.zahl : null, kaufzahl_text: kauf ? kauf.text : '',
    ts: Date.now()
  };
  // "Andere Verkäufer auf Amazon: 3" -> Zahl, damit der Verlauf sie führen kann
  var an = String(r.andere_angebote || '').match(/\d+/);
  p.anbieter_anzahl = an ? Number(an[0]) : null;
  // "Im Angebot seit" steht in der Attributtabelle, extract fasst es nicht
  var seit = '';
  Array.prototype.forEach.call(doc.querySelectorAll('th, span.a-text-bold'), function (n) {
    if (seit || !/Im Angebot .*seit|Date First Available/i.test(n.textContent)) return;
    var v = n.nextElementSibling, m = ((v && v.textContent) || '').match(/(\d{4})/);
    if (m) seit = m[1];
  });
  p.seit = seit;
  return p;
}

function recheckStoppen() { RECHECK.stop = true; }

function watchRecheck() {
  if (RECHECK.laeuft) return setStatus('Es läuft bereits eine Messung.', 'warn');
  load().then(function (d) {
    var watch = (d.watch || []).slice();
    if (!watch.length) return setStatus('Nichts beobachtet – erst eine ASIN hinzufügen.', 'err');
    return new Promise(function (res) {
      chrome.storage.local.get('lcNoCookies', function (s) { res(!s || s.lcNoCookies !== false); });
    }).then(function (ohneCookies) {
      RECHECK.laeuft = true; RECHECK.stop = false;
      laufZustand(true);
      if ($('abbrechen')) $('abbrechen').hidden = false;
      var i = 0, ok = 0, fehler = [];

      var fertig = function () {
        RECHECK.laeuft = false;
        laufZustand(false);
        fortschritt({ running: false });
        setStatus(ok + ' von ' + watch.length + ' gemessen' +
          (fehler.length ? ' · ' + fehler.length + ' Fehler: ' + fehler[0] : '') +
          (RECHECK.stop ? ' (abgebrochen)' : ''), fehler.length ? 'warn' : 'ok');
        load().then(render).catch(function () {});
      };

      var naechste = function () {
        if (RECHECK.stop || i >= watch.length) return fertig();
        var w = watch[i];
        fortschritt({ running: true, done: i, total: watch.length, current: w.asin + ' wird gelesen …' });
        seiteHolen(w.asin, ohneCookies).then(function (doc) {
          var p = profilAus(doc, w.asin);
          return speichereMessung(w.asin, p).then(function () { ok++; });
        }).catch(function (e) {
          fehler.push(w.asin + ': ' + ((e && e.message) || e));
        }).then(function () {
          i++;
          if (RECHECK.stop || i >= watch.length) return fertig();
          setTimeout(naechste, 1200);
        });
      };
      naechste();
    });
  }).catch(function (e) {
    RECHECK.laeuft = false;
    laufZustand(false);
    setStatus('Messung nicht gestartet: ' + ((e && e.message) || e), 'err');
  });
}

/* Ein Messergebnis vollständig ablegen. Der Verlaufspunkt geht über den Worker
   (histSample), damit dessen Dedupe, Stundenraster und Deckel greifen - ein
   Direktschreiben hatte das früher umgangen. */
function speichereMessung(asin, p) {
  var neu = {};
  neu['wdata:' + asin] = p;
  return saveViele(neu).then(function () {
    /* NUR 'watch' lesen, nicht load(): das zieht Keywords und Belege mit -
       bei 40 ASINs wären das 40 Durchläufe über den ganzen Bestand. */
    return storeGet(['watch']).then(function (d) {
      var watch = (d.watch || []).map(function (w) {
        if (w.asin !== asin) return w;
        return { asin: asin, titel: p.titel ? p.titel.slice(0, 80) : w.titel,
          preis: p.preis != null ? p.preis : w.preis,
          bsr: p.bsr != null ? p.bsr : w.bsr, ts: Date.now() };
      });
      return saveViele({ watch: watch });
    });
  }).then(function () {
    return new Promise(function (res) {
      try {
        chrome.runtime.sendMessage({
          type: 'histSample', asin: asin,
          sample: { preis: p.preis, bsr: p.bsr, buybox: p.buybox || null,
            anbieter: p.anbieter_anzahl, angebot_min: null }
        }, function () { void chrome.runtime.lastError; res(); });
      } catch (e) { res(); }
    });
  }).then(function () {
    // Kalibrier-Paar für den Verkaufsschätzer - kostenlos, die Seite ist schon da
    try {
      var kat = String(p.bsr_kategorie || '').toLowerCase().trim();
      if (window.LC && LC.sales && p.kaufzahl > 0 && p.bsr > 0 && kat) {
        return LC.sales.merken(kat, asin, p.bsr, p.kaufzahl);
      }
    } catch (e) { /* Lernen darf die Messung nie stoppen */ }
  });
}

// --------------------------------------------------------- Kommandopalette

/* EIN Feld für alles: Suchen, Keywords, Buybox, Beobachten. Die Aktionen
   richten sich nach dem erkannten Typ (EAN / ASIN / Text). popup.js hängt an
   dasselbe Feld einen Enter-Handler (Suche) - unser Listener läuft in der
   Capture-Phase, also vorher, und stoppt ihn, wenn die Palette übernimmt. */
var PAL = { offen: false, items: [], aktiv: 0 };

function paletteVerdrahten() {
  var q = $('query'), pal = $('palette');
  if (!q || !pal) return;
  q.addEventListener('input', function () { paletteBauen(q.value); });
  q.addEventListener('focus', function () { if (q.value.trim()) paletteBauen(q.value); });
  q.addEventListener('click', function () { if (!PAL.offen) paletteBauen(q.value); });
  q.addEventListener('keydown', function (ev) {
    if (!PAL.offen) {
      if (ev.key === 'ArrowDown') { ev.preventDefault(); paletteBauen(q.value); }
      return;
    }
    if (ev.key === 'Escape') { ev.preventDefault(); ev.stopImmediatePropagation(); paletteSchliessen(); return; }
    if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') {
      ev.preventDefault(); ev.stopImmediatePropagation();
      paletteBewegen(ev.key === 'ArrowDown' ? 1 : -1);
      return;
    }
    if (ev.key === 'Enter') {
      // Leeres Feld: popup.js übernimmt den Platzhalter-Vorschlag - nicht abfangen.
      if (!q.value.trim()) return;
      var it = PAL.items[PAL.aktiv];
      if (it && it.fn) { ev.preventDefault(); ev.stopImmediatePropagation(); paletteSchliessen(); it.fn(); }
    }
  }, true);
  document.addEventListener('click', function (ev) {
    if (!PAL.offen) return;
    var t = ev.target;
    if (t && t.closest && (t.closest('#cmd') || t.closest('#palette'))) return;
    paletteSchliessen();
  });
}

function paletteSchliessen() {
  var pal = $('palette');
  if (pal) pal.hidden = true;
  PAL.offen = false;
}

function paletteBewegen(d) {
  var n = PAL.items.length;
  if (!n) return;
  PAL.aktiv = (PAL.aktiv + d + n) % n;
  paletteMarkieren();
}

function paletteMarkieren() {
  PAL.items.forEach(function (it, i) {
    it.el.classList.toggle('active', i === PAL.aktiv);
    if (i === PAL.aktiv && it.el.scrollIntoView) it.el.scrollIntoView({ block: 'nearest' });
  });
}

function paletteSektion(pal, text) {
  pal.appendChild(el('div', 'pal-sec', text));
}

function paletteEintrag(pal, icon, label, sub, kbd, fn) {
  var b = el(fn ? 'button' : 'div', 'pal-item');
  if (fn) b.type = 'button';
  b.appendChild(el('span', 'pal-icon', icon));
  var txt = el('span', 'pal-txt', label);
  if (sub) txt.appendChild(el('span', 'pal-sub', sub));
  b.appendChild(txt);
  if (kbd) b.appendChild(el('kbd', '', kbd));
  if (fn) {
    b.addEventListener('click', function () { paletteSchliessen(); fn(); });
    b.addEventListener('mouseenter', function () { PAL.aktiv = PAL.items.map(function (x) { return x.el; }).indexOf(b); paletteMarkieren(); });
    PAL.items.push({ el: b, fn: fn });
  }
  pal.appendChild(b);
}

function ernte(seed, tief) {
  if ($('kwSeed')) $('kwSeed').value = seed;
  if ($('kwDeep')) $('kwDeep').checked = !!tief;
  if ($('kwRun')) $('kwRun').click();
}

/* ---------- Befehlsverzeichnis (JOURNEY.md, Palette-Spec) ----------
   Die Kommandozeile erreicht JEDE Funktion des Popups, nicht mehr nur die
   acht, die aus der Eingabe folgen. Ein Eintrag: [Gruppe, Icon, Label, Sub,
   Kuerzel, Aktion, Zustandsgeber?]. Der Zustandsgeber liefert bei Schaltern
   "an"/"aus" — ohne den schaltet der Nutzer blind.
   Bewusst NICHT hier: die Schieberegler (ein stufenloser Wert laesst sich
   nicht als Treffer waehlen — es gibt stattdessen "Regler oeffnen") und die
   Datei-Auswahlfelder, die einen Browser-Dialog brauchen. */
function klick(id) { return function () { var e = $(id); if (e) e.click(); }; }
function schalter(id) {
  return function () { var e = $(id); return e ? (e.checked ? 'an' : 'aus') : ''; };
}
function umlegen(id) {
  return function () {
    var e = $(id); if (!e) return;
    e.checked = !e.checked;
    e.dispatchEvent(new Event('change', { bubbles: true }));
  };
}

function befehlsListe() {
  var b = [];
  var add = function (g, ic, lb, sub, kbd, fn, zst) {
    if (fn) b.push({ g: g, ic: ic, lb: lb, sub: sub || '', kbd: kbd || '', fn: fn, zst: zst || null });
  };

  add('Navigation', '◈', 'Aktuell', 'Dossier des offenen Produkts', 'Alt+1', klick('viewHome'));
  add('Navigation', '≡', 'Listings', 'alles Erfasste', 'Alt+2', klick('viewRows'));
  add('Navigation', '⌕', 'Suche', 'Treffer der Preisjagd', 'Alt+3', klick('viewMatches'));
  add('Navigation', '◇', 'Keywords', 'geerntete Suchbegriffe', 'Alt+4', klick('viewKeywords'));
  add('Navigation', '◎', 'Preise', 'Buybox und Anbieter', 'Alt+5', klick('viewPro'));
  add('Navigation', '☆', 'Beobachtung', 'stündlich gemessene Artikel', 'Alt+6', klick('viewWatch'));
  add('Navigation', '⇅', 'Ränge', 'Rangverlauf je Keyword', '',
    function () { if (typeof switchView === 'function') switchView('rank'); });
  add('Navigation', '⚙', 'Einstellungen öffnen', '', '', klick('settingsBtn'));
  add('Navigation', '⧉', 'Als eigenes Fenster öffnen', '', '', klick('alsFenster'));

  add('Läufe', '↓', 'Offenen Tab erfassen', 'Listing der aktiven Seite übernehmen', '', klick('grab'));
  add('Läufe', '⇓', 'Alle Tabs erfassen', 'jede passende offene Seite', '', klick('grabAll'));
  add('Läufe', '⌕', 'Preisjagd starten', 'denselben Artikel auf allen Plattformen suchen', '', klick('search'));
  add('Läufe', '⧉', 'Nur Suchseiten öffnen', 'Tabs im Hintergrund, nichts erfassen', '', klick('openTabs'));
  add('Läufe', '◎', 'Preisprüfung starten', 'Buybox und günstigere Anbieter', '',
    function () { if (typeof proCheckStarten === 'function') proCheckStarten(); else klick('proRun')(); });
  add('Läufe', '≡', 'Keywords ernten – schnell', 'nur Vorschläge, kein Rang', '',
    function () { var s = $('kwSeed'); ernte((s && s.value) || '', false); });
  add('Läufe', '≣', 'Keywords ernten – tief', 'zusätzlich a–z und Rangmessung', '',
    function () { var s = $('kwSeed'); ernte((s && s.value) || '', true); });
  add('Läufe', '⇅', 'Ränge messen', 'Position auf Seite 1 prüfen', '', klick('kwSegRaenge'));
  add('Läufe', '☆', 'Alle beobachteten prüfen', '', '', klick('watchCheck'));
  add('Läufe', '€', 'Preise aller beobachteten prüfen', '', '', klick('watchPreise'));
  add('Läufe', '✕', 'Laufenden Vorgang abbrechen', 'stoppt den aktiven Lauf', '', klick('abbrechen'));

  add('Daten', '↗', 'Export', 'als Datei sichern', '', klick('export'));
  add('Daten', '↗', 'Export für ChatGPT', 'Markdown mit Prompt', '', klick('exportMd'));
  add('Daten', '↙', 'Import', 'Datei einlesen', '', klick('import'));
  add('Daten', '☰', 'Protokoll öffnen', 'die letzten Läufe', '',
    function () { var l = $('logbox'); if (l) { l.open = true; l.scrollIntoView({ block: 'nearest' }); } });
  add('Daten', '⧉', 'Protokoll kopieren', '', '', klick('logCopy'));
  add('Daten', '⌫', 'Liste leeren', 'Rückfrage folgt', '', klick('clear'));

  add('Sicherung', '⛁', 'Sicherung schreiben', '', '', klick('backupExport'));
  add('Sicherung', '⛃', 'Sicherung einlesen', '', '', klick('backupImport'));
  add('Sicherung', '#', 'Sicherung zählen', 'wie viel liegt gespeichert', '', klick('backupStats'));
  add('Sicherung', '⌂', 'Sicherungsordner wählen', '', '', klick('autoBackupOrdner'));
  add('Sicherung', '⤓', 'Jetzt sichern', '', '', klick('autoBackupJetzt'));
  add('Sicherung', '⟳', 'Automatisch sichern', 'stündlich in den Ordner', '',
    umlegen('autoBackupAn'), schalter('autoBackupAn'));

  add('Beobachtung', '☆', 'ASIN beobachten', 'Preis, BSR und Buybox stündlich', '',
    function () { var f = $('watchAdd'), q = $('query'); if (f && q && q.value.trim()) f.value = q.value.trim(); klick('watchAddBtn')(); });

  add('Einstellungen', '⛨', 'Messungen ohne Cookies', 'anonym messen, ohne Login', '',
    umlegen('noCookies'), schalter('noCookies'));
  add('Einstellungen', '↯', 'Schätzer lernt mit', 'Kaufzahlen als Stützpunkte sammeln', '',
    umlegen('autoLearn'), schalter('autoLearn'));
  add('Einstellungen', '⟲', 'Nach Erfassen vergleichen', '', '',
    umlegen('autoCompare'), schalter('autoCompare'));
  add('Einstellungen', '⟳', 'Auto-Recherche', '', '',
    umlegen('autoResearch'), schalter('autoResearch'));
  add('Einstellungen', 'H', 'Helium 10 nutzen', 'eigenes Konto, eigene Grenzen', '',
    umlegen('h10Enabled'), schalter('h10Enabled'));
  add('Einstellungen', 'P', 'Helium 10 Platinum', 'nur mit passendem Plan', '',
    umlegen('h10Platinum'), schalter('h10Platinum'));
  add('Einstellungen', '?', 'Helium-10-Diagnose', 'Konto und Plan prüfen', '', klick('h10Diag'));

  add('Schätzer', '↗', 'Kalibrierung exportieren', 'in die Zwischenablage', '', klick('salesCalExport'));
  add('Schätzer', '↙', 'Kalibrierung importieren', '', '', klick('salesCalImportBtn'));
  add('Schätzer', '↙', 'Brand-Analytics-CSV einlesen', '', '', klick('brandCsvImport'));
  add('Schätzer', '⌫', 'Brand-Analytics leeren', '', '', klick('brandCsvClear'));

  add('Darstellung', '◐', 'Darstellung öffnen', 'Dark-Mode- und Bild-Regler', '', klick('settingsBtn'));

  return b;
}

/* Filtert das Verzeichnis: Treffer bei Label, Untertitel oder Gruppe. */
function befehleFiltern(q) {
  var n = q.toLowerCase();
  return befehlsListe().filter(function (c) {
    return (c.lb + ' ' + c.sub + ' ' + c.g).toLowerCase().indexOf(n) > -1;
  });
}

/* Reiht gefilterte Befehle gruppenweise mit Zwischenüberschrift ein. */
function befehleEinreihen(pal, liste, deckel) {
  var gruppen = [], nach = {};
  liste.forEach(function (c) {
    if (!nach[c.g]) { nach[c.g] = []; gruppen.push(c.g); }
    nach[c.g].push(c);
  });
  var gezeigt = 0;
  gruppen.forEach(function (g) {
    if (deckel && gezeigt >= deckel) return;
    paletteSektion(pal, g + ' · ' + nach[g].length);
    nach[g].forEach(function (c) {
      if (deckel && gezeigt >= deckel) return;
      gezeigt++;
      var sub = c.sub;
      if (c.zst) { var z = c.zst(); if (z) sub = (sub ? sub + ' · ' : '') + z; }
      paletteEintrag(pal, c.ic, c.lb, sub, c.kbd, c.fn);
    });
  });
  return gezeigt;
}

function paletteBauen(text) {
  var pal = $('palette'), qh = $('qhint');
  if (!pal) return;
  var q = String(text || '').trim();
  pal.textContent = '';
  PAL.items = []; PAL.aktiv = 0;

  if (!q) {
    if (qh) qh.textContent = '';
    var hist = Array.prototype.map.call(document.querySelectorAll('#suchHistorie option'), function (o) { return o.value; })
      .filter(Boolean).slice(0, 5);
    if (hist.length) {
      paletteSektion(pal, 'Zuletzt gesucht');
      hist.forEach(function (h) {
        paletteEintrag(pal, '↺', h, '', '', function () {
          if ($('query')) { $('query').value = h; $('query').focus(); }
          paletteBauen(h);
        });
      });
    }
    paletteSektion(pal, 'Tastatur');
    paletteEintrag(pal, '⌥', 'Ansichten wechseln', 'Aktuell, Listings, Suche, Keywords, Preise, Beobachtung', 'Alt+1 … 6', null);
    paletteEintrag(pal, '/', 'Kommandozeile', 'von überall im Fenster', '/', null);
    paletteEintrag(pal, '⎋', 'Schließen', 'Palette, Einstellungen, Menüs', 'Esc', null);
    /* Bei leerem Feld nur ein Auszug — die volle Liste erschlaegt sonst den
       Platzhalter-Vorschlag, den popup.js hier setzen darf. */
    befehleEinreihen(pal, befehlsListe(), 12);
  } else {
    var typ = (window.LC && LC.search && LC.search.detectQueryType) ? LC.search.detectQueryType(q) : 'sku';
    var label = typ === 'ean' ? 'EAN' : (typ === 'asin' ? 'ASIN' : 'Text');
    if (qh) { qh.textContent = ''; qh.appendChild(el('b', '', label)); }
    paletteSektion(pal, 'Erkannt: ' + label);
    var plats = (typeof checkedPlats === 'function' ? checkedPlats() : []);
    var platText = plats.length ? plats.join(', ') : 'keine Plattform angehakt';
    if (typ === 'asin') {
      var asin = q.toUpperCase();
      paletteEintrag(pal, '◎', 'Buybox prüfen', 'Angebotslage und günstigere Anbieter zu ' + asin, 'Enter', function () { proCheckStarten(); });
      paletteEintrag(pal, '☆', 'Beobachten', 'Preis, BSR und Buybox stündlich messen', '', function () { watchHinzufuegen(asin); switchView('watch'); });
      paletteEintrag(pal, '⌕', 'Suchen & sammeln', 'auf ' + platText, '', function () { if ($('search')) $('search').click(); });
      paletteEintrag(pal, '↗', 'Auf Amazon öffnen', 'amazon.de/dp/' + asin, '', function () { neuerTab('https://www.amazon.de/dp/' + asin); });
    } else {
      paletteEintrag(pal, '⌕', 'Suchen & sammeln', 'auf ' + platText, 'Enter', function () { if ($('search')) $('search').click(); });
      paletteEintrag(pal, '⧉', 'Nur Tabs öffnen', 'Suchseiten der Plattformen im Hintergrund', '', function () { if ($('openTabs')) $('openTabs').click(); });
      paletteEintrag(pal, '≡', 'Keywords ernten – schnell', 'Autocomplete-Ränge zu „' + q + '“', '', function () { ernte(q, false); });
      paletteEintrag(pal, '≣', 'Keywords ernten – tief', 'zusätzlich a–z und SERP-Messung', '', function () { ernte(q, true); });
    }
    /* Danach die passenden Befehle aus dem Verzeichnis — so findet „export",
       „abbrechen" oder „cookies" denselben Weg wie eine ASIN. */
    befehleEinreihen(pal, befehleFiltern(q));
  }
  if (!pal.childNodes.length) { paletteSchliessen(); return; }
  paletteMarkieren();
  pal.hidden = false;
  PAL.offen = true;
}

/* ---------- Oeffnungsmoment (DESIGN.md „Nachtkontor") ----------
   Das Grundlinien-Lineal zeichnet sich von oben nach unten, die Zeilen
   setzen sich beim Passieren auf ihre Grundlinie. Laeuft EINMAL je
   Popup-Oeffnung, danach nie wieder in dieser Sitzung — eine reine
   Datenaktualisierung setzt kein viewWechsel() und ruehrt sich nicht.
   Unter prefers-reduced-motion steht alles sofort (CSS regelt das). */
document.body.classList.add('intro');
setTimeout(function () { document.body.classList.remove('intro'); }, 700);
