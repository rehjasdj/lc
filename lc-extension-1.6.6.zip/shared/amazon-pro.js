/* Listing Checker - Produktbetreuer-Checks fuer Amazon (Helium-Style, nur besser).
   Laeuft im Seitenkontext (Content-Script / Playwright page.evaluate), weil die
   Fetches Amazons eigene Session nutzen - kein Captcha, keine CORS-Probleme.

   Reverse-engineerte Quellen:
   - AOD-Ajax (/gp/product/ajax?...aodAjaxMain): alle Anbieter mit Preis/Versand,
     das "Weitere Angebote"-Panel als rohes HTML-Fragment.
   - dimensionValuesDisplayData (Inline-JS): alle Varianten-ASINs.
   - A+ Content: #aplus im HTML; Varianten werden per In-Page-Fetch geprueft.

   Setzt shared/extract.js voraus (globalThis.LC). */
(function () {
  'use strict';

  var LC = globalThis.LC || (typeof window !== 'undefined' ? window.LC : null);
  if (!LC) throw new Error('shared/extract.js muss vor shared/amazon-pro.js geladen werden');

  var clean = function (s) {
    return s == null ? '' : String(s).replace(/\s+/g, ' ').trim();
  };

  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

  // ------------------------------------------------------------ ASIN + Varianten

  function getAsin(doc, url) {
    var m = (url || '').match(/\/(?:dp|gp\/product)\/([A-Z0-9]{10})/i);
    if (m) return m[1].toUpperCase();
    var el = doc.querySelector('#ASIN, input[name="ASIN"]');
    return el && el.value ? String(el.value).toUpperCase() : '';
  }

  function variantAsins(doc, ownAsin) {
    var out = [];
    var seen = Object.create(null);
    var push = function (a) {
      a = String(a || '').toUpperCase();
      if (/^[A-Z0-9]{10}$/.test(a) && a !== ownAsin && !seen[a]) { seen[a] = 1; out.push(a); }
    };

    var lis = doc.querySelectorAll('#twister li[data-asin], #twister_feature_div li[data-asin], #tp-inline-twister-dim-values-container li[data-asin]');
    for (var i = 0; i < lis.length; i++) push(lis[i].getAttribute('data-asin'));

    // Fallback: Inline-JS "dimensionValuesDisplayData": {"B0XXXXXXXX": [...], ...}
    if (!out.length) {
      var scripts = doc.querySelectorAll('script');
      for (var j = 0; j < scripts.length; j++) {
        var t = scripts[j].textContent || '';
        var pos = t.indexOf('dimensionValuesDisplayData');
        if (pos === -1) continue;
        var chunk = t.slice(pos, pos + 5000);
        var ids = chunk.match(/"[A-Z0-9]{10}"\s*:/g) || [];
        for (var k = 0; k < ids.length; k++) push(ids[k].replace(/["\s:]/g, ''));
        break;
      }
    }
    return out;
  }

  // ------------------------------------------------------------ A+ Content

  function hasAplus(doc) {
    // gleiche Selektoren wie extract.js (Brand Story allein ist dort kein A+) - eine Wahrheit
    var el = doc.querySelector('#aplus, #aplus_feature_div');
    if (!el) return false;
    // <style>/<script> im A+-Container sind kein Inhalt - >40 Zeichen CSS
    // machten sonst aus einem leeren Modul ein falsches "A+" (Review 31.08.)
    var k = el.cloneNode(true);
    Array.prototype.forEach.call(k.querySelectorAll('style,script,[data-lc]'), function (n) { n.parentNode.removeChild(n); });
    return clean(k.textContent).length > 40;
  }

  // String-Check fuer gefetchtes Varianten-HTML (DOM-Parse waere Overkill).
  function htmlHasAplus(html) {
    return /id="aplus"|class="aplus-v2|aplus-module/.test(html || '');
  }

  // ------------------------------------------------------------ AOD (alle Anbieter)

  // Hoechste Option eines Mengen-Dropdowns (z.B. #quantity) - NUR lesen, nie aendern.
  // Selektor tolerant (id/name enthaelt "quantity"): deckt Buybox- wie AOD-Angebots-Dropdowns ab.
  function maxQtyFromSelect(root) {
    var sel = root && root.querySelector ? root.querySelector('select#quantity, select[id*="quantity" i], select[name*="quantity" i]') : null;
    if (!sel || !sel.options) return null;
    var max = null;
    for (var i = 0; i < sel.options.length; i++) {
      var n = parseInt(sel.options[i].value || sel.options[i].textContent, 10);
      if (isFinite(n) && (max == null || n > max)) max = n;
    }
    return max;
  }

  function parseOfferEl(el, pinned) {
    var preis = LC.parseNum(clean((el.querySelector('.a-price .a-offscreen') || {}).textContent || ''));
    var seller = clean((el.querySelector('[id^="aod-offer-soldBy"] a, .aod-offer-soldBy a') || {}).textContent || '');
    if (!seller) {
      var sb = el.querySelector('[id^="aod-offer-soldBy"] .a-col-right, .aod-offer-soldBy');
      seller = clean(sb ? sb.textContent : '').replace(/^Verkäufer\s*/i, '');
    }
    var zustand = clean((el.querySelector('[id^="aod-offer-heading"], .aod-offer-heading') || {}).textContent || '');
    if (preis == null && !seller) return null;
    // Versandart, Prime, Lieferdatum, Verkaeuferbewertung - fuer die Buybox-Diagnose (features/dp-buybox.js).
    // Selektoren tolerant: Amazon vergibt die aod-Ids mehrfach und aendert Klassen; fehlt etwas, bleibt das Feld leer.
    var sfEl = el.querySelector('[id^="aod-offer-shipsFrom"] .a-col-right, [id^="aod-offer-shipsFrom"], .aod-offer-shipsFrom');
    var versender = clean(sfEl ? sfEl.textContent : '').replace(/^(Versand durch|Versand von|Ships from)\s*/i, '');
    var prime = !!el.querySelector('.a-icon-prime, i[aria-label*="Prime"], .aod-prime-badge');
    var fba = versender ? /^amazon/i.test(versender) : (prime ? true : null);
    var ratEl = el.querySelector('[id^="aod-offer-seller-rating"], .aod-offer-seller-rating, [id^="aod-offer-soldBy"] .a-icon-alt');
    var bewertung = clean(ratEl ? ratEl.textContent : '');
    var lfEl = el.querySelector('[data-csa-c-delivery-time]');
    var lieferung = lfEl ? clean(lfEl.getAttribute('data-csa-c-delivery-time')) :
      clean((el.querySelector('.aod-delivery-promise, [id^="aod-offer-delivery"], [id^="mir-layout-DELIVERY_BLOCK"] .a-text-bold') || {}).textContent || '').slice(0, 60);
    var out = { verkaeufer: seller, preis: preis, zustand: zustand, buybox: !!pinned,
             versender: versender, fba: fba, prime: prime, bewertung: bewertung, lieferung: lieferung };
    // Bestand: kein eigener Selektor bekannt - Text-Regex ueber das ganze Angebot reicht
    // ("Nur noch X auf Lager" / "Nur noch X vorrätig"). Kein Treffer -> Feld weglassen.
    var bestandM = clean(el.textContent).match(/nur noch\s+(\d+)/i);
    if (bestandM) out.bestand = parseInt(bestandM[1], 10);
    var maxMenge = maxQtyFromSelect(el);
    if (maxMenge != null) out.maxMenge = maxMenge;
    return out;
  }

  function fetchOffers(asin, origin) {
    /* Seit Aug. 2026: /gp/product/ajax?...&experienceId=aodAjaxMain liefert 404 ("Seite
       wurde nicht gefunden"). Amazons all-offers-display-url-builder baut jetzt
       GXA_UPDATED_AOD_URL = /gp/product/ajax/aodAjaxMain + /ref=<marker> + ?asin=&pc=dp
       (ohne experienceId) - verifiziert 28.08.2026 gegen amazon.de (200, aod-pinned-offer). */
    var url = origin + '/gp/product/ajax/aodAjaxMain/ref=aod_f_msf?asin=' + encodeURIComponent(asin) + '&pc=dp';
    return fetch(url, { credentials: 'include' }).then(function (r) {
      if (!r.ok) throw new Error('AOD HTTP ' + r.status);
      return r.text();
    }).then(function (html) {
      var dp = new DOMParser().parseFromString(html, 'text/html');
      // HTTP 200 ohne AOD-Markup = Captcha/Consent/Layoutwechsel -> Fehler, sonst wird "0 Anbieter" 15 min gecacht
      if (!dp.querySelector('#aod-pinned-offer, #aod-offer-list, #aod-total-offer-count, div[id="aod-offer"]')) {
        throw new Error(/validateCaptcha|opfcaptcha/i.test(html) ? 'Captcha' : 'AOD-Layout unbekannt');
      }
      var offers = [];
      var pinned = dp.querySelector('#aod-pinned-offer');
      if (pinned) {
        var p = parseOfferEl(pinned, true);
        if (p) offers.push(p);
      }
      // Amazon vergibt die id mehrfach - querySelectorAll findet trotzdem alle.
      var rest = dp.querySelectorAll('div[id="aod-offer"], #aod-offer-list .aod-offer');
      for (var i = 0; i < rest.length; i++) {
        var o = parseOfferEl(rest[i], false);
        if (o) offers.push(o);
      }
      var countEl = dp.querySelector('#aod-total-offer-count');
      var count = countEl ? parseInt(countEl.getAttribute('value') || countEl.value || '', 10) : NaN;
      return { offers: offers, anzahl: isFinite(count) && count > 0 ? count : offers.length };
    });
  }

  // ------------------------------------------------------------ Buybox (On-Page)

  function buyboxOnPage(doc) {
    // "Alle Kaufoptionen ansehen" ohne Kaufblock = keine gewonnene Buybox.
    // Selektoren und Reihenfolge identisch zu extract.js (Buybox-Block) -
    // zwei Wahrheiten ueber dieselbe Frage waeren schlimmer als eine Doppelung.
    // "Derzeit nicht verfuegbar" = ausverkauft, NICHT unterdrueckt (sonst Buybox-Verlust im Verlauf).
    var seeAll = doc.querySelector('#buybox-see-all-buying-choices, a[href*="/gp/offer-listing/"], [data-action="show-all-offers-display"]');
    var kaufen = doc.querySelector('#add-to-cart-button, #buy-now-button, input#add-to-cart-button');
    var preisBlock = doc.querySelector('#corePrice_feature_div, #corePriceDisplay_desktop_feature_div');
    var verkaeufer = clean((doc.querySelector('#sellerProfileTriggerId, #merchant-info a') || {}).textContent || '');
    var avail = clean((doc.querySelector('#availability') || {}).textContent || '');

    var status;
    if (kaufen) status = 'ja';
    else if (/nicht verf|niet beschikbaar|unavailable/i.test(avail)) status = 'nicht verfuegbar';
    else if (seeAll || !preisBlock) status = 'UNTERDRUECKT';
    else status = 'unklar';

    /* Die Einzelbelege wandern mit in den Export: im Support-Case muss
       nachvollziehbar sein, WORAN die Unterdrueckung erkannt wurde. */
    return {
      status: status,
      verkaeufer: verkaeufer,
      hat_kaufblock: !!kaufen,
      hat_preisblock: !!preisBlock,
      hat_alle_kaufoptionen: !!seeAll
    };
  }

  // ------------------------------------------------------------ Varianten-A+-Check

  /* Geschwister-ASINs im Seitenkontext nachladen und pruefen, ob sie A+ haben.
     Gegenueber dem Tab-Weg im Background: kein Tab-Aufbau, keine Hydration-Wartezeit.
     Reicht hier, weil A+ serverseitig im HTML steht und kein JS braucht.
     Sequenziell mit Pause - parallele Fetches sehen nach Bot aus. */
  function checkVariantsAplus(asins, origin, opts) {
    opts = opts || {};
    var delay = opts.delay == null ? 300 : opts.delay;
    var out = [];

    var step = function (i) {
      if (i >= asins.length) return Promise.resolve();
      var asin = asins[i];
      if (opts.onProgress) opts.onProgress(i + 1, asins.length, asin);

      return fetch(origin + '/dp/' + encodeURIComponent(asin), { credentials: 'include' })
        .then(function (r) {
          if (!r.ok) throw new Error('HTTP ' + r.status);
          return r.text();
        })
        .then(function (html) {
          // Captcha-/Robot-Seite (HTTP 200) enthaelt kein "aplus" - darf nicht als KEIN A+ zaehlen
          if (/validateCaptcha|opfcaptcha/i.test(html) || !/id="productTitle"/.test(html)) throw new Error('Captcha/keine Produktseite');
          out.push({ asin: asin, aplus: htmlHasAplus(html) ? 'A+' : 'KEIN A+' });
        })
        .catch(function (e) {
          // Fehler NICHT verschlucken - eine nicht ladbare Variante darf nicht
          // aussehen wie eine ohne A+.
          out.push({ asin: asin, aplus: '', fehler: (e && e.message) || 'Fehler' });
        })
        .then(function () { return sleep(delay); })
        .then(function () { return step(i + 1); });
    };

    return step(0).then(function () { return out; });
  }

  // ------------------------------------------------------------ Gesamtcheck

  /* Ein Aufruf im Seitenkontext einer Amazon-Produktseite liefert alles,
     was der Produktbetreuer-Modus braucht. */
  function inspect(doc, url, opts) {
    opts = opts || {};
    var origin = (typeof location !== 'undefined' && location.origin) || 'https://www.amazon.de';
    var asin = getAsin(doc, url);
    var res = {
      asin: asin,
      aplus: hasAplus(doc) ? 'A+' : 'KEIN A+',
      buybox: buyboxOnPage(doc),
      varianten: variantAsins(doc, asin),
      angebote: null,
      varianten_aplus: null
    };
    if (!asin) return Promise.resolve(res);

    return fetchOffers(asin, origin)
      .then(function (a) { res.angebote = a; })
      .catch(function (e) { res.angebote = { offers: [], anzahl: null, fehler: (e && e.message) || 'AOD-Fehler' }; })
      .then(function () {
        // Varianten nur pruefen, wenn dieses Listing selbst kein A+ hat -
        // sonst ist die Frage "hat eine Schwester A+?" gegenstandslos.
        if (!opts.variantAplus || res.aplus === 'A+' || !res.varianten.length) return null;
        return checkVariantsAplus(res.varianten.slice(0, opts.maxVarianten || 8), origin, opts)
          .then(function (v) { res.varianten_aplus = v; });
      })
      .then(function () { return res; });
  }

  LC.amazonPro = {
    getAsin: getAsin,
    variantAsins: variantAsins,
    hasAplus: hasAplus,
    htmlHasAplus: htmlHasAplus,
    fetchOffers: fetchOffers,
    buyboxOnPage: buyboxOnPage,
    checkVariantsAplus: checkVariantsAplus,
    maxQtyFromSelect: maxQtyFromSelect,
    inspect: inspect
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = LC.amazonPro;
})();