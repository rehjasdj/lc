/* Datensicherung: exportiert ALLES aus dem einheitlichen Store als JSON,
   importiert mit Diff-Vorschau, Storage-Statistik (Bytes je Prefix) und der
   Spiegel-Abgleich mit dem Nutzerordner (spiegelSync).
   Ausgenommen: aod:*, qv:* (fluechtiger Detail-Cache) und h10:* (Login-Session
   von Helium 10 - kein sinnvoller Backup-Wert).
   Nur reine Logik - die Verdrahtung mit den Knoepfen macht popup.js. */
'use strict';
(function () {
  var LC = globalThis.LC = globalThis.LC || {};
  // Cache und Session-Auth - werden nie mitgesichert.
  var AUS = /^(aod:|qv:|h10:)/;

  function sendMsg(msg) {
    return new Promise(function (res, rej) {
      try {
        chrome.runtime.sendMessage(msg, function (r) {
          var e = chrome.runtime.lastError;
          if (!e && r && r.ok) return res(r);
          rej(new Error((e && e.message) || (r && r.error) || 'Speicher nicht erreichbar'));
        });
      } catch (e) { rej(e); }
    });
  }

  /* KEIN Fallback auf chrome.storage.local: die Nutzdaten liegen im OPFS-Store
     des Workers, lokal sind nur Einstellungen. Ein Export aus dem lokalen Rest
     waere ein leeres Backup, ein Import-Diff darauf falsch (03.09.). */
  function alleKeys() {
    return sendMsg({ type: 'lcStoreGet', keys: null }).then(function (r) { return r.data || {}; });
  }

  function exportObject() {
    return alleKeys().then(function (all) {
      var out = {};
      Object.keys(all).forEach(function (k) {
        if (!AUS.test(k)) out[k] = all[k];
      });
      return out;
    });
  }

  function validate(obj) {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) {
      return 'Kein gueltiges Backup-Objekt (erwartet: JSON-Objekt).';
    }
    var keys = Object.keys(obj);
    if (!keys.length) return 'Backup ist leer.';
    if (!keys.every(function (k) { return typeof k === 'string' && k.length > 0; })) {
      return 'Ungueltige Schluessel im Backup.';
    }
    return null;
  }

  /* Import-Grenze. Die url-Felder in rows/matches stammen urspruenglich aus
     fremdem Shop-HTML und werden auf der Amazon-Seite als Link gerendert
     (onpage.js chip()); ein Backup kann aber von ueberall kommen - Kollege,
     USB-Stick, alte Datei. Deshalb hier dieselbe Schema-Pruefung wie im Parser:
     nur http/https. Eintraege mit unbrauchbarer URL werden uebersprungen statt
     uebernommen; die Zahl geht in den Rueckgabewert von importObject, damit das
     Popup sie nennen kann. validate() behaelt bewusst seinen String-Vertrag
     (null = in Ordnung) - der Aufrufer in popup.js wirft auf jeden Wahrheitswert. */
  var URL_LISTEN = ['rows', 'matches'];
  function urlOk(u) {
    u = String(u == null ? '' : u).trim();
    if (!u) return true;                       // gar kein Link ist kein Risiko
    try {
      var p = new URL(u).protocol;
      return p === 'http:' || p === 'https:';
    } catch (e) { return false; }
  }
  function urlsSieben(obj) {
    var weg = 0;
    URL_LISTEN.forEach(function (key) {
      if (!Array.isArray(obj[key])) return;
      obj[key] = obj[key].filter(function (eintrag) {
        if (eintrag && typeof eintrag === 'object' && !urlOk(eintrag.url)) { weg++; return false; }
        return true;
      });
    });
    return weg;
  }

  function berechneDiff(neu, alt) {
    var out = { neu: 0, ueberschrieben: 0, gesamt: 0 };
    Object.keys(neu).forEach(function (k) {
      out.gesamt++;
      if (k in alt) out.ueberschrieben++; else out.neu++;
    });
    return out;
  }

  function importObject(obj) {
    var fehler = validate(obj);
    if (fehler) return Promise.reject(new Error(fehler));
    var uebersprungen = urlsSieben(obj);
    return alleKeys().then(function (alt) {
      var d = berechneDiff(obj, alt);
      d.uebersprungen = uebersprungen;
      return sendMsg({ type: 'lcStoreSet', data: obj }).then(function () { return d; });
    });
  }

  function bytesOf(v) {
    try { return new TextEncoder().encode(JSON.stringify(v)).length; }
    catch (e) {
      try { return String(JSON.stringify(v)).length; }
      catch (_) { return 0; }
    }
  }

  function stats() {
    return alleKeys().then(function (all) {
      var by = {};
      Object.keys(all).forEach(function (k) {
        var m = k.match(/^([^:]+):/);
        var p = m ? m[1] + ':*' : k;
        by[p] = (by[p] || 0) + bytesOf(all[k]);
      });
      return by;
    });
  }

  function heute() {
    var d = new Date();
    var mm = String(d.getMonth() + 1).padStart(2, '0');
    var tt = String(d.getDate()).padStart(2, '0');
    return d.getFullYear() + '-' + mm + '-' + tt;
  }

  function defaultFilename() { return 'lc-backup-' + heute() + '.json'; }

  // ---------------------------------------------------------------- Spiegel-Abgleich
  /* Dateinamen wie im Worker (background.js diskDateiname/diskKeyAusName):
     k-<base64url(key)>.json im Unterordner listing-checker-data - in OPFS und
     im Nutzerordner identisch, der Abgleich ist damit ein Dateivergleich. */
  var DIR = 'listing-checker-data';
  function dateiname(key) {
    var bytes = new TextEncoder().encode(key), bin = '';
    for (var i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    return 'k-' + btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '') + '.json';
  }
  function keyAusName(name) {
    var m = /^k-([A-Za-z0-9_-]+)\.json$/.exec(String(name || ''));
    if (!m) return null;
    var b64 = m[1].replace(/-/g, '+').replace(/_/g, '/');
    while (b64.length % 4) b64 += '=';
    try {
      var bin = atob(b64), bytes = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return new TextDecoder().decode(bytes);
    } catch (e) { return null; }
  }
  function dateinamen(dir) {
    return new Promise(function (res, rej) {
      var out = [], it = dir.keys();
      (function schritt() {
        it.next().then(function (r) {
          if (r.done) return res(out);
          if (keyAusName(r.value)) out.push(r.value);
          schritt();
        }).catch(rej);
      })();
    });
  }
  function lesen(dir, name) {
    return dir.getFileHandle(name).then(function (fh) { return fh.getFile(); }).then(function (f) { return f.text(); });
  }
  function schreiben(dir, name, text) {
    return dir.getFileHandle(name, { create: true }).then(function (fh) {
      return fh.createWritable().then(function (w) { return w.write(text).then(function () { return w.close(); }); });
    });
  }
  function seq(list, fn) {
    return list.reduce(function (p, x) { return p.then(function () { return fn(x); }); }, Promise.resolve());
  }

  /* Abgleich OPFS <-> Nutzerordner. Laeuft nur im Popup - die Freigabe des
     Ordners braucht eine Nutzergeste, die der Worker nicht hat.
     handle = DirectoryHandle des Ordners (readwrite, bereits freigegeben).
       1) im Worker vorgemerkte Loeschungen im Ordner nachziehen
       2) vorgemerkte Keys ('*' = alle) aus OPFS in den Ordner kopieren
       3) Dateien, die NUR im Ordner liegen, in den Store importieren
          (Wiederherstellung nach Profilwechsel/Neuinstallation) - ueber den
          Worker, damit er sie kennt und den Tabs meldet
       4) Erledigtes zurueckmelden (lcSpiegelErledigt)
     Rueckgabe { kopiert, importiert, geloescht }. */
  function spiegelSync(handle) {
    if (!navigator.storage || typeof navigator.storage.getDirectory !== 'function') {
      return Promise.reject(new Error('Dieser Browser hat kein OPFS - kein Abgleich moeglich'));
    }
    var flags = new Promise(function (res) {
      chrome.storage.local.get(['lcSpiegelDirty', 'lcSpiegelLoeschen'], function (d) { res(d || {}); });
    });
    return Promise.all([
      navigator.storage.getDirectory().then(function (r) { return r.getDirectoryHandle(DIR, { create: true }); }),
      handle.getDirectoryHandle(DIR, { create: true }),
      flags
    ]).then(function (x) {
      var opfs = x[0], ordner = x[1];
      // Werte sind Zeitstempel des letzten Writes - werden am Ende als "gesehen" zurueckgemeldet
      var dirty = x[2].lcSpiegelDirty || {}, loeschMap = x[2].lcSpiegelLoeschen || {}, loeschen = Object.keys(loeschMap);
      var alle = !!dirty['*'];
      return Promise.all([dateinamen(opfs), dateinamen(ordner)]).then(function (n) {
        var inOpfs = n[0], inOrdner = n[1];
        var zuKopieren = inOpfs.filter(function (name) { return alle || dirty[keyAusName(name)]; });
        var zuImportieren = inOrdner.filter(function (name) {
          var key = keyAusName(name);
          return key && inOpfs.indexOf(name) < 0 && loeschen.indexOf(key) < 0;
        });
        return seq(loeschen, function (key) { return ordner.removeEntry(dateiname(key)).catch(function () {}); })
          .then(function () {
            return seq(zuKopieren, function (name) {
              return lesen(opfs, name).then(function (txt) { return schreiben(ordner, name, txt); });
            });
          })
          .then(function () {
            return seq(zuImportieren, function (name) {
              return lesen(ordner, name).then(function (txt) {
                var o = {}; o[keyAusName(name)] = JSON.parse(txt);
                return sendMsg({ type: 'lcStoreSet', data: o });
              }).catch(function (e) { console.warn('[LC] Spiegel-Import', name, e); });
            });
          })
          .then(function () {
            /* Erledigt = { key: gesehener Zeitstempel }. Der Worker traegt nur
               aus, was seither nicht erneut geschrieben wurde (Audit 03.09., D6). */
            var erledigt = {};
            zuKopieren.forEach(function (name) { var k = keyAusName(name); erledigt[k] = dirty[k] || 0; });
            if (alle) erledigt['*'] = dirty['*'];
            return sendMsg({ type: 'lcSpiegelErledigt', dirty: erledigt, loeschen: loeschMap }).catch(function () {});
          })
          .then(function () {
            return { kopiert: zuKopieren.length, importiert: zuImportieren.length, geloescht: loeschen.length };
          });
      });
    });
  }

  /* Steht Spiegel-Arbeit an? (Statuszeile im Popup) */
  function spiegelAusstehend() {
    return new Promise(function (res) {
      chrome.storage.local.get(['lcSpiegelDirty', 'lcSpiegelLoeschen'], function (d) {
        d = d || {};
        var dirty = d.lcSpiegelDirty || {};
        res({
          n: Object.keys(dirty).length + Object.keys(d.lcSpiegelLoeschen || {}).length,
          alles: !!dirty['*']
        });
      });
    });
  }

  LC.backup = {
    exportObject: exportObject,
    importObject: importObject,
    validate: validate,
    stats: stats,
    defaultFilename: defaultFilename,
    spiegelSync: spiegelSync,
    spiegelAusstehend: spiegelAusstehend
  };
})();
