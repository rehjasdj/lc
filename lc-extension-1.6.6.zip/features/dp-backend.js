/* Backend Search Terms auf der Produktseite - eigene Sektion unter "Info zu diesem
   Artikel" (ctx.sec('Backend', 'bullets')). Amazons Backend ist leerzeichen-
   getrennt, max. 250 Bytes UTF-8, lowercase, kein Duplikat zu Titel/Highlights/
   Bullets/Beschreibung, keine eigene Marke. row.backend gibt es in shared/
   extract.js nicht - deshalb Textarea, gespeichert unter 'bkTerms:<ASIN>'.
   Live-Analyse bei jeder Aenderung: Bytes-Ziel 230-249, Duplikate, Marke drin,
   Ueberschneidung mit Frontend, Grossbuchstaben. Nur ui.el/ui.chip (data-lc). */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];

  var bytesUtf8 = function (t) {
    try { return new Blob([t]).size; }
    catch (e) { return String(t || '').replace(/[^\x00-\x7f]/g, '  ').length; }
  };
  var woerter = function (t) { return String(t || '').trim().split(/\s+/).filter(Boolean); };

  function frontendWoerter(r) {
    var teile = [r && r.titel, r && r.item_highlights, r && r.beschreibung];
    for (var i = 1; i <= 8; i++) if (r && r['bullet_' + i]) teile.push(r['bullet_' + i]);
    var t = teile.filter(Boolean).join(' ').toLowerCase();
    /* Wortgrenzen ueber Nicht-Wortzeichen - Umlaute bleiben Teil des Wortes.
       ponytail: reicht als Ueberschneidungspruefung; feine Stemmer waeren Overkill. */
    var out = {};
    t.split(/[^a-z0-9äöüß]+/).forEach(function (w) { if (w) out[w] = 1; });
    return out;
  }

  function pruefen(bk, r, EIGEN) {
    var ws = woerter(bk);
    /* Ci-Gruppen bilden und pro Gruppe die case-erhaltenen Formen zaehlen.
       Duplikat-Zahl = Summe der distinct case-Formen ueber alle Gruppen mit >=2
       Instanzen: 'garten GARTEN' (2 Formen, case-inkonsistent) zaehlt schwerer
       als 'garten garten' (1 Form). */
    var grp = {};
    ws.forEach(function (w) {
      var k = w.toLowerCase();
      var g = grp[k] || (grp[k] = { count: 0, forms: {} });
      g.count += 1;
      g.forms[w] = 1;
    });
    var dupWoerter = [], dupExtra = 0;
    Object.keys(grp).forEach(function (k) {
      if (grp[k].count > 1) {
        dupWoerter.push(k);
        dupExtra += Object.keys(grp[k].forms).length;
      }
    });

    var brand = ws.filter(function (w) { return EIGEN.test(w); });
    /* Brand-Woerter werden im eigenen Chip gemeldet; der Grossbuchstaben-Chip
       zaehlt sie nicht ein zweites Mal - sonst kollidieren die Zahlen mit der
       Spec (LO 29.08.2026). */
    var upperWoerter = ws.filter(function (w) { return /[A-Z]/.test(w) && !EIGEN.test(w); });
    var upperN = 0;
    upperWoerter.forEach(function (w) { upperN += (w.match(/[A-Z]/g) || []).length; });

    var fe = frontendWoerter(r);
    var overlap = [];
    var gesehen = {};
    ws.forEach(function (w) {
      var k = w.toLowerCase();
      if (gesehen[k]) return;
      gesehen[k] = 1;
      if (fe[k]) overlap.push(w);
    });

    return {
      bytes: bytesUtf8(bk),
      woerter: ws.length,
      dupExtra: dupExtra,
      dupWoerter: dupWoerter,
      brand: brand,
      upperWoerter: upperWoerter,
      upperN: upperN,
      overlap: overlap
    };
  }

  H.backendCheck = { bytesUtf8: bytesUtf8, woerter: woerter, pruefen: pruefen };

  H.panel.push(function (ctx) {
    var ui = ctx.ui, r = ctx.row || {};
    if (!ui || typeof ctx.sec !== 'function' || !ctx.asin) return;
    /* Falls extract.js irgendwann ein Feld liefert, nehmen wir es als Vorbelegung. */
    var vorbelegt = r.backend || r.backend_search_terms || '';
    var key = 'bkTerms:' + ctx.asin;

    var box = ctx.sec('Backend', 'bullets');
    var ta = ui.el('textarea', 'a-input-text');
    ta.setAttribute('placeholder', 'Backend Search Terms hier einfuegen (aus Seller Central kopieren)');
    ta.setAttribute('rows', '3');
    ta.style.width = '100%';
    ta.style.boxSizing = 'border-box';
    ta.style.fontFamily = 'inherit';
    box.appendChild(ta);

    var chips = ui.el('div', 'lc-row a-spacing-small');
    var details = ui.el('div', 'a-size-mini lc-k');
    box.appendChild(chips);
    box.appendChild(details);

    function malen(text) {
      var p = pruefen(text, r, ui.EIGEN);
      chips.innerHTML = '';
      details.innerHTML = '';

      var bytesKind = p.bytes > 249 ? 'bad' : (p.bytes >= 230 ? 'ok' : (p.bytes < 200 ? 'mut' : ''));
      chips.appendChild(ui.chip(p.bytes + ' <span class="lc-k">Bytes</span> / 249',
        bytesKind, 'Amazon: unter 250 Bytes UTF-8, also max. 249 (Seller Central „Suchbegriffe optimieren"); 230–249 = Deuba-Empfehlung, um das Limit auszunutzen. Aktuell: ' + p.bytes));
      chips.appendChild(ui.chip(p.woerter + ' <span class="lc-k">Wörter</span>', 'mut',
        'Amazon trennt das Backend leerzeichenweise, kein Komma nötig'));

      if (p.dupExtra) chips.appendChild(ui.chip(p.dupExtra + ' <span class="lc-k">Duplikate</span>',
        'bad', 'gleiches Wort mehrfach: ' + p.dupWoerter.join(', ')));
      if (p.brand.length) chips.appendChild(ui.chip('Marke drin!', 'bad',
        'eigene Marke im Backend verschwendet Bytes: ' + p.brand.join(', ')));
      if (p.overlap.length) chips.appendChild(ui.chip(p.overlap.length + ' <span class="lc-k">doppelt zum Frontend</span>',
        'bad', 'stehen schon sichtbar im Listing: ' + p.overlap.join(', ')));
      if (p.upperN) chips.appendChild(ui.chip(p.upperN + ' <span class="lc-k">Grossbuchstaben</span>',
        'bad', 'Backend soll lowercase sein: ' + p.upperWoerter.join(', ')));

      var probs = [];
      if (p.dupWoerter.length) probs.push('Duplikate: ' + p.dupWoerter.join(', '));
      if (p.brand.length) probs.push('Marke: ' + p.brand.join(', '));
      if (p.overlap.length) probs.push('Frontend: ' + p.overlap.join(', '));
      if (p.upperWoerter.length) probs.push('Gross: ' + p.upperWoerter.join(', '));
      if (probs.length) details.textContent = probs.join(' · ');
    }

    ui.storage(key).then(function (d) {
      if (ui.aktuelleAsin && ui.aktuelleAsin() !== ctx.asin) return;
      var start = (d && d[key]) || vorbelegt || '';
      ta.value = start;
      malen(start);
    }).catch(function () { malen(vorbelegt || ''); });

    /* P10: 300 ms Debounce statt Write je Tastendruck - jeder Write feuert
       onChanged in allen Kontexten (Popup, andere Tabs). Letzter Wert gewinnt;
       beim Verlassen des Feldes sofort schreiben. */
    var timer = null, ausstehend = null;
    var schreiben = function () {
      clearTimeout(timer); timer = null;
      if (ausstehend == null) return;
      var o = {}; o[key] = ausstehend; ausstehend = null;
      ui.storageSet(o).catch(function (e) { console.warn('[LC] Backend speichern', e); });
    };
    ta.addEventListener('input', function () {
      var v = ta.value;
      ausstehend = v;
      clearTimeout(timer); timer = setTimeout(schreiben, 300);
      malen(v);
    });
    ta.addEventListener('blur', schreiben);
  });
})();
