/* Preis-/Buybox-Alarme (Paket B, Repricing-Sicht): der Nutzer soll auf einen
   Blick sehen, ob der eigene Preis in der Angebotsliste angreifbar ist, ob eine
   Sammelpruefung ihn bereits als "UNTERBOTEN" markiert hat, wie oft die Buybox
   in den letzten 30 Tagen weg war und wie es um beobachtete ASINs steht.
   Alles aus lokalem Speicher (aod:<ASIN>, hist:<ASIN>, pro, watch) - keine
   neuen Requests, keine neuen Rechte. Nur ui.el/ui.chip (data-lc). */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];

  var EIGEN = /deuba|casaria|monzana|gardebruk/i;
  var TAGE30 = 30 * 24 * 3600 * 1000;
  var kurz = function (s, n) { s = String(s == null ? '' : s).replace(/\s+/g, ' ').trim(); return s.length > n ? s.slice(0, n - 1) + '…' : s; };

  function bestOffer(offers, mitEigen) {
    var best = null;
    (offers || []).forEach(function (o) {
      if (!o || o.preis == null) return;
      if (mitEigen !== EIGEN.test(o.verkaeufer || '')) return;
      if (!best || o.preis < best.preis) best = o;
    });
    return best;
  }

  // -100 .. +N: Abweichung des guenstigsten Fremdangebots zum eigenen Preis
  function fremdDelta(offers) {
    var eigen = bestOffer(offers, true), fremd = bestOffer(offers, false);
    if (!eigen || !fremd || !(eigen.preis > 0)) return null;
    return { eigen: eigen, fremd: fremd, pct: Math.round((fremd.preis / eigen.preis - 1) * 100) };
  }

  function fremdChip(ui, delta) {
    if (!delta) return null;
    var p = delta.pct, vor = p > 0 ? '+' : '';
    var titel = 'günstigstes Fremdangebot ' + ui.esc(kurz(delta.fremd.verkaeufer || '?', 22)) + ' ' +
      ui.eur(delta.fremd.preis) + ' vs eigen ' + ui.eur(delta.eigen.preis);
    if (p <= -5) return ui.chip('Fremd ' + p + ' %', 'bad', titel);
    if (p >= 5)  return ui.chip('Fremd ' + vor + p + ' %', 'ok', titel);
    return null;
  }

  function proChip(ui, proListe, asin) {
    var neuest = null;
    proListe.forEach(function (p) {
      if (p.asin !== asin || !/UNTERBOTEN/.test(p.urteil || '')) return;
      if (!neuest || String(p.geprueft_am || '').localeCompare(String(neuest.geprueft_am || '')) > 0) neuest = p;
    });
    if (!neuest) return null;
    var shop = neuest.guenstigste_plattform || 'Shop';
    // Link auf das guenstigere Fremdangebot (guenstigster_url), nicht auf die Amazon-Seite (url)
    return ui.chip('unterboten @ ' + ui.esc(kurz(shop, 22)), 'bad',
      neuest.urteil + (neuest.guenstigster_preis != null ? ' · ' + ui.eur(neuest.guenstigster_preis) : '') + ' (Stand ' + ui.tag(new Date(neuest.geprueft_am)) + ')',
      neuest.guenstigster_url || neuest.url);
  }

  function verlusteZahl(hist) {
    if (!Array.isArray(hist)) return 0;
    var jetzt = Date.now(), n = 0;
    hist.forEach(function (s) {
      if (!s || s[3] !== 2) return;
      var t = Date.parse(s[0]);
      if (isFinite(t) && jetzt - t <= TAGE30) n++;
    });
    return n;
  }

  H.panel.push(function (ctx) {
    var ui = ctx.ui;
    if (!ui || !ctx.asin) return;
    var asin = ctx.asin;

    // 1) Chips in der Buybox-Zeile: Fremdanbieter-Abstand + laufende "UNTERBOTEN"-Diagnose
    ui.storage(['aod:' + asin, 'pro']).then(function (d) {
      if (ui.aktuelleAsin && ui.aktuelleAsin() !== asin) return;
      if (!ctx.bbRow || !ctx.bbRow.isConnected) return;
      var c2 = proChip(ui, d.pro || [], asin);
      if (c2) ctx.bbRow.appendChild(c2);
      var fremd = function (cc) {
        var offers = cc && cc.angebote && cc.angebote.offers ? cc.angebote.offers : [];
        var c1 = fremdChip(ui, fremdDelta(offers));
        if (c1 && ctx.bbRow.isConnected) ctx.bbRow.appendChild(c1);
      };
      var cc = d['aod:' + asin];
      if (cc && cc.angebote && Date.now() - cc.ts < 15 * 60 * 1000) return fremd(cc);
      /* Cache fehlt oder ist aelter als 15 min: onpage.js holt gerade frisch und schreibt
         aod:<ASIN> asynchron - auf dieses Schreiben warten statt alte Angebote zu zeigen. */
      /* Singleton ueber Panel-Rebuilds: der Twister-Poll baut alle 800ms neu -
         ohne Abmelden des Vorgaengers sammelten sich Listener an, die bei
         JEDEM Storage-Write der Extension feuerten (Review 31.08.). */
      if (H.__aodWait) chrome.storage.onChanged.removeListener(H.__aodWait);
      var h = H.__aodWait = function (ch, area) {
        if (area !== 'local' || !ch['aod:' + asin]) return;
        chrome.storage.onChanged.removeListener(h);
        if (H.__aodWait === h) H.__aodWait = null;
        var neu = ch['aod:' + asin].newValue;
        // Negativ-Cache-Eintraege (angebote:null nach Captcha) nicht rendern
        if (ui.aktuelleAsin() === asin && neu && neu.angebote) fremd(neu);
      };
      chrome.storage.onChanged.addListener(h);
      setTimeout(function () {
        chrome.storage.onChanged.removeListener(h);
        if (H.__aodWait === h) H.__aodWait = null;
      }, 30000);   // AOD gescheitert -> nicht ewig lauschen
    }).catch(function (e) { console.warn('[LC] Repricing bbRow', e); });

    // 2) Preis-Alarm: Buybox-Verluste 30 T aus hist:<ASIN>
    ui.storage('hist:' + asin).then(function (d) {
      if (ui.aktuelleAsin && ui.aktuelleAsin() !== asin) return;
      var n = verlusteZahl(d['hist:' + asin]);
      if (!n || typeof ctx.sec !== 'function') return;
      var box = ctx.sec('Preis-Alarm');
      box.appendChild(ui.chip(n + ' <span class="lc-k">Buybox-Verluste 30 T</span>', 'bad',
        'so oft war die Buybox in den letzten 30 Tagen unterdrückt (aus hist:' + asin + ')'));
    }).catch(function (e) { console.warn('[LC] Repricing Alarm', e); });

    // 3) Beobachtungs-Alarme: fuer jede beobachtete ASIN mit AOD-Cache Fremd-vs-Eigen zeigen.
    //    Ohne aod-Cache still (nichts zu sagen, kein Netzabruf hier).
    ui.storage('watch').then(function (d) {
      var watch = Array.isArray(d.watch) ? d.watch : [];
      if (!watch.length || typeof ctx.sec !== 'function') return;
      var keys = watch.map(function (w) { return 'aod:' + w.asin; });
      return ui.storage(keys).then(function (dd) {
        if (ui.aktuelleAsin && ui.aktuelleAsin() !== asin) return;
        var eintraege = [];
        watch.forEach(function (w) {
          var cc = dd['aod:' + w.asin];
          var offers = cc && cc.angebote && cc.angebote.offers ? cc.angebote.offers : [];
          var delta = fremdDelta(offers);
          if (!delta) return;
          eintraege.push({ w: w, delta: delta });
        });
        if (!eintraege.length) return;
        var box = ctx.sec('Beobachtungsliste: Alarme (' + eintraege.length + ')');
        eintraege.forEach(function (e) {
          var p = e.delta.pct, vor = p > 0 ? '+' : '';
          var kind = p <= -5 ? 'bad' : (p >= 5 ? 'ok' : 'mut');
          var zeile = ui.el('div', 'lc-row a-spacing-micro' + (e.w.asin === asin ? ' lc-ok' : ''),
            '<a class="a-link-normal" href="/dp/' + ui.esc(e.w.asin) + '" title="' + ui.esc(e.w.titel || e.w.asin) + '">' +
            ui.esc(kurz(e.w.titel || e.w.asin, 40)) + '</a>' +
            '<span class="lc-mono lc-k">' + ui.esc(e.w.asin) + '</span>');
          zeile.appendChild(ui.chip('Fremd ' + vor + p + ' %', kind,
            'günstigstes Fremdangebot ' + ui.esc(kurz(e.delta.fremd.verkaeufer || '?', 22)) + ' ' + ui.eur(e.delta.fremd.preis) +
            ' vs eigen ' + ui.eur(e.delta.eigen.preis)));
          box.appendChild(zeile);
        });
      });
    }).catch(function (e) { console.warn('[LC] Repricing Watchlist', e); });
  });
})();
