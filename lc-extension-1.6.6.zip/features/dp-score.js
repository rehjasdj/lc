/* Listing-Score 0-100 (nach Helium 10 "Listing Health" / AMZScout LQS, aber an
   Amazons Regeln seit 27.07.2026 und dem Deuba-Listing-Skill v4 ausgerichtet:
   Titel <= 75, Highlights <= 125, Bullets 150-250 Zeichen, Beschreibung >= 1000).
   Dazu Amazons eigener Rezensions-Block "Die Kunden sagen" als Auszug.
   Daten: ctx.row (extract.js) + DOM. Keine Requests, keine Rechte. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  // extract.js liefert Zahlen (4.4) - die duerfen nicht durch den Punkt-Entferner ("44")
  var num = function (v) { if (typeof v === 'number') return isFinite(v) ? v : null; var n = parseFloat(String(v == null ? '' : v).replace(/\./g, '').replace(',', '.')); return isFinite(n) ? n : null; };

  function bullets(r) {
    var out = [];
    for (var i = 1; i <= 8; i++) { var b = clean(r['bullet_' + i]); if (b) out.push(b); }
    if (!out.length) {
      Array.prototype.forEach.call(document.querySelectorAll('#feature-bullets li span.a-list-item'), function (li) {
        var t = clean(li.textContent); if (t) out.push(t);
      });
    }
    return out;
  }

  function checks(r, ui) {
    var tl = r.titel_laenge || clean(r.titel).length;
    var hl = r.item_highlights_laenge || clean(r.item_highlights).length;
    var bl = bullets(r);
    var lens = bl.map(function (b) { return b.length; });
    var anker = bl.filter(function (b) { return /^[A-ZÄÖÜ0-9][A-ZÄÖÜ0-9 &\-\/,+]{3,}[:\-–]/.test(b); }).length;
    var bild = r.bilder_anzahl || document.querySelectorAll('#altImages li.imageThumbnail, #altImages li.item').length;
    var video = !!document.querySelector('.videoBlockIngress, #vse-vw-dp-container, [data-feature-name="videoBlock"]');
    var bs = document.querySelector('#aplusBrandStory_feature_div');
    var brandStory = !!(bs && clean(bs.textContent).length > 40);
    var bew = num(r.bewertung), anz = num(r.anzahl_bewertungen);
    // K2: die festen socialProofing-IDs greifen nicht mehr (Score war systematisch 4 Punkte zu niedrig) - robuster Finder aus onpage.js
    var kauf = !!(ui.kaufBadge && ui.kaufBadge());
    var marke = clean(r.marke), titel = clean(r.titel);
    var beschr = r.beschreibung_laenge || 0;
    return [
      { p: 10, ok: tl > 0 && tl <= 75 && tl >= 40, t: 'Titel 40–75 Zeichen (' + tl + ')' },
      { p: 4,  ok: !!marke && titel.toLowerCase().indexOf(marke.toLowerCase()) === 0, t: 'Titel beginnt mit der Marke' },
      { p: 10, ok: hl >= 90 && hl <= 125, t: 'Item Highlights 90–125 Zeichen (' + hl + ')' },
      { p: 8,  ok: bl.length >= 5, t: '5 Bullets (' + bl.length + ')' },
      { p: 8,  ok: bl.length > 0 && lens.every(function (n) { return n >= 150 && n <= 250; }), t: 'jeder Bullet 150–250 Zeichen (' + (lens.length ? Math.min.apply(null, lens) + '–' + Math.max.apply(null, lens) : '–') + ')' },
      { p: 4,  ok: bl.length > 0 && anker === bl.length, t: 'Bullet-Anker in Großbuchstaben (' + anker + '/' + bl.length + ')' },
      { p: 8,  ok: beschr >= 1000, t: 'Beschreibung ≥ 1000 Zeichen (' + beschr + ')' },
      { p: 8,  ok: bild >= 6, t: '≥ 6 Bilder (' + bild + ')' },
      { p: 6,  ok: video, t: 'Video' },
      { p: 8,  ok: r.aplus && r.aplus !== 'KEIN A+', t: 'A+ Content' },
      { p: 4,  ok: brandStory, t: 'Brand Story' },
      { p: 6,  ok: bew != null && bew >= 4, t: 'Bewertung ≥ 4,0 (' + (bew == null ? '–' : String(bew).replace('.', ',')) + ')' },
      { p: 4,  ok: anz != null && anz >= 100, t: '≥ 100 Rezensionen (' + (anz == null ? '–' : anz) + ')' },
      { p: 4,  ok: kauf, t: 'Kaufzahl-Badge sichtbar' },
      { p: 4,  ok: !!r.ean, t: 'EAN hinterlegt' },
      { p: 4,  ok: r.bsr != null && r.bsr !== '', t: 'Bestseller-Rang vorhanden' }
    ];
  }

  H.panel.push(function (ctx) {
    var ui = ctx.ui, r = ctx.row || {};
    if (!ui || !ctx.secQ) return;
    var list = checks(r, ui);
    var max = 0, got = 0;
    list.forEach(function (c) { max += c.p; if (c.ok) got += c.p; });
    var score = Math.round(100 * got / max);
    var fehl = list.filter(function (c) { return !c.ok; }).map(function (c) { return c.t; });
    ctx.secQ.insertBefore(ui.chip('<span class="lc-k">Listing-Score</span> ' + score + '/100',
      score >= 80 ? 'ok' : (score < 60 ? 'bad' : ''), fehl.length ? 'Offen: ' + fehl.join(' · ') : 'alle Kriterien erfüllt'), ctx.secQ.firstChild);

    if (typeof ctx.sec === 'function') {
      var box = ctx.sec('Listing-Score', 'bullets');
      var kind = score >= 80 ? 'ok' : (score < 60 ? 'bad' : 'warn');
      box.appendChild(ui.el('div', 'lc-score',
        '<b class="' + (kind === 'ok' ? 'lc-ok' : (kind === 'bad' ? 'lc-bad' : '')) + '">' + score + '<span class="lc-k">/100</span></b>' +
        '<span class="lc-bar ' + kind + '"><i style="width:' + score + '%"></i></span>'));
      var zeile = function (c) {
        return '<div><span class="' + (c.ok ? 'lc-ok' : 'lc-bad') + '">' + (c.ok ? '✓' : '✗') + '</span><span class="lc-t">' + ui.esc(c.t) +
          '</span><span class="lc-mono lc-k">' + (c.ok ? c.p : 0) + '/' + c.p + '</span></div>';
      };
      var offen = list.filter(function (c) { return !c.ok; }), erfuellt = list.filter(function (c) { return c.ok; });
      box.appendChild(ui.el('div', 'lc-check', offen.length ? offen.map(zeile).join('') : '<div><span class="lc-ok">✓</span><span class="lc-t">alle Kriterien erfüllt</span></div>'));
      if (erfuellt.length) {
        var more = ui.el('span', 'lc-more', erfuellt.length + ' erfüllte anzeigen');
        var erfBox = ui.el('div', 'lc-check', erfuellt.map(zeile).join(''));
        erfBox.style.display = 'none';
        more.addEventListener('click', function () {
          var auf = erfBox.style.display === 'none';
          erfBox.style.display = auf ? '' : 'none';
          more.textContent = auf ? 'erfüllte ausblenden' : erfuellt.length + ' erfüllte anzeigen';
        });
        box.appendChild(more); box.appendChild(erfBox);
      }

      /* Amazons "Die Kunden sagen" steht direkt daneben - kein Duplikat (LO 29.08.). */
    }
  });
})();
