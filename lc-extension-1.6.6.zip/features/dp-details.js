/* Media- und A+-Diagnose (Seller Assistant "Listing quality" / Helium 10 "Image
   analysis" light). Keine Netz-Requests: alles aus dem Seitenquelltext.
   Chips in ctx.secQ (Klasse lc-det, idempotent):
     - Videos:      #altImages li.videoBlockIngress, [data-video-id], .a-video-container video
     - Hi-Res:      "hiRes":"URL" aus dem colorImages-Skript, Breite aus _SL/_SX/_SY-Suffix
     - A+-Module:   #aplus .apm-brand-story-card, #aplus_feature_div .aplus-module,
                    #aplusBrandStory_feature_div .apm-brand-story-card
                    "+ Brand Story" wenn #aplusBrandStory_feature_div existiert
     - Vergleich:   #HLCXComparisonWidget_feature_div, .a-cardui.comparison-table
     - 360°:        #altImages li.item [data-spin], .a-360-container
   Zusatzsektion "Media-Details" (bullets-Anker) mit einer Liste der Hi-Res-Links
   und einem Kopier-Chip fuer alle Links. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];

  /* Amazon-Bild-URLs enden mit _SL1500_, _SX679_, _SY450_ etc. - die Zahl ist
     die Kantenlaenge. Nimmt die groesste Zahl (Hi-Res ist der groesste Slot). */
  function bildBreite(url) {
    var max = 0, re = /_S[LXY](\d+)_/gi, m;
    while ((m = re.exec(url)) !== null) { var n = parseInt(m[1], 10); if (n > max) max = n; }
    return max || null;
  }

  /* P4: Der Fallback scannt ALLE Skripte der Seite (hunderte, MB an Text) - und
     das bei jedem Panel-Aufbau, also auch bei jedem Variantenwechsel (800-ms-Poll).
     Ergebnis je ASIN merken, max. 20 Eintraege, samt den Fund-Knoten: ist einer
     davon nicht mehr isConnected, hat Amazon den Bildblock beim Ajax-Swap ersetzt
     -> neu scannen (sonst blieben die Bilder der VORHERIGEN Variante haengen).
     Leer wird nicht gemerkt, damit ein spaeter nachgeladenes Skript noch zaehlt. */
  var CACHE = {}, CACHE_KEYS = [];
  function merken(key, wert) {
    if (!CACHE[key]) { CACHE_KEYS.push(key); if (CACHE_KEYS.length > 20) delete CACHE[CACHE_KEYS.shift()]; }
    CACHE[key] = wert;
  }

  function hiResUrls(asin) {
    var c = asin && CACHE[asin];
    if (c && c.nodes.every(function (n) { return n.isConnected; })) return c.urls;
    var urls = [], seen = {}, nodes = [];
    var scripts = document.querySelectorAll('#imageBlock script, #imageBlock_feature_div script, #main-image-container script');
    /* Fallback: alle Skripte durchsuchen, wenn Amazon den imageBlock-Wrapper
       gerade nicht rendert (Mobile-Layout, A/B-Test). */
    if (!scripts.length) scripts = document.querySelectorAll('script');
    for (var i = 0; i < scripts.length; i++) {
      var t = scripts[i].textContent || '';
      if (t.indexOf('colorImages') < 0 && t.indexOf('"hiRes"') < 0) continue;
      nodes.push(scripts[i]);
      var re = /"hiRes"\s*:\s*"(https?:\\?\/\\?\/[^"\\]+(?:\\.[^"\\]*)*)"/g, m;
      while ((m = re.exec(t)) !== null) {
        var u = m[1].replace(/\\\//g, '/');
        if (u && !seen[u]) { seen[u] = 1; urls.push(u); }
      }
    }
    if (asin && urls.length) merken(asin, { urls: urls, nodes: nodes });
    return urls;
  }

  function zaehleVideos(d) {
    var sel = '#altImages li.videoBlockIngress, [data-video-id], .a-video-container video';
    return d.querySelectorAll(sel).length;
  }

  function zaehleAplus(d) {
    var sel = '#aplus .apm-brand-story-card, #aplus_feature_div .aplus-module, #aplusBrandStory_feature_div .apm-brand-story-card';
    return d.querySelectorAll(sel).length;
  }

  H.panel.push(function (ctx) {
    var ui = ctx.ui, d = document;
    if (!ui || !ctx.secQ) return;
    if (ctx.secQ.querySelector('.lc-det')) return;           // idempotent

    var mark = function (c) { c.classList.add('lc-det'); return c; };

    // -- Videos
    var vN = zaehleVideos(d);
    ctx.secQ.appendChild(mark(ui.chip(vN + ' <span class="lc-k">Video' + (vN === 1 ? '' : 's') + '</span>',
      vN >= 1 ? 'ok' : 'bad', vN >= 1 ? vN + ' Videoslot(s) auf der Seite' : 'kein Video im Listing')));

    // -- Hi-Res-Bilder: min-Breite entscheidet
    var urls = hiResUrls(ctx.asin);
    var breiten = urls.map(bildBreite).filter(function (n) { return n != null; });
    if (urls.length) {
      var mn = breiten.length ? Math.min.apply(null, breiten) : 0;
      // Amazon-Produktbildanforderungen: >= 1000 px auf der laengsten Seite fuer Zoom, 1600 px empfohlen
      ctx.secQ.appendChild(mark(ui.chip(urls.length + ' <span class="lc-k">Hi-Res</span> ' + (mn || '?') + ' px',
        mn >= 1000 ? 'ok' : 'mut', 'kleinstes Hi-Res-Bild unter ' + urls.length + ' (größte Kante laut URL-Suffix); Amazon: ≥ 1000 px für Zoom, 1600 px empfohlen (Seller Central „Produktbildanforderungen")')));
    }

    // -- A+-Module + Brand Story
    var aN = zaehleAplus(d);
    var bs = !!d.querySelector('#aplusBrandStory_feature_div');
    // nur informativ (mut): ob A+ da ist, entscheidet r.aplus (onpage-Chip); eine Mindestzahl Module gibt Amazon nicht vor
    ctx.secQ.appendChild(mark(ui.chip(aN + ' <span class="lc-k">A+ Module</span>' + (bs ? ' <span class="lc-k">+ Brand Story</span>' : ''),
      'mut', (aN ? aN + ' A+-Module gezählt' : 'keine A+-Module gezählt (.aplus-module)') + (bs ? ', Brand Story vorhanden' : ''))));

    // -- Vergleichstabelle
    var cmp = d.querySelector('#HLCXComparisonWidget_feature_div, .a-cardui.comparison-table');
    if (cmp) ctx.secQ.appendChild(mark(ui.chip('Vergleich', 'ok', 'Amazons Vergleichstabelle vorhanden')));

    // -- 360°-Ansicht
    var spin = d.querySelector('#altImages li.item [data-spin], .a-360-container');
    if (spin) ctx.secQ.appendChild(mark(ui.chip('360°', 'ok', '360°-Ansicht vorhanden')));

    // -- Zusatzsektion mit Bild-Links + Kopier-Chip
    if (typeof ctx.sec !== 'function' || !urls.length) return;
    if (d.querySelector('.lc-media-details')) return;
    var box = ctx.sec('Media-Details', 'bullets');
    box.classList.add('lc-media-details');
    var liste = ui.el('div', 'a-section a-spacing-mini');
    urls.forEach(function (u, i) {
      var a = ui.el('a', 'a-link-normal', ui.esc('Hi-Res ' + (i + 1) + ' (' + (bildBreite(u) || '?') + ' px)'));
      a.href = u; a.target = '_blank'; a.rel = 'noopener';
      var wrap = ui.el('div', 'a-size-small');
      wrap.appendChild(a);
      liste.appendChild(wrap);
    });
    box.appendChild(liste);
    box.appendChild(ui.textChip('Alle Bilder-Links', urls.join('\n'), urls.length + ' Hi-Res-Bilder-URLs in die Zwischenablage'));
  });

  H.details = { hiResUrls: hiResUrls, bildBreite: bildBreite, zaehleVideos: zaehleVideos, zaehleAplus: zaehleAplus };
})();
