/* Rezensions-Einblick (Helium 10 "Review Insights" light) - NUR aus der
   Produktseite, kein Netz (die Rezensionsseiten verlangen Login).
   Quellen (Stand Dumps 08/2026):
     - Amazons "Die Kunden sagen": [data-testid="aspect-list"] [aria-label]
       "Positiver|Negativer|Gemischter Aspekt <Name>, <n> Erwähnungen"
     - Histogramm: #histogramTable [aria-label="<p> Prozent der Bewertungen haben <s> Sterne"]
     - sichtbare Rezensionen: [data-hook="review"] mit review-star-rating (a-star-N),
       reviewTitle / review-title, reviewRichContentContainer / reviewText / review-body,
       review-date ("Bewertet in Deutschland am 29. Juni 2023")
   Sektion "Rezensionen" VOR Amazons Kundenrezensionen: Kennzahl-Chips, Aspekt-
   Chips, kritische Zitate, "Alle Rezensionen laden" (Rezensionsseiten mit dem
   Login des Nutzers, 5 Seiten) und Markdown-Export fuer ChatGPT.
   Die fruehere Wort-Haeufigkeit war Rauschen (LO, 29.08.) - weg. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  // extract.js liefert Zahlen; Strings koennen "4,4" (Schnitt) oder "2.297" (Anzahl) sein
  var num = function (v) { var n = typeof v === 'number' ? v : parseFloat(String(v == null ? '' : v).replace(',', '.')); return isFinite(n) ? n : null; };
  var ganz = function (v) { var n = typeof v === 'number' ? v : parseInt(String(v == null ? '' : v).replace(/\D/g, ''), 10); return isFinite(n) ? n : null; };
  var q = function (root, sel) { return root ? root.querySelector(sel) : null; };
  var qt = function (root, sel) { return clean((q(root, sel) || {}).textContent); };

  /* ponytail: Substantiv-Heuristik = Grossbuchstabe + >= 5 Zeichen. Satzanfaenge
     und Fuellwoerter ueber die Stoppliste; feiner wird es nur mit echtem Tagger. */
  var STOP = {};
  ('Amazon Artikel Produkt Produkte Produkts Lieferung Versand Verpackung Wochen Tagen Monate Monaten Monat Jahren Jahre ' +
   'Leider Dieser Diese Dieses Diesen Diesem Super Alles Allerdings Wurde Wurden Haben Hatte Hatten Nicht Nach Auch Aber Dann Gerne ' +
   'Absolut Meine Meiner Meinem Meinen Seine Seiner Unser Unsere Unserem Unseren Einen Einem Einer Eines Etwas Nichts Immer Jetzt ' +
   'Heute Gestern Wenn Wieder Schon Ganz Gute Guter Gutes Guten Kann Konnte Werden Bestellt Bestellung Gekauft Ansonsten ' +
   'Trotzdem Jedoch Weiter Empfehlen Empfehlung Klasse Prima Dafür Damit Danach Davon Dabei Darum Deshalb Durch Ohne Über Unter ' +
   'Zwischen Zudem Zuerst Bisher Bereits Viele Vielen Vieles Andere Anderen Einige Einigen Mehrere Insgesamt Fazit Positiv Negativ ' +
   'Tolle Tolles Toller Perfekt Schnell Schnelle Leicht Leichte Einfach Einfache Wirklich Natürlich Eigentlich Vielleicht ' +
   'Wahrscheinlich Ebenfalls Außerdem Inzwischen Mittlerweile Sonst Somit Sogar Allen Alle Aller Ihre Ihren Ihrem Ihrer Seit ' +
   'Seitdem Sterne Sternen Stern Rezension Bewertung Bewertungen Kunden Deutschland Hallo Danke Vielen Nochmal Endlich Genau ' +
   'Obwohl Sofort Zuvor Bevor Nachdem Während Weil Falls Sowie Sowohl Weder Deswegen Daher Zwar Doch Sehr Empfehlenswert ' +
   'Vollkommen Zufrieden Begeistert Enttäuscht Mangelhaft Schade Optimal Klasse Kaufen Kaufe Empfehle Habe Bekommen Erhalten ' +
   'Angekommen Geliefert Bestellte Zurück Retour Rücksendung Rückgabe Bilder Beschreibung Beschrieben Angegeben Angaben')
    .split(' ').forEach(function (w) { STOP[w] = 1; });

  function lesen(doc) {
    var d = doc || document;
    // -- Histogramm
    var vert = {};
    Array.prototype.forEach.call(d.querySelectorAll('#histogramTable [aria-label]'), function (n) {
      var m = clean(n.getAttribute('aria-label')).match(/(\d+)\s*Prozent.*?(\d)\s*Stern/i);
      if (m && vert[m[2]] == null) vert[m[2]] = parseInt(m[1], 10);
    });
    // -- Aspekte
    var aspekte = [], seen = {};
    Array.prototype.forEach.call(d.querySelectorAll('[data-testid="aspect-list"] [aria-label], [data-hook="cr-insights-aspect-link"]'), function (n) {
      var m = clean(n.getAttribute('aria-label')).match(/^(Positiver|Negativer|Gemischter)\s+Aspekt\s+(.+?)(?:,\s*(\d+)\s*Erwähnung\w*)?$/i);
      if (!m || seen[m[2].toLowerCase()]) return;
      seen[m[2].toLowerCase()] = 1;
      aspekte.push({ name: m[2], art: /^Pos/i.test(m[1]) ? 'ok' : (/^Neg/i.test(m[1]) ? 'bad' : 'mut'), n: m[3] ? parseInt(m[3], 10) : null });
    });
    // -- sichtbare Rezensionen (Bild-Popover wiederholt Rezensionen -> per ID dedupen)
    var revs = [], ids = {};
    Array.prototype.forEach.call(d.querySelectorAll('[data-hook="review"]'), function (r) {
      var id = r.id || '';
      if (id && ids[id]) return;
      ids[id] = 1;
      var star = q(r, '[data-hook="review-star-rating"], .review-rating');
      var st = null;
      if (star) {
        var cm = (star.className || '').match(/a-star-(\d)/);
        st = cm ? parseInt(cm[1], 10) : num((clean(star.textContent).match(/^([\d,.]+)\s*von/) || [])[1]);
      }
      var text = qt(r, '[data-hook="reviewRichContentContainer"]') || qt(r, '[data-hook="reviewText"], [data-hook="review-body"]')
        .replace(/(Brief|Full) content visible, double tap to read (full|brief) content\./g, '').replace(/\s*Mehr lesen\s*$/, '');
      var dm = qt(r, '[data-hook="review-date"]').match(/am\s+(\d{1,2}\.\s*\S+\s+\d{4})/);
      revs.push({ id: id, sterne: st, titel: qt(r, '[data-hook="reviewTitle"], [data-hook="review-title"]'), text: clean(text), datum: dm ? dm[1] : '' });
    });
    return { verteilung: vert, aspekte: aspekte, rezensionen: revs, summary: qt(d, '[data-testid="overall-summary"]') };
  }

  var fmtBew = function (b) { return b == null ? '–' : String(b).replace('.', ','); };
  var sterneTxt = function (n) { return n == null ? '?' : n + ' ★'; };
  /* Filter "nur negativ / nur positiv" (LO, 30.08.). Liegt auf Modul-Ebene,
     damit er den 800ms-Varianten-Rebuild ueberlebt (die IIFE laeuft nur einmal,
     der panel-Callback wird neu aufgerufen). Kein storage - Tab-Zustand reicht. */
  var filterModus = '';   // '' | 'neg' (1-2 Sterne) | 'pos' (4-5 Sterne)

  function markdown(ctx, R) {
    var r = ctx.row || {}, nf = ctx.ui.nf;
    var out = ['# Rezensionen ' + ctx.asin + (r.titel ? ' – ' + clean(r.titel) : ''), ''];
    out.push('Ø ' + fmtBew(num(r.bewertung)) + ' ★ (' + (ganz(r.anzahl_bewertungen) != null ? nf(ganz(r.anzahl_bewertungen)) : '?') + ' Bewertungen)');
    var v = ['5', '4', '3', '2', '1'].filter(function (s) { return R.verteilung[s] != null; }).map(function (s) { return s + ' ★ ' + R.verteilung[s] + ' %'; });
    if (v.length) out.push('Verteilung: ' + v.join(' · '));
    if (R.summary) out.push('', 'Die Kunden sagen: ' + R.summary);
    if (R.aspekte.length) out.push('', 'Aspekte: ' + R.aspekte.map(function (a) {
      return (a.art === 'ok' ? '+ ' : (a.art === 'bad' ? '− ' : '± ')) + a.name + (a.n != null ? ' (' + a.n + ')' : '');
    }).join(' · '));
    out.push('', '## Rezensionen (' + R.rezensionen.length + (R.geladen ? ', ' + R.geladen + ' Seiten geladen' : ', nur Produktseite') + ')');
    R.rezensionen.forEach(function (x) {
      out.push('', '### ' + sterneTxt(x.sterne) + (x.datum ? ' · ' + x.datum : '') + (x.titel ? ' · ' + x.titel : ''));
      if (x.text) out.push(x.text);
    });
    return out.join('\n');
  }

  /* Rezensionsseiten mit dem Login des Nutzers lesen (same-origin, Cookies), neueste
     zuerst, bis zu `seiten` Seiten a 10, 700 ms Abstand; Login-/Captcha-Wand -> Abbruch. */
  /* Durchlaeufe: erst "alle, neueste zuerst" Seite 1..seiten, dann je Sternfilter
     (Amazon kappt jede Liste bei ~10 Seiten; ueber die Sternfilter kommt man an
     bis zu 5x so viele Rezensionen). Ein Durchlauf endet, sobald eine Seite nichts
     Neues bringt. Jeder Abbruchgrund wird mitgegeben (LO 30.08.: "bricht ab bei 11"
     - vorher stand nirgends, WARUM). */
  function laden(asin, seiten, fortschritt, cb, weiter) {
    var alle = [], ids = {}, gruende = [], anfragen = 0, MAXREQ = 120;   // 6 Filter x max 20 Seiten
    var laeufe = [{ filter: '', name: 'alle' }, { filter: 'one_star', name: '1★' }, { filter: 'two_star', name: '2★' },
                  { filter: 'three_star', name: '3★' }, { filter: 'four_star', name: '4★' }, { filter: 'five_star', name: '5★' }];
    var li = 0, i = 1;
    var next = function () {
      /* weiter() = "gehoert die Seite noch dieser ASIN?" - ohne den Check
         liefen nach Varianten-/Seitenwechsel bis zu 120 Requests ueber ~84s
         gegen eine Seite weiter, die niemand mehr sieht (Review 31.08.) */
      if (weiter && !weiter()) return cb(null, alle, gruende.concat(['abgebrochen: Seite gewechselt']).join(' · '));
      if (li >= laeufe.length || anfragen >= MAXREQ) return cb(null, alle, gruende.join(' · '));
      var lauf = laeufe[li];
      if (i > seiten) { li++; i = 1; return next(); }
      fortschritt(lauf.name + ' S. ' + i, alle.length);
      var url = '/product-reviews/' + encodeURIComponent(asin) + '/ref=cm_cr_arp_d_viewopt_srt?ie=UTF8&reviewerType=all_reviews&sortBy=recent' +
        (lauf.filter ? '&filterByStar=' + lauf.filter : '') + '&pageNumber=' + i;
      anfragen++;
      fetch(url, { credentials: 'include' }).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status + ' bei ' + lauf.name + ' S. ' + i);
        return r.text();
      }).then(function (html) {
        if (html.indexOf('data-hook="review"') < 0) {
          if (/ap\/signin/.test(html)) throw new Error('Login nötig – bei Amazon anmelden');
          // "Roboter" flog raus: das Wort steht in jeder Saugroboter-Rezension
          if (/validateCaptcha|opfcaptcha/i.test(html)) throw new Error('Captcha');
          gruende.push(lauf.name + ' S. ' + i + ': keine Rezensionen im HTML' + (/aui-primitive|k-injected/.test(html) ? ' (neue React-Rezensionsseite)' : ''));
          li++; i = 1; return setTimeout(next, 700);
        }
        var neu = 0, gesamt = 0;
        lesen(new DOMParser().parseFromString(html, 'text/html')).rezensionen.forEach(function (x) {
          gesamt++;
          var k = x.id || (x.datum + '|' + x.titel);
          if (ids[k]) return;
          ids[k] = 1; alle.push(x); neu++;
        });
        if (!neu) { gruende.push(lauf.name + ' S. ' + i + ': ' + gesamt + ' Rezensionen, alle schon bekannt'); li++; i = 1; }
        else i++;
        setTimeout(next, 700);
      }).catch(function (e) { cb(e, alle, gruende.join(' · ')); });
    };
    next();
  }

  /* Wortanalyse (Helium 10 "Review Insights" light, LO 31.08.): haeufigste Woerter/
     Phrasen getrennt nach kritisch (<=3 Sterne) und positiv (>=4 Sterne), lokal aus
     den geladenen Rezensionen, kein LLM. Eigene Stoppliste (lowercase) - die STOP-
     Liste oben ist fuer die Aspekt-Grossbuchstaben-Heuristik, nicht wiederverwendbar. */
  var WORT_STOP = {};
  // Nur FUNKTIONSWOERTER filtern (Artikel, Pronomen, Hilfsverben, Fueller) -
  // Bewertungswoerter (gut, schlecht, super, laut, wackelig ...) tragen die
  // Aussage und bleiben drin (LO 01.09.: "den daß dass usw" kamen durch).
  ('der die das den dem des und ist sind war waren wurde wurden worden nicht für mit aber sehr auch ' +
   'ein eine einen einem einer eines kein keine keinen keinem keiner nach schon noch nur ganz alle ' +
   'alles allem allen man sich dass daß wie was wer wem wen wenn dann denn dann mehr weniger sein ' +
   'seine seinem seinen seiner bin bist seid ihre ihrem ihren ihrer ihr mein meine meinem meinen ' +
   'meiner dein deine uns euch ich du er sie es wir wird werden würde würden hat hatte hatten habe ' +
   'haben hast habt hätte hätten kann konnte konnten könnte könnten können muss musste mussten ' +
   'müssen soll sollte sollten will wollte wollten wollen darf durfte dürfen von zu zum zur am im ' +
   'in an auf aus bei beim vom bis durch gegen ohne um unter über vor zwischen ins ans aufs übers ' +
   'hier dort dabei dazu damit dafür davon daran darauf jetzt immer wieder also doch halt eben mal ' +
   'etwas nichts diese dieser dieses diesem diesen jede jeder jedes andere anderen macht machen ' +
   'gemacht gibt geben hab gab ja nein oder weil obwohl trotzdem deshalb somit sowie bzw ' +
   'the and is are was were be been being have has had do does did will would can could should ' +
   'shall may might must this that these those with for not but very so to on at by from as it ' +
   'its you he we they them his her our your of or if all just too than then there here when ' +
   'what which one get got had ' +
   'produkt artikel amazon sterne stern gekauft bestellt rezension bewertung lieferung versand ' +
   'item product review stars bought delivery shipping')
    .split(' ').forEach(function (w) { WORT_STOP[w] = 1; });

  var tokenisieren = function (s) {
    return (String(s || '').toLowerCase().match(/[a-zäöüß]{3,}/g) || []).filter(function (w) { return !WORT_STOP[w]; });
  };

  // Zaehlt Einzelwoerter + Zweiwort-Phrasen (aus der gefilterten Wortfolge, keine
  // Original-Adjazenz-Garantie - reicht als Heuristik), Top 8, mit Beispiel-Schnipseln.
  function haeufigkeit(reviews) {
    var wc = {}, bc = {}, texte = [];
    reviews.forEach(function (x) {
      var voll = clean((x.titel || '') + ' ' + (x.text || ''));
      if (!voll) return;
      texte.push(voll);
      var toks = tokenisieren(voll);
      toks.forEach(function (w) { wc[w] = (wc[w] || 0) + 1; });
      for (var i = 0; i < toks.length - 1; i++) { var p = toks[i] + ' ' + toks[i + 1]; bc[p] = (bc[p] || 0) + 1; }
    });
    var top = Object.keys(wc).map(function (k) { return { key: k, n: wc[k] }; })
      .concat(Object.keys(bc).filter(function (k) { return bc[k] >= 2; }).map(function (k) { return { key: k, n: bc[k] }; }))
      .sort(function (a, b) { return b.n - a.n; }).slice(0, 8);
    top.forEach(function (t) {
      var erste = t.key.split(' ')[0], bsp = [];
      for (var i = 0; i < texte.length && bsp.length < 3; i++) {
        var idx = texte[i].toLowerCase().indexOf(erste);
        if (idx < 0) continue;
        var a = Math.max(0, idx - 40), b = Math.min(texte[i].length, idx + erste.length + 40);
        bsp.push((a > 0 ? '…' : '') + texte[i].slice(a, b) + (b < texte[i].length ? '…' : ''));
      }
      t.beispiele = bsp;
    });
    return { n: reviews.length, top: top };
  }

  function analyseText(ctx, R, analyse) {
    var krit = R.rezensionen.filter(function (x) { return x.sterne != null && x.sterne <= 3; });
    var pos = R.rezensionen.filter(function (x) { return x.sterne != null && x.sterne >= 4; });
    var sz = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    R.rezensionen.forEach(function (x) { if (sz[x.sterne] != null) sz[x.sterne]++; });
    var out = ['Rezensions-Analyse ' + ctx.asin, '',
      'Rezensionen gesamt: ' + R.rezensionen.length + ' (1★ ' + sz[1] + ' · 2★ ' + sz[2] + ' · 3★ ' + sz[3] + ' · 4★ ' + sz[4] + ' · 5★ ' + sz[5] + ')'];
    if (R.rezensionen.length < 10) out.push('(nur ' + R.rezensionen.length + ' Rezensionen geladen – Basis dünn)');
    var liste = function (label, daten) {
      out.push('', label + ':');
      if (!daten.top.length) out.push('- keine auffälligen Wörter');
      daten.top.forEach(function (t) { out.push('- ' + t.key + ' (' + t.n + ')'); });
    };
    liste('Häufig in kritischen (' + analyse.krit.n + ')', analyse.krit);
    liste('Häufig in positiven (' + analyse.pos.n + ')', analyse.pos);
    var bsp = function (label, arr) {
      out.push('', label + ':');
      if (!arr.length) out.push('- keine');
      arr.slice(0, 2).forEach(function (x) { var t = x.text || x.titel; out.push('- „' + (t.length > 200 ? t.slice(0, 199) + '…' : t) + '"'); });
    };
    bsp('Beispiele kritisch', krit);
    bsp('Beispiele positiv', pos);
    return out.join('\n');
  }

  H.panel.push(function (ctx) {
    var ui = ctx.ui, r = ctx.row || {};
    if (!ui || typeof ctx.sec !== 'function' || document.querySelector('.lc-rev')) return;
    var R = lesen(document);
    R.geladen = 0;
    var box = ctx.sec('Rezensionen', 'reviews');
    box.classList.add('lc-rev');

    // -- Kennzahlen
    var row = ui.el('div', 'lc-row a-spacing-small');
    var h10Slot = ui.el('span', 'lc-h10-slot');                  // Chips + Sparkline aus H10 (falls Toggle an)
    box.appendChild(h10Slot);
    if (LC.h10 && LC.h10.ready) {
      LC.h10.ready().then(function (login) {
        if (!login || ui.aktuelleAsin() !== ctx.asin) return;
        var host = 'amazon.de';
        LC.h10.cache('reviews:' + ctx.asin, 12 * 60, function () { return LC.h10.reviewChart(ctx.asin, host, 365); }).then(function (res) {
          if (ui.aktuelleAsin() !== ctx.asin) return;
          if (!res || !res.ok) { h10Slot.appendChild(ui.chip('H10 Review-Chart: HTTP ' + (res && res.status), 'bad', 'Toggle bleibt an, siehe Popup')); return; }
          var arr = (res.data && res.data.results && (res.data.results.reviews || res.data.results.reviewsChart)) || [];
          if (arr.length < 2) { h10Slot.appendChild(ui.chip('H10 Reviews: keine Historie', 'mut')); return; }
          arr.sort(function (a, b) { return (a.timestamp || a.date || 0) > (b.timestamp || b.date || 0) ? 1 : -1; });
          var norm = arr.map(function (x) {
            var ts = x.timestamp || x.date; if (typeof ts === 'string') ts = Date.parse(ts) / 1000;
            return { ts: ts, count: x.count == null ? x.reviewCount : x.count, rating: x.rating == null ? x.avgRating : x.rating };
          }).filter(function (x) { return x.ts && x.count != null; });
          var last = norm[norm.length - 1], nowSec = Date.now() / 1000;
          function seit(tage) {
            for (var i = norm.length - 1; i >= 0; i--) if (nowSec - norm[i].ts >= tage * 86400) return last.count - norm[i].count;
            return null;
          }
          var d30 = seit(30), d90 = seit(90), d365 = last.count - norm[0].count;
          var kind = function (n) { return n == null ? 'mut' : (n > 0 ? 'ok' : (n < 0 ? 'bad' : 'mut')); };
          if (d30 != null) h10Slot.appendChild(ui.chip('Reviews 30 T <b>' + (d30 >= 0 ? '+' : '') + ui.nf(d30) + '</b>', kind(d30), 'Zuwachs in den letzten 30 Tagen laut Helium 10'));
          if (d90 != null) h10Slot.appendChild(ui.chip('Reviews 90 T <b>' + (d90 >= 0 ? '+' : '') + ui.nf(d90) + '</b>', kind(d90), 'Zuwachs in den letzten 90 Tagen'));
          h10Slot.appendChild(ui.chip('Reviews 365 T <b>' + (d365 >= 0 ? '+' : '') + ui.nf(d365) + '</b>', kind(d365), 'Zuwachs im letzten Jahr laut Helium 10'));
          var rf = norm[0].rating, rl = last.rating;
          if (rf != null && rl != null && rf !== rl) {
            var pf = function (v) { return Number(v).toFixed(1).replace('.', ','); };
            h10Slot.appendChild(ui.chip('★ ' + pf(rf) + ' → ' + pf(rl), rl >= rf ? 'ok' : 'bad', 'Bewertungsschnitt vor 365 Tagen vs. heute'));
          }
          /* Balken "neue Rezensionen je Monat" (LO 30.08.: die kumulierte Linie ohne
             Achsen war nicht lesbar). Aus der H10-Zaehlerhistorie: Stand am Monatsende
             minus Stand am Vormonatsende. Beschriftet mit Monat und Wert. */
          var MON = ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];
          var standBis = function (ts) { var c = null; for (var i = 0; i < norm.length; i++) { if (norm[i].ts <= ts) c = norm[i].count; else break; } return c; };
          var monate = [];
          var dA = new Date(norm[0].ts * 1000), dE = new Date(last.ts * 1000);
          var y = dA.getFullYear(), m = dA.getMonth(), vor = norm[0].count;
          while (y < dE.getFullYear() || (y === dE.getFullYear() && m <= dE.getMonth())) {
            var ende = new Date(y, m + 1, 1).getTime() / 1000 - 1;      // letzte Sekunde des Monats
            var stand = standBis(Math.min(ende, last.ts));
            if (stand == null) stand = vor;
            monate.push({ label: MON[m] + (m === 0 || !monate.length ? ' ' + String(y).slice(2) : ''), neu: Math.max(0, stand - vor), teil: ende > last.ts || monate.length === 0 });
            vor = stand; m++; if (m > 11) { m = 0; y++; }
          }
          var W = 360, HH = 84, PL = 6, PR = 6, PT = 14, PB = 16;
          var maxNeu = Math.max.apply(null, monate.map(function (x) { return x.neu; }).concat([1]));
          var bw = (W - PL - PR) / monate.length, gap = Math.min(6, bw * 0.25);
          var bars = monate.map(function (x, i) {
            var h = (HH - PT - PB) * x.neu / maxNeu, x0 = PL + i * bw + gap / 2, y0 = HH - PB - h;
            return '<rect x="' + x0.toFixed(1) + '" y="' + y0.toFixed(1) + '" width="' + (bw - gap).toFixed(1) + '" height="' + h.toFixed(1) + '" fill="currentColor" opacity="' + (x.teil ? '.35' : '.7') + '"/>' +
              '<text x="' + (x0 + (bw - gap) / 2).toFixed(1) + '" y="' + (y0 - 3).toFixed(1) + '" text-anchor="middle" fill="currentColor" class="a-size-mini">' + (x.neu ? '+' + x.neu : '0') + '</text>' +
              '<text x="' + (x0 + (bw - gap) / 2).toFixed(1) + '" y="' + (HH - 4) + '" text-anchor="middle" fill="currentColor" class="a-size-mini" opacity=".6">' + x.label + '</text>';
          }).join('');
          var svg = '<svg viewBox="0 0 ' + W + ' ' + HH + '" data-lc="1" style="display:block;width:100%;height:auto;margin-top:4px">' +
            '<line x1="' + PL + '" y1="' + (HH - PB) + '" x2="' + (W - PR) + '" y2="' + (HH - PB) + '" stroke="currentColor" opacity=".3"/>' + bars + '</svg>';
          var proMonat = monate.length > 1 ? (d365 / Math.max(1, monate.length - 1)) : d365;
          box.appendChild(ui.el('div', 'lc-k', 'Neue Rezensionen je Monat (Helium 10, 365 Tage) · gesamt ' + ui.nf(last.count) +
            ' · Ø ' + String(Math.round(proMonat * 10) / 10).replace('.', ',') + '/Monat' +
            ' <span style="opacity:.6">(heller Balken = angebrochener Monat)</span>' + svg));
        }).catch(function (e) { h10Slot.appendChild(ui.chip('H10 Review-Chart Fehler', 'bad', String(e && e.message || e))); });
      });
    }

    var bew = num(r.bewertung), anz = ganz(r.anzahl_bewertungen);
    row.appendChild(ui.chip((bew != null ? fmtBew(bew) + ' ★' : 'keine Bewertung') + (anz != null ? ' <span class="lc-k">(' + ui.nf(anz) + ')</span>' : ''),
      bew == null ? 'mut' : (bew >= 4 ? 'ok' : 'bad'), 'Durchschnitt und Anzahl laut Produktseite'));
    var schlecht = (R.verteilung['1'] || 0) + (R.verteilung['2'] || 0);
    if (R.verteilung['1'] != null || R.verteilung['2'] != null) {
      row.appendChild(ui.chip('<span class="lc-k">1–2 ★</span> ' + schlecht + ' %', schlecht >= 15 ? 'bad' : 'ok',
        'Anteil 1- und 2-Sterne-Bewertungen (Histogramm): ' + ['5', '4', '3', '2', '1'].map(function (x) { return x + '★ ' + (R.verteilung[x] == null ? '?' : R.verteilung[x]) + ' %'; }).join(' · ')));
    }
    var zaehl = ui.chip('', 'mut');
    row.appendChild(zaehl);
    box.appendChild(row);

    // -- Aspekte (Amazons eigene Auswertung)
    if (R.aspekte.length) {
      var arow = ui.el('div', 'lc-row a-spacing-small');
      R.aspekte.slice(0, 12).forEach(function (x) {
        arow.appendChild(ui.chip(ui.esc(x.name) + (x.n != null ? ' <span class="lc-k">' + x.n + '</span>' : ''), x.art,
          (x.art === 'ok' ? 'positiv' : (x.art === 'bad' ? 'negativ' : 'gemischt')) + (x.n != null ? ' · ' + x.n + ' Erwähnungen' : '') + ' (Amazons „Die Kunden sagen")'));
      });
      box.appendChild(arow);
    }

    // -- Kritik + Aktionen (werden nach dem Laden neu aufgebaut)
    var dyn = ui.el('div', 'a-section a-spacing-none');
    box.appendChild(dyn);
    // -- Wortanalyse (eigener Block ausserhalb von dyn, damit Filter-Klicks ihn nicht wegreissen)
    var aBox = ui.el('div', 'a-section a-spacing-small');
    aBox.style.display = 'none';
    box.appendChild(aBox);
    var analyse = null;
    var zeigeAnalyse = function () {
      var krit = R.rezensionen.filter(function (x) { return x.sterne != null && x.sterne <= 3; });
      var pos = R.rezensionen.filter(function (x) { return x.sterne != null && x.sterne >= 4; });
      analyse = { krit: haeufigkeit(krit), pos: haeufigkeit(pos) };
      aBox.innerHTML = '';
      if (R.rezensionen.length < 10) aBox.appendChild(ui.el('div', 'lc-k a-spacing-mini', '(nur ' + R.rezensionen.length + ' Rezensionen geladen – Basis dünn)'));
      var block = function (titel, daten, kind) {
        if (!daten.top.length) return;
        aBox.appendChild(ui.el('div', 'a-size-small a-text-bold a-spacing-mini', titel + ' (' + daten.n + ')'));
        var wrow = ui.el('div', 'lc-row a-spacing-small');
        daten.top.forEach(function (t) {
          wrow.appendChild(ui.chip(ui.esc(t.key) + ' <span class="lc-k">(' + t.n + ')</span>', kind, t.beispiele.join(' · ') || 'keine Textstelle gefunden'));
        });
        aBox.appendChild(wrow);
      };
      block('Häufig in kritischen', analyse.krit, 'bad');
      block('Häufig in positiven', analyse.pos, 'ok');
      if (analyse.krit.top.length || analyse.pos.top.length) {
        var ak = ui.chip('Analyse kopieren ⧉', 'mut lc-copy', 'Zusammenfassung für Einkauf/Produktmanagement (Sternstufen, Top-Wörter, Beispiele)');
        ak.addEventListener('click', function (ev) {
          ev.preventDefault(); ev.stopPropagation();
          navigator.clipboard.writeText(analyseText(ctx, R, analyse)).then(function () {
            ak.innerHTML = 'Analyse kopiert ✓';
            setTimeout(function () { ak.innerHTML = 'Analyse kopieren ⧉'; }, 1200);
          }).catch(function () { ak.innerHTML = 'Kopieren fehlgeschlagen'; });
        });
        aBox.appendChild(ak);
      }
    };
    var zeigen = function () {
      var krit = R.rezensionen.filter(function (x) { return x.sterne != null && x.sterne <= 3; });
      var gefiltert = filterModus === 'neg' ? R.rezensionen.filter(function (x) { return x.sterne != null && x.sterne <= 2; })
                    : filterModus === 'pos' ? R.rezensionen.filter(function (x) { return x.sterne != null && x.sterne >= 4; })
                    : null;
      zaehl.innerHTML = R.rezensionen.length + ' <span class="lc-k">Rezensionen ' + (R.geladen ? 'geladen' : 'auf der Seite') + '</span>' +
        (gefiltert ? ' · <b>' + gefiltert.length + '</b> <span class="lc-k">im Filter</span>' : (krit.length ? ' · ' + krit.length + ' ≤ 3 ★' : ''));
      dyn.innerHTML = '';
      var zitate = gefiltert || krit;
      var farbe = filterModus === 'pos' ? 'lc-ok' : 'lc-bad';
      dyn.appendChild(ui.el('div', 'a-size-small a-text-bold',
        filterModus === 'neg' ? 'Nur negativ (1–2 ★)' : filterModus === 'pos' ? 'Nur positiv (4–5 ★)' : 'Kritik (≤ 3 ★)'));
      if (zitate.length) {
        zitate.slice(0, R.geladen ? 6 : 3).forEach(function (x) {
          var t = x.text || x.titel;
          dyn.appendChild(ui.el('div', 'a-size-small a-color-secondary a-spacing-mini',
            '<span class="' + farbe + '">' + ui.esc(sterneTxt(x.sterne)) + '</span>' + (x.datum ? ' <span class="lc-k">' + ui.esc(x.datum) + '</span>' : '') +
            ' „' + ui.esc(t.length > 220 ? t.slice(0, 219) + '…' : t) + '"'));
        });
      } else dyn.appendChild(ui.el('div', 'lc-k', gefiltert ? 'keine Rezension im Filter' :
        (R.geladen ? 'keine kritische Rezension unter den geladenen' : 'keine kritische Rezension auf der Seite')));
      var crow = ui.el('div', 'lc-row a-spacing-top-small');
      // Filter-Chips: gegenseitig exklusiv (Skalar), Klick auf aktiven = aus.
      // In crow statt row, damit sie mit dyn.innerHTML='' den Aktiv-Zustand mitziehen.
      var mk = function (mode, label, kind, tip) {
        var c = ui.chip(label, (filterModus === mode ? kind : 'mut') + ' lc-copy', tip);
        c.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); filterModus = filterModus === mode ? '' : mode; zeigen(); });
        return c;
      };
      crow.appendChild(mk('neg', 'nur negativ (1–2 ★)', 'bad', 'Nur 1- und 2-Sterne-Rezensionen zeigen – Klick auf den aktiven Filter schaltet ihn aus'));
      crow.appendChild(mk('pos', 'nur positiv (4–5 ★)', 'ok', 'Nur 4- und 5-Sterne-Rezensionen zeigen – Klick auf den aktiven Filter schaltet ihn aus'));
      var av = ui.chip('Wortanalyse ' + (aBox.style.display === 'none' ? '▸' : '▾'), 'mut lc-copy',
        'Häufigste Wörter/Phrasen getrennt nach kritischen (≤3★) und positiven (≥4★) Rezensionen – lokal gezählt, ohne LLM');
      av.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        aBox.style.display = aBox.style.display === 'none' ? '' : 'none';
        if (aBox.style.display !== 'none') zeigeAnalyse();
        zeigen();
      });
      crow.appendChild(av);
      if (!R.geladen) {
        var ld = ui.chip('Alle Rezensionen laden (bis 10 Seiten + je Stern)', '', 'Liest die Rezensionsseiten mit deinem Amazon-Login: erst alle (neueste zuerst), dann je Sternfilter – für die Analyse mit ChatGPT');
        ld.classList.add('lc-copy');
        ld.addEventListener('click', function (ev) {
          ev.preventDefault(); ev.stopPropagation();
          if (ld.dataset.laeuft) return;
          ld.dataset.laeuft = '1';
          laden(ctx.asin, 10, function (wo, n) { ld.innerHTML = 'lade ' + ui.esc(wo) + ' … <span class="lc-k">' + n + ' bisher</span>'; }, function (err, alle, grund) {
            if (ui.aktuelleAsin() !== ctx.asin) return;
            if (alle.length) {
              var ids = {}; alle.forEach(function (x) { ids[x.id || (x.datum + '|' + x.titel)] = 1; });
              R.rezensionen.forEach(function (x) { var k = x.id || (x.datum + '|' + x.titel); if (!ids[k]) { ids[k] = 1; alle.push(x); } });
              R.rezensionen = alle; R.geladen = Math.ceil(alle.length / 10);
            }
            zeigen();
            if (aBox.style.display !== 'none') zeigeAnalyse();   // schon offen -> automatisch mit neu geladenen Rezensionen aktualisieren
            if (err) dyn.appendChild(ui.chip('Laden abgebrochen: ' + ui.esc(err.message || 'Fehler'), 'bad', grund || ''));
            else if (grund) dyn.appendChild(ui.chip(alle.length + ' Rezensionen geladen · Ende: ' + ui.esc(grund), alle.length > 30 ? 'mut' : 'bad', 'Warum nicht mehr: ' + grund));
          }, function () { return ui.aktuelleAsin() === ctx.asin; });   // Abbruch bei Varianten-/Seitenwechsel
        });
        crow.appendChild(ld);
      }
      var cp = ui.chip('Rezensionen als Markdown kopieren ⧉', 'mut lc-copy', 'Ø, Verteilung, Aspekte und alle Rezensionen für den Listing-Skill/ChatGPT');
      cp.addEventListener('click', function (ev) {
        ev.preventDefault(); ev.stopPropagation();
        navigator.clipboard.writeText(markdown(ctx, R)).then(function () {
          cp.innerHTML = 'Rezensionen als Markdown kopieren ✓';
          setTimeout(function () { cp.innerHTML = 'Rezensionen als Markdown kopieren ⧉'; }, 1200);
        }).catch(function () { cp.innerHTML = 'Kopieren fehlgeschlagen'; });
      });
      crow.appendChild(cp);
      dyn.appendChild(crow);
    };
    zeigen();
  });

  H.reviews = { lesen: lesen, markdown: markdown, laden: laden };
})();
