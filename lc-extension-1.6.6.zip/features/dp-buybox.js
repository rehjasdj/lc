/* Buybox-Tiefe (Paket A aus dem Helium/Keepa-Abgleich vom 27.08.2026):
     - Buybox-Diagnose: eigenes Angebot gegen den Gewinner (Preisabstand %,
       FBA/FBM, Lieferdatum) - aus der AOD-Liste (aod:<ASIN>, von onpage.js gefuellt)
     - Buybox-Quote aus dem lokalen Verlauf hist:<ASIN> (ehrlich mit Messzahl)
     - Aenderungen seit dem letzten Besuch (Preis, BSR, Buybox)
     - Kaufzahl-Badge der Produktseite
   Alles aus der Seite und chrome.storage.local, keine neuen Rechte.
   Eigene Zeile hinter der Buybox-Zeile, damit priceRow.innerHTML='' (Preisjagd)
   nichts davon loescht. Nur ui.el/ui.chip benutzen (data-lc, Scrape-Filter). */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];

  var EIGEN = /deuba|casaria|monzana|gardebruk/i;
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };
  var num = function (s) { var n = parseInt(String(s == null ? '' : s).replace(/\D/g, ''), 10); return isFinite(n) ? n : null; };
  var pctDiff = function (a, b) { return a != null && b != null && b > 0 ? Math.round((a / b - 1) * 1000) / 10 : null; };
  var fmtPct = function (p) { return (p > 0 ? '+' : '') + String(p).replace('.', ',') + ' %'; };
  var kurz = function (s, n) { s = clean(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; };

  // ---- Kaufzahl "200+ Mal im letzten Monat gekauft" ----------------------
  function kaufzahl(ui) {
    // robuster Finder in onpage.js (feste IDs griffen nicht mehr, LO 01.09.)
    var b = ui.kaufBadge ? ui.kaufBadge() : null;
    return b ? clean(b.text.replace(/\s*(?:Mal )?im (?:letzten|vergangenen) Monat gekauft/i, '')) : '';
  }

  // ---- Bestand "Nur noch X auf Lager" / "Nur noch X vorrätig" ------------
  // Wie Helium 10 "Inventory Levels", aber rein passiv: nur was Amazon selbst
  // zeigt. Ohne Badge ist der Bestand unbekannt, nicht hoch - das steht im
  // Tooltip, damit niemand Schweigen als "viel Bestand" liest.
  function bestand(ui, row) {
    var box = document.querySelector('#availability, #availability_feature_div');
    var m = clean(box ? box.textContent : '').match(/nur noch\s+(\d+)/i);
    if (!m) return null;
    var x = parseInt(m[1], 10);
    var maxMenge = LC.amazonPro && LC.amazonPro.maxQtyFromSelect ? LC.amazonPro.maxQtyFromSelect(document) : null;
    var tip = 'Nur was Amazon anzeigt - ohne Badge ist der Bestand unbekannt, nicht hoch.' +
      (maxMenge != null ? ' Dropdown erlaubt bis ' + maxMenge + ' - Amazon kappt bei 30, darüber keine Aussage.' : '');
    row.appendChild(ui.chip('<span class="lc-k">Bestand</span> ≤ ' + x, x < 10 ? 'bad' : '', tip));
    return x;
  }

  // ---- Bestandswert nachtraeglich ins eigene hist:<ASIN>-Sample schreiben --
  // Nicht direkt in storage: hist:<ASIN> gehoert der histKette in background.js
  // (recordSample). Ein Direkt-Write hier koennte deren parallelen Push
  // verlieren - deshalb nur eine Message, background patcht in der Kette.
  var bestandGemeldet = '';   // je Seite/Wert nur einmal senden (800ms-Poll)
  function verlaufBestandSchreiben(ui, asin, wert) {
    if (wert == null || !asin || bestandGemeldet === asin + ':' + wert) return;
    bestandGemeldet = asin + ':' + wert;
    try { chrome.runtime.sendMessage({ type: 'histBestand', asin: asin, wert: wert }); } catch (e) { /* Kontext weg */ }
  }

  // ---- AOD-Cache lesen; onpage.js fuellt aod:<ASIN> asynchron ----------------
  // Dieselbe Frische wie onpage.js (15 min): ein aelterer Cache wird dort gerade neu
  // geholt - darauf warten, statt mit einer anderen Angebotsliste zu rechnen.
  // Kein eigener Fetch: onpage.js ist die einzige AOD-Quelle (ein Request je Seite).
  function aodLesen(ui, asin, versuch) {
    versuch = versuch || 0;
    var key = 'aod:' + asin;
    return ui.storage(key).then(function (d) {
      var cc = d && d[key];
      if (cc && cc.angebote && Date.now() - cc.ts < 15 * 60 * 1000) return cc.angebote;
      if (versuch >= 12 || ui.aktuelleAsin() !== asin) return null;   // ~10 s gewartet oder Variante gewechselt
      return new Promise(function (res) { setTimeout(res, 800); }).then(function () { return aodLesen(ui, asin, versuch + 1); });
    });
  }

  var bestandTxt = function (o) { return o && o.bestand != null ? ' · Bestand ≤ ' + o.bestand : ''; };

  function diagnose(ui, row, ctx, a) {
    var offers = (a && a.offers) || [];
    if (!offers.length) return;
    var fremde = offers.filter(function (o) { return !EIGEN.test(o.verkaeufer || '') && o.preis != null; });
    var eigene = offers.filter(function (o) { return EIGEN.test(o.verkaeufer || '') && o.preis != null; });
    var gewinner = null;
    offers.forEach(function (o) { if (!gewinner && o.buybox) gewinner = o; });
    var eigenBest = null;
    eigene.forEach(function (o) { if (!eigenBest || o.preis < eigenBest.preis) eigenBest = o; });
    var fremdBest = null;
    fremde.forEach(function (o) { if (!fremdBest || o.preis < fremdBest.preis) fremdBest = o; });

    // Versandart-Zaehler (Felder kommen aus amazon-pro.js parseOfferEl; alte Caches haben sie nicht)
    var fba = offers.filter(function (o) { return o.fba === true; }).length;
    var kennt = offers.some(function (o) { return o.fba === true || o.fba === false; });
    var amazonDabei = offers.some(function (o) { return /^amazon(\.de)?$/i.test(clean(o.verkaeufer)); });
    if (kennt) {
      row.appendChild(ui.chip(fba + ' <span class="lc-k">FBA</span> · ' + (offers.length - fba) + ' <span class="lc-k">FBM</span>' +
        (amazonDabei ? ' · <span class="lc-k">Amazon selbst</span>' : ''), amazonDabei ? 'bad' : 'mut',
        'Versandart je Angebot aus der Angebotsliste (AOD)'));
    }

    var eigenHatBB = ctx.buybox && ctx.buybox.status === 'ja' && EIGEN.test(ctx.buybox.verkaeufer || '');
    if (eigenHatBB || (gewinner && EIGEN.test(gewinner.verkaeufer || ''))) {
      if (fremdBest && eigenBest) {
        var d1 = pctDiff(fremdBest.preis, eigenBest.preis);
        row.appendChild(ui.chip('<span class="lc-k">Buybox eigen · nächster Fremder</span> ' + ui.esc(kurz(fremdBest.verkaeufer, 22)) +
          ' ' + ui.esc(ui.eur(fremdBest.preis)) + (d1 != null ? ' (' + fmtPct(d1) + ')' : '') + bestandTxt(fremdBest),
          d1 != null && d1 < 0 ? 'bad' : 'ok', 'Abstand des günstigsten Fremdangebots zum eigenen Preis (Amazon nennt keine Prozentschwelle für die Buybox)'));
      }
      return;
    }
    if (!eigenBest) {
      row.appendChild(ui.chip('<span class="lc-k">Diagnose</span> kein eigenes Angebot in der Angebotsliste', 'bad'));
      return;
    }
    var ref = gewinner && gewinner.preis != null ? gewinner : fremdBest;
    if (!ref) return;
    var d = pctDiff(eigenBest.preis, ref.preis);   // >0: wir sind teurer
    var gruende = [];
    if (d != null) gruende.push(d > 0 ? 'wir ' + fmtPct(d) + ' teurer' : (d < 0 ? 'wir ' + fmtPct(d) + ' günstiger' : 'gleicher Preis'));
    if (ref.fba === true && eigenBest.fba === false) gruende.push('Gewinner FBA, wir FBM');
    if (ref.fba === true && eigenBest.fba === true) gruende.push('beide FBA');
    if (ref.lieferung && eigenBest.lieferung && ref.lieferung !== eigenBest.lieferung) gruende.push('liefert ' + kurz(ref.lieferung, 18) + ' (wir ' + kurz(eigenBest.lieferung, 18) + ')');
    if (ref.bewertung) gruende.push('Bewertung ' + kurz(ref.bewertung, 24));
    if (ref.bestand != null) gruende.push('Bestand ≤ ' + ref.bestand);
    var kind = d != null && d > 0 ? 'bad' : (d != null && d < 0 ? 'ok' : '');
    row.appendChild(ui.chip('<span class="lc-k">' + (gewinner ? 'Buybox-Gewinner' : 'günstigster Fremder') + '</span> ' +
      ui.esc(kurz(ref.verkaeufer || '?', 22)) + ' ' + ui.esc(ui.eur(ref.preis)) + (gruende.length ? ' · ' + ui.esc(gruende.join(' · ')) : ''),
      kind, 'Amazon gewichtet Gesamtpreis inkl. Versand, Liefergeschwindigkeit und Verfügbarkeit (Seller Central); eine Prozentschwelle nennt Amazon nicht'));
  }

  // ---- Verlauf: Quote + Delta seit letztem Besuch --------------------------
  function verlauf(ui, row, ctx) {
    var key = 'hist:' + ctx.asin;
    return ui.storage(key).then(function (d) {
      var list = (d && d[key]) || [];
      if (!list.length) return;
      var mitStatus = list.filter(function (s) { return s[3] === 1 || s[3] === 2; });
      if (mitStatus.length >= 2) {
        var ja = mitStatus.filter(function (s) { return s[3] === 1; }).length;
        var q = Math.round(100 * ja / mitStatus.length);
        row.appendChild(ui.chip('<span class="lc-k">Buybox-Quote</span> ' + q + ' % <span class="lc-k">(' + mitStatus.length + ' Messungen seit ' +
          ui.esc(ui.tag(new Date(mitStatus[0][0]))) + ')</span>', q >= 90 ? 'ok' : (q < 70 ? 'bad' : ''),
          'Anteil der eigenen Messungen mit gewonnener Buybox; nur Besuche und Sammelprüfungen, keine Dauerüberwachung'));
      }
      // letzter Besuch = juengstes Sample, das nicht gerade eben (diese Seite) geschrieben wurde
      var jetzt = Date.now(), prev = null;
      for (var i = list.length - 1; i >= 0; i--) {
        if (jetzt - Date.parse(list[i][0]) > 2 * 60 * 1000) { prev = list[i]; break; }
      }
      if (!prev) return;
      var r = ctx.row || {}, teile = [];
      var preis = r.preis == null ? null : Number(r.preis), bsr = num(r.bsr);
      if (preis != null && prev[1] != null && Math.abs(preis - prev[1]) >= 0.01) {
        var dp = Math.round((preis - prev[1]) * 100) / 100;
        teile.push('Preis ' + (dp > 0 ? '+' : '') + ui.eur(dp));
      }
      if (bsr != null && prev[2] != null && bsr !== prev[2]) teile.push('BSR ' + ui.nf(prev[2]) + '→' + ui.nf(bsr));
      var bbJetzt = ctx.buybox && ctx.buybox.status === 'ja' ? 1 : (ctx.buybox && ctx.buybox.status === 'UNTERDRUECKT' ? 2 : 0);
      var bbKind = '';
      if (prev[3] === 1 && bbJetzt === 2) { teile.push('Buybox verloren'); bbKind = 'bad'; }
      else if (prev[3] === 2 && bbJetzt === 1) { teile.push('Buybox zurück'); bbKind = 'ok'; }
      row.appendChild(ui.chip('<span class="lc-k">seit ' + ui.esc(ui.tag(new Date(prev[0]))) + '</span> ' +
        (teile.length ? ui.esc(teile.join(' · ')) : 'unverändert'), bbKind || (teile.length ? '' : 'mut'),
        'Vergleich mit der letzten gespeicherten Messung dieser ASIN'));
    });
  }

  H.panel.push(function (ctx) {
    var ui = ctx.ui;
    if (!ui || !ctx.asin) return;
    var row = ui.el('div', 'a-section a-spacing-small lc-row');
    if (ctx.bbRow && ctx.bbRow.parentNode) ctx.bbRow.insertAdjacentElement('afterend', row);
    else if (ctx.card) ctx.card.appendChild(row);

    var kz = kaufzahl(ui);
    if (kz) row.appendChild(ui.chip(ui.esc(kz) + ' <span class="lc-k">/ Monat</span>', 'ok', 'Amazons eigene Kaufzahl („' + kz + ' Mal im letzten Monat gekauft")'));

    var bestandWert = bestand(ui, row);
    verlaufBestandSchreiben(ui, ctx.asin, bestandWert);

    /* Sterne-Verteilung und Video zeigen dp-reviews.js (1-2-Stern-Chip mit Verteilung)
       und dp-details.js (Videozahl) - hier nicht ein zweites Mal mit anderer Ampel. */

    verlauf(ui, row, ctx).catch(function (e) { console.warn('[LC] Verlauf', e); });
    aodLesen(ui, ctx.asin).then(function (a) { diagnose(ui, row, ctx, a); }).catch(function (e) { console.warn('[LC] Diagnose', e); });
  });
})();
