/* Verkaufsschaetzer-Sammler (nach Helium 10 "30-Day Sales" / Keepa "Monthly
   Sold", aber ohne fremde Tabelle): Jede Produktseite mit Amazons Kaufzahl-
   Badge UND Hauptkategorie-BSR liefert ein (BSR, Kaufzahl)-Paar, gespeichert
   je Hauptkategorie in cal:<kategorie>. Die eigentliche Schaetzung (Fit ueber
   den Paaren ODER eingebaute Basiskurve, je Kategorie mit Korrekturfaktor)
   macht shared/sales.js (LC.sales) - hier nur Sammeln + Anzeige.
   Die Kaufzahl ist ein Untergrenzen-Eimer ("200+"), deshalb steht die Quelle
   (Fit aus X Paaren / Basiskurve unkalibriert) immer ehrlich daneben. Keine
   neuen Rechte. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC || !LC.sales) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];
  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };

  // Amazons Badge robust ueber ui.kaufBadge (feste IDs griffen nicht mehr, LO 01.09.)
  function kaufzahl(ui) {
    if (!ui.kaufBadge) return null;
    var b = ui.kaufBadge();
    return b ? b.zahl : null;
  }
  function hauptkategorie(r) {
    var k = clean(r.bsr_kategorie) || clean(r.kategorie).split(/[>›»]/)[0];
    return k.toLowerCase();
  }

  function zeigeSchaetzung(ui, ctx, res, kz, preis, kat, bsr) {
    if (!res || ui.aktuelleAsin() !== ctx.asin || !ctx.secQ) return;
    // Amazons Badge ist eine belegte Untergrenze: liegt die Kurve darunter,
    // gilt das Badge - der Kurvenwert bleibt aber sichtbar (LO 01.09.).
    var unterBadge = kz != null && res.quelle !== 'eigen' && res.menge < kz;
    var zahl = unterBadge ? kz : res.menge;
    var teile = [(unterBadge ? '≥ ' : '≈ ') + ui.nf(zahl) + ' <span class="lc-k">/ Monat</span>'];
    if (preis != null && isFinite(preis)) {
      teile.push('<span class="lc-k">' + (unterBadge ? '≥ ' : '≈ ') + ui.eur(zahl * preis) + ' Umsatz/Monat</span>');
    }
    var herkunft = res.quelle === 'eigen'
      ? (res.eigenArt === 'h' ? 'Helium-10-Wert dieser ASIN' : 'eigene Seller-Central-Zahl')
      : res.quelle === 'kalibriert' ? 'Kurve „' + kat + '", geeicht an ' + res.paare + ' Punkten'
      : res.quelle === 'kalibriertAlle' ? 'Kurve, geeicht an ' + res.paare + ' Punkten (alle Kategorien)'
      : 'Standardkurve, noch nicht geeicht';
    teile.push('<span class="lc-k">(' + herkunft + ')</span>');
    if (unterBadge) teile.push('<span class="lc-k">· Kurve ≈ ' + ui.nf(res.menge) + '</span>');
    if (res.faktor !== 1) teile.push('<span class="lc-k">· Faktor ' + res.faktor + '</span>');

    var titel;
    if (res.quelle === 'eigen') {
      titel = (res.eigenArt === 'h' ? 'Helium-10-Verkaufszahl' : 'Eure echte Seller-Central-Zahl') +
        ' für genau diese ASIN: ' + ui.nf(res.ankerWert) + '/Monat bei Rang ' + ui.nf(res.ankerBsr) +
        ' (' + ui.tag(new Date(res.ankerTs)) + ').' +
        (bsr !== res.ankerBsr ? '\nHeutiger Rang ' + ui.nf(bsr) + ' → über die Kurvenform umgerechnet.' : '') +
        '\nGenaueste Quelle, die es gibt.';
    } else {
      titel = 'Rang ' + ui.nf(bsr) + ' → ' + ui.nf(res.menge) + ' Verkäufe/Monat.\n' +
        'Grundlage ist eine veröffentlichte Rang-zu-Verkäufe-Tabelle (Marktfaktor Deutschland 0,20), ' +
        'die zu hohen Rängen hin steiler abfällt – eine einzelne Potenzkurve liegt hier systematisch daneben.\n' +
        (res.quelle === 'tabelle'
          ? 'Für „' + kat + '" gibt es noch keinen eigenen Datenpunkt – sobald einer da ist, wird die Kurve auf euer Niveau geeicht.'
          : 'Tabellenwert ' + ui.nf(res.tabelle) + ' × euer Niveaufaktor ' + res.niveau +
            ' (aus ' + res.paare + ' gesammelten Punkten' +
            (res.quelle === 'kalibriertAlle' ? ' über alle Kategorien, weil „' + kat + '" noch zu wenige hat' : '') + ').') +
        '\nExakt wird es artikelweise: „H10 Sales" klicken oder die Seller-Central-Zahl importieren.';
    }
    if (kz != null) {
      titel += '\nAmazons Badge „' + ui.nf(kz) + '+" zählt nur die gewählte Variante und ist bloß eine Untergrenze.';
      if (unterBadge) titel += '\nHier liegt die Kurve darunter – gezeigt wird deshalb die belegte Untergrenze.';
    }
    if (res.faktor !== 1) titel += '\nKorrekturfaktor ' + res.faktor + ' ist eingerechnet.';
    ctx.secQ.appendChild(ui.chip(teile.join(' '), res.quelle === 'eigen' ? 'ok' : '', titel));
  }

  H.panel.push(function (ctx) {
    var ui = ctx.ui, r = ctx.row || {};
    if (!ui || !ctx.secQ || !ctx.asin) return;
    var bsr = parseInt(String(r.bsr == null ? '' : r.bsr).replace(/\D/g, ''), 10);
    var kat = hauptkategorie(r);
    if (!isFinite(bsr) || bsr <= 0 || !kat) return;
    var kz = kaufzahl(ui), preis = r.preis == null ? null : Number(r.preis);

    /* EIN Weg fuer beide Faelle (mit und ohne Badge): schaetzeAsin nimmt einen
       eigenen H10-/Seller-Central-Punkt dieser ASIN, sonst die Kategorie-Kurve. */
    LC.sales.schaetzeAsin(bsr, kat, ctx.asin).then(function (res) {
      zeigeSchaetzung(ui, ctx, res, kz, preis, kat, bsr);
    }).catch(function (e) { console.warn('[LC] Schätzer', e); });

    if (kz == null) return;
    // Sichtbar lernen: Datenpunkt bestaetigen.
    LC.sales.merken(kat, ctx.asin, bsr, kz).then(function (n) {
      if (n == null || ui.aktuelleAsin() !== ctx.asin || !ctx.secQ) return;
      ctx.secQ.appendChild(ui.chip('✓ <span class="lc-k">Schätzer lernt: ' + n + '. Datenpunkt „' + kat + '"</span>', '',
        'Kaufzahl + Bestseller-Rang dieser Seite als Eich-Punkt gespeichert – er verschiebt die Kurve dieser Kategorie auf euer Niveau'));
    }).catch(function (e) { console.warn('[LC] Schätzer merken', e); });
  });
})();
