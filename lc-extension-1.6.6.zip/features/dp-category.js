/* Bestseller-Kategorie: ein Link-Chip "Bestseller-Liste →" neben unserem BSR-Chip
   an der Breadcrumb der Hauptkategorie, oeffnet Amazons Bestseller-Liste in
   neuem Tab. Frueher wurde die Liste hier per Fetch geholt, geparst und als
   Top-10-Sektion gerendert (Cache topcat:<slug>) - Amazon rendert die Kacheln
   inzwischen clientseitig, deshalb kein Vorschau-Auszug mehr; die Kopfzeile
   unserer Extension (onpage.js serp()) sammelt Preis-Median/Ø ★/Badges direkt
   auf der Zielseite. Der tote Fetch/Parser/Render-Code stand hinter einem
   `return` und wurde entfernt (S4). Nur bei sichtbarem Tab.
   Rechte: keine neuen (amazon.de freigegeben). */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];

  var clean = function (s) { return s == null ? '' : String(s).replace(/\s+/g, ' ').trim(); };

  H.panel.push(function (ctx) {
    var ui = ctx.ui;
    if (!ui || !ctx.row || !ctx.row.bsr || !ctx.row.bsr_kategorie) return;
    if (typeof document.visibilityState === 'string' && document.visibilityState !== 'visible') return;

    var kat = clean(ctx.row.bsr_kategorie);
    // Passenden BSR-Chip in der Breadcrumb finden (Hauptkategorie)
    var lis = document.querySelectorAll('#wayfinding-breadcrumbs_feature_div li');
    var bsrChip = null, href = '';
    for (var i = 0; i < lis.length; i++) {
      var a = lis[i].querySelector('a:not(.lc-chip)');
      if (!a || clean(a.textContent).toLowerCase() !== kat.toLowerCase()) continue;
      bsrChip = lis[i].querySelector('a.lc-chip[href*="/gp/bestsellers/"]');
      if (bsrChip) { href = bsrChip.getAttribute('href') || ''; break; }
    }
    if (!bsrChip || !href) return;
    // Idempotent innerhalb desselben panel()-Laufs
    if (bsrChip.parentNode.querySelector('.lc-topcat-trigger')) return;

    var trig = ui.chip('Bestseller-Liste →', 'mut', 'Amazon-Bestseller-Kategorie in neuem Tab öffnen. Kacheln lädt Amazon clientseitig – deshalb kein Vorschau-Auszug hier; die Kopfzeile unserer Extension sammelt Preis-Median/Ø ★/Badges direkt auf der Zielseite.', href);
    trig.setAttribute('target', '_blank'); trig.setAttribute('rel', 'noopener');
    trig.classList.add('lc-topcat-trigger');
    bsrChip.insertAdjacentElement('afterend', trig);
  });
})();
