/* Marge-Rechner (nach Helium 10 "Profitability Calculator"), lokal und ohne
   Gebuehrentabelle: Verkaufspreis brutto (von der Seite vorbelegt), Einkauf/
   Versand/Verpackung netto, Amazon-Provision % (Standard 15) und USt %
   (Standard 19) -> Gewinn, Marge, ROI und Break-even-Preis, live beim Tippen.
     netto = preis / (1 + USt);  provision = preis * prov (Amazon rechnet brutto)
     gewinn = netto - provision - einkauf - versand - verpackung
     marge = gewinn / netto;  ROI = gewinn / (einkauf + versand + verpackung)
   Eingaben je ASIN in calc:<ASIN>, Provision/USt zusaetzlich als calc:defaults.
   "Versand durch" ist nur Beschriftung.

   Zusatzblock FBA-Gebuehr: echte Rate Card DE (Nur-DE-Versand, gueltig ab
   1.7.2026), rein lokal eingebettet. Aus Gewicht + optionalen Massen wird eine
   Groessenklasse bestimmt und die Gebuehr berechnet; ein Link uebernimmt sie
   ins Versand-Feld. Lagergebuehr ist nur Anzeige (Verweildauer unbekannt).
   Keine Requests, keine Rechte. */
(function () {
  'use strict';
  var LC = globalThis.LC;
  if (!LC) return;
  var H = LC.onpage = LC.onpage || {};
  H.panel = H.panel || [];

  var FELDER = [
    { k: 'preis',      t: 'Verkaufspreis € (brutto)', tip: 'Amazon-Verkaufspreis inkl. USt – von der Seite vorbelegt, zum Durchspielen änderbar' },
    { k: 'einkauf',    t: 'Einkauf € (netto)',        tip: 'Einkaufspreis je Stück ohne USt' },
    { k: 'versand',    t: 'Versand/Logistik €',       tip: 'Versand je Stück netto – bei FBA die FBA-Gebühr hier eintragen' },
    { k: 'verpackung', t: 'Verpackung/Sonstiges €',   tip: 'Verpackung, Retourenanteil, sonstige Stückkosten netto' },
    { k: 'prov',       t: 'Amazon-Provision %',       tip: 'Verkaufsgebühr in % vom Bruttopreis – kategorieabhängig, teils nach Preis gestaffelt (Seller Central → Verkaufsgebühren amazon.de). Vorbelegt 15, zuletzt eingegebener Wert wird gemerkt' },
    { k: 'ust',        t: 'USt %',                    tip: 'Umsatzsteuer in % (Standard 19) – wird als Vorgabe gemerkt' }
  ];
  var GEMERKT = ['einkauf', 'versand', 'verpackung', 'prov', 'ust', 'gewicht', 'laenge', 'breite', 'hoehe'];
  // "1.299,00" -> 1299 (Tausenderpunkt nur entfernen, wenn ein Komma da ist; "12.5" bleibt 12.5)
  var zahl = function (v) { var s = String(v == null ? '' : v).trim(); if (s.indexOf(',') >= 0) s = s.replace(/\./g, ''); var n = parseFloat(s.replace(',', '.')); return isFinite(n) ? n : null; };
  var txt = function (n) { return n == null ? '' : String(n).replace('.', ','); };
  var pct = function (n) { return n == null ? '–' : n.toFixed(1).replace('.', ',') + ' %'; };

  // ---- FBA-Gebuehr Rate Card DE, Nur-DE-Versand, gueltig ab 1.7.2026 ----
  var GUELTIG = 'Rate Card ab 1.7.2026';
  var STANDARD_MAX_CM = [45, 34, 26];                 // Standardpaket-Gurtmass, absteigend sortiert vergleichen
  var STANDARD_STAFFEL = [                            // [Gewichtsgrenze kg, Gebuehr EUR]
    [0.15, 3.39], [0.4, 3.42], [0.9, 3.44], [1.4, 3.93], [1.9, 3.95],
    [2.9, 4.55], [3.9, 5.09], [5.9, 5.22], [8.9, 6.03], [11.9, 6.65]
  ];
  var LAGER_SATZ = { standard: { js: 27.54, od: 52.20 }, uebergroesse: { js: 21.78, od: 34.49 } };
  var sortiertAbst = function (a) { return a.slice().sort(function (x, y) { return y - x; }); };

  /* Groessenklasse + Gebuehr aus Gewicht/Massen. "ueber Basis" heisst: die
     Basisgebuehr deckt das Gewicht bis zur genannten Grenze, jedes weitere kg
     kostet den Aufschlag. Ohne Masse wird konservativ nach Gewicht eingestuft
     (Standardpaket bzw. die Gewichtsstaffel der Standarduebergroesse) - der
     Aufrufer zeigt die Unsicherheit im Tooltip an (siehe hinweis-Feld).
     Reihenfolge/Grenzen sind eine dokumentierte Vereinfachung dort, wo Amazon
     Gewichts- und Massklassen ueberlappen laesst (LO kann sie hier anpassen). */
  var fbaKlasse = function (kg, l, b, h) {
    var hatMasse = l != null && b != null && h != null;
    var sort = hatMasse ? sortiertAbst([l, b, h]) : null;
    var passtStandard = hatMasse ? (sort[0] <= STANDARD_MAX_CM[0] && sort[1] <= STANDARD_MAX_CM[1] && sort[2] <= STANDARD_MAX_CM[2]) : true;
    var passt120 = hatMasse ? (sort[0] <= 120 && sort[1] <= 60 && sort[2] <= 60) : true;

    if (kg > 23) {
      return { name: 'Übergröße schwer', standard: false, gebuehr: 13.00 + 0.15 * (kg - 23),
        hinweis: '23–31,5 kg: Basis 13,00 € + 0,15 €/kg über 23 kg' + (kg > 31.5 ? ' – über 31,5 kg außerhalb der Rate Card, Amazon individuell anfragen' : '') };
    }
    if (kg <= 11.9 && passtStandard) {
      var stufe = STANDARD_STAFFEL.filter(function (s) { return kg <= s[0]; })[0] || STANDARD_STAFFEL[STANDARD_STAFFEL.length - 1];
      return { name: 'Standardpaket', standard: true, gebuehr: stufe[1],
        hinweis: hatMasse ? ('passt in ' + STANDARD_MAX_CM.join('×') + ' cm, bis 11,9 kg') : 'ohne Maße nach Gewicht angenommen – bei sperrigen Artikeln evtl. tatsächlich Übergröße' };
    }
    if (hatMasse && !passt120) {
      return { name: 'Übergröße sperrig', standard: false, gebuehr: 8.24 + 0.27 * Math.max(0, kg - 0.76),
        hinweis: 'über 120×60×60 cm: Basis 8,24 € + 0,27 €/kg über 0,76 kg' };
    }
    if (kg <= 0.76) {
      return { name: 'Kleine Übergröße', standard: false, gebuehr: 4.56 + 0.18 * Math.max(0, kg - 0.76),
        hinweis: (hatMasse ? '' : 'ohne Maße angenommen, ') + 'bis 760 g: Basis 4,56 € + 0,18 €/kg über 0,76 kg' };
    }
    if (kg <= 15) {
      return hatMasse
        ? { name: 'Standardübergröße groß', standard: false, gebuehr: 6.06 + 0.08 * (kg - 0.76),
            hinweis: 'passt in 120×60×60 cm, bis 15 kg: Basis 6,06 € + 0,08 €/kg über 0,76 kg' }
        : { name: 'Standardübergröße leicht', standard: false, gebuehr: 4.59 + 0.18 * (kg - 0.76),
            hinweis: 'ohne Maße angenommen, bis 15 kg: Basis 4,59 € + 0,18 €/kg über 0,76 kg' };
    }
    return { name: 'Standardübergröße schwer', standard: false, gebuehr: 7.25 + 0.07 * (kg - 15),
      hinweis: (hatMasse ? '' : 'ohne Maße angenommen, ') + '15–23 kg: Basis 7,25 € + 0,07 €/kg über 15 kg' };
  };

  // Freitext der Attributtabelle ("5,2 kg", "70 x 50 x 30 cm") fuer die Vorbelegung lesen - misslingt das, bleibt das Feld leer
  var parseKg = function (s) {
    var m = String(s == null ? '' : s).match(/(\d+(?:[.,]\d+)?)\s*(kg|g)\b/i);
    if (!m) return null;
    var n = parseFloat(m[1].replace(',', '.'));
    return isFinite(n) ? (/^g$/i.test(m[2]) ? n / 1000 : n) : null;
  };
  var parseMasse = function (s) {
    var m = String(s == null ? '' : s).match(/(\d+(?:[.,]\d+)?)\s*[xX×]\s*(\d+(?:[.,]\d+)?)\s*[xX×]\s*(\d+(?:[.,]\d+)?)\s*cm/i);
    if (!m) return null;
    var n = [m[1], m[2], m[3]].map(function (x) { return parseFloat(x.replace(',', '.')); });
    return n.every(isFinite) ? n : null;
  };

  function rechnen(v) {
    var u = (v.ust || 0) / 100, p = (v.prov || 0) / 100;
    var kosten = (v.einkauf || 0) + (v.versand || 0) + (v.verpackung || 0);
    var netto = v.preis / (1 + u), provision = v.preis * p;
    var gewinn = netto - provision - kosten;
    var anteil = 1 / (1 + u) - p;   // was je Brutto-Euro nach USt und Provision bleibt
    return { netto: netto, provision: provision, kosten: kosten, gewinn: gewinn,
      marge: netto > 0 ? 100 * gewinn / netto : null,
      roi: kosten > 0 ? 100 * gewinn / kosten : null,
      be: anteil > 0 ? kosten / anteil : null };
  }
  H.profit = { rechnen: rechnen };

  H.panel.push(function (ctx) {
    var ui = ctx.ui, asin = ctx.asin, r = ctx.row || {};
    if (!ui || typeof ctx.sec !== 'function' || !asin) return;
    if (ctx.card && ctx.card.querySelector('.lc-profit')) return;
    var box = ctx.sec('Marge');
    box.classList.add('lc-profit');
    var form = ui.el('div', 'lc-row'); box.appendChild(form);
    var inp = {};
    var feld = function (k, t, tip, ctrl, ziel) {
      var w = ui.el('div');
      var lab = ui.el('label', 'a-size-small a-color-secondary', ui.esc(t));
      lab.htmlFor = ctrl.id = 'lc-profit-' + k; lab.title = tip; lab.style.display = 'block';
      ctrl.title = tip;
      w.appendChild(lab); w.appendChild(ctrl); (ziel || form).appendChild(w);
      return ctrl;
    };
    FELDER.forEach(function (f) {
      var i = ui.el('input', 'a-input-text a-width-small');
      i.type = 'text'; i.autocomplete = 'off'; i.setAttribute('inputmode', 'decimal');
      inp[f.k] = feld(f.k, f.t, f.tip, i);
      if (f.k === 'prov') {
        // Presets direkt neben der Provision - Gartenmoebel/Moebel sind Deubas Kernkategorien
        var presets = ui.el('div', 'lc-row');
        var pGarten = ui.chip('Garten 15%', 'mut', 'Setzt die Provision auf 15 % (Kategorie Garten)');
        var pMoebel = ui.chip('Möbel 15/10%', 'mut', 'Möbel-Staffel: 15 % bis 200 €, darüber 10 % – rechnet daraus den effektiven Prozentsatz für den aktuellen Verkaufspreis (Mindestgebühr 0,30 € nicht eingerechnet)');
        pGarten.style.cursor = 'pointer'; pMoebel.style.cursor = 'pointer';
        pGarten.addEventListener('click', function (ev) { ev.preventDefault(); inp.prov.value = '15'; zeigen(); merken(); });
        pMoebel.addEventListener('click', function (ev) {
          ev.preventDefault();
          var preis = zahl(inp.preis.value);
          var eff = (preis == null || preis <= 200) ? 15 : (200 * 0.15 + (preis - 200) * 0.10) / preis * 100;
          inp.prov.value = txt(Math.round(eff * 100) / 100);
          zeigen(); merken();
        });
        presets.appendChild(pGarten); presets.appendChild(pMoebel); form.appendChild(presets);
      }
    });
    var sel = ui.el('select', 'a-native-dropdown');
    ['Verkäufer', 'FBA'].forEach(function (o) { var op = ui.el('option', '', ui.esc(o)); op.value = o; sel.appendChild(op); });
    feld('durch', 'Versand durch', 'Nur Beschriftung – die Versand- bzw. FBA-Gebühr trägst du oben unter Versand ein', sel);
    var out = ui.el('div', 'lc-row a-spacing-top-small'); box.appendChild(out);

    inp.preis.value = r.preis == null ? '' : txt(Number(r.preis).toFixed(2));
    inp.prov.value = '15'; inp.ust.value = '19';

    // ---- optionaler Block: FBA-Gebuehr aus der Rate Card ----
    var fbaHead = ui.el('div', 'a-size-small a-spacing-top-small', 'FBA-Gebühr <span class="lc-k">(' + GUELTIG + ')</span>');
    box.appendChild(fbaHead);
    var fbaForm = ui.el('div', 'lc-row'); box.appendChild(fbaForm);
    var FBA_FELDER = [
      { k: 'gewicht', t: 'Gewicht kg',  tip: 'Versandgewicht in kg – bestimmt zusammen mit den Maßen die Größenklasse' },
      { k: 'laenge',  t: 'Länge cm',    tip: 'optional – ohne Maße wird konservativ nach Gewicht eingestuft' },
      { k: 'breite',  t: 'Breite cm',   tip: 'optional – ohne Maße wird konservativ nach Gewicht eingestuft' },
      { k: 'hoehe',   t: 'Höhe cm',     tip: 'optional – ohne Maße wird konservativ nach Gewicht eingestuft' }
    ];
    FBA_FELDER.forEach(function (f) {
      var i = ui.el('input', 'a-input-text a-width-small');
      i.type = 'text'; i.autocomplete = 'off'; i.setAttribute('inputmode', 'decimal');
      inp[f.k] = feld(f.k, f.t, f.tip, i, fbaForm);
    });
    var fbaOut = ui.el('div', 'lc-row a-spacing-top-small'); box.appendChild(fbaOut);

    var zeigen = function () {
      var v = {}; FELDER.forEach(function (f) { v[f.k] = zahl(inp[f.k].value); });
      out.innerHTML = '';
      if (v.preis == null || v.preis <= 0) { out.appendChild(ui.chip('Verkaufspreis fehlt', 'mut', 'Ohne Verkaufspreis keine Rechnung')); return; }
      if (v.einkauf == null) { out.appendChild(ui.chip('Einkauf fehlt', 'mut', 'Einkaufspreis netto eintragen – dann rechnet es')); return; }
      var e = rechnen(v);
      out.appendChild(ui.chip('<span class="lc-k">Gewinn</span> ' + ui.esc(ui.eur(e.gewinn)), e.gewinn >= 0 ? 'ok' : 'bad',
        'Netto ' + ui.eur(e.netto) + ' − Provision ' + ui.eur(e.provision) + ' − Kosten ' + ui.eur(e.kosten) + ' (Einkauf + Versand + Verpackung)'));
      out.appendChild(ui.chip('<span class="lc-k">Marge</span> ' + pct(e.marge), e.marge == null ? 'mut' : (e.marge >= 20 ? 'ok' : (e.marge < 0 ? 'bad' : '')),
        'Gewinn / Nettoumsatz (' + ui.eur(e.netto) + ')'));
      out.appendChild(ui.chip('<span class="lc-k">ROI</span> ' + pct(e.roi), 'mut', 'Gewinn / eingesetztes Kapital (Einkauf + Versand + Verpackung = ' + ui.eur(e.kosten) + ')'));
      out.appendChild(ui.chip('<span class="lc-k">Break-even</span> ' + (e.be == null ? '–' : ui.esc(ui.eur(e.be))), 'mut',
        e.be == null ? 'USt und Provision fressen den ganzen Preis – kein Break-even' : 'Bruttopreis, bei dem der Gewinn genau 0 € ist'));
    };
    var fbaZeigen = function () {
      var kg = zahl(inp.gewicht.value);
      var l = zahl(inp.laenge.value), b = zahl(inp.breite.value), h = zahl(inp.hoehe.value);
      fbaOut.innerHTML = '';
      if (kg == null || kg <= 0) return;   // optionaler Block - ohne Gewicht keine Anzeige
      var k = fbaKlasse(kg, l, b, h);
      fbaOut.appendChild(ui.chip('<span class="lc-k">Gebühr</span> ' + ui.esc(ui.eur(k.gebuehr)) + ' <span class="lc-k">(' + ui.esc(k.name) + ')</span>', '', k.hinweis));
      var uebernehmen = ui.chip('→ als Versand übernehmen', 'mut', 'Trägt ' + ui.eur(k.gebuehr) + ' ins Versand-Feld oben ein');
      uebernehmen.style.cursor = 'pointer';
      uebernehmen.addEventListener('click', function (ev) {
        ev.preventDefault();
        inp.versand.value = txt(Math.round(k.gebuehr * 100) / 100);
        zeigen(); merken();
      });
      fbaOut.appendChild(uebernehmen);
      if (l != null && b != null && h != null) {
        var m3 = (l * b * h) / 1e6;
        var satz = k.standard ? LAGER_SATZ.standard : LAGER_SATZ.uebergroesse;
        fbaOut.appendChild(ui.chip('<span class="lc-k">Lagergebühr/Monat</span> ' + ui.esc(ui.eur(m3 * satz.js)) + ' (Jan–Sep) / ' + ui.esc(ui.eur(m3 * satz.od)) + ' (Okt–Dez)', 'mut',
          'Aus Volumen ' + m3.toFixed(3).replace('.', ',') + ' m³ × Lagergebühr ' + (k.standard ? 'Standardgröße' : 'Übergröße') + ' – fließt NICHT automatisch in den Gewinn, die Verweildauer im Lager ist unbekannt'));
      }
    };
    var merkTimer = null;
    var merken = function () {   // sofort schreiben: Klicks, Auswahl, Feld verlassen
      clearTimeout(merkTimer); merkTimer = null;
      var d = { durch: sel.value }, o = {};
      GEMERKT.forEach(function (k) { d[k] = zahl(inp[k].value); });
      o['calc:' + asin] = d;
      o['calc:defaults'] = { prov: d.prov, ust: d.ust };
      ui.storageSet(o).catch(function (e) { console.warn('[LC] Kalkulation speichern', e); });
    };
    /* P10: beim Tippen 300 ms sammeln - ein Write je Tastendruck feuerte onChanged
       in allen Kontexten (Popup, andere Tabs). merken() liest immer den aktuellen
       Formularstand, der letzte Wert gewinnt also von selbst; ein Timer reicht. */
    var merkenSpaeter = function () { clearTimeout(merkTimer); merkTimer = setTimeout(merken, 300); };
    var beimVerlassen = function (i) { i.addEventListener('blur', function () { if (merkTimer) merken(); }); };
    FELDER.forEach(function (f) {
      inp[f.k].addEventListener('input', function () { zeigen(); if (f.k !== 'preis') merkenSpaeter(); });
      if (f.k !== 'preis') beimVerlassen(inp[f.k]);
    });
    FBA_FELDER.forEach(function (f) { inp[f.k].addEventListener('input', function () { fbaZeigen(); merkenSpaeter(); }); beimVerlassen(inp[f.k]); });
    sel.addEventListener('change', merken);
    zeigen(); fbaZeigen();

    // Gemerkte Werte: erst globale Vorgaben (Provision/USt), dann die der ASIN
    ui.storage(['calc:' + asin, 'calc:defaults']).then(function (d) {
      if (ui.aktuelleAsin() !== asin || !box.isConnected) return;
      var g = d['calc:defaults'] || {}, m = d['calc:' + asin] || {};
      if (g.prov != null) inp.prov.value = txt(g.prov);
      if (g.ust != null) inp.ust.value = txt(g.ust);
      GEMERKT.forEach(function (k) { if (m[k] != null) inp[k].value = txt(m[k]); });
      if (m.durch) sel.value = m.durch;
      // Gewicht/Masse noch nie gespeichert -> aus der Attributtabelle der Produktseite raten
      if (m.gewicht == null) { var pk = parseKg(r.eig_gewicht); if (pk != null) inp.gewicht.value = txt(pk); }
      if (m.laenge == null) { var pm = parseMasse(r.eig_masse); if (pm) { inp.laenge.value = txt(pm[0]); inp.breite.value = txt(pm[1]); inp.hoehe.value = txt(pm[2]); } }
      zeigen(); fbaZeigen();
    }).catch(function () { /* ohne Speicher eben mit Standardwerten */ });
  });
})();
