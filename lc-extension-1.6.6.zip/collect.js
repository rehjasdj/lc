/* Wird nach shared/extract.js in die Seite injiziert.
   Der Wert der letzten Anweisung ist das, was executeScript zurueckgibt. */
LC.extract(document, location.href);
