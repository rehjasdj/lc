/* Zerfalls-Animation für das Leeren — echte Pixel-Disintegration.

   Warum eine eigene Datei: Ein Popup ist ein eigenes kleines Fenster, jede
   Animation darin endet an dessen Kante. Der Zerfall soll über die Seite
   ziehen, also läuft er als Overlay im aktiven Tab (chrome.scripting).

   TECHNIK (nach der verbreiteten Thanos-Snap-Umsetzung, siehe redstapler.co
   und html-in-canvas.dev/demos/pixel-disintegration):
   Der erste Entwurf hat abstrakte Staubkörner erzeugt — das sah nach
   Konfetti aus, nicht nach Zerfall. Der Unterschied liegt darin, dass hier
   der INHALT selbst zerfällt: die Zeilen werden auf ein Canvas gezeichnet,
   per getImageData in Pixel zerlegt, und jedes Pixel wird ein Korn mit
   eigener Flugbahn. Deshalb behält die Wolke am Anfang die Form der Liste
   und löst sich erst im Flug auf.

   Drei Dinge machen den Effekt aus:
   1. GERICHTETE WELLE — die Körner lösen sich nicht gleichzeitig, sondern
      von links nach rechts (Verzögerung aus der normierten X-Position).
      Ohne das blinkt alles gemeinsam weg und wirkt billig.
   2. WIND STATT EXPLOSION — Grunddrift nach rechts-oben, überlagert von zwei
      Böenfrequenzen; leichte Körner werden stärker getragen als schwere,
      dadurch franst die Wolke aus.
   3. UNSCHÄRFE IM FLUG — ohne sie sieht das Verschieben pixelig aus. Wird
      über wachsende Korngröße bei sinkender Deckkraft angenähert, das ist
      billiger als ein echter Blur-Filter pro Frame.

   Räumt sich vollständig selbst ab. */
function deubaDustEffect(zeilen, ursprung) {
  var ALT = document.getElementById('deuba-dust-canvas');
  if (ALT) ALT.remove();

  zeilen = (zeilen && zeilen.length) ? zeilen : ['—'];
  ursprung = ursprung || {};

  var canvas = document.createElement('canvas');
  canvas.id = 'deuba-dust-canvas';
  canvas.style.cssText =
    'position:fixed;inset:0;width:100vw;height:100vh;' +
    'pointer-events:none;z-index:2147483647;background:transparent;';
  document.documentElement.appendChild(canvas);

  var dpr = Math.min(window.devicePixelRatio || 1, 2);
  var B = canvas.width = Math.floor(window.innerWidth * dpr);
  var H = canvas.height = Math.floor(window.innerHeight * dpr);
  var ctx = canvas.getContext('2d', { alpha: true });

  /* ---- 1. Inhalt zeichnen (wird gleich wieder gelöscht) ----
     Startfeld dort, wo das Popup sitzt: oben rechts unter der Symbolleiste. */
  var padX = Math.round((ursprung.x != null ? ursprung.x : 0.66) * B);
  var padY = Math.round((ursprung.y != null ? ursprung.y : 0.09) * H);
  var zeilenH = Math.round(19 * dpr);
  var schrift = Math.round(13 * dpr);

  ctx.font = schrift + 'px "Segoe UI", system-ui, sans-serif';
  ctx.textBaseline = 'top';
  var maxBreite = 0;
  for (var z = 0; z < zeilen.length; z++) {
    ctx.fillStyle = z % 3 === 0 ? '#d99441' : '#e8e5df';   // Akzent + Text
    var txt = String(zeilen[z]).slice(0, 58);
    ctx.fillText(txt, padX, padY + z * zeilenH);
    maxBreite = Math.max(maxBreite, ctx.measureText(txt).width);
  }

  var feldB = Math.ceil(Math.min(maxBreite + 8 * dpr, B - padX));
  var feldH = Math.ceil(zeilen.length * zeilenH + 4 * dpr);
  if (feldB <= 0 || feldH <= 0) { canvas.remove(); return; }

  /* ---- 2. In Körner zerlegen ----
     SCHRITT 3 statt jedes Pixels: bei jedem Pixel wären es hier über 100.000
     Körner, das schafft keine Bildwiederholrate. Drei ist der Punkt, an dem
     die Schrift noch als Schrift erkennbar bleibt. */
  var SCHRITT = 3;
  var bild;
  try {
    bild = ctx.getImageData(padX, padY, feldB, feldH);
  } catch (e) { canvas.remove(); return; }
  var d = bild.data;

  var xs = [], ys = [], rr = [], gg = [], bb = [];
  for (var py = 0; py < feldH; py += SCHRITT) {
    for (var px = 0; px < feldB; px += SCHRITT) {
      var o = (py * feldB + px) * 4;
      if (d[o + 3] < 40) continue;                 // durchsichtig -> kein Korn
      xs.push(padX + px); ys.push(padY + py);
      rr.push(d[o]); gg.push(d[o + 1]); bb.push(d[o + 2]);
    }
  }
  ctx.clearRect(0, 0, B, H);

  var N = xs.length;
  if (!N) { canvas.remove(); return; }

  var X = new Float32Array(N), Y = new Float32Array(N);
  var VX = new Float32Array(N), VY = new Float32Array(N);
  var VERZ = new Float32Array(N), MASSE = new Float32Array(N), SEED = new Float32Array(N);

  for (var i = 0; i < N; i++) {
    X[i] = xs[i]; Y[i] = ys[i];
    // Welle von links nach rechts, mit etwas Streuung - sonst wirkt die
    // Kante der Welle wie ein Lineal.
    var nx = (xs[i] - padX) / Math.max(feldB, 1);
    VERZ[i] = nx * 620 + Math.random() * 220;
    // Leichte Körner fliegen weiter: dadurch franst die Wolke aus, statt als
    // Block wegzurutschen. Das ist der Unterschied zu "verschoben".
    MASSE[i] = 0.4 + Math.random() * 0.6;
    VX[i] = 0; VY[i] = 0;
    SEED[i] = Math.random() * 6.283;
  }

  var t0 = performance.now();
  var DAUER = 2400;
  var raf = 0;
  var puffer = ctx.createImageData(B, H);
  var pd = puffer.data;

  function boe(t, y) {
    // Zwei Frequenzen: lange Böe plus kurze Verwirbelung. Ein konstanter
    // Vektor sähe aus wie Schwerkraft zur Seite, nicht wie Wind.
    return Math.sin(t * 0.0011 + y * 0.0035) * 0.6 +
           Math.sin(t * 0.0043 + y * 0.012) * 0.25;
  }

  function frame(now) {
    var t = now - t0;
    pd.fill(0);

    var lebt = false;
    for (var k = 0; k < N; k++) {
      var fort = (t - VERZ[k]) / 1250;            // 0..1 nach eigener Verzögerung
      if (fort < 0) {                              // noch nicht dran: ruhig stehen
        lebt = true;
        setzePixel(X[k], Y[k], rr[k], gg[k], bb[k], 1, 1);
        continue;
      }
      if (fort > 1) continue;
      lebt = true;

      var m = MASSE[k];
      VX[k] += (2.35 + boe(t, Y[k])) * 0.052 / m * dpr;   // Drift + Böe
      VY[k] += (-0.34 / m + Math.sin(t * 0.0031 + SEED[k]) * 0.06) * dpr;
      VX[k] *= 0.985; VY[k] *= 0.985;              // Luftwiderstand
      X[k] += VX[k]; Y[k] += VY[k];

      // Deckkraft fällt spät ab, damit die Wolke erst fliegt und dann vergeht.
      var a = fort < 0.35 ? 1 : 1 - (fort - 0.35) / 0.65;
      // Korn wächst leicht beim Verblassen - nähert die Unschärfe an, ohne
      // pro Bild einen echten Weichzeichner zu kosten.
      var gr = a > 0.6 ? 1 : 2;
      setzePixel(X[k], Y[k], rr[k], gg[k], bb[k], a * a, gr);
    }

    ctx.putImageData(puffer, 0, 0);

    if (lebt && t < DAUER) raf = requestAnimationFrame(frame);
    else beenden();
  }

  /* Direkt in den Bildpuffer schreiben statt fillRect je Korn: bei mehreren
     zehntausend Körnern ist der Aufrufaufwand von fillRect der Flaschenhals. */
  function setzePixel(x, y, r, g, b, a, groesse) {
    if (a <= 0.02) return;
    var ix = x | 0, iy = y | 0;
    for (var dy = 0; dy < groesse; dy++) {
      var yy = iy + dy;
      if (yy < 0 || yy >= H) continue;
      for (var dx = 0; dx < groesse; dx++) {
        var xx = ix + dx;
        if (xx < 0 || xx >= B) continue;
        var o = (yy * B + xx) * 4;
        var na = a * 255;
        if (pd[o + 3] >= na) continue;             // hellstes Korn gewinnt
        pd[o] = r; pd[o + 1] = g; pd[o + 2] = b; pd[o + 3] = na;
      }
    }
  }

  function beenden() {
    cancelAnimationFrame(raf);
    if (canvas.parentNode) canvas.remove();
  }

  raf = requestAnimationFrame(frame);
  // Notbremse: gedrosselte Tabs dürfen kein Overlay hinterlassen.
  setTimeout(beenden, DAUER + 1500);
}
