/* Listing Checker - Helium10 Backend-Endpoints
   Reversed aus Chrome-Extension njmehopjdpcckochcggncklnlmikcbnb v8.42.2.
   Live gegen Konto 1547836763 (Helium10_Free) getestet am 29.08.2026.

   Zwei Auth-Domains:
   - members.helium10.com nutzt die Session-Cookies aus dem H10-Login
     (credentials:'include' in derselben Domain).
   - research-tools.helium10.com braucht Bearer-Token, den wir per
     /api/v1/site/token aus der Members-Session ziehen (data.token,
     NICHT data.pacvueToken - der ist fuer Pacvue-Endpoints).

   Ratelimits stammen aus der uses-Anzeige der Free-Antworten. Der Server
   antwortet mit 402 "Not enough uses" wenn kein Kontingent mehr da ist und
   mit 403 "not allowed for your plan" bei komplett gesperrten Endpoints -
   wir behandeln beides als saubere Fehlfaelle, nicht als Bug.

   Laeuft im Extension-Kontext (background + content) und in Node. Setzt
   shared/extract.js voraus (globalThis.LC). */
(function () {
  'use strict';

  var LC = globalThis.LC || (typeof window !== 'undefined' ? window.LC : null);
  if (!LC) throw new Error('shared/extract.js muss vor shared/h10.js geladen werden');

  var MEMBERS  = 'https://members.helium10.com';
  var RESEARCH = 'https://research-tools.helium10.com';
  var CONTROL  = 'https://control-center.helium10.com';

  // Amazon-Marketplace-ID + interne H10-Marketplace-ID (die kleine Zahl fuer research-tools)
  var MARKETPLACE = {
    'amazon.de':    { amz: 'A1PA6795UKMFR9', h10: 4 },
    'amazon.com':   { amz: 'ATVPDKIKX0DER',  h10: 1 },
    'amazon.co.uk': { amz: 'A1F83G8C2ARO7P', h10: 3 },
    'amazon.fr':    { amz: 'A13V1IB3VIYZZH', h10: 5 },
    'amazon.it':    { amz: 'APJ6JRA9NG5V4',  h10: 6 },
    'amazon.es':    { amz: 'A1RKKUPIHCS9HS', h10: 7 }
  };

  // Live-verifiziert (get-uses-remaining schlaegt fuer alles andere mit 400 fehl)
  var VALID_MODULE_IDS = ['xray', 'xray-api', 'cerebro', 'review-insights', 'search-expander'];

  function mp(host, kind) {
    var row = MARKETPLACE[host] || MARKETPLACE['amazon.de'];
    return row[kind || 'amz'];
  }

  // ---------------------------------------------------------------- HTTP-Basis

  /* Direkt-Fetch geht wegen CORS nur bei /extension/check-login. Alle anderen
     Endpunkte muessen ueber den Background-Service-Worker (h10Fetch), der als
     Extension keinen Web-Origin hat und Amazons CORS-Wand nicht sieht. Fallback
     auf direktes fetch, damit der Wrapper auch in Node-Tests laeuft. */
  function fetchDirect(url, init) {
    return fetch(url, init).then(function (res) {
      return res.text().then(function (body) {
        var data = null;
        try { data = body ? JSON.parse(body) : null; } catch (e) { /* HTML */ }
        return { status: res.status, ok: res.ok, data: data, body: body };
      });
    });
  }
  function fetchProxy(url, init) {
    return new Promise(function (resolve) {
      try {
        chrome.runtime.sendMessage({ type: 'h10Fetch', url: url, init: init }, function (r) {
          void chrome.runtime.lastError;
          resolve(r || { ok: false, status: 0, data: null, body: '' });
        });
      } catch (e) { resolve({ ok: false, status: 0, data: null, body: '' }); }
    });
  }
  /* Gewuenschtes Konto bei MEHRFACH-KONTEN. Ohne diesen Parameter antwortet
     Helium immer mit dem PRIMAEREN Konto, egal was im H10-Web umgeschaltet
     wurde - live nachgemessen am 01.09.2026 mit zwei Konten:
       /extension/check-login                        -> 2090699148 (primaer)
       /extension/check-login?accountId=1547836763   -> 1547836763
     Genau das ist der Grund, warum immer nur der Free-Plan ankam. Die echte
     H10-Erweiterung fragt nicht "wer bin ich", sie schickt das Konto mit.
     Ausgenommen /black-box/: dort liefert der Parameter HTML statt JSON. */
  var _wunschKonto = '';
  LC_setKonto();
  function LC_setKonto() {
    try {
      chrome.storage.local.get('lcH10AccountId', function (d) {
        _wunschKonto = (d && d.lcH10AccountId) ? String(d.lcH10AccountId).trim() : '';
      });
      chrome.storage.onChanged.addListener(function (ch, area) {
        if (area === 'local' && ch.lcH10AccountId) {
          _wunschKonto = ch.lcH10AccountId.newValue ? String(ch.lcH10AccountId.newValue).trim() : '';
        }
      });
    } catch (e) { /* Node-Test: kein storage */ }
  }

  function mitKonto(url) {
    if (!_wunschKonto) return url;
    if (url.indexOf('/black-box/') >= 0) return url;      // dort bricht der Parameter
    if (/[?&]accountId=/.test(url)) return url;           // Aufrufer hat schon eins gesetzt
    return url + (url.indexOf('?') >= 0 ? '&' : '?') + 'accountId=' + encodeURIComponent(_wunschKonto);
  }

  function fetchJson(url, opts) {
    url = mitKonto(url);
    try { console.log('[LC.h10] fetchJson ->', url); } catch (e) {}
    opts = opts || {};
    var init = {
      method: opts.method || 'GET',
      credentials: opts.auth === 'bearer' ? 'omit' : 'include',
      headers: Object.assign({ 'Accept': 'application/json' }, opts.headers || {})
    };
    if (opts.body != null) {
      init.headers['Content-Type'] = 'application/json';
      init.body = typeof opts.body === 'string' ? opts.body : JSON.stringify(opts.body);
    }
    var kannProxy = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage;
    return (kannProxy ? fetchProxy(url, init) : fetchDirect(url, init)).then(function (r) {
      try { console.log('[LC.h10]', r && r.status, url.split('?')[0], r && r.data); } catch (e) {}
      return r;
    });
  }

  function qs(obj) {
    var p = new URLSearchParams();
    Object.keys(obj || {}).forEach(function (k) {
      var v = obj[k];
      if (v == null) return;
      if (Array.isArray(v)) v.forEach(function (x) { p.append(k, x); });
      else p.append(k, String(v));
    });
    var s = p.toString();
    return s ? '?' + s : '';
  }

  // ---------------------------------------------------------------- Members-API (Cookies)

  /* GEPRUEFT 29.08.2026: HTTP 200
     Antwort: { logged, plan, basePlan, accountId, modules, upsellInfo, ... }
     Pflicht vor jedem Batch: liefert accountId, plan und ob ueberhaupt eingeloggt. */
  function checkLogin() {
    return fetchJson(MEMBERS + '/extension/check-login');
  }

  /* GEPRUEFT 29.08.2026: HTTP 200
     Antwort: { data: { token, pacvueToken, user, account, isAccountOwner, permissions } }
     token       = opaker Hex-String fuer Authorization: Bearer <token> Richtung research-tools
     pacvueToken = JWT fuer Pacvue-eigene Endpoints (h10api.pacvue.com/rta) */
  function siteToken(accountId) {
    return fetchJson(MEMBERS + '/api/v1/site/token' + qs({ accountId: accountId }));
  }

  /* GEPRUEFT 29.08.2026: HTTP 200
     Antwort: { data: { subscription: { plan: { key, title, amount, ... }, ... } } }
     Detailliertere Plan-Info als checkLogin, inkl. Bullet-Points was der Plan enthaelt. */
  function subscription() {
    return fetchJson(MEMBERS + '/api/v1/customers/subscription/data');
  }

  /* GEPRUEFT 01.09.2026: HTTP 200 - ALLE Konten des Logins.
     Antwort: { results: { "<id>": { accountId, accountName, role, permissions,
                createdAt, isDefaultAccount, avatar } } }
     Der einzige Endpunkt, der die Konten AUFLISTET - check-login kennt nur das
     gerade aktive. Damit kann die Erweiterung die Konten zur Auswahl anbieten,
     statt eine Nummer abtippen zu lassen (LO 01.09.). Kostet kein Kontingent.
     Gefunden ueber die Adressen, die das H10-Dashboard selbst laedt. */
  function accounts() {
    return fetchJson(MEMBERS + '/api/v1/customers/accounts');
  }

  /* Fertige Liste [{ id, name, rolle, standard }], nach Namen sortiert. */
  function kontoListe() {
    return accounts().then(function (r) {
      var res = (r && r.data && r.data.results) || {};
      return Object.keys(res).map(function (k) {
        var a = res[k] || {};
        return { id: String(a.accountId != null ? a.accountId : k),
                 name: a.accountName || ('Konto ' + k),
                 rolle: a.role, standard: !!a.isDefaultAccount };
      }).sort(function (x, y) { return x.name.localeCompare(y.name); });
    });
  }

  /* GEPRUEFT 29.08.2026: HTTP 200
     Antwort: { results: { balance, total } }
     moduleId muss aus VALID_MODULE_IDS sein - alles andere gibt 400 "Invalid moduleId".
     Free-Beobachtung: xray=1000/1000, xray-api=2/5, cerebro=0/0,
     review-insights=100/100, search-expander=0/10. */
  function usesRemaining(moduleId) {
    return fetchJson(MEMBERS + '/api/v1/customers/uses/get-uses-remaining' + qs({ moduleId: moduleId }));
  }

  /* GEPRUEFT 29.08.2026: HTTP 200 auf Free-Plan
     Antwort: { asin, marketplace, last30DaysSales, userData: { plan, usesLeft } }
     Free-Limit: 10/Monat. usesLeft im Response mitfuehren, nie ohne pruefen aufrufen. */
  function salesEstimator(asin, host) {
    return fetchJson(MEMBERS + '/black-box/sales-estimator' + qs({
      asin: asin, marketplace: mp(host)
    }));
  }

  /* GEPRUEFT 29.08.2026: HTTP 200 auf Free-Plan
     Antwort: { userData: { plan, usesLeft } } - reiner Counter-Endpoint.
     Wenn nur der Restzaehler ohne echten Call gebraucht wird - kostet keine Use. */
  function salesEstimatorUses() {
    return fetchJson(MEMBERS + '/black-box/sales-estimator-uses');
  }

  /* GEPRUEFT 29.08.2026: HTTP 200 (POST) auf Free-Plan
     Antwort: { status:200, hash, left, totalAvailable, upsellInfo, plan, ... }
     Der Invocations-Counter fuers Xray-Popup. left=5/10 nach zwei Calls beobachtet. */
  function blackboxInvocations() {
    return fetchJson(MEMBERS + '/black-box/invocations', { method: 'POST', body: {} });
  }

  /* GEPRUEFT 29.08.2026: HTTP 200 auf Free-Plan
     Antwort: { results: { bsrHistory: [{ start, end, value }, ...] } }
     Volle BSR-Historie: fullHistory=1 lieferte 2853 Datenpunkte fuer B00UZA3HEG.
     Zeitraum sonst via dateFrom/dateTo (Unix-Sekunden). Keine Uses beobachtet. */
  function bsrChart(asin, host, opts) {
    opts = opts || {};
    var params = { asin: asin, marketplace: mp(host), allData: 1, replace: 0 };
    if (opts.fullHistory) params.fullHistory = 1;
    else {
      params.fullHistory = 0;
      if (opts.dateFrom) params.dateFrom = opts.dateFrom;
      if (opts.dateTo)   params.dateTo   = opts.dateTo;
    }
    return fetchJson(MEMBERS + '/api/v1/product/bsr-chart' + qs(params));
  }

  /* GEPRUEFT 29.08.2026: HTTP 200 auf Free-Plan
     Antwort: { results: { reviews: [{ timestamp, count }, ...] } }
     Tages-Aufloesung, days=365 lieferte 365 Punkte. Zaehlt aufs review-insights-Modul. */
  function reviewChart(asin, host, days) {
    return fetchJson(MEMBERS + '/api/v1/product/review-chart' + qs({
      asin: asin, marketplace: mp(host), days: days || 30, timezoneOffset: 0
    }));
  }

  /* GEPRUEFT 29.08.2026: HTTP 200
     Antwort: { results: { status, data: { exact, broad }, total, left } }
     Achtung: Param heisst SINGULAR 'keyword' - Plural gibt 400.
     Kostet nichts sichtbares, aber wahrscheinlich auf search-expander-Kontingent. */
  function searchVolume(keyword, host) {
    return fetchJson(MEMBERS + '/api/v1/keywords/search-volume' + qs({
      marketplace: mp(host), keyword: keyword
    }));
  }

  /* GEPRUEFT 29.08.2026: HTTP 200 auf Free-Plan
     Antwort: { results: { status, data: [keyword,...], uses: { total, left } } }
     Free-Limit: 50/Monat. Amazons intern gelernte verwandte Suchbegriffe fuer die ASIN. */
  function topKeywords(asin, host) {
    return fetchJson(MEMBERS + '/api/v1/keywords/top' + qs({
      asin: asin, marketplace: mp(host)
    }));
  }

  /* GEPRUEFT 29.08.2026: HTTP 200 auf Free-Plan
     Antwort: { results: { status, data: { <asin>: { performance, parentAsin, ... } }, uses } }
     Free-Limit: 100/Monat. Absatzverteilung zwischen Parent-ASIN-Varianten. */
  function childSalesPerformance(asin, host) {
    return fetchJson(MEMBERS + '/api/v1/chrome-extension/get-child-sales-performance' + qs({
      asin: asin, marketplace: mp(host)
    }));
  }

  /* GEPRUEFT 29.08.2026: HTTP 200
     Antwort: { status:"success", browseNodeExists, displayNames:[...] }
     Param heisst 'displayName' (NICHT asin) - der Kategorie-Name aus dem Amazon-Breadcrumb. */
  function checkBrowseNode(displayName, host) {
    return fetchJson(MEMBERS + '/api/v1/product/check-browse-node' + qs({
      displayName: displayName, marketplace: mp(host)
    }));
  }

  /* GEPRUEFT 29.08.2026: HTTP 200
     Antwort: { results:[], meta:{limit,offset,page,pageCount,totalCount,pageSize} }
     Die vom Nutzer im Keyword-Tracker angelegten Produkte, paginated. Leer wenn nichts getrackt. */
  function keywordTrackerProductsLite(host, opts) {
    opts = opts || {};
    return fetchJson(MEMBERS + '/api/v1/keywordtracker/products-lite' + qs({
      marketplace: mp(host), limit: opts.limit || 20, offset: opts.offset || 0
    }));
  }

  /* GEPRUEFT 29.08.2026: 500 auf Free-Plan ("plan limit of 0 keywords").
     Endpoint funktioniert, aber Free-Plan hat 0 KW-Slots.
     Params: { asin, phrases:[...], marketplace, copyTrackedHistory, specialChars, moduleId:"xray-api" } */
  function keywordTrackerAddProduct(asin, phrases, host) {
    return fetchJson(MEMBERS + '/api/v1/keywordtracker/product', {
      method: 'POST',
      body: {
        asin: asin, phrases: phrases, marketplace: mp(host),
        copyTrackedHistory: true, specialChars: true, moduleId: 'xray-api'
      }
    });
  }

  /* GEPRUEFT 29.08.2026: HTTP 200
     Antwort: { results: { config: { scoreParser:{bullets}, productParser:{sellerName, sellerUrl} } } }
     H10s eigene CSS-Selektoren fuer Amazon-DOM (bullets, sellerName, sellerUrl).
     Wird beim Extension-Boot einmal geladen und gecached. Nuetzlich als Cross-Check fuer den
     eigenen DOM-Extraktor - wenn H10s Selektoren failen, weiss man dass Amazon geaendert hat. */
  function parserConfig() {
    return fetchJson(MEMBERS + '/api/v1/site/get-parser-config');
  }

  /* GEPRUEFT 29.08.2026: HTTP 200 (POST) mit accountId-Param
     Antwort: { status:"error", message:"..." } - Server-side broken auf Free-Konto.
     Params: { asins:[...], marketplace, accountId, allData, replace, fullHistory } */
  function bsrWidget(asin, host, accountId) {
    return fetchJson(MEMBERS + '/api/v1/product/bsr-widget-data', {
      method: 'POST',
      body: {
        asins: [asin], marketplace: mp(host), accountId: accountId,
        allData: 1, replace: 0, fullHistory: 0
      }
    });
  }

  // ---------------------------------------------------------------- Research-Tools (Bearer)

  /* Token-Cache pro Account. Der opake token laeuft laut Beobachtung ~24h,
     wir cachen sicherheitshalber 55 min. */
  var _tokenCache = Object.create(null);

  function bearerFor(accountId) {
    var cached = _tokenCache[accountId];
    if (cached && cached.expiresAt > Date.now()) return Promise.resolve(cached.token);
    return siteToken(accountId).then(function (res) {
      if (!res.ok || !res.data || !res.data.data || !res.data.data.token) {
        throw new Error('siteToken HTTP ' + res.status);
      }
      var token = res.data.data.token;
      _tokenCache[accountId] = { token: token, expiresAt: Date.now() + 55 * 60 * 1000 };
      return token;
    });
  }

  function rt(accountId, path, params) {
    var ruf = function () {
      return bearerFor(accountId).then(function (token) {
        return fetchJson(RESEARCH + path + qs(params), {
          auth: 'bearer',
          headers: { 'Authorization': 'Bearer ' + token }
        });
      });
    };
    return ruf().then(function (res) {
      /* Abgelaufener/rotierter Token: Cache verwerfen und genau EINMAL neu
         holen - sonst laufen alle Research-Aufrufe bis zu 55 min in 401,
         obwohl ein frischer Token einen Request entfernt waere (Review 31.08.). */
      if (res && (res.status === 401 || res.status === 403)) {
        delete _tokenCache[accountId];
        return ruf();
      }
      return res;
    });
  }

  /* GEPRUEFT 29.08.2026: 402 "Not enough uses" auf Free-Plan (Auth ok, 0 balance)
     Auf Platinum+: HTTP 200 mit Google-Trends-Zeitreihe fuer die Keywords. */
  function googleTrends(accountId, keywords) {
    var kws = Array.isArray(keywords) ? keywords : [keywords];
    return rt(accountId, '/api/trends/get-google-trends', {
      period: 'year', 'keywords[]': kws, accountId: accountId
    });
  }

  /* GEPRUEFT 29.08.2026: 402 auf Free-Plan (search-expander balance 0/10)
     Long-Tail-Keywords (H10 Magnet-Ersatz). sort: -searchVolume | -competingProducts | ... */
  function longTailKeywords(accountId, seed, host, sort) {
    return rt(accountId, '/api/search-expander/v1/keywords/long-tail-new', {
      seedKeyword: seed, marketplaceId: mp(host, 'h10'), sort: sort || '-searchVolume'
    });
  }

  /* GEPRUEFT 29.08.2026: 402 auf Free-Plan
     Verwandte + Amazon-Suggest-Keywords (Cerebro-Ersatz light). */
  function suggestedKeywords(accountId, seed, host) {
    return rt(accountId, '/api/search-expander/v1/keywords/suggested-new', {
      seedKeyword: seed, marketplaceId: mp(host, 'h10')
    });
  }

  /* GEPRUEFT 29.08.2026: 402 auf Free-Plan
     Liste bisheriger Xray-Searches (SERP-Snapshots). */
  function xraySearches(accountId) {
    return rt(accountId, '/api/xray/v1/searches/', {});
  }

  /* GEPRUEFT 29.08.2026: 402 auf Free-Plan
     Detaildaten einer Xray-Session (die volle SERP-Tabelle). */
  function xraySearchData(accountId, searchId) {
    return rt(accountId, '/api/xray/v1/searches/' + encodeURIComponent(searchId) + '/data', {});
  }

  /* GEPRUEFT 29.08.2026: 403 "This action is unauthorized" auf Free-Plan.
     CPC-Historie fuer ein Keyword (Amazon-Ads-Kosten ueber Zeit). */
  function cpcHistory(accountId, keyword, host) {
    return rt(accountId, '/api/v1/amazon/cpc-history', {
      keyword: keyword, marketplaceId: mp(host, 'h10')
    });
  }

  // ---------------------------------------------------------------- Export

  LC.h10 = {
    MEMBERS: MEMBERS,
    RESEARCH: RESEARCH,
    // Platinum-Endpunkte (Popup-Toggle lcH10Platinum; auf Free 402/403):
    googleTrends: googleTrends,
    cpcHistory: cpcHistory,
    CONTROL: CONTROL,
    MARKETPLACE: MARKETPLACE,
    VALID_MODULE_IDS: VALID_MODULE_IDS,
    mp: mp,

    // Session
    checkLogin: checkLogin,
    siteToken: siteToken,
    subscription: subscription,
    accounts: accounts,
    kontoListe: kontoListe,
    usesRemaining: usesRemaining,
    parserConfig: parserConfig,

    // Members-API (Cookies)
    salesEstimator: salesEstimator,
    salesEstimatorUses: salesEstimatorUses,
    blackboxInvocations: blackboxInvocations,
    bsrChart: bsrChart,
    bsrWidget: bsrWidget,
    reviewChart: reviewChart,
    searchVolume: searchVolume,
    topKeywords: topKeywords,
    childSalesPerformance: childSalesPerformance,
    checkBrowseNode: checkBrowseNode,
    keywordTrackerProductsLite: keywordTrackerProductsLite,
    keywordTrackerAddProduct: keywordTrackerAddProduct,

    // Research-Tools (Bearer)
    googleTrends: googleTrends,
    longTailKeywords: longTailKeywords,
    suggestedKeywords: suggestedKeywords,
    xraySearches: xraySearches,
    xraySearchData: xraySearchData,
    cpcHistory: cpcHistory,

    // Low-Level
    fetchJson: fetchJson,
    qs: qs,
    bearerFor: bearerFor
  };


  /* -------- Aktiv-Gate + persistenter Cache (chrome.storage.local, TTL) ------
     ready() liefert einmalig Login/Plan wenn lcH10Enabled und angemeldet, sonst null.
     cache(key, ttlMin, fn) memoisiert Netzantworten in storage, kein LocalStorage. */
  var readyP = null;
  function storageGet(keys) {
    return new Promise(function (res) {
      try { chrome.storage.local.get(keys, function (d) { res(d || {}); }); }
      catch (e) { res({}); }
    });
  }
  function storageSet(o) { try { chrome.storage.local.set(o); } catch (e) { /* egal */ } }

  /* Aktives Konto, sobald ready() einmal gelaufen ist. Der Cache-Schluessel
     haengt daran - siehe LC.h10.cache. */
  var _aktivesKonto = '?';

  LC.h10.ready = function () {
    if (readyP) return readyP;
    readyP = storageGet(['lcH10Enabled', 'lcH10AccountId']).then(function (d) {
      if (!d.lcH10Enabled) return null;
      /* Wunschkonto HIER setzen, nicht auf das asynchrone LC_setKonto() beim
         Laden vertrauen: sonst geht ausgerechnet der erste check-login noch
         ohne accountId raus und meldet wieder das primaere Konto. */
      _wunschKonto = d.lcH10AccountId ? String(d.lcH10AccountId).trim() : '';
      return checkLogin().then(function (r) {
        try { console.log('[LC.h10] checkLogin', r && r.status, r && r.data); } catch (e) {}
        if (!r || !r.ok || !r.data) return null;
        var c = r.data;
        if (c.logged === false) return null;                                       // explizit ausgeloggt
        if (!c.logged && !c.plan && !c.accountId) return null;                     // gar keine Session
        /* Mehrfach-Konten: check-login meldet immer das Konto, das SERVERSEITIG
           in der Session aktiv ist - im Haus ist das oft das Free-Konto, auch
           wenn im H10-Web auf ein Premium-Konto umgeschaltet wurde. Wer im
           Popup eine Konto-Nummer eintraegt, ueberschreibt sie hier; die
           Bearer-Endpunkte (research-tools) nehmen sie direkt an. */
        var konto = d.lcH10AccountId ? String(d.lcH10AccountId).trim() : c.accountId;
        _aktivesKonto = String(konto || '?');
        return { accountId: konto, erkanntesKonto: c.accountId,
                 ueberschrieben: !!(d.lcH10AccountId && String(d.lcH10AccountId).trim() !== String(c.accountId)),
                 plan: c.plan, planLabel: c.planLabel };
      }).catch(function () { return null; });
    });
    return readyP;
  };

  /* Konto-Wechsel: verwirft die gemerkte Session UND die Bearer-Token, damit
     der naechste Aufruf frisch prueft statt die alte Antwort zu wiederholen. */
  LC.h10.vergissSession = function () {
    readyP = null;
    _aktivesKonto = '?';
    Object.keys(_tokenCache).forEach(function (k) { delete _tokenCache[k]; });
  };

  LC.h10.cache = function (key, ttlMin, fn) {
    /* Konto MIT in den Schluessel: sonst liefert der Speicher nach einem
       Konto-Wechsel tagelang weiter die Antworten des alten Kontos - bei
       googleTrends bis zu 7 Tage (LO 01.09.: "egal wie ich switche, er findet
       immer nur den normalen"). Alte Schluessel ohne Konto laufen ueber ihre
       TTL aus und werden nicht mehr gelesen. */
    var full = 'h10:' + _aktivesKonto + ':' + key;
    return storageGet(full).then(function (d) {
      var c = d[full];
      if (c && Date.now() - c.at < ttlMin * 60 * 1000) return c.value;
      return Promise.resolve(fn()).then(function (v) {
        /* Fehlantworten (402 Kontingent leer, 429, Proxy tot: ok:false) NICHT
           mit der Erfolgs-TTL einfrieren - ein einziger schlechter Abruf
           blendete sonst z.B. das Suchvolumen 7 Tage aus (Review 31.08.). */
        if (v && v.ok !== false) {
          var o = {}; o[full] = { at: Date.now(), value: v };
          storageSet(o);
        }
        return v;
      });
    });
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = LC.h10;
})();
