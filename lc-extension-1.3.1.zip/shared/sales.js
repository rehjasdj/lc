/* Verkaufsschaetz-Engine (LC.sales): BSR -> Verkaeufe/Monat -> x Preis = Umsatz.

   ARBEITSTEILUNG - das ist der Kern (Umbau 01.09.2026):

   1) FORM der Kurve kommt aus OEFFENTLICHEN Daten, nicht aus unseren Punkten.
      Die Beziehung BSR->Verkaeufe ist KEINE Gerade im log-log: sie wird zu
      hohen Raengen hin deutlich steiler. Gemessen an LOs echten H10-Werten
      (Garten DE) betraegt die Steigung -0.54 im Top-Bereich und -4.55 jenseits
      Rang 10.000; die veroeffentlichte Nova-Tabelle zeigt dieselbe Kruemmung.
      Eine einzige Potenzkurve MUSS deshalb oben unterschaetzen und unten
      ueberschaetzen - genau das waren die grossen Ausreisser (16.200 statt
      25.314 bei Rang 3, 110 statt 34 bei Rang 11.407).
      Darum: feste Stuetzpunkte je Kategorie, log-log-Interpolation dazwischen.

   2) HOEHE der Kurve kommt aus UNSEREN Daten. Schon ein einziger eigener Punkt
      verschiebt die ganze Kategorie-Kurve auf das richtige Niveau (gewichteter
      Median der Verhaeltnisse ist/Tabelle). Die Steigung wird NICHT mehr aus
      unseren Punkten geschaetzt - dafuer sind Badge-Werte zu verrauscht.

   3) EIGENER MESSWERT der ASIN (Seller Central 'm' / Helium 10 'h') schlaegt
      alles: er liefert den Wert, die Kurvenform nur die Umrechnung auf den
      heutigen Rang.

   Ergebnis ist immer EINE Zahl, keine Spanne.

   QUELLEN der Tabelle (oeffentlich, ohne Konto):
   - novadata.io/amazon-sales-estimator: Rang-Baender je Kategorie fuer
     amazon.com (Home & Kitchen als Basis; hier als geometrische Bandmitten).
   - Marktfaktor Deutschland 0.20: amzprep.com nennt fuer Rang 5.000 210
     Einheiten/Monat in den USA gegen 42 in Deutschland (= 0.20). Unabhaengig
     bestaetigt an LOs 9 echten Garten-Werten: Nova x 0.20 trifft Rang 320 ->
     1.600 (echt 1.527/1.827), Rang 2.236 -> 500 (echt 535), Rang 11.180 -> 120
     (echt 123). Der oft zitierte DE-Faktor 0.5 ist damit widerlegt.
   - Kategorie-Multiplikatoren in der Groessenordnung des oeffentlichen
     nexscope-ai/Amazon-Skills (Electronics 1.2, Toys 1.1, Sport 0.9,
     Bekleidung 0.8, Buecher 0.7, Rest 1.0).

   Laeuft wie shared/api.js im Addon (Content-Script + Popup); ohne LC bleibt
   das Modul inaktiv. */
(function () {
  'use strict';
  var LC = globalThis.LC || (typeof window !== 'undefined' ? window.LC : null);
  if (!LC) return;

  // ---------------------------------------------------------------- Kurventabelle
  // [Rang, Einheiten/Monat] fuer amazon.com, Kategorie-Basis Home & Kitchen.
  // Bandmitten geometrisch aus den Nova-Baendern (1-100, 101-1K, 1K-5K,
  // 5K-25K, 25K-100K, 100K+).
  // Rang 1 = 90.000/Monat: amzprep.com nennt fuer Home & Kitchen 3.000
  // Einheiten/TAG auf Platz 1. Ohne diesen Punkt lief die Extrapolation im
  // Spitzenbereich zu flach (Rang 3 wurde um Faktor 3,6 unterschaetzt).
  var KURVE_US = [[1, 90000], [10, 20000], [320, 8000], [2236, 2500], [11180, 600], [50000, 120], [200000, 20]];
  var MARKT_DE = 0.20;

  // Kategorie-Multiplikator relativ zu Home & Kitchen. Treffer per Teilstring
  // auf der deutschen Kategoriebezeichnung; unbekannt -> 1.0 (die Hoehe holt
  // sich die Kalibrierung ohnehin aus den eigenen Punkten).
  var KAT_MULT = [
    [/elektronik|computer|foto|handy|hifi/, 1.2],
    [/spielzeug|spiele|games/, 1.1],
    [/k(ue|ü)che|haushalt|wohnen|garten|baumarkt|heimwerk/, 1.0],
    [/sport|freizeit|auto|motorrad/, 0.9],
    [/bekleidung|schuhe|schmuck|mode|koffer/, 0.8],
    [/b(ue|ü)cher|buch|kindle|musik|dvd/, 0.7]
  ];
  function katMult(kat) {
    var k = String(kat || '');
    for (var i = 0; i < KAT_MULT.length; i++) if (KAT_MULT[i][0].test(k)) return KAT_MULT[i][1];
    return 1;
  }

  /* Tabellenwert fuer einen Rang: log-log-Interpolation zwischen den
     Stuetzpunkten, ausserhalb mit der Steigung des Randsegments extrapoliert. */
  function kurveBasis(bsr, kat) {
    if (!(bsr > 0)) return null;
    var lx = KURVE_US.map(function (p) { return Math.log(p[0]); });
    var ly = KURVE_US.map(function (p) { return Math.log(p[1]); });
    var x = Math.log(bsr), i;
    if (x <= lx[0]) i = 0;
    else if (x >= lx[lx.length - 1]) i = lx.length - 2;
    else { for (i = 0; i < lx.length - 1; i++) { if (x <= lx[i + 1]) break; } }
    var b = (ly[i + 1] - ly[i]) / (lx[i + 1] - lx[i]);
    var menge = Math.exp(ly[i] + b * (x - lx[i])) * MARKT_DE * katMult(kat);
    return menge > 0 ? menge : null;
  }

  // ---------------------------------------------------------------- Niveau
  // Automatische Paare altern: Gewicht 1 frisch, linear auf 0.3 bei 90 Tagen.
  function alterGewicht(ts) {
    var tage = (Date.now() - (ts || 0)) / 86400000;
    if (tage <= 0) return 1;
    if (tage >= 90) return 0.3;
    return 1 - 0.7 * (tage / 90);
  }

  /* VARIANTEN-AUFSCHLAG fuer Badge-Paare: Amazons "X+ Mal gekauft" zaehlt nur
     die GEWAEHLTE Variante, Seller Central und H10 die ganze Familie. Wert 2.5
     an LOs echten Garten-Daten kalibriert. Fuer 'm'/'h' kein Aufschlag. */
  var VARIANTEN_AUFSCHLAG = 2.5;

  function gewichteterMedian(elems) {
    if (!elems.length) return null;
    var s = elems.slice().sort(function (a, b) { return a.v - b.v; });
    var sw = 0, ak = 0;
    s.forEach(function (e) { sw += e.w; });
    for (var i = 0; i < s.length; i++) { ak += s[i].w; if (ak >= sw / 2) return s[i].v; }
    return s[s.length - 1].v;
  }

  /* Niveaufaktor: gewichteter Median von (eigener Wert / Tabellenwert). Robust
     gegen Ausreisser - ein einzelner Badge-Eimer kann die Kurve nicht kippen.
     paar = [bsr, menge, ts, quelle?]; 'm' Seller Central (Gewicht 3),
     'h' Helium 10 (2), sonst Badge (Altersgewicht, mit Varianten-Aufschlag). */
  /* Plausibilitaetsfenster JE PUNKT, nicht erst am Ergebnis. Ein Paar, dessen
     Verhaeltnis um mehr als Faktor 10 von der Tabelle abweicht, ist kein
     verrauschter Messwert - es ist die falsche RANG-SKALA: ein Unterkategorie-
     Rang, der unter der Hauptkategorie abgelegt wurde. Live-Beleg (LO 01.09.,
     cal:garten): "Rang 31 -> 2 Verkaufe", "Rang 8 -> 7", "Rang 2 -> 153" - in
     Garten waeren das Zehntausende. 14 der 20 Punkte lagen so, der gewichtete
     Median folgte damit der Mehrheit auf der falschen Skala und druckte das
     Niveau auf 0.124: BSR 3453 wurde als 42 statt 535 angezeigt.
     Die Punkte bleiben gespeichert - sie zaehlen nur nicht als Hauptkategorie-
     Beleg. Gerechnet wird ausschliesslich mit dem Oberkategorie-BSR. */
  var PUNKT_MIN = 0.1, PUNKT_MAX = 10;
  function niveauAus(paare, kat) {
    if (!paare || !paare.length) return null;
    var el = [];
    paare.forEach(function (p) {
      if (!(p[0] > 0) || !(p[1] > 0)) return;
      var tab = kurveBasis(p[0], kat);
      if (!tab) return;
      var q = p[3];
      var menge = (q === 'm' || q === 'h') ? p[1] : p[1] * VARIANTEN_AUFSCHLAG;
      var v = menge / tab;
      if (!(v > PUNKT_MIN && v < PUNKT_MAX)) return;
      el.push({ v: v, w: q === 'm' ? 3 : q === 'h' ? 2 : alterGewicht(p[2]) });
    });
    if (!el.length) return null;
    var v = gewichteterMedian(el);
    if (!(v > PUNKT_MIN && v < PUNKT_MAX)) return null;
    return { wert: v, n: el.length };
  }

  function rund(est) {
    return est >= 1000 ? Math.round(est / 100) * 100 : (est >= 100 ? Math.round(est / 10) * 10 : Math.round(est));
  }

  function kategorieNorm(k) { return String(k == null ? '' : k).toLowerCase().trim(); }

  function faktorAus(calFaktor, kat) {
    calFaktor = calFaktor || {};
    var roh = calFaktor[kat] != null ? calFaktor[kat] : calFaktor['*'];
    var f = Number(roh);
    return roh != null && isFinite(f) && f > 0 ? f : 1;
  }

  /* Alle Kategorien zusammen als Rueckfall: heisst die Kategorie auf der Seite
     mal anders (Unterkategorie, Schreibweise), stuende sonst 0 Punkte da. */
  function poolPaare() {
    var out = [];
    var kats = (typeof CACHE !== 'undefined' && CACHE && CACHE.kats) || null;
    if (!kats) return out;
    Object.keys(kats).forEach(function (k) { out = out.concat(kats[k] || []); });
    return out;
  }

  /* Eine Zahl, keine Spanne. quelle: 'kalibriert' (Tabelle + eigenes Niveau),
     'kalibriertAlle' (Niveau aus allen Kategorien), 'tabelle' (nur oeffentliche
     Tabelle, noch kein eigener Punkt). */
  function schaetzung(bsr, paare, faktor, kat) {
    var tab = kurveBasis(bsr, kat);
    if (tab == null) return null;
    var niv = niveauAus(paare, kat), quelle = 'kalibriert', n = paare ? paare.length : 0;
    if (!niv) {
      var pool = poolPaare();
      var nivP = pool.length ? niveauAus(pool, kat) : null;
      if (nivP) { niv = nivP; quelle = 'kalibriertAlle'; n = pool.length; }
      else { quelle = 'tabelle'; n = 0; }
    }
    var menge = tab * (niv ? niv.wert : 1) * faktor;
    if (!(menge >= 1)) return null;
    return { menge: rund(menge), quelle: quelle, paare: n, faktor: faktor,
      niveau: niv ? Math.round(niv.wert * 100) / 100 : 1, tabelle: rund(tab) };
  }
  // ---------------------------------------------------------------- Speicher-Cache
  // cal:*-Keys + calFaktor einmal beim Laden lesen, danach per storage.onChanged
  // aktuell halten - schaetzeSync() braucht dann keinen eigenen Storage-Zugriff.
  var CACHE = { kats: Object.create(null), faktor: {} };

  function cacheAufbauen(d) {
    var kats = Object.create(null);
    Object.keys(d || {}).forEach(function (k) {
      if (k.indexOf('cal:') !== 0) return;
      var kat = kategorieNorm(k.slice(4));
      var tab = d[k] || {};
      kats[kat] = Object.keys(tab).map(function (a) { return tab[a]; })
        .filter(function (p) { return Array.isArray(p) && p[0] > 0 && p[1] > 0; });
    });
    CACHE.kats = kats;
    CACHE.faktor = (d && d.calFaktor && typeof d.calFaktor === 'object') ? d.calFaktor : {};
    CACHE.autoLernen = !d || d.lcAutoLearn !== false;   // Popup-Toggle, Standard AN
  }

  function cacheLaden() {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return Promise.resolve(CACHE);
    return new Promise(function (res) {
      chrome.storage.local.get(null, function (d) { cacheAufbauen(d); res(CACHE); });
    });
  }

  var bereitPromise = cacheLaden();

  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener(function (ch, area) {
        if (area !== 'local') return;
        var betroffen = Object.keys(ch).some(function (k) { return k.indexOf('cal:') === 0 || k === 'calFaktor' || k === 'lcAutoLearn'; });
        if (betroffen) cacheLaden();
      });
    }
  } catch (e) { /* kein storage im Test-Kontext */ }

  // ---------------------------------------------------------------- API
  function leseKategorie(kat) {
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) {
      return Promise.resolve({ paare: [], faktor: 1 });
    }
    var key = 'cal:' + kat;
    return new Promise(function (res) {
      chrome.storage.local.get([key, 'calFaktor'], function (d) {
        var tab = (d && d[key]) || {};
        var paare = Object.keys(tab).map(function (a) { return tab[a]; })
          .filter(function (p) { return Array.isArray(p) && p[0] > 0 && p[1] > 0; });
        res({ paare: paare, faktor: faktorAus(d && d.calFaktor, kat), tab: tab });
      });
    });
  }

  /* Erst wenn der Cache steht rechnen: direkt nach einem Extension-Reload lief
     die erste Panel-Berechnung sonst gegen einen leeren Cache - kein Pool,
     also Startkurve, also exakt der Badge-Wert. Genau das sah aus wie ein
     zurueckgesetzter Schaetzer (LO 01.09.). */
  function bereitDann(fn) {
    return bereitPromise.catch(function () { return null; }).then(fn);
  }

  function schaetze(bsr, hauptkategorie) {
    var kat = kategorieNorm(hauptkategorie);
    return bereitDann(function () { return leseKategorie(kat); })
      .then(function (d) { return schaetzung(bsr, d.paare, d.faktor, kat); });
  }

  /* Schaetzung MIT eigenem Messpunkt dieser ASIN: ein H10-Klick ('h') oder eine
     Seller-Central-Zahl ('m') fuer genau diese ASIN ist die beste Information,
     die es gibt. Der Wert kommt vom Messpunkt, die Kurvenform rechnet ihn nur
     auf den heutigen Rang um: menge = wert * tabelle(heute) / tabelle(damals).
     Steht der Rang noch, kommt exakt der gemessene Wert heraus. */
  function schaetzeAsin(bsr, hauptkategorie, asin) {
    var kat = kategorieNorm(hauptkategorie);
    return bereitDann(function () { return leseKategorie(kat); }).then(function (d) {
      var e = asin && d.tab && d.tab[asin];
      if (e && (e[3] === 'h' || e[3] === 'm') && e[1] > 0 && e[0] > 0 && bsr > 0) {
        var jetztT = kurveBasis(bsr, kat), damalsT = kurveBasis(e[0], kat);
        if (jetztT && damalsT) {
          var menge = e[1] * (jetztT / damalsT);
          if (menge >= 1) {
            return { menge: rund(menge * d.faktor), quelle: 'eigen', eigenArt: e[3],
              ankerWert: e[1], ankerBsr: e[0], ankerTs: e[2],
              paare: d.paare.length, faktor: d.faktor };
          }
        }
      }
      return schaetzung(bsr, d.paare, d.faktor, kat);
    });
  }

  /* Ein Kalibrier-Paar ablegen - zentrale Lern-API fuer dp-sales (Produktseite)
     UND serp-quickview (parst fremde DP-HTML nebenbei mit). Race-sicher: frisch
     lesen, nur den eigenen Eintrag setzen. MAX 300 je Kategorie, manuelle
     'm'-Paare (Seller Central) werden nie weggeraeumt. Gibt die neue
     Paar-Anzahl der Kategorie zurueck (fuer den Lern-Chip). */
  var MERK_MAX = 300;
  function merken(hauptkategorie, asin, bsr, kaufzahl, quelle) {
    var kat = kategorieNorm(hauptkategorie);
    if (!kat || !asin || !(bsr > 0) || !(kaufzahl > 0)) return Promise.resolve(null);
    // Popup-Toggle "sammelt automatisch": blockt nur STILLE Auto-Paare (Badge/
    // Quick-View, quelle undefined) - bewusste Aktionen ('h' Klick, 'm' Import) immer.
    if (!quelle && CACHE.autoLernen === false) return Promise.resolve(null);
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return Promise.resolve(null);
    var key = 'cal:' + kat;
    var eintrag = (quelle === 'm' || quelle === 'h') ? [bsr, kaufzahl, Date.now(), quelle] : [bsr, kaufzahl, Date.now()];
    var rang = function (q) { return q === 'm' ? 2 : q === 'h' ? 1 : 0; };
    return new Promise(function (res) {
      chrome.storage.local.get(key, function (d) {
        var tab = (d && d[key]) || {};
        // Kein Downgrade: ein Seller-Central-/H10-Eintrag desselben ASIN wird
        // nicht von einem Badge-Eimer ueberschrieben (LO 01.09.).
        var alt = tab[asin];
        if (!alt || rang(eintrag[3]) >= rang(alt[3])) tab[asin] = eintrag;
        var keys = Object.keys(tab);
        if (keys.length > MERK_MAX) {
          var auto = keys.filter(function (k) { return tab[k][3] !== 'm' && tab[k][3] !== 'h'; });
          auto.sort(function (x, y) { return tab[x][2] - tab[y][2]; });
          auto.slice(0, keys.length - MERK_MAX).forEach(function (k) { delete tab[k]; });
        }
        var o = {}; o[key] = tab;
        chrome.storage.local.set(o, function () { res(Object.keys(tab).length); });
      });
    });
  }

  function schaetzeSync(bsr, hauptkategorie) {
    var kat = kategorieNorm(hauptkategorie);
    var paare = CACHE.kats[kat] || [];
    return schaetzung(bsr, paare, faktorAus(CACHE.faktor, kat), kat);
  }

  /* Batch-Variante fuer Bestseller-Listen (onpage.js): dort stehen Rang (= BSR
     der Listen-Kategorie) und Kaufzahl an Dutzenden Kacheln gleichzeitig - ein
     einziges RMW statt 50 parallelen merken()-Aufrufen, die sich gegenseitig
     die Eintraege wegschreiben wuerden. Gleiche Regeln: Auto-Quelle, Toggle-
     Gate, kein Downgrade, 'm'/'h' nie wegraeumen. */
  function merkenViele(hauptkategorie, liste) {
    var kat = kategorieNorm(hauptkategorie);
    if (!kat || !liste || !liste.length) return Promise.resolve(0);
    if (CACHE.autoLernen === false) return Promise.resolve(0);
    if (typeof chrome === 'undefined' || !chrome.storage || !chrome.storage.local) return Promise.resolve(0);
    var key = 'cal:' + kat, jetzt = Date.now();
    return new Promise(function (res) {
      chrome.storage.local.get(key, function (d) {
        var tab = (d && d[key]) || {}, neu = 0;
        liste.forEach(function (e) {
          if (!e || !e.asin || !(e.bsr > 0) || !(e.kz > 0)) return;
          var alt = tab[e.asin];
          if (alt && (alt[3] === 'm' || alt[3] === 'h')) return;   // kein Downgrade
          if (!alt) neu++;
          tab[e.asin] = [e.bsr, e.kz, jetzt];
        });
        var keys = Object.keys(tab);
        if (keys.length > MERK_MAX) {
          var auto = keys.filter(function (k) { return tab[k][3] !== 'm' && tab[k][3] !== 'h'; });
          auto.sort(function (x, y) { return tab[x][2] - tab[y][2]; });
          auto.slice(0, keys.length - MERK_MAX).forEach(function (k) { delete tab[k]; });
        }
        var o = {}; o[key] = tab;
        chrome.storage.local.set(o, function () { res(neu); });
      });
    });
  }

  LC.sales = {
    schaetze: schaetze,
    schaetzeAsin: schaetzeAsin,
    schaetzeSync: schaetzeSync,
    merken: merken,
    merkenViele: merkenViele,
    kurveBasis: kurveBasis,
    niveauAus: niveauAus,
    rund: rund,
    bereit: function () { return bereitPromise; }
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = LC.sales;
})();
