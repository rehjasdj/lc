'use strict';

var assert = require('assert');
global.LC = { onpage: { panel: [] } };

require('../shared/api.js');
require('../features/dp-keywords.js');
var kw = global.LC.onpage.kwCheck;
var data = {
  keywordRuns: [
    { lauf_id: 'alt', plattform_id: 'amazon', seed: 'regal', gestartet_am: '2026-08-30T10:00:00Z' },
    { lauf_id: 'neu', plattform_id: 'amazon', seed: 'schrank', gestartet_am: '2026-08-31T10:00:00Z' },
    { lauf_id: 'neu', plattform_id: 'amazon', seed: 'schrank', gestartet_am: '2026-08-31T10:00:00Z' },
    { lauf_id: 'ebay', plattform_id: 'ebay', seed: 'regal', gestartet_am: '2026-09-01T10:00:00Z' }
  ],
  keywordEvidence: [
    { lauf_id: 'alt', plattform_id: 'amazon', plattform: 'Amazon', seed: 'regal', such_prefix: 'regal', keyword: 'bambus regal', position: 2, antwort_anzahl: 5 },
    { lauf_id: 'neu', plattform_id: 'amazon', plattform: 'Amazon', seed: 'schrank', such_prefix: 'schrank', keyword: 'badschrank', position: 1, antwort_anzahl: 5 },
    { lauf_id: 'ebay', plattform_id: 'ebay', plattform: 'eBay', seed: 'regal', such_prefix: 'regal', keyword: 'ebay regal', position: 1, antwort_anzahl: 5 }
  ],
  keywordSerpMeasurements: [
    { lauf_id: 'alt', plattform_id: 'amazon', keyword: 'bambus regal' },
    { lauf_id: 'neu', plattform_id: 'amazon', keyword: 'badschrank' }
  ]
};

assert.deepStrictEqual(kw.laeufe(data).map(function (x) { return x.run.lauf_id; }), ['neu', 'alt'],
  'Dropdown muss nur belegte Amazon-Laeufe und den neuesten zuerst enthalten');
var nurAlt = kw.keywordsFuerLauf(data, 'alt');
assert.deepStrictEqual(nurAlt.map(function (x) { return x.keyword; }), ['bambus regal'],
  'Keyword-Auswahl darf keine Keywords anderer Laeufe enthalten');
assert.strictEqual(nurAlt[0].lauf_ids, 'alt');
assert.strictEqual(nurAlt[0].serp_lauf_id, 'alt');
console.log('KEYWORD-RUN OK - Abdeckung und Ranking bleiben im gewaehlten Lauf');
