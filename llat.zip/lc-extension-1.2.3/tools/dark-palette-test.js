/* Palette-Test:  node tools/dark-palette-test.js
   ---------------------------------------------------------------------------
   Prueft die Zusage "kein Regler macht Amazons Text unlesbar" - an der ECHTEN
   Rechnung: theme() wird aus dark.js herausgeschnitten und ausgefuehrt, nicht
   nachgebaut. Aendert jemand die Faktoren in dark.js, schlaegt der Test an,
   ohne dass man ihn mitpflegen muss.

   Drei Regler: Dunkelstufe (lcDunkel), Theme-Kontrast/Spreizung (lcSpreiz),
   Textkontrast (lcKontrast). Alle Kombinationen in 10er-Schritten, jede
   Textfarbe gegen jede Flaeche nach WCAG. Grenze ist 3.0 (nicht 4.5):
   "ausgewaschen" ist seit 30.08. ein erlaubter Look, unlesbar nicht.
   Exit 1, wenn irgendeine Kombination darunter faellt. */
const fs = require('fs'), path = require('path');
const src = fs.readFileSync(path.join(__dirname, '..', 'dark.js'), 'utf8');
const cut = (a, b) => src.slice(src.indexOf(a), src.indexOf(b));
const code = cut('var BASIS =', 'var hell =').replace(/localStorage[^;]*;/g, '');
const box = { root: { style: { setProperty(k, v) { box.out[k] = v; } }, classList: { toggle() {} } }, out: {} };
new Function('root', 'Object', 'Math', 'parseFloat', 'isFinite', 'parseInt', 'box',
  code + '\nbox.theme=theme;')(box.root, Object, Math, parseFloat, isFinite, parseInt, box);

const MIN = 3.0;
const ch = h => { const n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
const lum = c => { const a = ch(c).map(v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }); return .2126 * a[0] + .7152 * a[1] + .0722 * a[2]; };
const q = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };

let min = 99, worst = '', n = 0;
for (let du = 0; du <= 100; du += 10)
  for (let sp = 0; sp <= 100; sp += 10)
    for (let ko = 0; ko <= 100; ko += 10) {
      box.out = {};
      box.theme({ lcDunkel: du, lcSpreiz: sp, lcKontrast: ko, lcBild: 100, lcFont: '' });
      const o = box.out;
      for (const f of ['--lc-bg', '--lc-card', '--lc-raised'])
        for (const t of ['--lc-fg', '--lc-fg2', '--lc-fg3', '--lc-link', '--lc-price']) {
          const c = q(o[t], o[f]); n++;
          if (c < min) { min = c; worst = `dunkel=${du} spreiz=${sp} kontrast=${ko}  ${t}(${o[t]}) auf ${f}(${o[f]}) = ${c.toFixed(2)}:1`; }
        }
    }
// Regler auf 50/50/50 muss die Originalpalette liefern
box.out = {};
box.theme({ lcDunkel: 50, lcSpreiz: 50, lcKontrast: 50, lcBild: 100, lcFont: '' });
console.log('Standardstellung: bg=' + box.out['--lc-bg'] + ' card=' + box.out['--lc-card'] + ' fg=' + box.out['--lc-fg']);
console.log(`${n} Paarungen geprueft. Schlechteste:\n  ${worst}`);
console.log(min >= MIN ? `\nOK - keine Reglerstellung faellt unter ${MIN}:1` : `\nFEHLER - faellt unter ${MIN}:1`);
process.exit(min >= MIN ? 0 : 1);
