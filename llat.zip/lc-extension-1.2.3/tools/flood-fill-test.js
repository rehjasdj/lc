/* Flood-Fill-Test:  node tools/flood-fill-test.js
   Prueft alphaMaske aus dark.js (dem eingebauten Original, nicht der Kopie im
   Vergleichsblatt) gegen die Assertions des Tests vom 28.08.2026 - plus die
   Notbremse fuer gefressene weisse Produkte. */
const fs = require('fs'), path = require('path'), assert = require('assert');
const src = fs.readFileSync(path.join(__dirname, '..', 'dark.js'), 'utf8');
const code = src.slice(src.indexOf('var HELLW = 228'), src.indexOf('var maskeSetzen'));
const alphaMaske = new Function(code + '\nreturn alphaMaske;')();

function bild(w, h, eckenWeiss, schattiert) {
  const px = new Uint8ClampedArray(w * h * 4);
  const set = (x, y, r, g, b) => { const o = (y * w + x) * 4; px[o] = r; px[o + 1] = g; px[o + 2] = b; px[o + 3] = 255; };
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) set(x, y, 255, 255, 255);
  for (let y = 10; y < 40; y++) for (let x = 10; x < 40; x++) set(x, y, 120, 60, 30);    // Produkt
  for (let y = 20; y < 30; y++) for (let x = 20; x < 30; x++) set(x, y, 255, 255, 255);  // GROSSE eingeschlossene helle Flaeche (3,3%)
  if (schattiert) for (let y = 25; y < 30; y++) for (let x = 20; x < 30; x++) set(x, y, 210, 210, 210);  // ...mit Schattierung = Produktflaeche
  for (let y = 12; y < 16; y++) for (let x = 32; x < 36; x++) set(x, y, 255, 255, 255);  // KLEINES Loch (0,5% -> Latten-Durchbruch)
  for (let y = 10; y < 40; y++) for (let x = 40; x < 44; x++) set(x, y, 205, 205, 205);  // Schatten
  if (!eckenWeiss) for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) if (x < 5 || y < 5 || x >= w - 5 || y >= h - 5) set(x, y, 40, 80, 120);
  return px;
}
const W = 60, H = 50, a = alphaMaske(bild(W, H, true, true), W, H), at = (x, y) => a[y * W + x];
assert.ok(a, 'Maske fuer weissen Grund');
assert.strictEqual(at(0, 0), 0, 'Ecke transparent');
assert.strictEqual(at(50, 45), 0, 'Grund transparent');
assert.strictEqual(at(15, 15), 255, 'Produkt bleibt');
assert.strictEqual(at(25, 22), 255, 'grosse SCHATTIERTE Flaeche bleibt (weisser Teil)');
assert.strictEqual(at(25, 27), 255, 'grosse SCHATTIERTE Flaeche bleibt (grauer Teil)');
assert.strictEqual(at(33, 13), 0, 'KLEINES eingeschlossenes Loch wird entfernt (Latten-Durchbruch)');
assert.ok(at(42, 20) > 0 && at(42, 20) < 255, 'Schatten halbdurchsichtig: ' + at(42, 20));
assert.strictEqual(at(39, 20), 255, 'Produktkante neben dem Schatten bleibt voll');
// Dieselbe grosse Flaeche OHNE Schattierung = gleichmaessig reinweiss = Faecher-
// Oeffnung eines Regals -> wird jetzt auch entfernt (LO-Bild 30.08.)
const a2 = alphaMaske(bild(W, H, true, false), W, H);
assert.strictEqual(a2[25 * W + 25], 0, 'grosser REINWEISSER Durchbruch (Faecher-Oeffnung) wird entfernt');
assert.strictEqual(alphaMaske(bild(W, H, false, true), W, H), null, 'Lifestyle-Foto unangetastet');

// Notbremse: komplett weisses Bild (= weisses Produkt komplett gefressen) -> null
const leer = new Uint8ClampedArray(W * H * 4).fill(255);
assert.strictEqual(alphaMaske(leer, W, H), null, 'Notbremse: fast alles gefressen -> keine Maske');

console.log('FLOOD-FILL OK - 28.08.-Verhalten + Notbremse');
