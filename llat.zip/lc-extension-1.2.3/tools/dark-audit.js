/* Dark-Mode-Pruefung fuer amazon.de.
   ---------------------------------------------------------------------------
   So benutzen: Amazon-Seite oeffnen (Produktseite, SERP, Warenkorb, Konto ...),
   Dark Mode EINSCHALTEN, F12 -> Konsole -> diese Datei komplett einfuegen.

   Was sie macht: geht JEDES sichtbare Textfeld durch, sucht den tatsaechlichen
   Hintergrund (erster Vorfahre mit deckender Flaeche) und rechnet den
   WCAG-Kontrast aus. Alles unter 4.5:1 landet in der Tabelle - das sind genau
   die Stellen, an denen dark.css etwas kaputt macht: heller Text auf heller
   Flaeche, dunkler auf dunkler, oder eine Amazon-Farbe, die nicht mitgezogen
   wurde. Raten ist damit ueberfluessig, jede Meldung ist eine echte Stelle.

   Die Tabelle ist nach Kontrast sortiert (schlimmstes zuerst) und nach
   Selektor gruppiert, sonst sind es tausend Zeilen. Das zurueckgegebene Array
   enthaelt unter .el das echte Element - im Konsolen-Log anklickbar, springt
   direkt in den Elements-Tab. */
(function () {
  var GRENZE = 4.5;   // WCAG AA fuer normalen Text

  var lum = function (c) {
    var a = c.map(function (v) {
      v /= 255;
      return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    });
    return 0.2126 * a[0] + 0.7152 * a[1] + 0.0722 * a[2];
  };
  var rgb = function (s) {
    var m = String(s).match(/rgba?\(([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s/]+([\d.]+))?/);
    return m ? { c: [+m[1], +m[2], +m[3]], a: m[4] == null ? 1 : +m[4] } : null;
  };
  // Der Hintergrund, den das Auge sieht: erster Vorfahre, der wirklich deckt.
  var grund = function (el) {
    for (var n = el; n && n.nodeType === 1; n = n.parentElement) {
      var b = rgb(getComputedStyle(n).backgroundColor);
      if (b && b.a > 0.5) return b.c;
    }
    return [20, 26, 31];   // Seitenhintergrund, falls alles transparent ist
  };
  var quote = function (a, b) {
    var x = lum(a), y = lum(b);
    return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
  };

  var treffer = {};
  document.querySelectorAll('body *').forEach(function (el) {
    // Nur Elemente mit EIGENEM Text - sonst meldet jeder Container sein Kind mit
    var t = '';
    el.childNodes.forEach(function (n) { if (n.nodeType === 3) t += n.textContent; });
    if (!t.trim()) return;

    var s = getComputedStyle(el);
    if (s.visibility === 'hidden' || s.display === 'none' || +s.opacity < 0.1) return;
    var r = el.getBoundingClientRect();
    if (!r.width || !r.height) return;

    var f = rgb(s.color);
    if (!f) return;
    var g = grund(el);
    var k = quote(f.c, g);
    if (k >= GRENZE) return;

    var kl = (typeof el.className === 'string' && el.className.trim())
      ? '.' + el.className.trim().split(/\s+/).slice(0, 3).join('.') : '';
    var key = el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') + kl;

    if (!treffer[key]) {
      treffer[key] = {
        Selektor: key, Kontrast: +k.toFixed(2), Anzahl: 0,
        Text: t.trim().slice(0, 40), Farbe: s.color,
        Grund: 'rgb(' + g.join(',') + ')', el: el
      };
    }
    treffer[key].Anzahl++;
    if (k < treffer[key].Kontrast) { treffer[key].Kontrast = +k.toFixed(2); treffer[key].el = el; }
  });

  var liste = Object.keys(treffer).map(function (k) { return treffer[k]; })
    .sort(function (a, b) { return a.Kontrast - b.Kontrast; });

  console.log('%cDark-Mode-Pruefung: ' + liste.length + ' Stellen unter ' + GRENZE + ':1',
    'font-size:14px;font-weight:bold;color:#ffb04d');
  console.table(liste.map(function (o) {
    return { Selektor: o.Selektor, Kontrast: o.Kontrast, Anzahl: o.Anzahl, Text: o.Text, Farbe: o.Farbe, Grund: o.Grund };
  }));
  console.log('Elemente (anklickbar):', liste.map(function (o) { return o.el; }));
  return liste;
})();
