# Listing Checker: Nutzen, Datenverarbeitung, Grenzen (Stand 2026-09-01)

Browser-Erweiterung für Chrome und Firefox, gebaut für die tägliche Arbeit an unseren eigenen Amazon-Listings (Deuba, Casaria, Monzana, Gardebruk). Sie läuft vollständig im Browser des Nutzers. Es gibt keinen Server dahinter und kein Abo. Gewachsen seit dem 26.08.2026 im täglichen Einsatz; aktueller Stand v1.3.0.

In Zahlen: 30 Bausteine auf der Seite, 16 freigegebene Shop-Adressen, drei Berechtigungen. Jeder Baustein ersetzt gezielt eine Funktion, für die sonst Helium 10, Keepa, Jungle Scout oder Seller Assistant fällig wären.

## 1. Was sie im Alltag tut

**Auf der Produktseite** stehen die Kennzahlen automatisch dort, wo Amazon das jeweilige Thema zeigt. Man öffnet die Seite und sieht:

- **Bestseller-Rang** an der Kategorie in der Brotkrume, verlinkt auf Amazons Top-100-Liste; dazu ein Kategorie-Einblick (Top 10 mit Preis-Median und den drei stärksten Marken)
- **Zeichenzähler** für Titel (max. 75) und Highlights (max. 125), ein Kopierknopf an jedem Bullet
- **Buybox komplett**: Status, alle Anbieter mit Preis und Versender (derselbe Abruf wie Amazons „Weitere Angebote“, 15 Minuten zwischengespeichert), Abstand zum Buybox-Gewinner, Buybox-Quote der letzten 30 Tage, was sich seit dem letzten Besuch geändert hat
- **Preis-Alarme**: eigener Preis angreifbar? Von einer Sammelprüfung als unterboten markiert? Beobachtete Artikel mit Veränderung?
- **Unsere Preise auf Otto, eBay, Kaufland, bol und im Shop** unter dem Amazon-Preis, mit Beleg-Link. Liegt ein Kanal darunter, fällt das auf, bevor die Buybox leidet
- **Preis- und BSR-Verlauf** als Kurve; die Daten entstehen nebenbei bei jedem Seitenbesuch eines Kollegen
- **Listing-Score 0–100** nach unseren eigenen Regeln (Titel-/Highlight-Grenzen, Bullet-Längen, Beschreibung), offene Punkte zuerst; dazu eine Bild-Diagnose (Videos? Hi-Res? A+-Module? Brand Story?)
- **Keyword-Abdeckung** je Messlauf gegen Titel, Highlights, Bullets und Beschreibung – jedes Keyword aufklappbar bis zur Fundstelle im Text, mit Rang-Prüfung (organische Position je Keyword, gedrosselt) und Amazons Suchhäufigkeit (SFR) daneben
- **Backend-Suchbegriffe** direkt auf der Seite pflegen: Byte-Zähler (Ziel 230–249), Duplikat- und Marken-Prüfung, je ASIN gespeichert
- **Rezensions-Auswertung**: Verteilung, Amazons Aspekt-Chips, Kritik-Zitate, Filter „nur negativ / nur positiv“, auf Wunsch alle Rezensionen nachladen. Eine Wortanalyse zählt danach die häufigsten Begriffe getrennt nach kritischen und positiven Stimmen, mit Beispielzitaten – und ein Klick kopiert die Auswertung für Einkauf oder Produktmanagement
- **Verkaufs- und Umsatzschätzer**: eine Zahl je Artikel, kein Bereich. Grundlage ist der Bestseller-Rang, geeicht an eigenen Datenpunkten – aus Amazons „X+ Mal gekauft“-Badge, aus Helium-10-Werten und aus unseren Seller-Central-Zahlen, die schwerer wiegen als alles andere. Jede Zahl steht mit ihrer Quelle da („Kurve Garten, geeicht an 20 Punkten“), dazu der geschätzte Monatsumsatz
- **Bestandsanzeige**: zeigt „Nur noch X auf Lager“ für Buybox und einzelne Anbieter und schreibt den Wert in den Verlauf – so sieht man, wie schnell ein Wettbewerber abverkauft
- **Varianten-Liste** (alle Kind-ASINs mit Ausprägung), **ASIN-Vergleicher** (bis vier Listings nebeneinander), **Watchlist** mit Sammelprüfung, **Marge-Rechner** (Gewinn, Marge, ROI, Break-even) mit eingebetteter FBA-Gebührentabelle für Deutschland (Stand 1.7.2026): Gewicht und Maße eintragen, Versandgebühr und Lagerkosten werden berechnet, die Verkaufsprovision für Garten und Möbel liegt als Voreinstellung bereit

**Auf der Suchseite**: Position und Anzeigen-Kennzeichnung jeder Kachel, Markierung der eigenen Produkte, Kaufzahlen, Preis-Median der Seite. Ein Quick-View holt je Kachel BSR, Verkäufer und Alter des Listings (gedrosselt, mit Captcha-Stopp); eine sortierbare Übersichtstabelle stellt die ganze Seite gegenüber – inzwischen mit geschätzten Verkäufen und Umsatz je Treffer, einer Marktübersicht (Preisspanne, Seitenumsatz) und einem Nischen-Wert von 0 bis 10, dessen Rechenweg offen im Tooltip steht. An jeder Kachel steht zusätzlich eine Mini-Verlaufskurve, sobald zwei Messungen vorliegen. Nebenbei merkt sich die Erweiterung bei jedem Besuch, wo unsere Produkte stehen – so wächst ein Rang-Verlauf samt Trend-Kurve, ohne dass jemand dafür etwas tun muss. Export als CSV, ASIN-Liste oder Markdown.

**Auf den Bestseller-Listen** (`/gp/bestsellers/…`) laufen dieselben Kachel-Anzeigen. Wichtiger ist aber, was dabei nebenbei entsteht: Auf diesen Seiten stehen Rang und Kaufzahl direkt nebeneinander – genau das Paar, das der Verkaufsschätzer zum Eichen braucht. Ein Aufruf der Liste liefert also bis zu fünfzig Datenpunkte auf einmal, ohne Zutun und ohne zusätzliche Zugriffe.

**Darstellung**: Ein eingebauter Dunkelmodus rechnet Amazons Farben um, statt sie pauschal zu invertieren – Produktfotos, Sterne und Badges bleiben unangetastet, und der Kontrast wird je Fläche geprüft, bis er lesbar ist. Fremde Add-ons wie Helium 10 oder Keepa zeichnen ihre Fenster in eigenen Wurzeln; für die wird ein eigenes Themenblatt eingehängt, damit nicht die halbe Seite hell bleibt.

**Im Popup**: Suche per EAN, SKU oder ASIN über alle Plattformen. Die Stärke dabei: Treffer werden nicht geraten, sondern **bewiesen** – über EAN, Artikelnummer oder Maß-Vergleich, notfalls über den Umweg deubaxxl-Stammsatz (führt die GTIN eines Kandidaten auf Amazon nicht zum Ausgangsartikel zurück, wird er verworfen statt gespeichert). Dazu: automatischer Preisvergleich mit Beleg je Plattform, Buybox-Sammelprüfung, Keyword-Messung mit echten Autocomplete-Rängen (a–z-Vertiefung) und Suchseiten-Stichproben, Brand-Analytics-CSV-Import, Export als Excel oder als aufbereitete Daten für ChatGPT (fertige Arbeitsanweisung zum Listing-Optimieren), Rückimport früherer Exporte, Komplettsicherung als JSON mit Vorschau. Ein Protokoll der letzten 300 Schritte zeigt jederzeit, womit gesucht wurde und woran ein Treffer gescheitert ist.

## 2. Was sie spart

**Werkzeugkosten.** Die Funktionen, für die sonst Helium 10 fällig wäre, deckt die Erweiterung für unseren Zweck ab. Helium 10 kostet je nach Paket 99 bis 279 US-Dollar im Monat und pro Platz. Ein vorhandenes kostenloses Helium-10-Konto kann die Erweiterung optional anzapfen (Suchvolumen, Rezensions-Trends), Pflicht ist es nicht. Gerade die Verkaufsschätzung ist das Hauptverkaufsargument dieser Tools – und in unabhängigen Tests lagen Helium 10 und Jungle Scout dabei je nach Studie zwischen 60 und 90 Prozent Trefferquote. Auch dort wird nur von der Rangposition zurückgerechnet; Amazons echte Zahlen hat keiner.

**Zeit.** Eine Listing-Kontrolle hieß bisher: Anbieterliste aufklappen und durchzählen, fünf Preisvergleichs-Tabs öffnen, Zeichen im Texteditor nachzählen, Keywords von Hand in die Suche tippen. Jetzt steht das alles beim Öffnen der Produktseite da. Pro Listing sind das einige Minuten, über den Katalog und die Woche gerechnet Stunden.

**Diskussionszeit.** Jede Keyword-Zahl speichert ihren Beleg: die abgerufene URL und einen Prüf-Hash der Antwort. Wenn eine Agentur oder ein Kollege eine Zahl anzweifelt, zeigt man den Beleg statt zu diskutieren.

## 3. Was damit neu möglich ist

- **Verläufe über Monate.** Preis, BSR und Suchposition je Keyword, lokal gesammelt. Solche Historien verkauft sonst Keepa oder Helium 10.
- **Frühwarnung für die Buybox.** Der Quervergleich der eigenen Kanäle zeigt Preisunterbietungen im eigenen Haus, bevor Amazon reagiert.
- **Brand-Analytics-Anbindung.** Die Search-Frequency-Rank-Tabelle aus Seller Central lässt sich als CSV einlesen. Amazons eigene Suchhäufigkeit steht dann neben unseren Messungen.
- **Listing-Optimierung mit Daten.** Ein Klick erzeugt eine Datei mit Listing, Wettbewerbern, Keywords und Preisen plus Arbeitsanweisung, fertig zum Einfügen in ChatGPT.
- **Verkaufsschätzung mit Haus-Kalibrierung.** Wir kennen unsere echten Verkaufszahlen aus Seller Central – die Kauf-Tools nicht. Im Popup lassen sich die gesammelten Datenpunkte als CSV ausgeben, mit Seller Central abgleichen und echte Monatszahlen zurückspielen; die fließen mit höherem Gewicht in die Schätzkurve ein. In unseren Kategorien kann die Schätzung dadurch genauer werden als die der Kauf-Tools, und der Rechenweg bleibt nachvollziehbar statt Blackbox.

  Ein Vergleich mit echten Helium-10-Werten aus der Kategorie Garten: Im mittleren Rangbereich, in dem unsere Artikel überwiegend liegen, trifft unsere Schätzung auf wenige Prozent genau (Rang 3.453: 550 gegen 535). Ganz oben und jenseits von Rang 10.000 wird sie ungenauer – dort fällt die Kurve so steil, dass schon kleine Rangunterschiede das Ergebnis stark verändern. Zum Einordnen: Für Helium 10 und Jungle Scout werden in unabhängigen Tests 60 bis 90 Prozent Trefferquote genannt, und auch dort wird nur von der Rangposition zurückgerechnet.

## 4. Welche Daten sie verarbeitet

- **Quellen:** die öffentlich sichtbaren Seiten von amazon.de, otto.de, ebay.de, kaufland.de, bol.com, deubaxxl.de und den Preisvergleichern, abgerufen mit der bestehenden Browser-Sitzung des Nutzers. Optional Helium 10 mit dem eigenen Login des Nutzers.
- **Es fließt nichts nach außen.** Keine eigenen Server, keine Telemetrie. Die einzigen Netzwerkzugriffe gehen an dieselben Seiten, die man auch von Hand öffnen würde.
- **Personenbezug:** keiner. Gespeichert werden Produkt- und Marktdaten: ASINs, Preise, Ränge, Keywords, öffentlich einsehbare Rezensionstexte.
- **Berechtigungen:** nur `storage`, `scripting` und `activeTab` plus die feste Liste der genannten Shops. Kein Zugriff auf Browserverlauf, Downloads oder fremde Seiten. Eine Datenschutz-Beschreibung (DATENSCHUTZ.md) liegt der Erweiterung bei.

## 5. Persistenter Speicher: Vorteil und Grenze

Alle Daten liegen in `chrome.storage.local`, also im Browserprofil des jeweiligen Nutzers.

- **Vorteil:** Verläufe entstehen nebenbei und bleiben erhalten, auch offline. Nichts verlässt das Unternehmen, datenschutzrechtlich ist das der einfachste denkbare Fall.
- **Grenze:** Die Daten hängen am Profil. Neuer Rechner oder gelöschtes Profil bedeutet ohne Sicherung Datenverlust. Dafür gibt es den Komplett-Export als JSON-Datei mit einem Klick, samt Import mit Vorschau, was überschrieben würde. Einen automatischen Team-Abgleich gibt es nicht; wer denselben Stand haben will, tauscht die Sicherungsdatei.
- **Speichergröße** ist gedeckelt (etwa 2.000 Verlaufspunkte je Produkt), damit das Browser-Limit von rund 10 MB nie erreicht wird.

## 6. Ehrliche Nachteile

- **Amazon ändert sein HTML.** Danach zeigt ein Teil der Chips nichts mehr an, bis nachgezogen wird. Bisherige Erfahrung: einzelne kleine Korrekturen, Aufwand in Stunden.
- **Sichtbarkeits-Daten, keine Amazon-Interna.** Die Erweiterung misst, was auf den Seiten steht. Amazons echte Suchhäufigkeit kommt nur über den Brand-Analytics-Import dazu.
- **Bewusst gedrosselt.** Rang-Prüfungen laufen nacheinander mit Wartezeit. Zeigt Amazon ein Captcha, bricht der Lauf ab und meldet das, statt es zu umgehen.
- **Die Verkaufsschätzung bleibt eine Schätzung.** Für Bestellmengen taugt sie zur Größenordnung, nicht zur Kommastelle. Wer eine belastbare Zahl für einen einzelnen Artikel braucht, gleicht ihn einmal mit Seller Central ab – danach rechnet die Erweiterung für diesen Artikel mit der echten Zahl weiter.
- **Wartung** liegt derzeit bei einer Person.
- **Installation** per Zip im Entwicklermodus (Chrome) bzw. als Datei (Firefox), nicht über den Web Store. Für interne Nutzung ist das gewollt.

## 7. Einordnung gegenüber Kauf-Tools

| | Listing Checker | Helium 10 | Keepa |
|---|---|---|---|
| Kosten | 0 € | 99–279 $/Monat/Platz | 19 €/Monat |
| Daten bleiben im Haus | ja | nein, US-Cloud | nein |
| Belege je Messung | URL + Hash | nein | nein |
| Preis-/Rang-Verlauf | lokal, ab Nutzung | ja, Cloud | ja, Cloud |
| Auf unsere Abläufe zugeschnitten | ja | nein | nein |
| Fremdplattform-Preise (Otto, Kaufland …) | ja | nein | nein |
| Verkaufsschätzung | kalibrierbar mit Seller-Central-Zahlen | ja, Blackbox | Kaufzahlen-Historie |

Der ehrliche Unterschied: Kauf-Tools bringen historische Daten ab Tag eins mit, unsere Verläufe wachsen erst ab Nutzung. Dafür gehören uns Werkzeug und Daten, und jede Zahl ist belegbar.

## 8. Vorschlag

Die Erweiterung auf zwei bis drei Arbeitsplätzen im Team einsetzen, wöchentlich die Sicherungsdatei ablegen und einmal im Monat die Verkaufsschätzung mit den Seller-Central-Zahlen abgleichen. Kosten entstehen keine; das Risiko beschränkt sich auf die unter Punkt 6 genannten Grenzen. Läuft das gut, ist der nächste sinnvolle Schritt ein geteilter Datenstand fürs Team.
