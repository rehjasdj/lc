# Baut zwei Zips im Elternordner: Chrome (manifest.json) und Firefox (manifest.firefox.json).
# Aufruf: powershell -ExecutionPolicy Bypass -File .\build-zips.ps1
# Bewusst NICHT Compress-Archive: das schreibt unter Windows Backslashes in die
# Zip-Eintraege (shared\extract.js) - Firefox findet die Dateien dann nicht und
# die Erweiterung ist tot. Hier werden die Eintraege von Hand mit "/" angelegt.
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$src = $PSScriptRoot
$ver = (Get-Content "$src\manifest.json" -Raw | ConvertFrom-Json).version
$out = Split-Path $src -Parent
$skip = @('build-zips.ps1', 'manifest.firefox.json', 'PITCH-LISTING-CHECKER.md')
# Ordner, die nur der Entwicklung dienen und nicht ausgeliefert werden
$skipDirs = @('tools')

function Build-Zip($zipPath, $manifestFile) {
  if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
  $zip = [System.IO.Compression.ZipFile]::Open($zipPath, 'Create')
  try {
    Get-ChildItem $src -Recurse -File | Where-Object {
      $rel = $_.FullName.Substring($src.Length + 1).Replace('\', '/')
      $skip -notcontains $_.Name -and $_.Extension -ne '.zip' -and
      -not ($skipDirs | Where-Object { $rel.StartsWith("$_/") })
    } | ForEach-Object {
      $rel = $_.FullName.Substring($src.Length + 1).Replace('\', '/')
      if ($rel -eq 'manifest.json') { $file = Join-Path $src $manifestFile } else { $file = $_.FullName }
      [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $file, $rel, 'Optimal') | Out-Null
    }
  } finally { $zip.Dispose() }
}

Build-Zip "$out\lc-extension-$ver.zip" 'manifest.json'
Build-Zip "$out\lc-extension-$ver-firefox.zip" 'manifest.firefox.json'
Write-Host "fertig: $out\lc-extension-$ver.zip  +  $out\lc-extension-$ver-firefox.zip"
