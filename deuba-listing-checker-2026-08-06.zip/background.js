/* Service Worker: Badge + Batch-Suche + Varianten-Check + EAN-Mapping.
   Alles Schreibende laeuft hier, weil das Popup beim Tab-Oeffnen schliessen
   kann - der Worker arbeitet weiter, Ergebnisse landen in chrome.storage.local. */
'use strict';

/* Chrome laedt background.js als Service Worker -> importScripts.
   Firefox/Zen laedt die geteilten Dateien schon ueber background.scripts
   im Manifest - dort gibt es kein importScripts. */
/* shared/amazon-pro.js gehoert NICHT hierher: es braucht DOMParser, den es im
   Service Worker nicht gibt. Es wird ausschliesslich in den Seitenkontext
   injiziert (siehe inTab). */
if (typeof importScripts === 'function') {
  importScripts('shared/extract.js', 'shared/search.js', 'shared/api.js', 'shared/match.js');
}

// ------------------------------------------------------------------ Badge

function refreshBadge() {
  chrome.storage.local.get(['rows', 'matches'], function (d) {
    var n = (d.rows || []).length + (d.matches || []).length;
    chrome.action.setBadgeText({ text: n ? String(n) : '' });
    chrome.action.setBadgeBackgroundColor({ color: '#2f6feb' });
  });
}

chrome.runtime.onInstalled.addListener(refreshBadge);
chrome.runtime.onStartup.addListener(refreshBadge);
chrome.storage.onChanged.addListener(function (changes, area) {
  if (area === 'local' && (changes.rows || changes.matches)) refreshBadge();
});

// ------------------------------------------------------------------ Helfer

var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

function get(keys) {
  return new Promise(function (res) { chrome.storage.local.get(keys, res); });
}
function set(obj) {
  return new Promise(function (res) { chrome.storage.local.set(obj, res); });
}

function setStatus(patch) {
  return get('searchStatus').then(function (d) {
    var s = Object.assign({}, d.searchStatus || {}, patch);
    return set({ searchStatus: s });
  });
}

/* ------------------------------------------------------------------ Protokoll

   Warum: Der Ablauf laeuft im Hintergrund und ueber fremde Seiten - wenn eine
   Plattform nichts liefert, war bisher nicht erkennbar, WOMIT gesucht wurde,
   ob eine zweite Stufe ueberhaupt lief und woran ein Treffer gescheitert ist.
   Ohne das bleibt nur Raten. Jede Suchstufe schreibt deshalb eine Zeile.
   Ringpuffer statt unbegrenztem Wachstum - 300 Zeilen decken einen ganzen
   Durchlauf ab, mehr braucht niemand. */
var LOG_MAX = 300;

/* Serialisierte Schreibkette statt Sammelpuffer mit Timer.
   Der erste Entwurf hat Zeilen 120 ms lang gesammelt und dann gebuendelt
   geschrieben - im MV3-Service-Worker ist das unzuverlaessig: der Worker darf
   zwischen zwei Ereignissen jederzeit beendet werden, und dann ist der Puffer
   samt allem, was drinstand, weg. Genau deshalb blieb das Protokoll leer.
   Jede Zeile wird jetzt sofort geschrieben, die Aufrufe haengen aber
   hintereinander in einer Kette - sonst ueberschreiben sich parallele
   get/set-Paare gegenseitig. storage.local ist schnell genug dafuer. */
var logKette = Promise.resolve();

function logLine(text) {
  var t = new Date();
  var zeit = ('0' + t.getHours()).slice(-2) + ':' + ('0' + t.getMinutes()).slice(-2) +
             ':' + ('0' + t.getSeconds()).slice(-2);
  var zeile = zeit + '  ' + text;

  logKette = logKette
    .then(function () { return get('log'); })
    .then(function (d) {
      return set({ log: (d.log || []).concat([zeile]).slice(-LOG_MAX) });
    })
    .catch(function () { /* Protokoll darf den Ablauf nie stoppen */ });
  return logKette;
}

function logReset(was) {
  logKette = logKette
    .then(function () { return set({ log: [] }); })
    .catch(function () { /* egal */ });
  // Codestand in JEDE Kopfzeile: logReset leert das Protokoll, die Startzeile
  // des Workers waere sonst weg - und genau sie beantwortet die Frage, ob
  // ueberhaupt der neue Code laeuft.
  return logLine('=== ' + was + ' ===  [' + CODE_STAND + ']');
}

/* Kennung des geladenen Codestands. Wichtig, weil ein Service Worker NUR beim
   Neuladen der Erweiterung ersetzt wird - popup.html dagegen bei jedem Oeffnen.
   Man sieht also leicht ein neues Aussehen und bekommt trotzdem altes
   Verhalten. Steht diese Zeile nicht im Protokoll, laeuft alter Code. */
var CODE_STAND = '2026-08-06 Resolver+Protokoll';
logLine('Service Worker gestartet — ' + CODE_STAND);

/* ASIN<->EAN-Merkliste. Amazon zeigt keine EAN - einmal per EAN-Suche gefunden
   (oder aus der Modellnummer gelesen), muss nie wieder gesucht werden. */
function learnEan(map, key, ean) {
  if (key && ean && /^\d{8}$|^\d{12,14}$/.test(ean)) map[key] = ean;
}

/* Zentraler Row-Writer: dedupe per URL, EAN-Mapping pflegen und anwenden. */
function saveRows(newRows) {
  return get(['rows', 'eanMap']).then(function (d) {
    var rows = d.rows || [];
    var eanMap = d.eanMap || {};

    newRows.forEach(function (nr) {
      // Aus jeder Zeile mit EAN lernen (eigener Shop liefert SKU+EAN,
      // Amazon-Zeilen mit Modellnummer-EAN liefern ASIN+EAN).
      learnEan(eanMap, nr.produkt_id, nr.ean);
      learnEan(eanMap, nr.sku, nr.ean);
      // Umgekehrt: bekannte EAN in Zeilen ohne EAN eintragen (Amazon).
      if (!nr.ean && nr.produkt_id && eanMap[nr.produkt_id]) {
        nr.ean = eanMap[nr.produkt_id];
        nr.warnungen = String(nr.warnungen || '').split('; ')
          .filter(function (w) { return w && w !== 'keine EAN'; }).join('; ');
      }
      var idx = rows.findIndex(function (r) { return r.url === nr.url; });
      if (idx > -1) rows[idx] = nr; else rows.push(nr);
    });

    return set({ rows: rows, eanMap: eanMap });
  });
}

// ------------------------------------------------------------------ Tab-Maschinerie

function waitForComplete(tabId, timeoutMs) {
  return new Promise(function (resolve) {
    var done = false;
    var finish = function () {
      if (done) return;
      done = true;
      chrome.tabs.onUpdated.removeListener(onUpd);
      resolve();
    };
    var onUpd = function (id, info) {
      if (id === tabId && info.status === 'complete') finish();
    };
    chrome.tabs.onUpdated.addListener(onUpd);
    chrome.tabs.get(tabId, function (t) {
      if (!chrome.runtime.lastError && t && t.status === 'complete') finish();
    });
    setTimeout(finish, timeoutMs || 30000);
  });
}

function closeTab(tabId) {
  return new Promise(function (res) {
    chrome.tabs.remove(tabId, function () {
      void chrome.runtime.lastError; // Tab evtl. schon zu - egal
      res();
    });
  });
}

/* URL in unsichtbarem Tab laden, fn in der Seite ausfuehren, Tab schliessen. */
function inTab(url, fn, args) {
  var tabId = null;
  return new Promise(function (res, rej) {
    chrome.tabs.create({ url: url, active: false }, function (tab) {
      if (chrome.runtime.lastError || !tab) return rej(new Error('Tab konnte nicht geoeffnet werden'));
      res(tab.id);
    });
  }).then(function (id) {
    tabId = id;
    return waitForComplete(tabId, 30000);
  }).then(function () {
    return sleep(2500); // Hydration / nachgeladene Preise
  }).then(function () {
    return chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['shared/extract.js', 'shared/search.js', 'shared/api.js', 'shared/match.js', 'shared/amazon-pro.js']
    });
  }).then(function () {
    return chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: fn,
      args: args || []
    });
  }).then(function (frames) {
    return frames && frames[0] ? frames[0].result : null;
  }).finally(function () {
    if (tabId != null) return closeTab(tabId);
  });
}

// ------------------------------------------------------------------ Batch-Suche / Preisvergleich

/* JEDE Kennung im Suchfeld laeuft zuerst ueber den Deuba-Stammsatz:
   - ASIN: Amazon-Seite einmal lesen (Titel/Marke/EAN), DANN Deuba finden.
     Ein ASIN ist Amazon-intern - auf Kaufland/Otto/Temu sucht er ins Leere.
   - EAN/SKU: direkt im Shop aufloesen (SKU-Suche leitet dort aufs Produkt).
   Erst mit den SHOP-Daten (EAN, kanonischer Titel) suchen die Marktplaetze.
   Gelingt kein Stammsatz, laeuft die klassische Suche - bei Freitext ist das
   der Normalfall, kein Fehler. */
function stammsatzFuerQuery(query, qtype, platforms, opts) {
  var fertig = { platforms: platforms, opts: opts };
  if (opts.perPlatform || !query) return Promise.resolve(fertig);

  var vorab;
  if (qtype === 'asin') {
    vorab = setStatus({ current: 'ASIN ' + query + ' aufloesen' })
      .then(function () {
        return inTab('https://www.amazon.de/dp/' + query, function () {
          return globalThis.LC.extract(document, location.href);
        });
      })
      .then(function (row) {
        if (!row || !row.titel) return null;
        row.produkt_id = row.produkt_id || query;
        return saveRows([row]).then(function () { return row; });
      })
      .catch(function () { return null; });
  } else if (qtype === 'ean') {
    vorab = Promise.resolve({ ean: query });
  } else {
    // SKU/Freitext: als Artikelnummer im Shop versuchen.
    vorab = Promise.resolve({ sku: query, mpn: query });
  }

  return vorab.then(function (row) {
    if (!row) return fertig;
    return stammsatz(row).then(function (s) {
      if (!s.master) return fertig;   // kein Deuba-Artikel -> klassische Suche
      var basisAmazon = qtype === 'asin';
      return {
        platforms: platforms.filter(function (p) {
          return p !== 'deubaxxl' && (!basisAmazon || p !== 'amazon');
        }),
        opts: Object.assign({}, opts, {
          perPlatform: true,
          ean: s.master.ean, titel: s.master.titel, marke: s.master.marke,
          mpn: s.master.mpn, sku: s.master.sku,
          herkunft: s.herkunft,
          // Basis deubaxxl: der Shop-Preis ist der Vergleichswert, kein Treffer.
          shopHit: basisAmazon ? s.shopHit : null,
          sourcePreis: opts.sourcePreis != null ? opts.sourcePreis
            : (basisAmazon ? row.preis : s.master.preis),
          sourceLabel: opts.sourceLabel || (basisAmazon ? 'Amazon' : 'deubaxxl')
        })
      };
    });
  });
}

/* Plattformen nacheinander statt parallel: 6 gleichzeitige Suchseiten
   sehen nach Bot aus, und der Rechner bleibt bedienbar.
   opts.sourcePreis/sourceLabel: Vergleichsbasis fuer die Bilanz-Zeile. */
function runBatchSearch(query, qtype, platforms, opts) {
  opts = opts || {};
  logReset('Suche: ' + (query || opts.ean || opts.titel || '?') +
    ' auf ' + (platforms || []).join(', '));
  var collected = [];
  var errors = [];
  var usedQueries = {};
  var urteil = '';
  if (query) usedQueries[query] = 1;

  var step = function (i) {
    if (i >= platforms.length) return Promise.resolve();
    var pid = platforms[i];

    /* Preisvergleich-Modus: Query je Plattform waehlen - EAN wo die Suche
       EANs versteht, sonst Marke+Titel (Otto, Temu). */
    var qf = opts.perPlatform
      ? globalThis.LC.search.queryFor(pid, opts.ean, opts.titel, opts.marke)
      : { q: query, type: qtype };
    if (!qf) return step(i + 1);
    usedQueries[qf.q] = 1;

    var url = globalThis.LC.search.searchUrl(pid, qf.q, qf.type);

    return setStatus({ current: pid, done: i, total: platforms.length })
      .then(function () {
        // ASIN auf Amazon = direkte Produktseite -> volles Listing extrahieren.
        if (pid === 'amazon' && qf.type === 'asin') {
          return inTab(url, function () {
            return globalThis.LC.extract(document, location.href);
          }).then(function (row) {
            if (row && row.titel) return saveRows([row]);
            errors.push('amazon: ASIN nicht gefunden');
          });
        }
        return inTab(url, function (q, qt) {
          return globalThis.LC.search.extractSearchResults(document, location.href, q, qt, 5);
        }, [qf.q, qf.type]).then(function (hits) {
          if (hits && hits.length) {
            hits.forEach(function (h) { h.gesucht_am = new Date().toISOString(); });
            /* Auch hier pruefen, nicht nur in der Preisjagd: sonst landen ueber
               diesen Weg weiter Hochbeete und Gartenduschen ungeprueft in der
               Trefferliste und sehen aus wie derselbe Artikel. */
            if (opts.perPlatform) {
              var key = globalThis.LC.match.produktSchluessel({
                ean: opts.ean, titel: opts.titel, marke: opts.marke
              });
              hits = globalThis.LC.match.bewerteAlle(key, hits).treffer;
            }
            collected = collected.concat(hits);
          } else {
            errors.push(pid + ': keine Treffer');
          }
        });
      })
      .catch(function (e) {
        errors.push(pid + ': ' + (e && e.message ? e.message.split('\n')[0] : 'Fehler'));
      })
      .then(function () { return step(i + 1); });
  };

  /* Erst die Kennung ueber den Deuba-Stammsatz aufloesen, dann suchen. Im
     Preisvergleich-Modus uebernimmt sammlePreise: gleiche Schleife, aber mit
     Identitaets-Beleg auf der Trefferseite. */
  return stammsatzFuerQuery(query, qtype, platforms, opts).then(function (v) {
    platforms = v.platforms;
    opts = v.opts;
    if (!opts.perPlatform) return step(0);
    if (!platforms.length) return null;

    /* Button-Pfad (Analyse-Panel): opts kommt direkt vom Popup, der Stammsatz
       ist noch nicht beschafft - nachholen. Der Suchfeld-Pfad hat ihn schon
       (opts.herkunft gesetzt). */
    var vorbereitet = opts.herkunft ? Promise.resolve() : stammsatz({
      ean: opts.ean, titel: opts.titel, marke: opts.marke,
      mpn: opts.mpn, sku: opts.sku, produkt_id: opts.produktId
    }).then(function (s) {
      if (s.master) {
        opts.ean = s.master.ean; opts.titel = s.master.titel;
        opts.marke = s.master.marke; opts.mpn = s.master.mpn; opts.sku = s.master.sku;
        opts.herkunft = s.herkunft;
        if (opts.sourceLabel !== 'deubaxxl') opts.shopHit = s.shopHit;
        platforms = platforms.filter(function (p) { return p !== 'deubaxxl'; });
      } else {
        /* KEIN Stammsatz -> KEINE Suche. Mit dem Marktplatz-Titel
           weiterzustreuen sammelt garantiert Fremdartikel ein ("sucht nach
           allem Moeglichen") - das ist schlimmer als eine ehrliche Absage. */
        opts.kein_stammsatz = 'ABBRUCH: Artikel im Deuba-Shop nicht gefunden (' +
          s.versuche.join('; ') + ') - Suche gestoppt, bevor Fremdartikel eingesammelt werden';
      }
    });

    return vorbereitet.then(function () {
      if (opts.kein_stammsatz) {
        urteil = opts.kein_stammsatz;
        return;
      }
      var key = globalThis.LC.match.produktSchluessel({
        ean: opts.ean, titel: opts.titel, marke: opts.marke, mpn: opts.mpn, sku: opts.sku
      });
      return sammlePreise(key, platforms).then(function (pv) {
        var alle = opts.shopHit ? [opts.shopHit].concat(pv.hits) : pv.hits;
        var b = globalThis.LC.match.bewerteAlle(key, alle, opts.sourcePreis);
        collected = b.treffer;               // inkl. Begruendung je Treffer
        urteil = (opts.herkunft ? '[' + opts.herkunft + '] ' : '') + b.urteil;
        errors = errors.concat(pv.fehler);
        Object.keys(pv.queries).forEach(function (q) { usedQueries[q] = 1; });
      });
    });
  }).then(function () {
    return get(['matches', 'eanMap']);
  }).then(function (d) {
    var matches = d.matches || [];
    var eanMap = d.eanMap || {};

    // EAN-Suche + Amazon-Treffer mit ASIN -> Mapping lernen.
    var gelernteEan = qtype === 'ean' ? query : (opts.perPlatform ? opts.ean : null);
    if (gelernteEan) {
      collected.forEach(function (h) {
        if (h.plattform === 'Amazon' && /^B0[A-Z0-9]{8}$/i.test(h.produkt_id || '')) {
          learnEan(eanMap, h.produkt_id.toUpperCase(), gelernteEan);
        }
      });
    }

    // Alte Treffer zu denselben Suchbegriffen ersetzen - der neue Stand zaehlt.
    matches = matches.filter(function (m) { return !usedQueries[m.suchbegriff]; });
    matches = matches.concat(collected);
    return set({ matches: matches, eanMap: eanMap });
  }).then(function () {
    // Bilanz: guenstigster Fremd-Treffer vs. unser Preis.
    var result = collected.length + ' Treffer';
    /* Der eigene Webshop ist hier genauso ausgenommen wie im Urteil von
       bewerteAlle(): Amazon rechnet ihn dem Seller nicht an, also darf er
       auch in dieser Kurzbilanz nicht als "guenstigster" erscheinen. */
    var priced = collected.filter(function (h) {
      return h.preis != null && !globalThis.LC.match.istEigenerShop(h);
    }).sort(function (a, b) { return a.preis - b.preis; });
    if (urteil) {
      // Preisvergleich-Modus: nur BELEGTE Treffer duerfen ins Urteil.
      result = urteil;
    } else if (priced.length && opts.sourcePreis != null) {
      var best = priced[0];
      var diff = Math.round((best.preis / opts.sourcePreis - 1) * 100);
      result = 'guenstigster: ' + best.plattform + ' ' +
        best.preis.toFixed(2).replace('.', ',') + ' € (' +
        (opts.sourceLabel || 'unser Preis') + ' ' + opts.sourcePreis.toFixed(2).replace('.', ',') +
        ' €, ' + (diff > 0 ? '+' : '') + diff + '%)' +
        (diff < 0 ? ' - UNTERBOTEN!' : '');
    } else if (priced.length) {
      var b0 = priced[0];
      result = collected.length + ' Treffer, guenstigster: ' + b0.plattform + ' ' +
        b0.preis.toFixed(2).replace('.', ',') + ' €';
    }
    if (errors.length) result += ' | ' + errors.join('; ');
    return setStatus({
      running: false, current: '', done: platforms.length, total: platforms.length,
      result: result, ok: collected.length > 0
    });
  });
}

// ------------------------------------------------------------------ Deep-Grab

/* Treffer-URL -> volles Listing ins Blatt "Listings". */
function runDeepGrab(url) {
  return inTab(url, function () {
    return globalThis.LC.extract(document, location.href);
  }).then(function (row) {
    if (!row || !row.titel) throw new Error('kein Listing erkannt');
    return saveRows([row]).then(function () { return row; });
  });
}

// ------------------------------------------------------------------ Varianten-Check (A+)

/* Geschwister-ASINs nacheinander laden und pruefen: haben die Varianten A+,
   wo das aktuelle Listing keins hat? Ergebnisse landen als volle Listings
   in rows, die Zusammenfassung im Status. */
function runCheckVariants(asins) {
  var fehlt = [], hat = [], fehler = [];

  var step = function (i) {
    if (i >= asins.length) return Promise.resolve();
    var asin = asins[i];
    return setStatus({ current: 'Variante ' + asin, done: i, total: asins.length })
      .then(function () {
        return inTab('https://www.amazon.de/dp/' + asin, function () {
          return globalThis.LC.extract(document, location.href);
        });
      })
      .then(function (row) {
        if (!row || !row.titel) { fehler.push(asin); return; }
        (row.aplus === 'KEIN A+' ? fehlt : hat).push(asin);
        return saveRows([row]);
      })
      .catch(function () { fehler.push(asin); })
      .then(function () { return sleep(1500); })
      .then(function () { return step(i + 1); });
  };

  return step(0).then(function () {
    var teile = [];
    if (fehlt.length) teile.push('A+ FEHLT bei: ' + fehlt.join(', '));
    if (hat.length) teile.push(hat.length + ' Variante(n) mit A+');
    if (fehler.length) teile.push(fehler.length + ' nicht ladbar');
    return setStatus({
      running: false, current: '', done: asins.length, total: asins.length,
      result: teile.join(' | ') || 'keine Varianten geprueft',
      ok: !fehlt.length && !fehler.length
    });
  });
}

// ------------------------------------------------------------------ Keyword-Ernte

/* Autocomplete-Ernte ueber LC.api: die Plattform verraet selbst, wonach gesucht wird.
   Laeuft im Service Worker, weil es reines fetch/JSON ist - kein Tab noetig.
   Ergebnis landet in chrome.storage.local.keywords. */
function runKeywords(seeds, platforms, opts) {
  opts = opts || {};
  var out = [];
  var seen = Object.create(null);
  var errors = [];
  var jobs = [];

  seeds.forEach(function (s) {
    platforms.forEach(function (p) { jobs.push({ seed: s, plat: p }); });
  });

  var step = function (i) {
    if (i >= jobs.length) return Promise.resolve();
    var job = jobs[i];
    var platLabel = (globalThis.LC.PLATFORMS.find(function (p) { return p.id === job.plat; }) || {}).label || job.plat;

    return setStatus({ current: platLabel + ': ' + job.seed, done: i, total: jobs.length })
      .then(function () {
        // expand() haengt a-z an den Seed - das ist die Standard-Keyword-Ernte.
        // Ohne tiefe Ernte nur der direkte Vorschlag (schnell, fuer einen Schnellcheck).
        return opts.tief
          ? globalThis.LC.api.expand(job.plat, job.seed, { delay: opts.delay || 350 })
          : globalThis.LC.api.suggest(job.plat, job.seed, {});
      })
      .then(function (list) {
        if (!list || !list.length) { errors.push(platLabel + '/' + job.seed + ': nichts'); return; }
        list.forEach(function (kw, idx) {
          var key = job.plat + '|' + kw;
          if (seen[key]) return;
          seen[key] = 1;
          out.push({
            gefunden_am: new Date().toISOString(),
            plattform: platLabel,
            seed: job.seed,
            keyword: kw,
            position: idx + 1
          });
        });
      })
      .catch(function (e) {
        errors.push(platLabel + '/' + job.seed + ': ' + ((e && e.message) || 'Fehler'));
      })
      .then(function () { return step(i + 1); });
  };

  return step(0).then(function () {
    return get('keywords');
  }).then(function (d) {
    // Gleiche Plattform + gleiches Keyword ersetzen, Rest behalten.
    var neuKey = Object.create(null);
    out.forEach(function (o) { neuKey[o.plattform + '|' + o.keyword] = 1; });
    var merged = (d.keywords || []).filter(function (k) {
      return !neuKey[k.plattform + '|' + k.keyword];
    }).concat(out);
    return set({ keywords: merged });
  }).then(function () {
    var res = out.length + ' Keywords';
    if (errors.length) res += ' | ' + errors.join('; ');
    return setStatus({
      running: false, current: '', done: jobs.length, total: jobs.length,
      result: res, ok: out.length > 0
    });
  });
}

// ------------------------------------------------------------------ Stammsatz aus dem eigenen Shop

/* ERSTER SCHRITT JEDER PREISJAGD - ohne Ergebnis wird NICHT weitergesucht.
   Grund: Der Amazon-Titel ist seit dem Titel-Update vom 27.07.2026 bewusst
   generisch ("Garten Beistelltisch FSC-Zertifiziert Wetterfest"). Als Suchtext
   auf fremden Plattformen liefert er Hochbeete und Gartenduschen. Nur der
   eigene Shop hat Artikelnummer, EAN UND den Titel, unter dem derselbe Artikel
   auch auf den Marktplaetzen steht.

   Reihenfolge der Kandidaten nach Beweiskraft: EAN, dann Modellnummer/MPN,
   dann SKU. Jeder Fund wird gegengeprueft - ein Shop-Treffer, dessen EAN oder
   Artikelnummer nicht passt, ist KEIN Stammsatz. Lieber abbrechen als mit dem
   falschen Artikel weiterrechnen. */
function findeDeubaArtikel(kandidaten) {
  var versuche = [];

  var step = function (i) {
    if (i >= kandidaten.length) return Promise.resolve(null);
    var k = kandidaten[i];
    if (!k || !k.wert) return step(i + 1);

    var typ = globalThis.LC.search.detectQueryType(k.wert);
    var url = globalThis.LC.search.searchUrl('deubaxxl', k.wert, typ);

    return setStatus({ current: 'Shop-Artikel ueber ' + k.label + ' ' + k.wert })
      .then(function () {
        return inTab(url, function (q, qt) {
          return {
            row: globalThis.LC.extract(document, location.href),
            hits: globalThis.LC.search.extractSearchResults(document, location.href, q, qt, 5),
            href: location.href
          };
        }, [k.wert, typ]);
      })
      .then(function (res) {
        var r = res && res.row;
        /* Suchseite = Pfad /search. NICHT ?vsaisearch= mitmatchen: das
           Vision-AI-Widget haengt diesen Parameter an die PRODUKTSEITE an,
           auf die es bei exakter SKU direkt umleitet (live 05.08.2026,
           /schubkarre-.../108751/?vsaisearch=108751) - der alte Check
           verwarf genau diese Treffer als "noch auf der Suchseite". */
        var aufSuchseite = /\/search([?/]|$)/i.test((res && res.href) || '');

        /* Die SKU-Suche leitet direkt auf die Produktseite um - dann steht hier
           bereits der volle Artikel. Bleiben wir auf der Suchseite, kann das
           Overlay trotzdem GENAU EINEN Kandidaten zeigen (Screenshot-Fall
           "1 Ergebnis gefunden") - den oeffnen wir und pruefen ihn, statt
           aufzugeben. */
        if (!r || !r.titel || aufSuchseite) {
          var treffer = ((res && res.hits) || []).filter(function (h) { return h.url; });
          // Kandidat, der die gesuchte Nummer in der Produkt-URL/ID traegt, sonst Einzeltreffer.
          var kandidat = treffer.filter(function (h) {
            return String(h.produkt_id || '') === String(k.wert);
          })[0] || (treffer.length === 1 ? treffer[0] : null);
          if (!kandidat) {
            versuche.push(k.label + ' ' + k.wert + ': kein eindeutiger Shop-Treffer');
            return step(i + 1);
          }
          return inTab(kandidat.url, function () {
            return globalThis.LC.extract(document, location.href);
          }).then(function (r2) {
            if (!r2 || !r2.titel) {
              versuche.push(k.label + ' ' + k.wert + ': Kandidatenseite nicht lesbar');
              return step(i + 1);
            }
            return pruefeGegenprobe(r2);
          });
        }
        return pruefeGegenprobe(r);

        // Gegenprobe: der gefundene Artikel muss den Kandidaten auch tragen.
        function pruefeGegenprobe(r) {
          var passt = true, grund = '';
          if (k.art === 'ean' && r.ean && r.ean.replace(/\D/g, '') !== k.wert.replace(/\D/g, '')) {
            passt = false; grund = 'EAN im Shop ist ' + r.ean;
          }
          if (k.art === 'nummer') {
            var hay = (String(r.sku || '') + ' ' + String(r.mpn || '') + ' ' + String(r.produkt_id || '')).toLowerCase();
            if (hay.indexOf(String(k.wert).toLowerCase()) === -1) {
              passt = false; grund = 'Artikelnummer im Shop: ' + (r.sku || r.produkt_id || '?');
            }
          }
          if (!passt) {
            versuche.push(k.label + ' ' + k.wert + ': Treffer passt nicht (' + grund + ')');
            return step(i + 1);
          }

          r._gefundenUeber = k.label + ' ' + k.wert;
          return r;
        }
      })
      .catch(function (e) {
        versuche.push(k.label + ' ' + k.wert + ': ' + ((e && e.message) ? e.message.split('\n')[0] : 'Fehler'));
        return step(i + 1);
      });
  };

  return step(0).then(function (r) {
    return { artikel: r, versuche: versuche };
  });
}

// ------------------------------------------------------------------ Preisjagd

/* Denselben Artikel auf allen anderen Plattformen suchen und die Preise holen.
   Bewusst NICHT auf comparePlatforms() beschraenkt: fuer die Buybox-Sanierung
   sind gerade die EIGENEN Angebote auf Kaufland/eBay/ManoMano entscheidend -
   Amazon vergleicht dagegen, ganz gleich wer dort verkauft. Am 05.08.2026 an
   B078Y6TKG4 belegt: eigenes Kaufland-Angebot 62,95 € bei Amazon-Preis 62,95 €,
   Amazon forderte 62,48 €.
   Kaufland und bol blocken statisches Fetching - ueber den echten Tab (inTab)
   gehen sie trotzdem. */
/* Wie viele Kandidaten pro Plattform wir zum Belegen wirklich aufmachen.
   Jeder Aufruf ist ein echter Tab - zwei reichen, weil vorher nach
   Plausibilitaet sortiert wird. */
var PRUEF_TIEFE = 2;

/* Ein Suchtreffer zeigt Titel und Preis, aber keine EAN. Ohne die Trefferseite
   selbst zu oeffnen bleibt jeder Marktplatztreffer eine Vermutung - genau der
   Fehler, der auf Otto und Temu den falschen Artikel als "guenstiger" meldet.
   Also: die aussichtsreichsten Kandidaten aufmachen, EAN/Artikelnummer und den
   echten Seitenpreis nachtragen (Trefferkacheln zeigen oft "ab"-Preise).
   Beim ersten EAN-Beleg ist Schluss - mehr Beweis geht nicht. */
function belegeTreffer(key, hits, label) {
  if (!hits.length || (!key.ean && !key.mpn)) return Promise.resolve(hits);
  var m = globalThis.LC.match;

  /* NACH PLATTFORM gruppieren, dann je Plattform die aussichtsreichsten
     Kandidaten. Vorher galt PRUEF_TIEFE global - beim Preisportal, das SECHS
     Plattformen auf einmal liefert, wurden damit nur zwei Zeilen ueberhaupt
     geoeffnet und die uebrigen vier blieben ohne Nachweis. Genau das war das
     gemeldete "5 Kandidaten ohne Identitaetsnachweis": die Preise waren da,
     nur belegt hat sie niemand. Ein EAN-Beleg fuer Otto sagt eben nichts
     ueber den Kaufland-Preis. */
  var proPlattform = {};
  hits.filter(function (h) { return h.url; }).forEach(function (h) {
    var p = h.plattform || '?';
    (proPlattform[p] = proPlattform[p] || []).push(h);
  });

  /* Plausible zuerst, aber "anderer Artikel" NICHT ausschliessen: eine
     passende EAN schlaegt jeden Titelverdacht - und ein Marktplatztitel, der
     nichts mit dem Shoptitel zu tun hat, kann trotzdem derselbe Artikel sein. */
  var kandidaten = [];
  Object.keys(proPlattform).forEach(function (p) {
    proPlattform[p]
      .map(function (h) { return { hit: h, rang: m.bewerte(key, h).rang }; })
      .sort(function (a, b) { return a.rang - b.rang; })
      .slice(0, PRUEF_TIEFE)
      .forEach(function (x) { kandidaten.push(x.hit); });
  });

  // Je Plattform ist nach dem ersten EAN-Beleg Schluss - mehr Beweis geht nicht.
  var belegt = {};

  var step = function (i) {
    if (i >= kandidaten.length) return Promise.resolve(hits);
    var hit = kandidaten[i];
    var platKey = hit.plattform || '?';
    if (belegt[platKey]) return step(i + 1);

    return setStatus({ current: 'Beleg pruefen: ' + label + ' (' + (i + 1) + '/' + kandidaten.length + ')' })
      .then(function () {
        /* Die erwartete Kennung MITGEBEN. Grund: Ob wir eine EAN aus einer
           Seite herauslesen koennen, haengt an unseren Selektoren - ob sie
           dort steht, nicht. Findet die Extraktion kein EAN-Feld, heisst das
           also nicht, dass der Artikel ein anderer ist; es heisst nur, dass
           wir das Feld nicht kennen. Deshalb zusaetzlich die simpelste und
           haerteste Probe: kommt genau diese Ziffernfolge im Quelltext vor?
           Eine 13-stellige GTIN steht nicht zufaellig auf einer fremden
           Produktseite - das ist ein Beleg, keine Vermutung. */
        return inTab(hit.url, function (wantEan, wantMpn) {
          var row = globalThis.LC.extract(document, location.href);
          if (!row.ean || !row.mpn) {
            var html = '';
            try { html = document.documentElement.innerHTML; } catch (e) { /* leer */ }
            if (!row.ean && wantEan && html.indexOf(wantEan) > -1) {
              row.ean = wantEan;
              row.kennung_aus_quelltext = 'EAN';
            }
            /* Artikelnummern sind kuerzer und damit anfaelliger fuer
               Zufallstreffer - nur ab 5 Ziffern und mit Ziffernbegrenzung. */
            if (!row.mpn && wantMpn && /^\d{5,9}$/.test(wantMpn) &&
                new RegExp('(^|[^0-9])' + wantMpn + '([^0-9]|$)').test(html)) {
              row.mpn = wantMpn;
              row.kennung_aus_quelltext = (row.kennung_aus_quelltext ? 'EAN+' : '') + 'Artikelnummer';
            }
          }
          return row;
        }, [key.ean || '', key.mpn || '']);
      })
      .then(function (row) {
        if (!row || !row.titel) {
          logLine('  Beleg ' + label + ': Seite nicht lesbar');
          return;
        }
        /* Login- oder Sperrseite statt Produktseite: Temu schickt JEDE
           Trefferseite ohne Session auf login.html ("Anmelden / Registrieren"),
           bol antwortet mit einer IP-Sperrseite. Ohne jede Kennung UND ohne
           Preis ist das kein Produkt - solche Daten duerfen den bereits
           gefundenen Treffer nicht ueberschreiben. Genau so wurde aus
           "TRESKO Campingstuhl" ein "Anmelden / Registrieren", das die
           Identitaetspruefung dann folgerichtig als FREMD verwarf: der Treffer
           war gefunden und wurde nachtraeglich zerstoert. */
        if (!row.ean && !row.mpn && !row.sku && row.preis == null) {
          logLine('  Beleg ' + label + ': Login-/Sperrseite ("' + String(row.titel).slice(0, 40) + '") - verworfen');
          return;
        }
        logLine('  Beleg ' + (hit.plattform || label) + ': ' +
          (row.ean ? 'EAN ' + row.ean : 'kein EAN-Feld gefunden') +
          (row.kennung_aus_quelltext ? ' (' + row.kennung_aus_quelltext + ' im Quelltext)' : '') +
          (row.preis != null ? ', ' + row.preis + ' EUR' : ''));
        if (row.ean) hit.ean = row.ean;
        if (row.mpn || row.sku) hit.mpn = row.mpn || row.sku;
        if (row.preis != null) hit.preis = row.preis;
        if (row.waehrung) hit.waehrung = row.waehrung;
        /* Marke und Titel der PRODUKTSEITE schlagen die Kachel: Otto zeigt
           die Marke gar nicht in der Kachel, und Kacheltitel sind gekuerzt -
           beides liess echte Treffer durchfallen bzw. falsche durch. */
        if (row.marke) hit.marke = row.marke;
        if (row.titel) hit.titel = row.titel;
        /* Die Masse der geoeffneten Seite mitnehmen. Genau sie wurden bisher
           weggeworfen - deshalb meldete die Pruefung "Treffer nennt keine
           Masse", obwohl die Produktseite sie fuehrt. Attribute zuerst: dort
           steht die Kette maschinenlesbar ("Produktabmessungen 70x70x73 cm"). */
        var mq = [row.masse_quelle, row.eigenschaften || row.attribute, row.slug, row.item_highlights,
                  row.bullet_1, row.bullet_2, row.bullet_3].filter(Boolean).join(' ');
        if (mq) hit.masse_text = mq;
      })
      .catch(function () { /* Kandidat nicht ladbar - bleibt eben unbelegt */ })
      .then(function () {
        if (m.bewerte(key, hit).stufe === 'EAN') belegt[platKey] = true;
        return sleep(700).then(function () { return step(i + 1); });
      });
  };

  return step(0);
}

// ------------------------------------------------------------------ Stammsatz (deubaxxl ZUERST)

/* Letzte Stufe der Stammsatz-Suche, wenn EAN/Modellnummer/SKU nichts ergaben:
   Titel-Eskalation (shopQueries), Kandidaten-Produktseiten oeffnen und mit
   LC.match gegen die Amazon-Daten pruefen. Liefert { shop, beleg } oder null. */
function sucheShopZeileLive(row) {
  var LCg = globalThis.LC;
  var key = LCg.match.produktSchluessel(row);
  // EAN/Nummer bewusst NICHT als Query - die hat findeDeubaArtikel schon erfolglos
  // probiert. Es bleibt die Leiter aus Produkttyp, Marke und Mass.
  var queries = LCg.search.shopQueries(Object.assign({}, key, { ean: '', mpn: '' }));
  var geoffnet = 0;                    // hartes Tab-Budget ueber alle Stufen
  var besterUnbestaetigt = null;

  var stufe = function (qi) {
    if (qi >= queries.length || geoffnet >= 4) {
      /* Ein unbestaetigter Kandidat wird NIE einfach genommen - "frueher oder
         spaeter bleibt er bei einem Competitor stehen" (LO, 05.08.2026).
         Er geht markiert nach oben, wo NUR der Ringschluss ueber Amazon ihn
         noch beweisen kann. Sonst: lieber kein Stammsatz als ein falscher. */
      if (besterUnbestaetigt) return Promise.resolve(Object.assign({ unbestaetigt: true }, besterUnbestaetigt));
      return Promise.resolve(null);
    }
    var qf = queries[qi];
    var url = LCg.search.searchUrl('deubaxxl', qf.q, qf.type);

    return setStatus({ current: 'Shop-Listing suchen: "' + qf.q + '"' })
      .then(function () {
        return inTab(url, function (q, qt) {
          return globalThis.LC.search.extractSearchResults(document, location.href, q, qt, 10);
        }, [qf.q, qf.type]);
      })
      .then(function (hits) {
        /* Nach Fingerabdruck ordnen, NICHT nach Titelaehnlichkeit: bei einem
           generischen Amazon-Titel ("Casaria Garten Beistelltisch FSC") ist die
           Aehnlichkeit zum Shoptitel reines Rauschen - genau daran haben wir
           Hochbeete fuer Beistelltische gehalten. bewerte() vergleicht die
           Masse; wer der Kette widerspricht (Geschwistermodell 46x46x47 statt
           70x70x73), fliegt sofort raus statt einen der vier Tabs zu fressen. */
        var kandidaten = (hits || []).filter(function (h) { return h.url; })
          .map(function (h) { return { h: h, b: LCg.match.bewerte(key, h) }; })
          .filter(function (x) { return x.b.stufe !== 'FREMD'; })
          .sort(function (a, b) { return a.b.rang - b.b.rang || b.b.punkte - a.b.punkte; })
          .slice(0, 3)
          .map(function (x) { return x.h; });

        var pruefe = function (ki) {
          if (ki >= kandidaten.length || geoffnet >= 4) return null;
          geoffnet++;
          return inTab(kandidaten[ki].url, function () {
            return globalThis.LC.extract(document, location.href);
          }).then(function (shop) {
            if (shop && shop.titel) {
              /* deubaxxl-Titel fuehren die Marke nicht - sie steht im
                 Marken-FELD der Produktseite. Fuer den Markencheck davorsetzen. */
              var b = LCg.match.bewerte(key, {
                titel: (shop.marke ? shop.marke + ' ' : '') + shop.titel,
                ean: shop.ean, mpn: shop.mpn || shop.sku
              });
              if (b.bestaetigt) return { shop: shop, beleg: b.label };
              if (b.stufe !== 'FREMD' && b.punkte >= 0.55 &&
                  (!besterUnbestaetigt || b.punkte > besterUnbestaetigt.punkte)) {
                besterUnbestaetigt = { shop: shop, beleg: 'unbestaetigt, Titel ' + Math.round(b.punkte * 100) + '%', punkte: b.punkte };
              }
            }
            return sleep(700).then(function () { return pruefe(ki + 1); });
          }).catch(function () { return pruefe(ki + 1); });
        };
        return pruefe(0);
      })
      .then(function (gefunden) {
        if (gefunden && gefunden.shop) return gefunden;
        return sleep(700).then(function () { return stufe(qi + 1); });
      })
      .catch(function () { return stufe(qi + 1); });
  };

  return stufe(0);
}

/* Rueckwaerts-Beweis, wenn Amazon selbst keine EAN zeigt: die GTIN des
   Deuba-Kandidaten auf Amazon suchen. Landet die Suche wieder beim
   Start-ASIN, ist der Kreis geschlossen - Kandidat und Amazon-Listing sind
   derselbe Artikel. Negativ heisst nur "nicht beweisbar", nicht "falsch"
   (Amazon indexiert nicht jede EAN). */
function ringschluss(asin, ean) {
  var url = globalThis.LC.search.searchUrl('amazon', ean, 'ean');
  return setStatus({ current: 'Ringschluss: EAN ' + ean + ' auf Amazon suchen' })
    .then(function () {
      return inTab(url, function (q) {
        return globalThis.LC.search.extractSearchResults(document, location.href, q, 'ean', 5);
      }, [ean]);
    })
    .then(function (hits) {
      return (hits || []).some(function (h) {
        return String(h.produkt_id || '').toUpperCase() === asin;
      });
    })
    .catch(function () { return false; });
}

/* Der gefundene Shop-Preis ist selbst ein Vergleichstreffer - und zwar der
   wichtigste: der eigene Webshop ist ein moeglicher Preisanker fuer Amazon. */
function shopHitAus(master) {
  return {
    gesucht_am: new Date().toISOString(),
    suchbegriff: master.ean || master.sku || '',
    suchtyp: master.ean ? 'ean' : 'sku',
    plattform: 'deubaxxl',
    position: 1,
    produkt_id: master.sku || master.produkt_id || '',
    titel: master.titel,
    ean: master.ean || '',
    mpn: master.mpn || master.sku || '',
    preis: master.preis,
    waehrung: master.waehrung || 'EUR',
    gesponsert: '',
    url: master.url,
    treffer_gesamt: 1
  };
}

/* PFLICHT-SCHRITT 1 jeder Preisjagd, fuer ALLE Pfade (Buybox-Check UND
   Preisvergleich-Button): das eigene deubaxxl-Listing finden. Stufen:
   bereits erfasst -> Kennungen (EAN/Modellnummer/SKU, hart gegengeprueft)
   -> Titel-Eskalation mit geoeffneten Kandidatenseiten. Ergebnis:
   master   = Zeile, mit der ALLE weiteren Suchen laufen (null = nichts belegbar)
   herkunft = fuers Stammsatz-Feld, damit sichtbar bleibt worauf alles fusst
   shopHit  = Shop-Preis als fertiger Vergleichstreffer
   versuche = was probiert wurde (fuer die Fehlermeldung beim Abbruch) */
function stammsatz(row) {
  return get(['rows', 'eanMap']).then(function (d) {
    var eanMap = d.eanMap || {};
    /* Fingerabdruck statt Titel: liefert die EAN auch dann, wenn Amazon sie
       nicht als Attribut fuehrt, sondern nur im Bullettext ("EAN: 4251...").
       Das ist der haeufigste Fall und die staerkste Bruecke zum Shop - die
       GTIN-Pruefziffer macht den Fund sicher, nicht geraten. */
    var fp = globalThis.LC.match.produktSchluessel(row);
    var ean = row.ean || (row.produkt_id && eanMap[row.produkt_id]) ||
              (row.sku && eanMap[row.sku]) || fp.ean || '';
    row = Object.assign({}, row, { ean: ean });

    // Schon erfasst? (EAN ist der einzige Schluessel, der beide Welten verbindet.)
    var cache = (d.rows || []).filter(function (r) {
      return r.plattform === 'deubaxxl' && ean && r.ean === ean;
    })[0];
    if (cache) {
      return { master: cache, herkunft: 'deubaxxl ' + (cache.sku || '') + ' (bereits erfasst)',
               shopHit: shopHitAus(cache), versuche: [] };
    }

    return findeDeubaArtikel([
      { art: 'ean',    label: 'EAN',          wert: ean },
      { art: 'nummer', label: 'Modellnummer', wert: row.mpn || '' },
      { art: 'nummer', label: 'SKU',          wert: row.sku || '' }
    ]).then(function (fund) {
      if (fund.artikel) {
        var a = fund.artikel;
        logLine('Shop-Artikel gefunden: ' + (a.sku || a.produkt_id || '?') +
          ' via ' + a._gefundenUeber);
        return saveRows([a]).then(function () {
          return { master: a, herkunft: 'deubaxxl ' + (a.sku || a.produkt_id || '') + ' via ' + a._gefundenUeber,
                   shopHit: shopHitAus(a), versuche: fund.versuche };
        });
      }
      // Keine Kennung hat getroffen -> Titel-Eskalation als letzte Stufe.
      return sucheShopZeileLive(row).then(function (res) {
        if (!res || !res.shop) {
          logLine('ABBRUCH: kein Shop-Artikel (' + fund.versuche.join('; ') + ')');
        return { master: null, herkunft: '', shopHit: null,
                   versuche: fund.versuche.concat(['Titelsuche: kein belegbarer Shop-Treffer']) };
        }
        var nimm = function (beleg) {
          return saveRows([res.shop]).then(function () {
            return { master: res.shop,
                     herkunft: 'deubaxxl ' + (res.shop.sku || '') + ' via Titel (' + beleg + ')',
                     shopHit: shopHitAus(res.shop), versuche: fund.versuche };
          });
        };
        if (!res.unbestaetigt) return nimm(res.beleg);

        /* Ringschluss - der einzige Weg, einen unbestaetigten Kandidaten noch
           zu beweisen: seine GTIN (steht auf JEDER Deuba-Produktseite) auf
           Amazon suchen. Landet die Suche beim Start-ASIN, ist der Kreis
           geschlossen, obwohl Amazon selbst nie eine EAN gezeigt hat.
           Scheitert er: Kandidat VERWERFEN. Lieber kein Stammsatz als ein
           Competitor. */
        var asin = /^B0[A-Z0-9]{8}$/i.test(String(row.produkt_id || ''))
          ? String(row.produkt_id).toUpperCase() : '';
        if (!asin || !res.shop.ean) {
          return { master: null, herkunft: '', shopHit: null,
                   versuche: fund.versuche.concat(
                     ['Titel-Kandidat ' + (res.shop.sku || '?') + ' (' + res.beleg + ') nicht beweisbar - verworfen']) };
        }
        return ringschluss(asin, res.shop.ean).then(function (ok) {
          if (!ok) {
            return { master: null, herkunft: '', shopHit: null,
                     versuche: fund.versuche.concat(
                       ['Ringschluss: EAN ' + res.shop.ean + ' fuehrt auf Amazon nicht zu ' + asin + ' - verworfen']) };
          }
          // Bewiesen -> ASIN<->EAN dauerhaft lernen, naechster Lauf geht direkt.
          return get('eanMap').then(function (d2) {
            var map = d2.eanMap || {};
            map[asin] = res.shop.ean;
            return set({ eanMap: map });
          }).then(function () {
            return nimm('EAN ' + res.shop.ean + ' fuehrt auf Amazon zurueck zu ' + asin + ' - bewiesen');
          });
        });
      });
    });
  });
}

/* key = LC.match.produktSchluessel(...): Stammsatz mit EAN, Artikelnummer,
   Marke, Titel und Massen. */
/* SCHRITT 0 der Preisjagd: eine EAN in ein Preisvergleichsportal, alle
   Haendler mit Preis heraus. Das umgeht genau die Stellen, an denen die
   Direktsuche scheitert - Ottos EAN-Blindheit und Kauflands Bot-Wall - und
   kostet EINE Seitenladung statt sieben Suchen.
   Live 06.08.2026: guenstiger.de fand alle vier Test-EANs mit je 5-6
   Haendlerzeilen, darunter Kaufland, OTTO und eBay.
   Bewusst KEIN Ersatz, sondern eine Vorstufe: was das Portal nicht kennt,
   wird danach wie bisher direkt gesucht. */
function resolveViaAggregator(key, platforms) {
  if (!key.ean) {
    logLine('Preisportal uebersprungen: keine EAN im Stammsatz');
    return Promise.resolve({ hits: [], fehler: [], quelle: '' });
  }

  var quellen = globalThis.LC.search.AGGREGATOREN.map(function (a) { return a.id; });

  var versuch = function (qi) {
    if (qi >= quellen.length) return Promise.resolve({ hits: [], fehler: [], quelle: '' });
    var quelle = quellen[qi];
    var url = globalThis.LC.search.aggregatorUrl(quelle, key.ean);

    return setStatus({ current: quelle + ': EAN ' + key.ean })
      .then(function () {
        return inTab(url, function () {
          return globalThis.LC.search.parseAggregator(document, location.href);
        });
      })
      .then(function (zeilen) {
        logLine(quelle + ': ' + ((zeilen && zeilen.length) || 0) + ' Angebotszeilen gelesen' +
          (zeilen && zeilen.length
            ? ' (' + zeilen.map(function (z) { return z.plattform || z.shop; }).join(', ') + ')'
            : ''));
        zeilen = (zeilen || []).filter(function (z) {
          // Nur Plattformen, die tatsaechlich gefragt sind.
          return z.plattform && platforms.indexOf(z.plattform) > -1;
        });
        if (!zeilen.length) return sleep(600).then(function () { return versuch(qi + 1); });

        /* Kein Nachfiltern ueber den Titel: dieselbe Ware heisst bei Otto
           anders als bei Kaufland, ein Titelvergleich wuerde hier echte
           Treffer wegwerfen. Die Identitaet belegt spaeter belegeTreffer
           ueber die geoeffnete Produktseite und deren EAN. */
        var out = zeilen.map(function (z, n) {
          var plat = globalThis.LC.PLATFORMS.filter(function (p) { return p.id === z.plattform; })[0];
          return {
            gesucht_am: new Date().toISOString(),
            suchbegriff: key.ean,
            suchtyp: 'ean',
            plattform: (plat && plat.label) || z.plattform,
            position: n + 1,
            produkt_id: '',
            titel: z.titel || '',
            marke: key.marke || '',
            preis: z.preis,
            waehrung: 'EUR',
            gesponsert: '',
            // Der Klick-Link leitet auf die echte Produktseite um - genau die,
            // die belegeTreffer dann oeffnet und per EAN gegenprueft.
            url: z.url,
            versand: z.versand || '',
            verkaeufer: z.shop || '',
            treffer_gesamt: zeilen.length,
            quelle: quelle
          };
        }).filter(function (h) { return h.url; });

        if (!out.length) return sleep(600).then(function () { return versuch(qi + 1); });
        return { hits: out, fehler: [], quelle: quelle };
      })
      .catch(function (e) {
        return sleep(600).then(function () {
          return versuch(qi + 1);
        });
      });
  };

  return versuch(0);
}

/* STUFE 2, nur fuer die Plattformen, die weder das Preisportal noch ihre
   eigene Suche liefert. Live 06.08.2026 bewiesen: Otto und Kaufland sind per
   EAN ueber KEINE Suchmaschine auffindbar - "site:otto.de 4250525353426"
   ergibt null Treffer. Beide FUEHREN die Artikel, rendern die EAN aber nicht
   in den Index. Mit Marke + Titelwoertern kommt dieselbe Suche direkt auf die
   Produktseite. Google gibt die Ziel-URL nicht preis, der Link fuehrt beim
   Oeffnen im Tab aber dorthin - der Host im cite-Element reicht zum Sortieren. */
var GOOGLE_SITE = { otto: 'otto.de', kaufland: 'kaufland.de', bol: 'bol.com', ebay: 'ebay.de' };

function resolveViaGoogle(key, platformId) {
  var host = GOOGLE_SITE[platformId];
  if (!host || !key.titel) return Promise.resolve([]);

  var q = globalThis.LC.search.googleSiteQuery(host, key);
  var url = globalThis.LC.search.googleUrl(q);

  return setStatus({ current: 'Google: ' + q.slice(0, 52) })
    .then(function () {
      return inTab(url, function () {
        return globalThis.LC.search.parseGoogle(document);
      });
    })
    .then(function (treffer) {
      var plat = globalThis.LC.PLATFORMS.filter(function (p) { return p.id === platformId; })[0];
      return (treffer || [])
        .filter(function (t) { return t.host && t.host.indexOf(host) > -1 && t.url; })
        .slice(0, 3)
        .map(function (t, n) {
          return {
            gesucht_am: new Date().toISOString(),
            suchbegriff: q, suchtyp: 'sku',
            plattform: (plat && plat.label) || platformId,
            position: n + 1, produkt_id: '',
            titel: t.titel || '', marke: key.marke || '',
            preis: t.preis, waehrung: t.preis != null ? 'EUR' : '',
            gesponsert: '', url: t.url, treffer_gesamt: treffer.length,
            quelle: 'google'
          };
        });
    })
    .catch(function () { return []; });
}

function sammlePreise(key, platforms) {
  var hits = [];
  var fehler = [];
  var queries = {};

  var step = function (i) {
    if (i >= platforms.length) return Promise.resolve();
    var pid = platforms[i];
    var label = (globalThis.LC.PLATFORMS.find(function (p) { return p.id === pid; }) || {}).label || pid;

    /* Erst EAN (exakt), und wenn die Plattform sie nicht kennt: Titel+Marke.
       Live 05.08.2026: die Amazon-EAN-Suche liefert je nach Katalogstand
       "keine Ergebnisse" - dann NICHT aufgeben, sondern per Titel suchen;
       die Identitaet sichert danach der Beleg-Schritt, nicht die Query. */
    var qf = globalThis.LC.search.queryFor(pid, key.ean, key.titel, key.marke);
    if (!qf) { fehler.push(label + ': keine brauchbare Suchanfrage'); return step(i + 1); }
    var qf2 = qf.type === 'ean'
      ? globalThis.LC.search.queryFor(pid, '', key.titel, key.marke)
      : null;

    var suche = function (q) {
      queries[q.q] = 1;
      var url = globalThis.LC.search.searchUrl(pid, q.q, q.type);
      if (!url) return Promise.resolve(null);
      return inTab(url, function (qq, qt) {
        return globalThis.LC.search.extractSearchResults(document, location.href, qq, qt, 5);
      }, [q.q, q.type]);
    };

    return setStatus({ current: 'Preise: ' + label })
      .then(function () {
        return logLine(label + ': Stufe 1 (' + qf.type + ') "' + qf.q + '"');
      })
      .then(function () { return suche(qf); })
      .then(function (res) {
        logLine(label + ': Stufe 1 -> ' + ((res && res.length) || 0) + ' Treffer');
        if (res && res.length) return res;
        if (!qf2 || qf2.q === qf.q) {
          logLine(label + ': Stufe 2 entfaellt (keine abweichende Titelsuche moeglich)');
          return res;
        }
        return setStatus({ current: 'Preise: ' + label + ' (Titelsuche)' })
          .then(function () { return logLine(label + ': Stufe 2 (Titel) "' + qf2.q + '"'); })
          .then(function () { return sleep(700); })
          .then(function () { return suche(qf2); })
          .then(function (r2) {
            logLine(label + ': Stufe 2 -> ' + ((r2 && r2.length) || 0) + ' Treffer');
            return r2;
          });
      })
      /* Findet die plattformeigene Suche nichts, ueber Google nachfassen -
         fuer Otto und Kaufland ist das der einzige belegte Weg: beide sind
         EAN-blind, finden den Artikel ueber Marke+Titel aber sehr wohl. */
      .then(function (res) {
        if (res && res.length) return res;
        if (!GOOGLE_SITE[pid]) {
          logLine(label + ': Stufe 3 entfaellt (kein Google-Site-Muster hinterlegt)');
          return res;
        }
        return sleep(700)
          .then(function () { return resolveViaGoogle(key, pid); })
          .then(function (r3) {
            logLine(label + ': Stufe 3 (Google site:) -> ' + ((r3 && r3.length) || 0) + ' Treffer');
            return r3;
          });
      })
      .then(function (res) {
        if (!res || !res.length) {
          logLine(label + ': AUFGEGEBEN - alle Stufen ohne Treffer');
          fehler.push(label + ': keine Treffer');
          return;
        }
        res.forEach(function (h) { h.gesucht_am = new Date().toISOString(); });
        // Erst belegen, dann sammeln - ungeprueft ist ein Preis wertlos.
        return belegeTreffer(key, res, label).then(function () {
          hits = hits.concat(res);
        });
      })
      .catch(function (e) {
        fehler.push(label + ': ' + ((e && e.message) ? e.message.split('\n')[0] : 'Fehler'));
      })
      .then(function () { return sleep(900); })
      .then(function () { return step(i + 1); });
  };

  /* Erst das Preisportal, dann die Direktsuche - und zwar nur noch fuer die
     Plattformen, die das Portal NICHT geliefert hat. Das spart nicht bloss
     Zeit: die uebrig bleibenden sind gerade die, deren Suche funktioniert. */
  return resolveViaAggregator(key, platforms).then(function (agg) {
    if (!agg.hits.length) return step(0);

    var gefunden = {};
    agg.hits.forEach(function (h) { gefunden[h.plattform] = 1; });
    var offen = platforms.filter(function (pid) {
      var plat = globalThis.LC.PLATFORMS.filter(function (p) { return p.id === pid; })[0];
      return !gefunden[(plat && plat.label) || pid];
    });

    queries[key.ean] = 1;
    // Auch die Portaltreffer muessen belegt werden - der Klick-Link fuehrt auf
    // die echte Produktseite, dort steht die EAN.
    return belegeTreffer(key, agg.hits, agg.quelle).then(function () {
      hits = hits.concat(agg.hits);
      var uebersprungen = platforms.length - offen.length;
      if (uebersprungen > 0) {
        fehler.push(agg.quelle + ': ' + uebersprungen + ' Plattform(en) direkt gefunden');
      }
      platforms = offen;
      return step(0);
    });
  }).then(function () {
    return { hits: hits, fehler: fehler, queries: queries };
  });
}

// ------------------------------------------------------------------ Produktbetreuer-Check

/* AOD-Angebote, Buybox-Belege und Varianten-A+ fuer eine oder mehrere ASINs.
   Laeuft zwingend im Seitenkontext von Amazon (amazon-pro.js braucht DOMParser
   und Amazons eigene Session fuer den AOD-Ajax). */
function runProCheck(asins, origin, opts) {
  origin = origin || 'https://www.amazon.de';
  opts = opts || {};
  logReset('Buybox-Pruefung: ' + (asins || []).join(', '));
  var out = [];
  var errors = [];
  var trefferAlle = [];

  var step = function (i) {
    if (i >= asins.length) return Promise.resolve();
    var asin = asins[i];

    return setStatus({ current: 'ASIN ' + asin, done: i, total: asins.length })
      .then(function () {
        /* Ein Seitenbesuch, beide Ergebnisse: Angebote/Buybox UND die
           Listingdaten (Titel, Marke, EAN) - die brauchen wir gleich als
           Stammsatz fuer die Preisjagd. */
        return inTab(origin + '/dp/' + asin, function () {
          return globalThis.LC.amazonPro.inspect(document, location.href, { variantAplus: true })
            .then(function (pro) {
              return { pro: pro, row: globalThis.LC.extract(document, location.href) };
            });
        });
      })
      .then(function (paket) {
        var res = paket && paket.pro;
        var row = (paket && paket.row) || {};
        if (!res || !res.asin) { errors.push(asin + ': nicht gelesen'); return; }
        var bb = res.buybox || {};
        var angebote = (res.angebote && res.angebote.offers) || [];
        var preise = angebote.map(function (o) { return o.preis; })
                             .filter(function (p) { return p != null; });
        var eintrag = {
          geprueft_am: new Date().toISOString(),
          asin: res.asin,
          buybox: bb.status || '',
          buybox_verkaeufer: bb.verkaeufer || '',
          beleg: 'Kaufblock=' + (bb.hat_kaufblock ? 'ja' : 'nein') +
                 ', Preisblock=' + (bb.hat_preisblock ? 'ja' : 'nein') +
                 ', AlleKaufoptionen=' + (bb.hat_alle_kaufoptionen ? 'ja' : 'nein'),
          aplus: res.aplus || '',
          angebote_anzahl: res.angebote ? res.angebote.anzahl : null,
          angebot_min: preise.length ? Math.min.apply(null, preise) : null,
          angebot_max: preise.length ? Math.max.apply(null, preise) : null,
          anbieter: angebote.map(function (o) {
            return (o.verkaeufer || '?') + (o.preis != null ? ' ' + o.preis.toFixed(2).replace('.', ',') + ' €' : '') +
                   (o.buybox ? ' [Buybox]' : '');
          }).join(' | '),
          varianten: (res.varianten || []).join(', '),
          varianten_ohne_aplus: (res.varianten_aplus || [])
            .filter(function (v) { return v.aplus === 'KEIN A+'; })
            .map(function (v) { return v.asin; }).join(', '),
          fehler: (res.angebote && res.angebote.fehler) || '',
          url: origin + '/dp/' + res.asin
        };

        /* Jetzt die eigentliche Frage: WO ist es guenstiger?
           SCHRITT 1 UND PFLICHT: den Artikel im eigenen Shop finden
           (erfasst -> Kennungen -> Titel-Eskalation). Erst danach wird
           irgendwo anders gesucht - mit den SHOP-Daten. */
        row.produkt_id = row.produkt_id || asin;
        return stammsatz(row).then(function (s) {
          var master = s.master;

          /* Kein Shop-Artikel = KEINE Preissuche. Mit dem generischen
             Amazon-Titel weiterzusuchen liefert nachweislich fremde Artikel
             (Hochbeet, Gartendusche, Sitzgruppe) - ein falscher Preis ist
             schlimmer als gar keiner. */
          if (!master) {
            eintrag.urteil = 'ABBRUCH: Artikel im Deuba-Shop nicht gefunden - ohne Stammsatz keine Preissuche';
            eintrag.stammsatz = 'nicht aufloesbar: ' + (s.versuche.join('; ') || 'keine Kennung am Amazon-Listing');
            out.push(eintrag);
            return;
          }

          var key = globalThis.LC.match.produktSchluessel(master);
          eintrag.stammsatz = s.herkunft +
            (key.ean ? ', EAN ' + key.ean : ', ohne EAN') +
            (key.masse.length ? ', Masse ' + key.masse.join('/') : '');

          // deubaxxl ist jetzt Bezugspunkt, kein Suchziel mehr.
          var plats = (opts.platforms && opts.platforms.length ? opts.platforms
            : globalThis.LC.PLATFORMS.map(function (p) { return p.id; }))
            .filter(function (p) { return p !== 'amazon' && p !== 'deubaxxl'; });

          return sammlePreise(key, plats)
            .then(function (pv) {
              var eigener = eintrag.angebot_min != null ? eintrag.angebot_min : row.preis;
              /* Der eigene Shop-Preis gehoert MIT in den Vergleich: er ist
                 der wahrscheinlichste Preisanker, gegen den Amazon rechnet. */
              var alleHits = s.shopHit ? [s.shopHit].concat(pv.hits) : pv.hits;
              var b = globalThis.LC.match.bewerteAlle(key, alleHits, eigener);

              eintrag.urteil = b.urteil;
              eintrag.kandidaten = b.treffer.length;
              eintrag.bestaetigte = b.treffer.filter(function (h) { return h.match_bestaetigt === 'ja'; }).length;
              if (b.guenstigster) {
                eintrag.guenstigster_preis = b.guenstigster.preis;
                eintrag.guenstigste_plattform = b.guenstigster.plattform;
                eintrag.guenstigster_beleg = b.guenstigster.match_grund;
                eintrag.guenstigster_url = b.guenstigster.url;
              }
              /* Auch die verworfenen Kandidaten mitschreiben - der Nutzer muss
                 sehen KOENNEN, was aussortiert wurde, sonst ist die Pruefung
                 eine Blackbox. */
              eintrag.verworfen = b.treffer.filter(function (h) { return h.match_bestaetigt !== 'ja'; })
                .slice(0, 6)
                .map(function (h) { return h.plattform + ': ' + h.match_grund; }).join(' | ');
              if (pv.fehler.length) {
                eintrag.fehler = [eintrag.fehler, pv.fehler.join('; ')].filter(Boolean).join(' | ');
              }
              trefferAlle = trefferAlle.concat(b.treffer);
              out.push(eintrag);
            });
        });
      })
      .catch(function (e) {
        errors.push(asin + ': ' + ((e && e.message) ? e.message.split('\n')[0] : 'Fehler'));
      })
      .then(function () { return sleep(1200); })
      .then(function () { return step(i + 1); });
  };

  return step(0).then(function () {
    return get(['pro', 'matches']);
  }).then(function (d) {
    var alt = (d.pro || []).filter(function (p) {
      return !out.some(function (o) { return o.asin === p.asin; });
    });
    /* Bewertete Treffer landen zusaetzlich im Blatt "Suchtreffer" - mit
       Begruendung. Dabei die Treffer der GERADE geprueften Suchbegriffe
       ersetzen statt blind anhaengen: ohne das wuchs die Liste bei jedem Lauf
       weiter und zeigte Treffer zu Artikeln, die laengst nicht mehr geprueft
       werden (die Gartenliege). */
    var neueBegriffe = {};
    trefferAlle.forEach(function (t) { if (t.suchbegriff) neueBegriffe[t.suchbegriff] = 1; });
    var alteMatches = (d.matches || []).filter(function (m) {
      return !neueBegriffe[m.suchbegriff];
    });
    return set({ pro: alt.concat(out), matches: alteMatches.concat(trefferAlle) });
  }).then(function () {
    /* Der Status beantwortet die Frage, die der Nutzer wirklich hat:
       nicht "ist die Buybox weg" (das sieht er selbst), sondern "wo ist es
       guenstiger". */
    var res = out.map(function (o) { return o.asin + ': ' + (o.urteil || 'kein Urteil'); }).join(' || ');
    if (!res) res = out.length + ' ASIN(s) geprueft';
    if (errors.length) res += ' | ' + errors.join('; ');
    var unterboten = out.some(function (o) { return /UNTERBOTEN/.test(o.urteil || ''); });
    return setStatus({
      running: false, current: '', done: asins.length, total: asins.length,
      result: res, ok: out.length > 0 && !unterboten
    });
  });
}

// ------------------------------------------------------------------ Nachrichten

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  /* Jeden Auftrag protokollieren, bevor irgendetwas laeuft. Damit ist sofort
     unterscheidbar, ob ein Klick gar nicht ankam oder ob die Suche ankam und
     ergebnislos blieb - vorher sah beides gleich aus. */
  if (msg && msg.type) logLine('Auftrag: ' + msg.type);

  if (msg && msg.type === 'batchSearch') {
    setStatus({ running: true, query: msg.query || msg.ean, qtype: msg.qtype, done: 0,
                total: msg.platforms.length, current: '', result: '', ok: null })
      .then(function () {
        return runBatchSearch(msg.query, msg.qtype, msg.platforms, {
          sourcePreis: msg.sourcePreis, sourceLabel: msg.sourceLabel,
          perPlatform: !!msg.perPlatform, ean: msg.ean, titel: msg.titel, marke: msg.marke,
          mpn: msg.mpn, sku: msg.sku, produktId: msg.produktId
        });
      })
      .catch(function (e) {
        logLine('FEHLER: ' + ((e && e.message) ? e.message.split(String.fromCharCode(10))[0] : e));
        return setStatus({ running: false, result: 'Fehler: ' + e.message, ok: false });
      });
    sendResponse({ started: true });
    return false;
  }

  if (msg && msg.type === 'checkVariants') {
    setStatus({ running: true, done: 0, total: msg.asins.length, current: '', result: '', ok: null })
      .then(function () { return runCheckVariants(msg.asins); })
      .catch(function (e) {
        logLine('FEHLER: ' + ((e && e.message) ? e.message.split(String.fromCharCode(10))[0] : e));
        return setStatus({ running: false, result: 'Fehler: ' + e.message, ok: false });
      });
    sendResponse({ started: true });
    return false;
  }

  if (msg && msg.type === 'deepGrab') {
    runDeepGrab(msg.url)
      .then(function (row) { sendResponse({ ok: true, titel: row.titel }); })
      .catch(function (e) { sendResponse({ ok: false, error: e.message.split('\n')[0] }); });
    return true; // async sendResponse
  }

  if (msg && msg.type === 'keywords') {
    setStatus({ running: true, done: 0, total: (msg.seeds || []).length * (msg.platforms || []).length,
                current: '', result: '', ok: null })
      .then(function () { return runKeywords(msg.seeds, msg.platforms, { tief: !!msg.tief }); })
      .catch(function (e) {
        logLine('FEHLER: ' + ((e && e.message) ? e.message.split(String.fromCharCode(10))[0] : e));
        return setStatus({ running: false, result: 'Fehler: ' + e.message, ok: false });
      });
    sendResponse({ started: true });
    return false;
  }

  if (msg && msg.type === 'proCheck') {
    setStatus({ running: true, done: 0, total: msg.asins.length, current: '', result: '', ok: null })
      .then(function () { return runProCheck(msg.asins, msg.origin); })
      .catch(function (e) {
        logLine('FEHLER: ' + ((e && e.message) ? e.message.split(String.fromCharCode(10))[0] : e));
        return setStatus({ running: false, result: 'Fehler: ' + e.message, ok: false });
      });
    sendResponse({ started: true });
    return false;
  }

  if (msg && msg.type === 'saveRows') {
    saveRows(msg.rows)
      .then(function () { sendResponse({ ok: true }); })
      .catch(function (e) { sendResponse({ ok: false, error: e.message }); });
    return true;
  }
});
