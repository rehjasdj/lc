/* Listing Checker - geteilte Extraktions-Logik.
   Laeuft unveraendert im Browser-Addon (chrome.scripting) und im Node-Script (Playwright).
   Kein Import, keine Dependencies: haengt sich an globalThis.LC. */
(function () {
  'use strict';

  // ---------------------------------------------------------------- Helfer

  var clean = function (s) {
    if (s == null) return '';
    return String(s)
      .replace(/ /g, ' ')
      .replace(/[​-‏‪-‮]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  };

  /* Microdata steckt oft in <meta itemprop="gtin13" content="..."> - solche Knoten
     haben keinen Textinhalt. Deshalb hier zentral abfangen statt an jeder Fundstelle. */
  var txt = function (el) {
    if (!el) return '';
    var tag = el.tagName;
    if (tag === 'META') return clean(el.getAttribute('content'));
    if (tag === 'IMG') return clean(el.getAttribute('alt'));
    if (tag === 'INPUT') return clean(el.value || el.getAttribute('value'));
    /* Otto haengt <style>-Bloecke und das BreadcrumbList-JSON-LD MITTEN in die
       Inhaltscontainer - textContent kippt deren Quelltext sonst ins Feld.
       Live 06.08.2026: verfuegbarkeit = "lieferbar - in 2-3 Werktagen bei dir
       .pdp_usk-info{margin-top:0}", kategorie = rohes JSON. Betrifft JEDES
       Feld JEDER Plattform, das ueber txt()/qt() laeuft - deshalb einmal hier
       zentral statt in dreissig Selektorlisten. */
    var body;
    if (el.querySelector && el.querySelector('style, script')) {
      var kopie = el.cloneNode(true);
      var muell = kopie.querySelectorAll('style, script');
      for (var m = 0; m < muell.length; m++) muell[m].parentNode.removeChild(muell[m]);
      body = clean(kopie.textContent);
    } else {
      body = clean(el.textContent);
    }
    if (!body && el.getAttribute) {
      return clean(el.getAttribute('content') || el.getAttribute('title') || '');
    }
    return body;
  };

  // Erster Selektor aus der Liste, der etwas trifft.
  var q = function (root, sels) {
    for (var i = 0; i < sels.length; i++) {
      try {
        var el = root.querySelector(sels[i]);
        if (el) return el;
      } catch (e) { /* ungueltiger Selektor -> naechster */ }
    }
    return null;
  };

  var qa = function (root, sels) {
    for (var i = 0; i < sels.length; i++) {
      try {
        var els = root.querySelectorAll(sels[i]);
        if (els && els.length) return Array.prototype.slice.call(els);
      } catch (e) { /* weiter */ }
    }
    return [];
  };

  var qt = function (root, sels) { return txt(q(root, sels)); };

  /* Zahlen-Parser. Der kritische Teil: deutsche und englische Schreibweise
     sicher auseinanderhalten, sonst wird aus 1.299,00 EUR schnell 1,29 EUR. */
  var parseNum = function (raw) {
    if (raw == null || raw === '') return null;
    if (typeof raw === 'number') return isFinite(raw) ? raw : null;

    var s = String(raw).replace(/ /g, ' ');
    /* Nur die erste zusammenhaengende Zahl nehmen, nicht global alle Ziffern
       einsammeln: "4,4 von 5 Sternen" ergaebe sonst 4,45 statt 4,4. */
    var m = s.match(/-?\d+(?:[.,\s]\d+)*/);
    if (!m) return null;
    s = m[0].replace(/\s/g, '');

    var neg = s.charAt(0) === '-';
    if (neg) s = s.slice(1);

    var lastComma = s.lastIndexOf(',');
    var lastDot = s.lastIndexOf('.');

    if (lastComma > -1 && lastDot > -1) {
      // Beide vorhanden: der hintere ist das Dezimaltrennzeichen.
      if (lastComma > lastDot) s = s.replace(/\./g, '').replace(',', '.');
      else s = s.replace(/,/g, '');
    } else if (lastComma > -1) {
      // Nur Komma: 1,234,567 ist Tausender, 19,99 ist Dezimal.
      s = /^\d{1,3}(,\d{3})+$/.test(s) ? s.replace(/,/g, '') : s.replace(',', '.');
    } else if (lastDot > -1) {
      // Nur Punkt: 1.299 bzw. 1.234.567 ist im DE-Kontext Tausender.
      s = /^\d{1,3}(\.\d{3})+$/.test(s) ? s.replace(/\./g, '') : s;
    }

    var n = parseFloat(s);
    if (!isFinite(n)) return null;
    return neg ? -n : n;
  };

  var parseInt2 = function (raw) {
    var n = parseNum(raw);
    return n == null ? null : Math.round(n);
  };

  /* Ersten Treffer suchen, der auch wirklich eine Zahl enthaelt - nicht bloss den
     ersten Treffer. Amazon rendert im Preisblock zuerst ein leeres
     <span class="a-offscreen"> </span>; wer da stehenbleibt, liest keinen Preis.
     Gibt Zahl und Rohtext zurueck, damit der Text in die Excel-Spalte kann. */
  var qNum = function (root, sels) {
    for (var i = 0; i < sels.length; i++) {
      var els;
      try { els = root.querySelectorAll(sels[i]); } catch (e) { continue; }
      for (var j = 0; j < els.length; j++) {
        var t = clean(els[j].getAttribute('content') || '') || txt(els[j]);
        var n = parseNum(t);
        if (n != null) return { n: n, text: t };
      }
    }
    return { n: null, text: '' };
  };

  var absUrl = function (u, base) {
    if (!u) return '';
    try { return new URL(u, base).href; } catch (e) { return String(u); }
  };

  var uniq = function (arr) {
    var seen = Object.create(null), out = [];
    for (var i = 0; i < arr.length; i++) {
      var v = arr[i];
      if (v && !seen[v]) { seen[v] = 1; out.push(v); }
    }
    return out;
  };

  var firstVal = function () {
    for (var i = 0; i < arguments.length; i++) {
      var v = arguments[i];
      if (v != null && v !== '' && !(typeof v === 'number' && isNaN(v))) return v;
    }
    return '';
  };

  // ------------------------------------------------------- Plattform-Erkennung

  /* vergleich:true = Fremdplattform, auf der wir NICHT verkaufen. Dort wird nur
     der Preis gejagt (Buybox-Frage: gibt es unseren Artikel woanders guenstiger?),
     keine Listing-Checks. Weitere Vergleichsplattformen = 1 Eintrag hier +
     SEARCH_URLS + RESULT_RULES in search.js + host_permission im Manifest. */
  var PLATFORMS = [
    { id: 'amazon',   label: 'Amazon',   test: /(^|\.)amazon\./i },
    { id: 'ebay',     label: 'eBay',     test: /(^|\.)ebay\./i },
    { id: 'kaufland', label: 'Kaufland', test: /(^|\.)kaufland\./i },
    { id: 'otto',     label: 'Otto',     test: /(^|\.)otto\./i },
    { id: 'bol',      label: 'BOL',      test: /(^|\.)bol\.com$/i },
    { id: 'deubaxxl', label: 'deubaxxl', test: /(^|\.)deubaxxl\./i },
    { id: 'temu',     label: 'Temu',     test: /(^|\.)temu\.com$/i, vergleich: true }
  ];

  var detectPlatform = function (host) {
    for (var i = 0; i < PLATFORMS.length; i++) {
      if (PLATFORMS[i].test.test(host)) return PLATFORMS[i];
    }
    return { id: 'generic', label: host || 'unbekannt', test: null };
  };

  /* Maximale Titellaenge je Marktplatz (fuer die Warnungen).
     Amazon: seit 27.07.2026 nur noch 75 Zeichen fuer den Titel selbst,
     die frueheren 200 gelten nicht mehr. Der Rest wandert in die
     Item Highlights (max. 125), die extract() separat ausweist. */
  var TITEL_MAX = {
    amazon: 75, ebay: 80, kaufland: 150, otto: 150, bol: 150, deubaxxl: 150, generic: 150
  };
  var HIGHLIGHTS_MAX = 125;

  // ------------------------------------------------------------- JSON-LD

  var collectJsonLd = function (doc) {
    var out = [];
    var nodes = doc.querySelectorAll('script[type="application/ld+json"]');
    for (var i = 0; i < nodes.length; i++) {
      var data;
      try {
        data = JSON.parse(clean(nodes[i].textContent));
      } catch (e) { continue; }
      var stack = [data];
      while (stack.length) {
        var cur = stack.pop();
        if (!cur || typeof cur !== 'object') continue;
        if (Array.isArray(cur)) { stack.push.apply(stack, cur); continue; }
        if (cur['@graph']) stack.push.apply(stack, [].concat(cur['@graph']));
        out.push(cur);
      }
    }
    return out;
  };

  var typeOf = function (node) {
    var t = node && node['@type'];
    if (!t) return '';
    return (Array.isArray(t) ? t.join(',') : String(t)).toLowerCase();
  };

  var pickProduct = function (lds) {
    for (var i = 0; i < lds.length; i++) {
      if (/product|offer\b/.test(typeOf(lds[i])) && (lds[i].name || lds[i].offers)) return lds[i];
    }
    return null;
  };

  var ldOffer = function (prod) {
    if (!prod || !prod.offers) return null;
    var o = prod.offers;
    if (Array.isArray(o)) {
      // Guenstigstes echtes Angebot gewinnt.
      var best = null, bestP = Infinity;
      for (var i = 0; i < o.length; i++) {
        var p = parseNum(o[i] && (o[i].price || (o[i].priceSpecification && o[i].priceSpecification.price)));
        if (p != null && p < bestP) { bestP = p; best = o[i]; }
      }
      return best || o[0] || null;
    }
    if (typeOf(o) === 'aggregateoffer' && o.offers) return ldOffer({ offers: o.offers }) || o;
    return o;
  };

  var ldText = function (v) {
    if (v == null) return '';
    if (typeof v === 'string' || typeof v === 'number') return clean(v);
    if (Array.isArray(v)) return clean(v.map(ldText).filter(Boolean).join(' | '));
    if (typeof v === 'object') return clean(v.name || v.value || v['@id'] || '');
    return '';
  };

  var ldImages = function (prod, base) {
    if (!prod || !prod.image) return [];
    var raw = [].concat(prod.image);
    var out = [];
    for (var i = 0; i < raw.length; i++) {
      var v = raw[i];
      var u = typeof v === 'string' ? v : (v && (v.url || v.contentUrl));
      if (u) out.push(absUrl(u, base));
    }
    return uniq(out);
  };

  // ------------------------------------------------------------- Bilder aus DOM

  var BAD_IMG = /sprite|1x1|pixel|transparent|placeholder|blank\.|loading|data:image\/gif/i;

  var imgUrl = function (el, base) {
    var u = el.getAttribute('src') || el.getAttribute('data-src') ||
            el.getAttribute('data-old-hires') || el.getAttribute('data-zoom-image') || '';
    if ((!u || /^data:/.test(u))) {
      var ss = el.getAttribute('srcset') || el.getAttribute('data-srcset') || '';
      if (ss) u = clean(ss.split(',')[0]).split(' ')[0];
    }
    if (!u || /^data:/.test(u) || BAD_IMG.test(u)) return '';
    return absUrl(u, base);
  };

  /* Dieselbe Datei wird in vielen Groessen ausgeliefert (eBay s-l500/s-l1600,
     Amazon ._AC_SX466_). Ohne Normalisierung zaehlt eine Galerie ihre Bilder mehrfach. */
  var normImg = function (u) {
    return String(u).split('?')[0]
      .replace(/\/s-l\d+\.(jpg|jpeg|png|webp)/i, '/s-l.$1')
      .replace(/\._[A-Z0-9_,%-]+_\.(jpg|jpeg|png|webp)/i, '.$1');
  };

  /* rootSels grenzt die Suche auf die Hauptgalerie ein. Noetig bei eBay:
     dieselbe Karussell-Klasse wird auch fuer "Aehnliche Artikel" verwendet,
     ohne Eingrenzung zaehlt man >100 fremde Bilder mit. */
  var domImages = function (doc, sels, base, rootSels) {
    var scope = doc;
    if (rootSels && rootSels.length) {
      var root = q(doc, rootSels);
      if (root) scope = root;
    }
    var els = qa(scope, sels);
    var out = [];
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      var u = el.tagName === 'IMG' ? imgUrl(el, base) : '';
      if (!u && el.querySelector) {
        var inner = el.querySelector('img');
        if (inner) u = imgUrl(inner, base);
      }
      if (u) out.push(normImg(u));
    }
    return uniq(out);
  };

  // ------------------------------------------------------------- Attribute (Key/Value)

  var tableAttrs = function (doc, rowSels) {
    var rows = qa(doc, rowSels);
    var out = [];
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      // div:first/last-child: bol.com (neues Tailwind-Frontend) nutzt Flex-Divs statt Tabellen.
      var k = txt(r.querySelector('th, td:first-child, dt, .properties-label, .a-span3, .ux-labels-values__labels, :scope > div:first-child'));
      var vEl = r.querySelector('td:last-child, dd, .properties-value, .a-span9, .ux-labels-values__values, :scope > div:last-child');
      var v = txt(vEl);
      if (vEl && vEl === r.querySelector('td:first-child')) v = '';
      k = k.replace(/[:\s]+$/, '');
      if (k && v && k !== v) out.push(k + ': ' + v);
    }
    return uniq(out);
  };

  /* Kaufland legt die Produktdaten in Definitionslisten statt Tabellen ab. */
  var dlAttrs = function (doc, sels) {
    var lists = qa(doc, sels);
    var out = [];
    for (var i = 0; i < lists.length; i++) {
      var kids = lists[i].children || [];
      var k = '';
      for (var j = 0; j < kids.length; j++) {
        var tag = kids[j].tagName;
        if (tag === 'DT') {
          k = txt(kids[j]).replace(/[:\s]+$/, '');
        } else if (tag === 'DD' && k) {
          var v = txt(kids[j]);
          if (v && k !== v && k.length < 80) out.push(k + ': ' + v);
          k = '';
        }
      }
    }
    return uniq(out);
  };

  // Amazon "Detailbullets" sind li-Elemente mit "Label: Wert".
  var listAttrs = function (doc, sels) {
    var items = qa(doc, sels);
    var out = [];
    for (var i = 0; i < items.length; i++) {
      var t = txt(items[i]).replace(/\s*:\s*/, ': ');
      if (t && /.+:\s*.+/.test(t) && t.length < 300) out.push(t);
    }
    return uniq(out);
  };

  var findAttr = function (attrs, re) {
    for (var i = 0; i < attrs.length; i++) {
      var m = attrs[i].split(/:\s*/);
      if (m.length >= 2 && re.test(m[0])) return clean(m.slice(1).join(': '));
    }
    return '';
  };

  /* ------------------------------------------------- Produkteigenschaften

     Feature-Bullets und Produkteigenschaften sind ZWEI VERSCHIEDENE DINGE und
     wurden bisher wie eines behandelt: Bullets sind die Marketing-Aufzaehlung
     ueber dem Kauffeld, Eigenschaften die strukturierte Merkmalstabelle
     (Material, Farbe, Abmessungen ...). Beides in einer Textspalte "Attribute"
     zusammenzukippen macht es fuer den Produktbetreuer unbrauchbar: man kann
     nicht filtern, nicht sortieren, nicht zwei Listings gegeneinanderhalten.

     Deshalb bekommen die Merkmale, die bei Garten- und Moebelartikeln wirklich
     gepflegt werden, eigene Spalten. Der Rest bleibt vollstaendig in
     "eigenschaften" erhalten - abgeschnitten wird nichts. */
  var EIGENSCHAFTEN = [
    { key: 'eig_material',      label: 'Material',        re: /^(material|materialzusammensetzung|obermaterial|werkstoff)/i },
    { key: 'eig_farbe',         label: 'Farbe',           re: /^(farbe|colour|color|farbton)/i },
    { key: 'eig_masse',         label: 'Abmessungen',     re: /^(produktabmessungen|artikel ?abmessungen|artikelabmessungen|abmessungen|masse|maße|groesse|größe|breite|laenge)/i },
    { key: 'eig_gewicht',       label: 'Gewicht',         re: /^(gewicht|artikelgewicht|produktgewicht|nettogewicht)/i },
    { key: 'eig_belastbarkeit', label: 'Belastbarkeit',   re: /^(belastbarkeit|maximale? (belastung|tragkraft|gewicht)|tragkraft|traglast)/i },
    { key: 'eig_hersteller',    label: 'Hersteller',      re: /^(hersteller|manufacturer|marke|brand)/i },
    { key: 'eig_modell',        label: 'Modellnummer',    re: /^(modellnummer|modell|artikelnummer|hersteller.?referenz|teilenummer|item model)/i },
    { key: 'eig_lieferumfang',  label: 'Lieferumfang',    re: /^(lieferumfang|enthaltene? (teile|komponenten)|im lieferumfang)/i },
    { key: 'eig_form',          label: 'Form',            re: /^(form|formfaktor|stil|ausfuehrung|ausführung)/i },
    { key: 'eig_montage',       label: 'Montage',         re: /^(montage|aufbau|zusammenbau|montageart)/i }
  ];

  function eigenschaftenAus(attrs) {
    var out = {};
    EIGENSCHAFTEN.forEach(function (e) { out[e.key] = findAttr(attrs, e.re); });
    return out;
  }

  // ------------------------------------------------------------- Keywords

  var STOPWORDS = ('der die das den dem des ein eine einen einem einer eines und oder aber auch mit ohne ' +
    'fuer für von vom zum zur bei aus auf ist sind war sein ihre ihr sich nicht nur noch sehr mehr als ' +
    'wie wenn dann durch über uber unter vor nach ins in im an am zu es sie er wir ihnen man kann koennen ' +
    'können wird werden wurde haben hat hatte dass da so um been the and for with without from this that ' +
    'are was you your our its has have will can all any new inkl inklusive ca bzw usw etc mm cm kg xxl ' +
    'stk stück stueck set farbe größe groesse ideal perfekt einfach hochwertig'
  ).split(/\s+/);

  var stopSet = (function () {
    var s = Object.create(null);
    for (var i = 0; i < STOPWORDS.length; i++) s[STOPWORDS[i]] = 1;
    return s;
  })();

  var topKeywords = function (text, limit) {
    var words = String(text || '')
      .toLowerCase()
      .replace(/[^a-z0-9äöüß\s-]/g, ' ')
      .split(/[\s-]+/);
    var freq = Object.create(null);
    for (var i = 0; i < words.length; i++) {
      var w = words[i];
      if (w.length < 3 || w.length > 28) continue;
      if (stopSet[w]) continue;
      if (/^\d+$/.test(w)) continue;
      freq[w] = (freq[w] || 0) + 1;
    }
    var arr = Object.keys(freq).map(function (w) { return [w, freq[w]]; });
    arr.sort(function (a, b) { return b[1] - a[1] || a[0].localeCompare(b[0]); });
    return arr.slice(0, limit || 15).map(function (p) { return p[0] + ' (' + p[1] + ')'; });
  };

  // ------------------------------------------------------------- Plattform-Regeln
  /* Pro Plattform nur das, was JSON-LD nicht liefert bzw. wo es falsch liegt.
     Jeder Eintrag ist eine Selektor-Liste: der erste Treffer gewinnt. */

  var RULES = {
    amazon: {
      id: function (doc, url) {
        var m = url.match(/\/(?:dp|gp\/product|product)\/([A-Z0-9]{10})/i);
        if (m) return m[1].toUpperCase();
        /* NIE nacktes '[data-asin]': das trifft auf der Produktseite die erste
           Empfehlungskachel (live 06.08.2026, B078Y6TKG4 -> B07B22ZSCP) und auf
           einer SUCHSEITE eine beliebige Trefferkachel - so wird die Suchseite
           selbst zum "Produkt". #ASIN ist der Hidden-Input des DP-Formulars. */
        var el = q(doc, ['#ASIN', 'input#ASIN', '#averageCustomerReviews[data-asin]',
                         '#all-offers-display-params[data-asin]']);
        return el ? clean(el.value || el.getAttribute('data-asin')) : '';
      },
      titel: ['#productTitle', '#title span', 'h1#title'],
      marke: ['#bylineInfo', 'a#bylineInfo', '#brand', 'tr.po-brand .a-span9'],
      /* Live-DOM: .priceToPay .a-offscreen ist befuellt. Im statischen HTML ist er
         leer - dann greift span.priceToPay (a-price-whole+fraction als Text). */
      /* NUR im Buybox-/Apex-Bereich suchen. Der alte letzte Selektor
         '.a-price:not(.a-text-price) .a-offscreen' war ungebunden und griff bei
         UNTERDRUECKTER Buybox in die Empfehlungskarussells: B078Y6TKG4 hat am
         06.08.2026 keinen Buybox-Preis, gemeldet wurde 39,98 € - der Preis einer
         fremden Kachel (a-fixed-left-grid-col > a.a-link-normal). Ohne Buybox ist
         "kein Preis" die richtige Antwort, nicht irgendein Preis. */
      preis: ['#corePriceDisplay_desktop_feature_div span.priceToPay .a-offscreen',
              '#corePrice_feature_div .a-offscreen', 'span.priceToPay',
              '#apex_desktop .a-price:not(.a-text-price) .a-offscreen',
              '#desktop_buybox .a-price:not(.a-text-price) .a-offscreen',
              '#priceblock_ourprice', '#priceblock_dealprice'],
      uvp: ['#corePriceDisplay_desktop_feature_div .basisPrice .a-price.a-text-price .a-offscreen',
            '.basisPrice .a-offscreen', 'span[data-a-strike="true"] .a-offscreen',
            '#listPrice', '.a-text-price .a-offscreen'],
      bullets: ['#feature-bullets ul li:not(.aok-hidden) span.a-list-item',
                '#featurebullets_feature_div li span.a-list-item'],
      beschreibung: ['#productDescription', '#aplus', '#bookDescription_feature_div'],
      bilder: ['#altImages li.item:not(.videoThumbnail) img', '#imageBlock img#landingImage',
               '#main-image-container img'],
      bewertung: ['#acrPopover', 'span[data-hook="rating-out-of-text"]', '.a-icon-alt'],
      bewertungAttr: 'title',
      anzahlBew: ['#acrCustomerReviewText', '[data-hook="total-review-count"]'],
      verkaeufer: ['#sellerProfileTriggerId', '#merchant-info a', '#bylineInfo_feature_div a', '#merchant-info'],
      verfuegbar: ['#availability span', '#availability'],
      // Live geprueft: praezises Lieferdatum steckt in data-csa-c-delivery-time.
      lieferzeit: ['span[data-csa-c-delivery-time]', '#mir-layout-DELIVERY_BLOCK',
                   '#deliveryBlockMessage', '#delivery-block-message'],
      versand: ['#deliveryMessageMirId', '#priceBadging_feature_div'],
      // Live geprueft: die Merkmalstabelle steckt heute in productOverview,
      // die klassischen techSpec-Sektionen sind auf vielen Seiten leer.
      attrTable: ['#productOverview_feature_div tr',
                  '#productDetails_techSpec_section_1 tr', '#productDetails_detailBullets_sections1 tr',
                  '.prodDetTable tr', '#technicalSpecifications_section_1 tr', 'table.a-keyvalue tr'],
      attrList: ['#detailBullets_feature_div li', '#detailBulletsWrapper_feature_div li'],
      kategorie: ['#wayfinding-breadcrumbs_feature_div'],
      varianten: ['#variation_color_name .selection', '#variation_size_name .selection',
                  '#twister .selection', '#twister li[data-asin]']
    },

    ebay: {
      id: function (doc, url) {
        var m = url.match(/\/itm\/(?:[^/]*\/)?(\d{9,15})/);
        return m ? m[1] : qt(doc, ['[data-testid="x-item-id"]', '.ux-textspans--SECONDARY']);
      },
      titel: ['.x-item-title__mainTitle span', 'h1.x-item-title__mainTitle', 'h1 .ux-textspans--BOLD', 'h1#itemTitle'],
      marke: ['.ux-labels-values--brand .ux-labels-values__values'],
      preis: ['.x-price-primary span.ux-textspans', '[itemprop="price"]', '#prcIsum', '#mm-saleDscPrc'],
      uvp: ['.x-price-section span.ux-textspans--STRIKETHROUGH', '.x-price-original .ux-textspans',
            '#orgPrc', '.x-additional-info__original-price'],
      bullets: ['.ux-layout-section--features li', '.d-item-description ul li'],
      beschreibung: ['.d-item-description', '#desc_div', '.x-item-description'],
      bilder: ['.ux-image-carousel-item img', '.ux-image-grid-item img', '#icImg'],
      // Ohne diese Eingrenzung zaehlen die Empfehlungs-Karussells mit (>100 Bilder).
      bilderRoot: ['[data-testid="x-photos"]', '.ux-image-carousel', '.ux-image-grid'],
      bewertung: ['.x-sellercard-atf__data-item .ux-textspans--PSEUDOLINK', '.reviews .ux-summary__start--rating'],
      anzahlBew: ['.ux-summary__count', '.reviews .ux-summary__count'],
      verkaeufer: ['.x-sellercard-atf__about-seller-item--seller-name a span',
                   '.x-sellercard-atf__info__about-seller a span', '.x-sellercard-atf__info__about-seller',
                   '.mbg-nw'],
      verfuegbar: ['#qtyAvailability', '.d-quantity__availability', '.ux-quantity__availability'],
      lieferzeit: ['.ux-labels-values--deliverto .ux-textspans--BOLD', '.d-shipping-minview .ux-textspans--BOLD'],
      versand: ['.ux-labels-values--shipping .ux-labels-values__values', '#fshippingCost'],
      // Live geprueft: Artikelmerkmale (inkl. EAN-Zeile) im x-about-this-item-Modul.
      attrTable: ['[data-testid="x-about-this-item"] .ux-labels-values',
                  '.ux-layout-section--features .ux-labels-values',
                  '.ux-layout-section-evo__row .ux-labels-values',
                  '.itemAttr table tr'],
      attrList: [],
      kategorie: ['.x-breadcrumb', '.breadcrumbs', 'nav[aria-label="Sie sind hier"]', '#vi-VR-brumb-lnkLst'],
      varianten: ['.x-msku .listbox__option .listbox__value', '.x-msku__select-box', 'select.msku-sel']
    },

    /* Live neu bestimmt 06.08.2026 (echtes Chrome per CDP - Playwright-Chromium
       bekommt bei Kaufland 403). Der ganze alte Block stand auf einer
       abgeloesten Seitenversion: "data-e2e" kommt im heutigen DOM KEIN
       einziges Mal mehr vor, der stabile Hook heisst "data-test". Deshalb
       waren 11 von 17 Feldern leer - Marke und EAN nicht "nicht erkannt",
       sondern ohne funktionierenden Selektor.
       Anders als bei Otto gibt es hier KEINE strukturierte Quelle als Rettung:
       kein JSON-LD, kein __NUXT__, kein __INITIAL_STATE__. Einziger
       maschinenlesbarer Anker ist data-loadbee-gtin (die EAN). */
    kaufland: {
      id: function (doc, url) {
        var m = url.match(/\/product\/(\d+)/);
        return m ? m[1] : qt(doc, ['[data-test="product-id"]']);
      },
      titel: ['h1[data-test="product-title"]', 'h1[data-e2e="title"]', 'h1'],
      // Die Marke steht als Link auf die Markenseite (/m/<marke>).
      marke: ['.pdp-attribute-list__value a[href*="kaufland.de/m/"]', 'a[href*="kaufland.de/m/"]',
              '[data-test="brand"]'],
      preis: ['[data-test="product-price"]', '[data-e2e="price"]', '.rd-buybox__price'],
      uvp: ['[data-test="buybox-comparison"] [data-test="strikeout"]',
            '.rd-buybox-comparison__strikeout', '[data-e2e="crossed-price"]'],
      bullets: ['.pdp-product-description__section ul li', '[data-e2e="product-bullet-points"] li'],
      beschreibung: ['#product-description .pdp-product-description__section',
                     '[data-e2e="description"]', '.rd-product-description'],
      bilder: ['[data-test="gallery-desktop"] img[src*="/product-images/"]',
               '[data-e2e="gallery"] img', 'picture img'],
      bilderRoot: ['[data-test="gallery-desktop"]', '[data-e2e="gallery"]'],
      bewertung: ['#teaser-aria-label', '.widget-review-teaser .a11y-hidden',
                  '.widget-review-teaser--full-text'],
      anzahlBew: ['.widget-review-teaser--number-only', '.widget-review-teaser .a11y-hidden'],
      verkaeufer: ['[data-test="seller-name"]', '.pdp-info-card__headline-text'],
      verfuegbar: ['[data-test="atc-button"]', '[data-e2e="availability"]'],
      lieferzeit: ['[data-test="info-card-delivery-delivery-time"]', '[data-e2e="delivery-time"]'],
      versand: ['[data-test="info-card-shipping-return-country-phrase"]', '[data-e2e="shipping-cost"]'],
      /* Kaufland nutzt Definitionslisten, aber dt/dd stecken in einem
         div-Wrapper statt direkt im dl - der generische dl-Leser sieht sie
         deshalb nicht. Die Item-Ebene ist der richtige Einstieg. */
      attrList: ['.pdp-attribute-list__item'],
      attrDl: ['dl.pdp-attribute-list > div', '.rd-attributes dl'],
      attrTable: ['[data-e2e="attributes"] tr', '.rd-attributes tr'],
      kategorie: ['.pdp-breadcrumb', '[data-e2e="breadcrumb"]'],
      varianten: ['.rd-variants', '[data-e2e="variants"]'],
      /* Letzte Rettung fuer die EAN: der Loadbee-Container traegt sie als
         Attribut. textContent ist leer, deshalb per Attribut lesen. */
      eanAttr: { sel: '[data-loadbee-gtin]', attr: 'data-loadbee-gtin' }
    },

    /* Live neu bestimmt 06.08.2026 an den PDPs S0Q5F0BH (Casaria Beistelltisch),
       S0O1G002 (Gardebruk Schubkarre) und S0N0A0LE. Praktisch die komplette alte
       Liste war tot - Otto hat die data-qa-/pdp_-Klassen abgeloest. Deshalb
       fehlten Marke, Bullets und Attribute, und das Listing wurde gelb.
       Wo eine Liste hier LEER ist, ist das Absicht: dann greift der JSON-LD-
       Fallback weiter unten, und der ist stabiler als jede CSS-Klasse - Otto
       liefert Product.name, brand.name und gtin13 sauber aus. */
    otto: {
      id: function (doc, url) {
        // Otto-Artikelnummern sind 8-stellig alphanumerisch (S0Q5F0BH), nicht rein numerisch.
        var m = url.match(/\/p\/[a-z0-9-]*?-([A-Z0-9]{8})\/?(?:[?#]|$)/) ||
                url.match(/\/p\/[^/]*-(\d{6,})/) || url.match(/artikelnummer[=/](\w+)/i);
        return m ? m[1] : qt(doc, ['[data-qa="articleNr"]', '[data-qa="articleNumber"]',
                                   '.pdp_short-info__article-number']);
      },
      titel: [],                                  // -> JSON-LD Product.name
      marke: ['h1 [data-brand-name]', '.pdp_short-info__brand-link', '.pdp_short-info__brand-name'],
      markeAttr: 'data-brand-name',
      preis: ['[data-qa="retailPrice"]', '.pdp_price__retail-price', '.pdp_price__price', '.js_pdp_price'],
      uvp: ['.pdp_price__strike-through-price', '[data-qa="strikePrice"]', '.pdp_price__reference-price'],
      bullets: ['.js_pdp_selling-points li', '.js_pdp_description__expander li',
                '.pdp_details__list li'],
      beschreibung: ['.js_pdp_description__expander', '[data-qa="description"]', '.pdp_details__description'],
      bilder: ['.pdp_gallery img', '[data-qa="gallery"] img', '.js_pdp_gallery img', '.pdp_image img'],
      bewertung: ['[data-qa="rating"]', '.pdp_rating__average', '.rating__average'],
      anzahlBew: ['[data-qa="reviewCount"]', '.pdp_rating__count', '.reviews__count'],
      verkaeufer: ['[data-qa="seller"]', '.pdp_seller__name', '.pdp_short-info__partner'],
      verfuegbar: ['.js_pdp_delivery', '[data-qa="availability"]', '.pdp_delivery__availability'],
      lieferzeit: ['.js_pdp_delivery', '[data-qa="deliveryTime"]', '.pdp_delivery__time'],
      versand: ['.pdp_price__vat-and-shipping-link', '[data-qa="shippingCost"]'],
      attrTable: ['.dv_characteristicsTable tr', '.pdp_details__characteristics-html tr',
                  '.pdp_details__table tr'],
      attrList: ['.js_pdp_selling-points li'],
      kategorie: [],                              // -> JSON-LD BreadcrumbList
      varianten: ['.pdp_variation', '[data-qa="variations"]']
    },

    /* bol.com faehrt zwei Frontends parallel (Wayback-verifiziert):
       alt (bis ~2025): data-test-Attribute, .promo-price, dl.specs__list
       neu (ab ~2026):  Tailwind/React-Router, data-testid-Sections, #buyBlockSlot
       Selektoren decken beide ab; JSON-LD (gtin13, productID, offers) ist die Primaerquelle. */
    bol: {
      id: function (doc, url) {
        var m = url.match(/\/p\/[^/]*\/(\d{7,16})/);
        return m ? m[1] : qt(doc, ['[data-test="product-id"]']);
      },
      titel: ['[data-test="title"]', 'h1 span[data-test="title"]', 'h1 span', '.page-heading', 'h1'],
      marke: ['a[aria-label^="Merk"]', '[data-test="party-name"]', '.buy-block__party a',
              '.pdp-header__meta-item a'],
      preis: ['[data-test="price"]', '#buyBlockSlot span.font-produkt', '.promo-price',
              '.buy-block__price-block .promo-price'],
      uvp: ['[data-test="list-price"]', '#buyBlockTop s', '[data-test="priceBlock"] s',
            '.buy-block__list-price', 'del.h-nowrap'],
      bullets: ['[data-test="description"] ul li', '[data-testid="productdescription"] ul li',
                '.product-description ul li', '.specs__list li'],
      beschreibung: ['[data-test="description"]', '[data-testid="productdescription"]',
                     '.product-description', '.js_description_content'],
      bilder: ['[data-testid="productimage"] img', '[data-test="product-image"] img',
               '.product-images img', '.js_slider img', '.image-slot img'],
      bewertung: ['div[role="img"][aria-label^="Gemiddeld"]', '[data-test="rating-suffix"]',
                  '.pdp-header__rating .rating', '.star-rating'],
      bewertungAttr: 'aria-label',
      anzahlBew: ['[data-test="rating-count"]', '.pdp-header__rating a'],
      verkaeufer: ['#buyBlockSlot span[aria-label^="Verkoop door"]', '[data-test="plazaseller-link"]',
                   '[data-test="seller-name"]', '.buy-block__seller a', '.seller-info__name'],
      verfuegbar: ['[data-test="delivery-highlight"]', '#buyBlockSlot', '.buy-block__delivery',
                   '.product-delivery-highlight'],
      lieferzeit: ['[data-test="delivery-highlight"]', '.buy-block__delivery-time'],
      versand: ['[data-test="shipping-cost"]', '.buy-block__shipping'],
      attrTable: ['[data-testid="productspecification"] [data-testid="data_table"] .flex.py-2',
                  'dl.specs__list .specs__row', '.specs .specs__row',
                  '[data-test="specs"] .specs__row', '.specs__table tr'],
      attrList: [],
      kategorie: ['.breadcrumbs', '[data-test="breadcrumb"]'],
      varianten: ['.pdp-variant-selector', '[data-test="variant"]']
    },

    // Shopware 6 Storefront (per Live-Check auf deubaxxl.de bestaetigt).
    deubaxxl: {
      id: function (doc, url) {
        var m = url.match(/\/(\d{4,})\/?(?:[?#]|$)/);
        if (m) return m[1];
        return qt(doc, ['.product-detail-ordernumber', '[itemprop="sku"]']);
      },
      titel: ['.product-detail-name', 'h1.product-detail-name', 'h1'],
      // Live geprueft: Markenname steckt im title-Attribut des Hersteller-Links.
      marke: ['.product-detail-manufacturer-link', '[itemprop="brand"] [itemprop="name"]',
              '.product-detail-manufacturer img'],
      markeAttr: 'title',
      // Live geprueft: meta[itemprop=price] content = Brutto-Dezimalzahl.
      preis: ['.product-detail-price-container meta[itemprop="price"]', '.product-detail-price',
              '[itemprop="price"]'],
      uvp: ['.product-detail-list-price-wrapper .list-price-price', '.product-detail-list-price',
            '.list-price-price', '.product-detail-price-was'],
      bullets: ['.product-detail-description-text ul li', '.product-detail-description ul li',
                '.product-detail-features li'],
      beschreibung: ['.product-detail-description-text', '.product-detail-description'],
      bilder: ['.cms-element-image-gallery .gallery-slider-item img', '.gallery-slider-image',
               '.product-detail-media img', '.gallery-slider-item img'],
      bewertung: ['[itemprop="ratingValue"]', '.product-detail-review-rating'],
      anzahlBew: ['[itemprop="ratingCount"]', '.product-detail-reviews-link'],
      verkaeufer: [],
      verfuegbar: ['.product-detail-delivery-information', '.delivery-information'],
      lieferzeit: ['.product-detail-delivery-information', '.delivery-information'],
      versand: ['.product-detail-shipping-information', '.product-detail-tax-container'],
      attrTable: ['.product-detail-properties-table tr', '.properties-table tr'],
      attrList: [],
      kategorie: ['.breadcrumb', 'nav[aria-label="breadcrumb"]'],
      varianten: ['.product-detail-configurator', '.product-detail-configurator-group']
    },

    generic: {
      id: function (doc, url) {
        return qt(doc, ['[itemprop="sku"]', '[data-sku]', '.sku', '.product-sku']);
      },
      titel: ['h1[itemprop="name"]', '.product-title', '.product_title', 'h1'],
      marke: ['[itemprop="brand"] [itemprop="name"]', '[itemprop="brand"]', '.product-brand'],
      preis: ['[itemprop="price"]', '.price', '.product-price', '.current-price'],
      uvp: ['[itemprop="highPrice"]', '.list-price', '.old-price', 'del .amount'],
      bullets: ['.product-description ul li', '.product-details ul li', '#description ul li'],
      beschreibung: ['[itemprop="description"]', '.product-description', '#description', '.description'],
      bilder: ['.product-gallery img', '.product-images img', '[itemprop="image"]'],
      bewertung: ['[itemprop="ratingValue"]', '.rating-value'],
      anzahlBew: ['[itemprop="ratingCount"]', '[itemprop="reviewCount"]', '.review-count'],
      verkaeufer: ['[itemprop="seller"]', '.seller-name'],
      verfuegbar: ['[itemprop="availability"]', '.availability', '.stock'],
      lieferzeit: ['.delivery-time', '.shipping-time'],
      versand: ['.shipping-cost', '.delivery-cost'],
      attrTable: ['.product-attributes tr', '.specifications tr', 'table.specs tr', '.properties tr'],
      attrList: ['.product-attributes li', '.specifications li'],
      kategorie: ['.breadcrumb', 'nav[aria-label="breadcrumb"]', '.breadcrumbs'],
      varianten: ['.variations', '.product-options']
    }
  };

  // ------------------------------------------------------------- Feld-Definition
  /* Reihenfolge + Typ der Excel-Spalten. type steuert die Zellformatierung:
     text = immer Text (EAN/ASIN behalten fuehrende Nullen), money/num/int = echte Zahl. */

  var FIELDS = [
    { key: 'erfasst_am',          label: 'Erfasst am',          type: 'datetime' },
    { key: 'plattform',           label: 'Plattform',           type: 'text' },
    { key: 'produkt_id',          label: 'Produkt-ID',          type: 'text' },
    { key: 'ean',                 label: 'EAN/GTIN',            type: 'text' },
    { key: 'sku',                 label: 'SKU',                 type: 'text' },
    { key: 'mpn',                 label: 'MPN',                 type: 'text' },
    { key: 'marke',               label: 'Marke',               type: 'text' },
    { key: 'titel',               label: 'Titel',               type: 'text' },
    { key: 'titel_laenge',        label: 'Titel Zeichen',       type: 'int' },
    // Amazon ab 27.07.2026: Teil hinter " | " im Titelelement
    { key: 'item_highlights',        label: 'Item Highlights',        type: 'text' },
    { key: 'item_highlights_laenge', label: 'Item Highlights Zeichen', type: 'int' },
    { key: 'preis',               label: 'Preis',               type: 'money' },
    { key: 'waehrung',            label: 'Waehrung',            type: 'text' },
    { key: 'uvp',                 label: 'UVP/Streichpreis',    type: 'money' },
    { key: 'rabatt_prozent',      label: 'Rabatt %',            type: 'int' },
    { key: 'preis_text',          label: 'Preis (Rohtext)',     type: 'text' },
    { key: 'versand',             label: 'Versand',             type: 'text' },
    { key: 'verfuegbarkeit',      label: 'Verfuegbarkeit',      type: 'text' },
    { key: 'lieferzeit',          label: 'Lieferzeit',          type: 'text' },
    { key: 'verkaeufer',          label: 'Verkaeufer',          type: 'text' },
    { key: 'bewertung',           label: 'Bewertung',           type: 'num' },
    { key: 'anzahl_bewertungen',  label: 'Anzahl Bewertungen',  type: 'int' },
    { key: 'bullets_anzahl',      label: 'Bullets Anzahl',      type: 'int' },
    { key: 'bullet_1',            label: 'Bullet 1',            type: 'text' },
    { key: 'bullet_2',            label: 'Bullet 2',            type: 'text' },
    { key: 'bullet_3',            label: 'Bullet 3',            type: 'text' },
    { key: 'bullet_4',            label: 'Bullet 4',            type: 'text' },
    { key: 'bullet_5',            label: 'Bullet 5',            type: 'text' },
    { key: 'bullet_6',            label: 'Bullet 6',            type: 'text' },
    { key: 'bullet_7',            label: 'Bullet 7',            type: 'text' },
    { key: 'bullet_8',            label: 'Bullet 8',            type: 'text' },
    { key: 'bullets_weitere',     label: 'Weitere Bullets',     type: 'text' },
    { key: 'beschreibung_laenge', label: 'Beschreibung Zeichen', type: 'int' },
    { key: 'beschreibung',        label: 'Beschreibung',        type: 'text' },
    { key: 'bilder_anzahl',       label: 'Bilder Anzahl',       type: 'int' },
    { key: 'bilder_urls',         label: 'Bilder URLs',         type: 'text' },
    /* Produkteigenschaften = strukturierte Merkmalstabelle. Bewusst NICHT
       "Attribute" (Entwicklerwort) und strikt getrennt von den Bullets, die
       eine Marketing-Aufzaehlung sind - das eine sagt WAS der Artikel ist,
       das andere WIE er beworben wird. */
    { key: 'eigenschaften_anzahl', label: 'Produkteigenschaften Anzahl', type: 'int' },
    { key: 'eig_material',        label: 'Material',            type: 'text' },
    { key: 'eig_farbe',           label: 'Farbe',               type: 'text' },
    { key: 'eig_masse',           label: 'Abmessungen',         type: 'text' },
    { key: 'eig_gewicht',         label: 'Gewicht',             type: 'text' },
    { key: 'eig_belastbarkeit',   label: 'Belastbarkeit',       type: 'text' },
    { key: 'eig_hersteller',      label: 'Hersteller',          type: 'text' },
    { key: 'eig_modell',          label: 'Modellnummer',        type: 'text' },
    { key: 'eig_lieferumfang',    label: 'Lieferumfang',        type: 'text' },
    { key: 'eig_form',            label: 'Form',                type: 'text' },
    { key: 'eig_montage',         label: 'Montage',             type: 'text' },
    { key: 'eigenschaften',       label: 'Produkteigenschaften (alle)', type: 'text' },
    // Altname, damit bestehende Auswertungen nicht brechen.
    { key: 'attribute',           label: 'Attribute (Rohtext)', type: 'text' },
    { key: 'top_keywords',        label: 'Top Keywords',        type: 'text' },
    { key: 'kategorie',           label: 'Kategorie',           type: 'text' },
    { key: 'varianten',           label: 'Varianten',           type: 'text' },
    // Produktbetreuer-Spalten (nur Amazon befuellt sie)
    { key: 'slug',                label: 'URL-Slug',            type: 'text' },
    { key: 'masse_quelle',        label: 'Masse (Tabelle)',     type: 'text' },
    { key: 'aplus',               label: 'A+ Content',          type: 'text' },
    { key: 'buybox',              label: 'Buybox',              type: 'text' },
    { key: 'andere_angebote',     label: 'Andere Angebote',     type: 'text' },
    { key: 'warnungen',           label: 'Warnungen',           type: 'text' },
    { key: 'url',                 label: 'URL',                 type: 'text' }
  ];

  var BULLET_COLS = 8;

  // ------------------------------------------------------------- Hauptfunktion

  function extract(doc, url) {
    doc = doc || document;
    url = url || (doc.location && doc.location.href) || '';

    var host = '';
    try { host = new URL(url).hostname; } catch (e) { host = ''; }

    var plat = detectPlatform(host);
    var R = RULES[plat.id] || RULES.generic;
    var G = RULES.generic;

    var lds = collectJsonLd(doc);
    var prod = pickProduct(lds);
    var offer = ldOffer(prod);

    var meta = function (name) {
      var el = doc.querySelector('meta[property="' + name + '"], meta[name="' + name + '"]');
      return el ? clean(el.getAttribute('content')) : '';
    };

    var sel = function (field) {
      var t = qt(doc, R[field] || []);
      if (!t && G[field]) t = qt(doc, G[field]);
      return t;
    };

    // -- Titel
    var titel = clean(firstVal(
      qt(doc, R.titel || []),
      ldText(prod && prod.name),
      meta('og:title'),
      doc.title
    ));

    /* Amazon zeigt seit dem Titel-Update vom 27.07.2026 "Titel | Item Highlights"
       in EINEM Element (Titel max. 75, Highlights max. 125 Zeichen). Ungetrennt
       misst die Laengenpruefung beides zusammen und schlaegt falschen Alarm.
       Live geprueft: B078Y6TKG4 (49+95), B081PD6D5P (55+117), B0DMPHGPL3 (45+119). */
    var itemHighlights = '';
    if (plat.id === 'amazon') {
      /* Ohne #productTitle ist das KEINE Produktseite (Suchseite, "Weiter
         shoppen"-Wall, Fehlerseite). Dann darf doc.title nicht als Produktname
         durchrutschen: live 06.08.2026 wurde so "Amazon.de : 4250525353426"
         zum Treffer - mit dem erstbesten Kachelpreis der Suchseite. */
      if (!qt(doc, R.titel || [])) titel = '';
      var pipePos = titel.indexOf(' | ');
      if (pipePos > 0) {
        itemHighlights = titel.slice(pipePos + 3).trim();
        titel = titel.slice(0, pipePos).trim();
      }
    }

    // -- Marke
    var markeEl = q(doc, R.marke || []);
    var marke = '';
    if (markeEl) {
      marke = R.markeAttr ? clean(markeEl.getAttribute(R.markeAttr) || markeEl.textContent) : txt(markeEl);
    }
    marke = clean(firstVal(marke, ldText(prod && prod.brand), meta('og:brand'), qt(doc, G.marke)));
    marke = marke.replace(/^(Marke|Brand|Besuche den|Besuchen Sie den)\s*:?\s*/i, '')
                 .replace(/[- ]?Store$/i, '').trim();

    // -- Preise
    var preisHit = qNum(doc, R.preis || []);
    var preisText = preisHit.text;
    var preis = firstVal(
      preisHit.n,
      parseNum(offer && (offer.price || (offer.priceSpecification && offer.priceSpecification.price))),
      parseNum(meta('product:price:amount')),
      qNum(doc, G.preis).n
    );
    if (preis === '') preis = null;
    if (!preisText && preis != null) preisText = String(preis);

    var waehrung = clean(firstVal(
      offer && (offer.priceCurrency || (offer.priceSpecification && offer.priceSpecification.priceCurrency)),
      meta('product:price:currency'),
      /€|EUR/.test(preisText) ? 'EUR' : (/£|GBP/.test(preisText) ? 'GBP' : (/\$|USD/.test(preisText) ? 'USD' : '')),
      'EUR'
    ));

    var uvp = qNum(doc, R.uvp || []).n;
    if (uvp == null) uvp = parseNum(prod && prod.highPrice);
    var rabatt = null;
    if (preis != null && uvp != null && uvp > preis && uvp > 0) {
      rabatt = Math.round((1 - preis / uvp) * 100);
    }

    // -- Bullets
    var bulletEls = qa(doc, R.bullets || []);
    if (!bulletEls.length) bulletEls = qa(doc, G.bullets);
    var bullets = uniq(bulletEls.map(txt).filter(function (t) {
      return t && t.length > 2 && t.length < 1200 && !/^(mehr|weniger|alle anzeigen)$/i.test(t);
    }));

    // -- Beschreibung
    var beschreibung = clean(firstVal(
      qt(doc, R.beschreibung || []),
      ldText(prod && prod.description),
      meta('og:description'),
      meta('description')
    ));

    // -- Bilder
    var bilder = domImages(doc, R.bilder || [], url, R.bilderRoot);
    var ldImg = ldImages(prod, url);
    if (ldImg.length > bilder.length) bilder = ldImg;
    if (!bilder.length) {
      var og = meta('og:image');
      if (og) bilder = [absUrl(og, url)];
    }

    // -- Bewertung
    var bewEl = q(doc, R.bewertung || []);
    var bewRaw = '';
    if (bewEl) {
      bewRaw = clean(
        (R.bewertungAttr && bewEl.getAttribute(R.bewertungAttr)) ||
        bewEl.getAttribute('content') || bewEl.textContent
      );
    }
    var bewertung = firstVal(
      parseNum((bewRaw.match(/([\d.,]+)\s*(?:von|out of|\/)/i) || [])[1]),
      parseNum(bewRaw),
      parseNum(prod && prod.aggregateRating && prod.aggregateRating.ratingValue)
    );
    if (bewertung === '' || (typeof bewertung === 'number' && bewertung > 5.5)) bewertung = null;

    var anzahlBew = firstVal(
      parseInt2(qt(doc, R.anzahlBew || [])),
      parseInt2(prod && prod.aggregateRating && (prod.aggregateRating.ratingCount || prod.aggregateRating.reviewCount))
    );
    if (anzahlBew === '') anzahlBew = null;

    /* -- Attribute
       ALLE konfigurierten Tabellen zusammenfuehren, nicht nur die erste treffende:
       qa() liefert den ersten Selektor mit Treffern, und Amazon verteilt die
       Merkmale auf #productOverview_feature_div (oben) UND .prodDetTable
       (Produktinformationen). Nur letztere fuehrt die EAN als "Global Trade
       Identification Number" - mit First-Match blieb sie unsichtbar und damit
       die EAN leer, was die plattformuebergreifende Suche lahmlegte.
       Live geprueft an B081PD6D5P. */
    /* ALLE Quellen zusammenfuehren, nicht nur die erste, die etwas liefert.
       Vorher standen Liste und Definitionsliste hinter "if (!attribute.length)"
       - lieferte die erste Tabelle auch nur zwei Zeilen, wurden die uebrigen
       Bloecke nie mehr angesehen. Amazon verteilt die Merkmale aber regelmaessig
       auf DREI Stellen: Produktuebersicht (oben), technische Details und
       "weitere Artikeldetails". Das Ergebnis war eine Eigenschaftsliste, die
       zufaellig abbrach - unvollstaendig, ohne dass man es sah. */
    var attribute = [];
    (R.attrTable || []).forEach(function (sel) {
      attribute = attribute.concat(tableAttrs(doc, [sel]));
    });
    attribute = attribute.concat(listAttrs(doc, R.attrList || []));
    attribute = attribute.concat(dlAttrs(doc, R.attrDl || ['dl']));
    if (!attribute.length) attribute = tableAttrs(doc, G.attrTable);
    attribute = uniq(attribute);
    var eig = eigenschaftenAus(attribute);

    // -- Identifikatoren (immer als Text, nie als Zahl)
    var ean = clean(firstVal(
      qt(doc, ['[itemprop="gtin13"]', '[itemprop="gtin"]', '[itemprop="gtin14"]', '[itemprop="gtin8"]']),
      prod && (prod.gtin13 || prod.gtin || prod.gtin14 || prod.gtin8 || prod.ean),
      /* Amazon fuehrt die EAN in der Detailtabelle unter dem Label
         "Global Trade Identification Number" - der Anker ^(ean|gtin) greift
         dort nicht, die EAN blieb deshalb leer. Live geprueft an B081PD6D5P:
         <th>Global Trade Identification Number</th><td>04250525373769</td> */
      findAttr(attribute, /^(ean|gtin|barcode)|global trade/i)
    ));
    /* Plattformen ohne EAN im Text: Kaufland fuehrt sie ausschliesslich als
       Attribut am Loadbee-Container (data-loadbee-gtin) - textContent dort ist
       leer, ein normaler Selektor findet also nichts. */
    if (!ean && R.eanAttr) {
      var eanEl = doc.querySelector(R.eanAttr.sel);
      if (eanEl) ean = clean(eanEl.getAttribute(R.eanAttr.attr) || '');
    }
    ean = (String(ean).match(/\d{8,14}/) || [''])[0];
    // GTIN-14 mit fuehrender Null ist dieselbe Nummer wie die EAN-13.
    if (/^0\d{13}$/.test(ean)) ean = ean.slice(1);

    var sku = clean(firstVal(
      prod && prod.sku,
      /* :not([itemprop]): auf deubaxxl traegt der GTIN-Zwilling dieselbe Klasse
         .product-detail-ordernumber, nur mit itemprop="gtin13". */
      qt(doc, ['[itemprop="sku"]', '.product-detail-ordernumber:not([itemprop])']),
      findAttr(attribute, /^(artikelnummer|sku|art\.?-?nr)/i)
    ));

    var mpn = clean(firstVal(
      prod && prod.mpn,
      qt(doc, ['[itemprop="mpn"]']),
      findAttr(attribute, /^(mpn|herstellernummer|modellnummer)/i)
    ));

    var produktId = '';
    try { produktId = clean(R.id ? R.id(doc, url) : ''); } catch (e) { produktId = ''; }
    if (!produktId) produktId = sku || ean;

    // -- Kategorie / Varianten
    var kategorie = qt(doc, R.kategorie || []);
    if (!kategorie) {
      var bc = null;
      for (var i = 0; i < lds.length; i++) if (typeOf(lds[i]) === 'breadcrumblist') { bc = lds[i]; break; }
      if (bc && bc.itemListElement) {
        kategorie = [].concat(bc.itemListElement).map(function (it) {
          return ldText(it && (it.name || it.item));
        }).filter(Boolean).join(' > ');
      }
    }
    kategorie = clean(kategorie).replace(/\s*[>›»/]\s*/g, ' > ');

    var varianten = clean(qt(doc, R.varianten || [])).slice(0, 500);

    // -- Produktbetreuer-Analyse (Amazon)
    /* Kein A+? Buybox weg? Das sind die Fragen, die ein Produktbetreuer beim
       Aufruf der Seite sofort beantwortet haben will. */
    var aplus = '', buybox = '', andereAngebote = '';
    var slug = '', masseText = '';
    var variantenAsins = [];
    if (plat.id === 'amazon') {
      var aplusEl = doc.querySelector('#aplus_feature_div, #aplus');
      var hatAplus = !!(aplusEl && clean(aplusEl.textContent).length > 40);
      var premium = !!doc.querySelector('#aplus_feature_div .premium-aplus, #aplus_feature_div [class*="premium-aplus"], .aplus-premium');
      var story = !!doc.querySelector('#aplusBrandStory_feature_div .aplus-module, [data-feature-name="aplusBrandStory"] .aplus-module, #aplus-brand-story-cards');
      aplus = hatAplus ? (premium ? 'Premium A+' : 'A+') + (story ? ' + Brand Story' : '') : 'KEIN A+';

      /* Buybox: Kaufen-Button da = gewonnen. Nur "Alle Kaufoptionen ansehen"
         ohne Kaufen-Button = unterdrueckt (Preis-Alarm: irgendwo ist der
         Artikel guenstiger). "Derzeit nicht verfuegbar" = ausverkauft. */
      var kaufenBtn = doc.querySelector('#add-to-cart-button, #buy-now-button, input#add-to-cart-button');
      var alleOptionen = doc.querySelector('#buybox-see-all-buying-choices, a[href*="/gp/offer-listing/"], [data-action="show-all-offers-display"]');
      var availText = qt(doc, ['#availability span', '#availability']) || '';
      if (kaufenBtn) buybox = 'ja';
      else if (/nicht verf|niet beschikbaar|unavailable/i.test(availText)) buybox = 'nicht verfuegbar';
      else if (alleOptionen) buybox = 'UNTERDRUECKT';

      andereAngebote = clean(qt(doc, ['#dynamic-aod-ingress-box', '#aod-ingress-link',
        '#olp_feature_div .olp-text-box', '#olpLinkWidget_feature_div', '#olp-upd-new']));

      // Varianten-ASINs fuer den A+-Quercheck ueber die Geschwister
      var vas = qa(doc, ['#twister li[data-asin]', '#twister_feature_div li[data-asin]',
                         '#inline-twister-expander-content-color_name li[data-asin]']);
      variantenAsins = uniq(vas.map(function (el) {
        return String(el.getAttribute('data-asin') || '').toUpperCase();
      }).filter(function (a) { return /^[A-Z0-9]{10}$/.test(a); }));

      /* RE-Fund: Amazon exponiert keine EAN - aber Deuba pflegt sie als
         "Modellnummer" in der Spec-Tabelle. Nur uebernehmen, wenn der Wert
         auch wirklich wie eine GTIN aussieht. */
      if (!ean) {
        var modell = findAttr(attribute, /^(modellnummer|herstellernummer|artikelnummer|item model number)/i);
        if (/^\d{8}$/.test(modell) || /^\d{12,14}$/.test(modell)) ean = modell;
      }

      /* Live-Befund 06.08.2026 (13 Deuba/Casaria/Gardebruk/Monzana-ASINs):
         GTIN steht nur auf 2/13 Seiten, die DEUBA-Artikelnummer dagegen auf
         8/13 - unter "Artikelnummer/Seriennummer des Herstellers" (102380,
         995167, DB-109614) oder als "Modellnummer" (108753, 106393). Das ist
         nach der EAN der beste Brueckenschluessel in den eigenen Shop.
         "Modellnummer" traegt aber auch Muell ("see title", "Deuba") - was
         nicht wie eine Artikelnummer aussieht, fliegt raus, sonst matcht
         key.mpn="deuba" spaeter JEDE deubaxxl-Seite. */
      var istArtNr = function (v) { return /^(db-)?\d{5,9}$/i.test(String(v).trim()); };
      if (!istArtNr(mpn)) mpn = '';
      if (!sku) {
        var nr = findAttr(attribute, /^(artikelnummer|modellnummer|hersteller.?referenz)/i);
        if (istArtNr(nr)) sku = clean(nr);
      }
      if (!mpn && istArtNr(sku)) mpn = sku;
      // deubaxxl fuehrt die Nummer ohne das Amazon-Praefix "DB-".
      sku = String(sku).replace(/^db-/i, '');
      mpn = String(mpn).replace(/^db-/i, '');

      /* MASSE: die verlaesslichste Quelle auf Amazon ist die Attributtabelle,
         NICHT Titel/Bullets. 13/13 Seiten fuehren eine Dimensionskette unter
         "Produktabmessungen" bzw. "Artikel Abmessungen T x B x H" - aber im
         Format "70T x 70B x 73H cm" bzw. "89L x 89B x 54H cm". Die Buchstaben
         kleben an der Zahl, deshalb erkennt LC.match.masse() sie nicht. Hier
         einmal normalisieren ("70 x 70 x 73 cm"), damit jeder Konsument sie
         sieht. Produkt- und Artikelabmessungen weichen teils voneinander ab
         (B07S5LB814: 195x60x93 vs 155x60x93) - deshalb BEIDE behalten und nie
         als Ausschlusskriterium verwenden. "Verpackungsabmessungen" gibt es
         auf keiner der 13 Seiten. */
      var massQuellen = [];
      attribute.forEach(function (a) {
        if (/^(produktabmessungen|artikel ?abmessungen|artikelabmessungen|grösse|größe|produktabmessungen l x b x h)/i.test(a)) {
          massQuellen.push(a.replace(/^[^:]*:\s*/, ''));
        }
      });
      masseText = uniq(massQuellen.map(function (s) {
        return clean(s).replace(/(\d)\s*[TBHLWDtbhlwd](\s*[x×])/g, '$1$2')
                       .replace(/(\d)\s*[TBHLWDtbhlwd]\s*(cm|mm|m)\b/gi, '$1 $2');
      })).join(' | ');

      /* Der URL-Slug traegt den Produkttyp: 13/13 Seiten (Klapptisch,
         Bauschubkarre, Geraeteschuppen, Aufbewahrungsbox ...) - der auf 75
         Zeichen gestutzte Titel oft nicht. Masse traegt er nur 4/13 und sie
         koennen VERALTET sein (B09PBYS2CP: Slug 181x162x86cm, Titel
         185x165x90cm) - deshalb taugt der Slug fuer Suchbegriffe, NICHT als
         Identitaetsbeweis. Bei Aufruf ueber /dp/ASIN fehlt der Slug in der
         URL, steht aber immer in link[rel=canonical]. */
      var canon = doc.querySelector('link[rel=canonical]');
      var slugRoh = ((canon && canon.getAttribute('href')) || url)
        .match(/amazon\.[a-z.]+\/([^/?#]+)\/(?:dp|gp\/product)\//i);
      if (slugRoh) {
        try { slugRoh = decodeURIComponent(slugRoh[1]); } catch (e) { slugRoh = slugRoh[1]; }
        slug = uniq(slugRoh.split('-').map(clean).filter(function (w) {
          return w && w.length > 2 && !/^(und|mit|fuer|für|der|die|das|von)$/i.test(w);
        })).join(' ');
      }
    }

    // -- Keywords ueber Titel + Bullets + Beschreibung
    var keywords = topKeywords([titel, bullets.join(' '), beschreibung].join(' '), 15);
    var metaKeywords = meta('keywords');

    // -- Checks
    var max = TITEL_MAX[plat.id] || 150;
    var warn = [];
    if (!titel) warn.push('kein Titel gefunden');
    else if (titel.length > max) warn.push('Titel zu lang (' + titel.length + '/' + max + ')');
    else if (titel.length < 30) warn.push('Titel sehr kurz (' + titel.length + ')');
    if (itemHighlights.length > HIGHLIGHTS_MAX) {
      warn.push('Item Highlights zu lang (' + itemHighlights.length + '/' + HIGHLIGHTS_MAX + ')');
    }
    if (preis == null) warn.push('kein Preis gefunden');
    if (bullets.length < 5) warn.push('nur ' + bullets.length + ' Bullets (<5)');
    if (bilder.length < 6) warn.push('nur ' + bilder.length + ' Bilder (<6)');
    if (!beschreibung) warn.push('keine Beschreibung');
    else if (beschreibung.length < 200) warn.push('Beschreibung kurz (' + beschreibung.length + ')');
    if (!ean) warn.push('keine EAN');
    if (!marke) warn.push('keine Marke');
    if (!attribute.length) warn.push('keine Attribute');
    if (plat.id === 'amazon') {
      if (aplus === 'KEIN A+') warn.push('kein A+ Content' +
        (variantenAsins.length ? ' (' + variantenAsins.length + ' Varianten pruefen)' : ''));
      if (buybox === 'UNTERDRUECKT') warn.push('Buybox unterdrueckt - Preisvergleich fahren!');
      if (buybox === 'nicht verfuegbar') warn.push('Listing nicht verfuegbar');
    }

    // -- Zeile bauen
    var row = {
      erfasst_am: new Date(),
      plattform: plat.label,
      produkt_id: produktId,
      ean: ean,
      sku: sku,
      mpn: mpn,
      marke: marke,
      titel: titel,
      titel_laenge: titel.length || null,
      item_highlights: itemHighlights,
      item_highlights_laenge: itemHighlights.length || null,
      preis: preis,
      waehrung: waehrung,
      uvp: uvp,
      rabatt_prozent: rabatt,
      preis_text: preisText,
      versand: sel('versand'),
      // Amazon haengt an #availability inline-JSON an - alles ab "{" abschneiden.
      verfuegbarkeit: clean(firstVal(sel('verfuegbar'),
        ldText(offer && offer.availability).replace(/^https?:\/\/schema\.org\//, ''))).split('{')[0].trim(),
      // Bei manchen Shops zeigen beide Selektoren auf denselben Block -
      // dann lieber eine leere Spalte als zweimal derselbe Text.
      lieferzeit: sel('lieferzeit') === sel('verfuegbar') ? '' : sel('lieferzeit'),
      verkaeufer: clean(firstVal(sel('verkaeufer'), ldText(offer && offer.seller))),
      bewertung: bewertung,
      anzahl_bewertungen: anzahlBew,
      bullets_anzahl: bullets.length || null,
      bullets_weitere: bullets.slice(BULLET_COLS).join(' | '),
      beschreibung_laenge: beschreibung.length || null,
      beschreibung: beschreibung,
      bilder_anzahl: bilder.length || null,
      bilder_urls: bilder.join(' | '),
      eigenschaften_anzahl: attribute.length || null,
      eig_material:      eig.eig_material,
      eig_farbe:         eig.eig_farbe,
      eig_masse:         eig.eig_masse,
      eig_gewicht:       eig.eig_gewicht,
      eig_belastbarkeit: eig.eig_belastbarkeit,
      eig_hersteller:    eig.eig_hersteller,
      eig_modell:        eig.eig_modell,
      eig_lieferumfang:  eig.eig_lieferumfang,
      eig_form:          eig.eig_form,
      eig_montage:       eig.eig_montage,
      eigenschaften: attribute.join(' | '),
      attribute: attribute.join(' | '),
      top_keywords: keywords.join(', ') + (metaKeywords ? '  [meta: ' + metaKeywords + ']' : ''),
      kategorie: kategorie,
      varianten: varianten,
      aplus: aplus,
      // Amazon-Identitaet, die weder im 75-Zeichen-Titel noch in den Bullets steht.
      slug: slug,
      masse_quelle: masseText,
      buybox: buybox,
      andere_angebote: andereAngebote,
      warnungen: warn.join('; '),
      url: url
    };

    for (var b = 0; b < BULLET_COLS; b++) {
      row['bullet_' + (b + 1)] = bullets[b] || '';
    }

    // Nicht in FIELDS (keine Excel-Spalte) - fuers Addon: A+-Quercheck der Geschwister.
    row.varianten_asins = variantenAsins;

    return row;
  }

  // ------------------------------------------------------------- Export

  var LC = {
    extract: extract,
    FIELDS: FIELDS,
    PLATFORMS: PLATFORMS,
    detectPlatform: detectPlatform,
    parseNum: parseNum,      // fuer den Selbsttest
    topKeywords: topKeywords
  };

  if (typeof globalThis !== 'undefined') globalThis.LC = LC;
  else if (typeof window !== 'undefined') window.LC = LC;
  if (typeof module !== 'undefined' && module.exports) module.exports = LC;
})();
