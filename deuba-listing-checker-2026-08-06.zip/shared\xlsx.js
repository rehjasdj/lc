/* Listing Checker - geteilter Excel-Export.
   Erwartet, dass shared/extract.js vorher geladen wurde (globalThis.LC).

   Warum .xlsx und nicht CSV: Zahlen werden als echte Zahlen gespeichert, nicht als Text.
   Excel rendert sie dann automatisch in der Systemsprache - auf deutschem Windows also
   mit Komma als Dezimaltrenner und Punkt als Tausendertrenner. Kein Suchen/Ersetzen,
   kein Import-Assistent, keine kaputten "1.299" die zu 1,299 werden.
   Umgekehrt bleiben EAN/ASIN/SKU explizit Text - sonst frisst Excel fuehrende Nullen
   und macht aus 4260xxxxxxxx eine 4,26E+12. */
(function () {
  'use strict';

  var LC = globalThis.LC || (typeof window !== 'undefined' ? window.LC : null);
  if (!LC) throw new Error('shared/extract.js muss vor shared/xlsx.js geladen werden');

  var SHEET = 'Listings';
  var SHEET_MATCHES = 'Suchtreffer';
  var SHEET_KEYWORDS = 'Keywords';
  var SHEET_MATRIX = 'Keyword-Matrix';
  var SHEET_PRO = 'Buybox & Angebote';

  var KEYWORD_FIELDS = [
    { key: 'gefunden_am', label: 'Gefunden am', type: 'datetime' },
    { key: 'plattform',   label: 'Plattform',   type: 'text' },
    { key: 'seed',        label: 'Seed',        type: 'text' },
    { key: 'keyword',     label: 'Keyword',     type: 'text' },
    { key: 'position',    label: 'Pos.',        type: 'int' }
  ];

  var PRO_FIELDS = [
    { key: 'geprueft_am',          label: 'Geprueft am',            type: 'datetime' },
    { key: 'asin',                 label: 'ASIN',                   type: 'text' },
    // Das Urteil zuerst - es ist der Grund, warum man die Zeile aufmacht.
    { key: 'urteil',               label: 'Urteil',                 type: 'text' },
    { key: 'guenstigster_preis',   label: 'Guenstigster (belegt)',  type: 'money' },
    { key: 'guenstigste_plattform', label: 'wo',                    type: 'text' },
    { key: 'guenstigster_beleg',   label: 'Identitaetsnachweis',    type: 'text' },
    { key: 'guenstigster_url',     label: 'Beleg-URL',              type: 'text' },
    { key: 'bestaetigte',          label: 'belegte Treffer',        type: 'int' },
    { key: 'kandidaten',           label: 'Kandidaten gesamt',      type: 'int' },
    { key: 'verworfen',            label: 'verworfen (Grund)',      type: 'text' },
    { key: 'stammsatz',            label: 'Stammsatz',              type: 'text' },
    { key: 'buybox',               label: 'Buybox',                 type: 'text' },
    { key: 'buybox_verkaeufer',    label: 'Buybox-Verkaeufer',      type: 'text' },
    { key: 'beleg',                label: 'Beleg (Seitenmerkmale)', type: 'text' },
    { key: 'aplus',                label: 'A+ Content',             type: 'text' },
    { key: 'angebote_anzahl',      label: 'Angebote',               type: 'int' },
    { key: 'angebot_min',          label: 'Angebot min',            type: 'money' },
    { key: 'angebot_max',          label: 'Angebot max',            type: 'money' },
    { key: 'anbieter',             label: 'Anbieter',               type: 'text' },
    { key: 'varianten',            label: 'Varianten',              type: 'text' },
    { key: 'varianten_ohne_aplus', label: 'Varianten ohne A+',      type: 'text' },
    { key: 'fehler',               label: 'Fehler',                 type: 'text' },
    { key: 'url',                  label: 'URL',                    type: 'text' }
  ];

  // Excel-Zahlenformate. Die Codes sind immer englisch notiert; Excel zeigt sie
  // anschliessend lokalisiert an (0.00 -> 0,00 auf deutschem System).
  var FMT = {
    money: '#,##0.00 "' + '€' + '"',
    num: '0.0',
    int: '#,##0',
    datetime: 'dd.mm.yyyy hh:mm'
  };

  // Spaltenbreiten in Zeichen. Lange Textfelder werden gedeckelt,
  // sonst ist die Tabelle nicht mehr bedienbar.
  var WIDTH = {
    erfasst_am: 16, plattform: 11, produkt_id: 15, ean: 15, sku: 14, mpn: 14,
    marke: 16, titel: 60, titel_laenge: 8,
    item_highlights: 55, item_highlights_laenge: 10,
    preis: 11, waehrung: 8, uvp: 12,
    rabatt_prozent: 8, preis_text: 14, versand: 20, verfuegbarkeit: 18,
    lieferzeit: 20, verkaeufer: 20, bewertung: 9, anzahl_bewertungen: 10,
    bullets_anzahl: 8, bullets_weitere: 40, beschreibung_laenge: 10,
    beschreibung: 60, bilder_anzahl: 8, bilder_urls: 40, eigenschaften_anzahl: 8,
    eigenschaften: 60, eig_material: 18, eig_farbe: 12, eig_masse: 20, eig_gewicht: 12,
    attribute: 50, top_keywords: 45, kategorie: 30, varianten: 20,
    warnungen: 45, url: 45,
    // Produktbetreuer-Spalten
    aplus: 16, buybox: 14, andere_angebote: 28,
    // Blatt "Suchtreffer"
    gesucht_am: 16, suchbegriff: 16, suchtyp: 7, position: 6,
    gesponsert: 10, treffer_gesamt: 9,
    // Blaetter "Keywords" / "Keyword-Matrix"
    gefunden_am: 16, seed: 20, keyword: 34, treffer_listings: 12, fehlt_bei: 34,
    // Blatt "Buybox & Angebote"
    geprueft_am: 16, asin: 13, buybox_verkaeufer: 20, beleg: 46,
    urteil: 52, guenstigster_preis: 15, guenstigste_plattform: 12,
    guenstigster_beleg: 44, guenstigster_url: 40, bestaetigte: 10,
    kandidaten: 10, verworfen: 52, stammsatz: 34,
    match_stufe: 13, match_bestaetigt: 10, match_grund: 46,
    angebote_anzahl: 9, angebot_min: 12, angebot_max: 12, anbieter: 60,
    varianten_ohne_aplus: 26, fehler: 26
  };

  var isEmpty = function (v) {
    return v == null || v === '' || (typeof v === 'number' && !isFinite(v));
  };

  // Text-Zelle. Fuehrendes = / + / - wuerde Excel als Formel deuten,
  // deshalb bei solchen Werten ein Apostroph-freies Vorzeichen erzwingen.
  var textCell = function (v) {
    var s = String(v);
    if (/^[=+\-@]/.test(s)) s = "'" + s;
    return { t: 's', v: s };
  };

  function makeCell(value, type) {
    if (isEmpty(value)) return null;

    if (type === 'datetime') {
      var d = value instanceof Date ? value : new Date(value);
      if (isNaN(d.getTime())) return textCell(value);
      return { t: 'd', v: d, z: FMT.datetime };
    }

    if (type === 'money' || type === 'num' || type === 'int') {
      var n = typeof value === 'number' ? value : LC.parseNum(value);
      if (n == null || !isFinite(n)) return isEmpty(value) ? null : textCell(value);
      return { t: 'n', v: n, z: FMT[type] };
    }

    return textCell(value);
  }

  function makeSheet(XLSX, fields, rows) {
    var ws = {};

    // Kopfzeile
    for (var c = 0; c < fields.length; c++) {
      ws[XLSX.utils.encode_cell({ c: c, r: 0 })] = { t: 's', v: fields[c].label };
    }

    // Datenzeilen
    for (var r = 0; r < rows.length; r++) {
      for (var c2 = 0; c2 < fields.length; c2++) {
        var f = fields[c2];
        var cell = makeCell(rows[r][f.key], f.type);
        if (cell) ws[XLSX.utils.encode_cell({ c: c2, r: r + 1 })] = cell;
      }
    }

    ws['!ref'] = XLSX.utils.encode_range({
      s: { c: 0, r: 0 }, e: { c: fields.length - 1, r: rows.length }
    });
    ws['!cols'] = fields.map(function (f) { return { wch: WIDTH[f.key] || 16 }; });
    ws['!rows'] = [{ hpt: 22 }];
    ws['!freeze'] = { xSplit: 0, ySplit: 1 };
    ws['!autofilter'] = { ref: ws['!ref'] };
    return ws;
  }

  // Nicht ueberlappende Vorkommen einer Wortfolge zaehlen.
  function countOcc(hay, needle) {
    if (!needle) return 0;
    var n = 0, i = 0;
    while ((i = hay.indexOf(needle, i)) !== -1) { n++; i += needle.length; }
    return n;
  }

  // Der durchsuchbare Text eines Listings: alles, was Amazon indexiert.
  function listingText(r) {
    var parts = [r.titel, r.beschreibung, r.eigenschaften || r.attribute, r.bullets_weitere, r.kategorie];
    for (var i = 1; i <= 8; i++) parts.push(r['bullet_' + i]);
    return ' ' + parts.filter(Boolean).join(' ').toLowerCase().replace(/\s+/g, ' ') + ' ';
  }

  /* Keyword x Listing. Spalte je Listing, Wert = Anzahl der Vorkommen,
     dazu "fehlt bei" - das ist die eigentliche Arbeitsspalte. */
  function buildMatrix(rows, keywords) {
    var listings = (rows || []).filter(function (r) { return r && String(r.titel || '').trim(); });
    var uniq = [], seen = Object.create(null);
    (keywords || []).forEach(function (k) {
      var v = String(k.keyword || '').trim().toLowerCase();
      if (v && !seen[v]) { seen[v] = 1; uniq.push(v); }
    });
    if (!listings.length || !uniq.length) return null;

    var texts = listings.map(listingText);
    var cols = listings.map(function (r, i) {
      return {
        key: 'l' + i,
        label: r.produkt_id || r.sku || r.ean || (r.plattform + ' ' + (i + 1)),
        type: 'int'
      };
    });
    var fields = [{ key: 'keyword', label: 'Keyword', type: 'text' }]
      .concat(cols)
      .concat([
        { key: 'treffer_listings', label: 'in Listings', type: 'int' },
        { key: 'fehlt_bei',        label: 'fehlt bei',   type: 'text' }
      ]);

    var out = uniq.map(function (kw) {
      var row = { keyword: kw }, fehlt = [], n = 0;
      texts.forEach(function (t, i) {
        var c = countOcc(t, kw);
        row['l' + i] = c;
        if (c) n++; else fehlt.push(cols[i].label);
      });
      row.treffer_listings = n;
      row.fehlt_bei = fehlt.join(', ');
      return row;
    });

    // Luecken zuerst: was nirgends vorkommt, ist die interessanteste Zeile.
    out.sort(function (a, b) {
      return a.treffer_listings - b.treffer_listings ||
             (a.keyword < b.keyword ? -1 : a.keyword > b.keyword ? 1 : 0);
    });
    return { fields: fields, rows: out };
  }

  /* Baut die Arbeitsmappe.
     rows    = Listings aus LC.extract()            -> Blatt "Listings"
     matches = Suchtreffer aus LC.search (optional) -> Blatt "Suchtreffer"
     extra   = { keywords, pro } (optional)         -> Keywords, Keyword-Matrix,
                                                       Buybox & Angebote */
  function buildWorkbook(XLSX, rows, matches, extra) {
    extra = extra || {};
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, makeSheet(XLSX, LC.FIELDS, rows || []), SHEET);

    if (matches && matches.length && LC.search) {
      XLSX.utils.book_append_sheet(wb, makeSheet(XLSX, LC.search.MATCH_FIELDS, matches), SHEET_MATCHES);
    }

    if (extra.keywords && extra.keywords.length) {
      XLSX.utils.book_append_sheet(wb, makeSheet(XLSX, KEYWORD_FIELDS, extra.keywords), SHEET_KEYWORDS);
      var m = buildMatrix(rows, extra.keywords);
      if (m) XLSX.utils.book_append_sheet(wb, makeSheet(XLSX, m.fields, m.rows), SHEET_MATRIX);
    }

    if (extra.pro && extra.pro.length) {
      XLSX.utils.book_append_sheet(wb, makeSheet(XLSX, PRO_FIELDS, extra.pro), SHEET_PRO);
    }

    // Fenster fixieren, damit die Kopfzeile beim Scrollen stehen bleibt.
    wb.Workbook = wb.Workbook || {};
    wb.Workbook.Views = [{ RTL: false }];

    return wb;
  }

  // listings_2026-07-30_2015.xlsx
  function defaultFilename(now) {
    var d = now || new Date();
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return 'listings_' + d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) +
           '_' + p(d.getHours()) + p(d.getMinutes()) + '.xlsx';
  }

  LC.buildWorkbook = buildWorkbook;
  LC.buildMatrix = buildMatrix;
  LC.defaultFilename = defaultFilename;
  LC.SHEET = SHEET;
  LC.SHEET_MATCHES = SHEET_MATCHES;
  LC.KEYWORD_FIELDS = KEYWORD_FIELDS;
  LC.PRO_FIELDS = PRO_FIELDS;

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { buildWorkbook: buildWorkbook, defaultFilename: defaultFilename };
  }
})();
