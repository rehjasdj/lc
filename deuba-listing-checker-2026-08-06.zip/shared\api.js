/* Listing Checker - Plattform-Endpoints (RE'te bzw. oeffentliche JSON-Schnittstellen).
   Oberste Schicht des Extraktors: strukturiertes JSON schlaegt DOM-Selektoren,
   weil es Redesigns ueberlebt und keine Hydration braucht.

   Jeder Endpoint hier ist am 30.07.2026 gegen die Live-Seite geprueft worden.
   Ungeprueftes steht bewusst NICHT drin - lieber eine Luecke als eine Luege.

   Laeuft wie die anderen shared-Module im Addon und in Node (fetch ist in beiden global).
   Setzt shared/extract.js voraus (globalThis.LC). */
(function () {
  'use strict';

  var LC = globalThis.LC || (typeof window !== 'undefined' ? window.LC : null);
  if (!LC) throw new Error('shared/extract.js muss vor shared/api.js geladen werden');

  // ---------------------------------------------------------------- Marktplatz-IDs

  // Amazon: Marketplace-ID je Domain, ohne sie liefert completion.amazon.* nichts Sinnvolles.
  var AMAZON_MID = {
    'amazon.de': 'A1PA6795UKMFR9',
    'amazon.com': 'ATVPDKIKX0DER',
    'amazon.co.uk': 'A1F83G8C2ARO7P',
    'amazon.fr': 'A13V1IB3VIYZZH',
    'amazon.it': 'APJ6JRA9NG5V4',
    'amazon.es': 'A1RKKUPIHCS9HS',
    'amazon.nl': 'A1805IZSGTT6HS'
  };

  // eBay: Site-ID je Domain.
  var EBAY_SID = {
    'ebay.de': 77, 'ebay.com': 0, 'ebay.co.uk': 3,
    'ebay.fr': 71, 'ebay.it': 101, 'ebay.es': 186, 'ebay.nl': 146
  };

  // ---------------------------------------------------------------- Suggest / Keywords

  /* Die Autocomplete-Endpoints sind das, was bei Helium "Magnet" heisst: die Plattform
     verraet selbst, wonach gesucht wird - sortiert nach Popularitaet. Kein Auth, kein
     Seller-Konto. Absolute Suchvolumina gibt es damit nicht, die Reihenfolge ist aber
     ein belastbarer Nachfrage-Proxy. */
  var SUGGEST = {
    // GEPRUEFT: HTTP 200, {"suggestions":[{"value":"..."}]}
    amazon: {
      url: function (prefix, opts) {
        var host = (opts && opts.host) || 'amazon.de';
        var mid = AMAZON_MID[host] || AMAZON_MID['amazon.de'];
        return 'https://completion.' + host + '/api/2017/suggestions' +
          '?prefix=' + encodeURIComponent(prefix) +
          '&alias=aps&mid=' + mid +
          '&lop=' + ((opts && opts.lop) || 'de_DE') +
          '&client-info=amazon-search-ui&site-variant=desktop' +
          '&limit=' + ((opts && opts.limit) || 11);
      },
      parse: function (d) {
        return (d && d.suggestions ? d.suggestions : [])
          .filter(function (s) { return s && s.value; })
          .map(function (s) { return s.value; });
      }
    },

    // GEPRUEFT: HTTP 200, OpenSearch-Format ["prefix",["sug1","sug2",...]]
    // Nicht /sch/ajax/autocomplete - das liefert nur den JS-Bundle-Loader.
    ebay: {
      url: function (prefix, opts) {
        var host = (opts && opts.host) || 'ebay.de';
        var sid = EBAY_SID[host];
        if (sid == null) sid = EBAY_SID['ebay.de'];
        return 'https://autosug.ebay.com/autosug' +
          '?kwd=' + encodeURIComponent(prefix) +
          '&sId=' + sid + '&fmt=osr&maxKw=' + ((opts && opts.limit) || 10);
      },
      parse: function (d) {
        return Array.isArray(d) && Array.isArray(d[1]) ? d[1] : [];
      }
    },

    // GEPRUEFT: HTTP 200, {"original":{...},"keywords":["..."]}
    // Parameter heisst q - userInput/searchTerm quittiert Otto mit 502.
    otto: {
      url: function (prefix) {
        return 'https://www.otto.de/san-squirrel-suggest-api/completion' +
          '?q=' + encodeURIComponent(prefix);
      },
      parse: function (d) {
        var kw = d && d.keywords ? d.keywords : [];
        return kw.map(function (k) { return typeof k === 'string' ? k : (k && (k.term || k.visual)); })
                 .filter(Boolean);
      }
    }

    /* --- Abgeklopft, aber bewusst NICHT als Fetch-Endpoint eingebaut ---

       kaufland: Endpoints existieren und sind per Traffic-Mitschnitt belegt:
         GET /api/search/v1/auto-suggestions?searchValue={q}
         GET /api/search/v1/search-trends?limit=10
       Header der echten Requests sind unauffaellig (referer, accept:
       application/json,text/plain,*​/*, accept-language: de-DE) - trotzdem
       antwortet die API 403, sobald man sie per fetch() ruft, selbst aus dem
       Seitenkontext mit gueltiger Session und identischen Headern. Die Requests
       der Seite selbst gehen gleichzeitig durch. Kaufland bewertet also die
       Herkunft des Requests, nicht seine Form.
       Konsequenz: fuer Kaufland die echte UI bedienen (ins Suchfeld tippen und
       die Vorschlaege aus dem DOM lesen) statt die API aufzurufen. Das kann das
       Addon im echten Tab von Haus aus - dieses Modul kann es nicht.

       bol: liefert 403 auch mit echtem Chrome im sichtbaren Modus, schon beim
       Laden der Startseite. Kein Pfad-Problem, sondern Bot-Schutz vor allem
       anderen. Ebenfalls nur ueber eine echte Nutzersession erreichbar.

       amazon reviews: POST /portal/customer-reviews/ajax/lazy-widgets/stream
         ?asin={asin}&csrf={token}   body: th=1&{hash}=C&scope=reviewsAjax0
       Der CSRF-Token steht in der Produktseite - also nur mit vorherigem
       Seitenabruf nutzbar, nicht standalone.

       deubaxxl: Shopware Store API antwortet 401 "sw-access-key is required".
       Ohne Key aus dem Admin kein Zugang. */
  };

  /* Nur zur Dokumentation und fuer den Addon-Pfad - hier bewusst ohne fetch-Wrapper,
     siehe Begruendung oben. */
  var BROWSER_ONLY = {
    kaufland: {
      suggest: 'https://www.kaufland.de/api/search/v1/auto-suggestions?searchValue={q}',
      trends: 'https://www.kaufland.de/api/search/v1/search-trends?limit=10'
    },
    amazon: {
      reviews: 'https://www.amazon.de/portal/customer-reviews/ajax/lazy-widgets/stream?asin={asin}&csrf={csrf}'
    }
  };

  // ---------------------------------------------------------------- Abruf

  function fetchJson(url, timeoutMs) {
    var ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = ctl ? setTimeout(function () { ctl.abort(); }, timeoutMs || 12000) : null;

    return fetch(url, {
      signal: ctl ? ctl.signal : undefined,
      credentials: 'omit',
      headers: { 'Accept': 'application/json,text/javascript,*/*' }
    }).then(function (res) {
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.text();
    }).then(function (body) {
      /* eBay liefert bei fmt=json ein JSONP-Paket. fmt=osr nutzen wir zwar,
         aber der Guard kostet nichts und faengt Formatwechsel ab. */
      var t = body.replace(/^\/\*\*\/[\w.$]+\(/, '').replace(/\);?\s*$/, '');
      return JSON.parse(t);
    }).finally(function () {
      if (timer) clearTimeout(timer);
    });
  }

  /* Keyword-Vorschlaege einer Plattform. Liefert [] statt zu werfen, damit ein
     blockierter Marktplatz nicht den ganzen Durchlauf killt. */
  function suggest(platformId, prefix, opts) {
    var cfg = SUGGEST[platformId];
    if (!cfg || !prefix) return Promise.resolve([]);
    return fetchJson(cfg.url(prefix, opts), opts && opts.timeout)
      .then(function (d) { return cfg.parse(d) || []; })
      .catch(function () { return []; });
  }

  function hasSuggest(platformId) { return !!SUGGEST[platformId]; }

  /* Keyword-Ernte: Seed um a-z und 0-9 erweitern und einsammeln. Das ist die
     Standardmethode, um aus einer Autocomplete-Box einen Keyword-Pool zu machen.
     Sequenziell mit Pause - parallel sieht nach Bot aus und bringt hier nichts. */
  function expand(platformId, seed, opts) {
    opts = opts || {};
    var alphabet = opts.alphabet || 'abcdefghijklmnopqrstuvwxyz'.split('');
    var delay = opts.delay == null ? 350 : opts.delay;
    var out = Object.create(null);
    var order = [];

    var add = function (list) {
      list.forEach(function (k) {
        var v = String(k).trim().toLowerCase();
        if (v && !out[v]) { out[v] = 1; order.push(v); }
      });
    };

    var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };

    return suggest(platformId, seed, opts).then(function (base) {
      add(base);
      var step = function (i) {
        if (i >= alphabet.length) return Promise.resolve();
        if (opts.onProgress) opts.onProgress(i + 1, alphabet.length, order.length);
        return suggest(platformId, seed + ' ' + alphabet[i], opts)
          .then(add)
          .then(function () { return sleep(delay); })
          .then(function () { return step(i + 1); });
      };
      return step(0);
    }).then(function () { return order; });
  }

  LC.api = {
    suggest: suggest,
    expand: expand,
    hasSuggest: hasSuggest,
    fetchJson: fetchJson,
    SUGGEST: SUGGEST,
    BROWSER_ONLY: BROWSER_ONLY,
    AMAZON_MID: AMAZON_MID,
    EBAY_SID: EBAY_SID
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = LC.api;
})();
